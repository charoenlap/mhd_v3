-- phpMyAdmin SQL Dump
-- version 5.0.3
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Feb 09, 2021 at 06:44 AM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.2.34

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `fsoftpro_mhd`
--

-- --------------------------------------------------------

--
-- Table structure for table `md_tools`
--

CREATE TABLE `md_tools` (
  `id` int(11) NOT NULL,
  `tool_id` varchar(11) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tool_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `test_id` int(11) DEFAULT NULL,
  `other` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tool_section` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `method` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `md_tools`
--

INSERT INTO `md_tools` (`id`, `tool_id`, `tool_name`, `test_id`, `other`, `tool_section`, `method`) VALUES
(1, '18', 'Sysmex K series, XP series', 15, NULL, '18', NULL),
(2, '15', 'XS series', 15, NULL, '15', NULL),
(3, '17', 'XE series', 15, NULL, '17', NULL),
(510, '14', 'XN series', 15, NULL, '14', NULL),
(5, '1', 'BC 3000 series', 15, NULL, '31', NULL),
(6, '2', 'BC 5000 series', 15, NULL, '32', NULL),
(503, '16', 'XT series', 15, NULL, '16', NULL),
(9, '3', 'BC 6000 series', 15, NULL, '33', NULL),
(10, '7', 'LH', 15, NULL, '27', NULL),
(11, '6', 'DxH 500 / 520', 15, NULL, '26', NULL),
(507, '23', 'Ac.T 5 series', 15, NULL, '23', NULL),
(16, '22', 'Advia 120/2120', 15, NULL, '67', NULL),
(17, '11', 'Quintus', 15, NULL, '62', NULL),
(505, '8', 'MEK', 15, NULL, '60', NULL),
(20, '4', 'BF 6800', 15, NULL, '4', NULL),
(506, '13', 'XN-L series', 15, NULL, '13', NULL),
(22, '19', 'Swelab', 15, NULL, '64', NULL),
(504, '12', 'URIT', 15, NULL, '63', NULL),
(24, '20', 'Hycel', 15, NULL, '65', NULL),
(508, '54', 'NM-BAPTA', 1, NULL, '1', NULL),
(26, '26', 'VDRL', 6, NULL, 'NTP', NULL),
(27, '27', 'RPR', 6, NULL, 'NTP', NULL),
(28, '28', 'Unheated VDLR', 6, NULL, 'NTP', NULL),
(29, '29', 'Other', 6, '1', 'NTP', NULL),
(30, '30', 'TPHA', 6, NULL, 'TP', NULL),
(31, '31', 'FTA-ABS', 6, NULL, 'TP', NULL),
(32, '32', 'TPPA', 6, NULL, 'TP', NULL),
(33, '33', 'Immunochromatography', 6, NULL, 'TP', NULL),
(34, '34', 'CMIA', 6, NULL, 'TP', NULL),
(35, '35', 'ECLIA', 6, NULL, 'TP', NULL),
(36, '40', 'Other', 6, '1', 'TP', NULL),
(37, '37', 'Reactive', 6, NULL, 'Qualitative', NULL),
(38, '38', 'Weakly Reactive', 6, NULL, 'Qualitative', NULL),
(39, '39', 'Non-reactive', 6, NULL, 'Qualitative', NULL),
(40, '01', 'Maglumi Series /800', 5, NULL, NULL, 'CLIA'),
(41, '02', 'Abbott, Architect Series /Armity', 5, NULL, NULL, 'CMIA'),
(42, '03', 'Siemens, Advia Centaur CP  [  ] XP', 5, NULL, NULL, 'ICMA'),
(43, '04', 'Beckman, Access ; Unicel DXi', 5, NULL, NULL, 'ICMA'),
(44, '05', 'BioMerieux, VIDAS ; Minividas', 5, NULL, NULL, 'ELFA'),
(45, '06', 'Tosoh AIA Series', 5, NULL, NULL, 'FEIA'),
(46, '07', 'Johnson, Vitros ECi 3600, 5600', 5, NULL, NULL, 'ICMA'),
(47, '08', 'Roche; Cobas Series, Modular, Elecsys series', 5, NULL, NULL, 'ECLIA'),
(48, '09', 'Hybiome AE-180', 5, NULL, NULL, 'CLIA'),
(49, '10', 'Mindray CL 6000i,2000i / 1000i', 5, NULL, NULL, 'ICMA'),
(50, '11', 'Liaison Series ;', 5, NULL, NULL, 'CLIA'),
(51, '12', 'Immulite, LKB1277, DPC, Others', 5, NULL, NULL, 'IEMA, ICMA, IRMA, CLLA, ECLIA'),
(52, '01', 'Maglumi Series 800', 3, NULL, NULL, 'CLIA'),
(53, '02', 'Abbott Architect Series; Armity', 3, NULL, NULL, 'CLIA'),
(54, '03', 'Advia centaur CP; XP', 3, NULL, NULL, 'ECLIA'),
(55, '04', 'Beckman, access series DXi', 3, NULL, NULL, 'CLIA'),
(56, '05', 'Bio merieux; Vidas; Mini Vidas', 3, NULL, NULL, 'ELFA'),
(57, '06', 'Tosoh AIA series', 3, NULL, NULL, 'CLIA'),
(58, '07', 'Johnson vitros Eci. 3600, 5600', 3, NULL, NULL, 'CMIA'),
(59, '08', 'Roche; Cobas series; Elecsys series; Modular', 3, NULL, NULL, 'FEIA'),
(60, '09', 'Hybiome AE-180', 3, NULL, NULL, 'CLIA'),
(61, '10', 'Mindray CL 1000i; 2000i; 6000', 3, NULL, NULL, 'CLIA'),
(62, '11', 'Liaison; Liaison XL', 3, NULL, NULL, 'CLIA'),
(63, '12', 'Sysmex HISCL-800', 3, '1', NULL, ''),
(65, '65', 'No AFB Observed', 13, NULL, '1', ''),
(66, '66', '1-9 AFB per 100 fields', 13, NULL, '1', ''),
(67, '67', 'AFB 1+ (10-99 AFB/100 fields)', 13, NULL, '1', ''),
(68, '68', 'AFB 2+ (1-10 AFB per field in 50 fields', 13, '1', '1', ''),
(69, '69', 'AFB 3+ (more than 10 AFB per field in 20 fields)', 13, NULL, '1', ''),
(70, '70', 'Conventional tests', 13, NULL, '2', ''),
(71, '71', 'VITEK', 13, NULL, '2', ''),
(72, '72', 'VITEK 2', 13, NULL, '2', ''),
(73, '73', 'MicroScan', 13, NULL, '2', ''),
(74, '74', 'MALDI-TOF (bioMerieux)', 13, NULL, '2', ''),
(75, '75', 'MALDI-TOF (Bruker)', 13, NULL, '2', ''),
(76, '76', 'Molecular techniques', 13, NULL, '2', ''),
(77, '77', 'API (bioMerieux)', 13, NULL, '2', ''),
(78, '78', 'Rapid Test NF PLUS', 13, NULL, '2', ''),
(79, '79', 'Phoenix M50', 13, NULL, '2', ''),
(80, '80', 'Other…', 13, '1', '2', ''),
(81, '81', 'Question Type', 13, NULL, '3', ''),
(82, '82', 'Disc diffusion', 13, NULL, '3', ''),
(83, '83', 'VITEK', 13, NULL, '3', ''),
(84, '84', 'VITEK 2', 13, NULL, '3', ''),
(85, '85', 'Phoenix M50', 13, NULL, '3', ''),
(86, '86', 'MicroScan', 13, NULL, '3', ''),
(87, '87', 'Sensititre', 13, NULL, '3', ''),
(88, '88', 'Other…', 13, '1', '3', ''),
(217, '1', 'Automation', 7, 'auto', '1', NULL),
(216, '2', 'Immunochromatography', 7, NULL, '1', NULL),
(215, '3', 'Other', 7, 'other', '1', NULL),
(214, '1', 'EIA / ELISA', 7, NULL, 'auto', NULL),
(213, '2', 'CLIA', 7, NULL, 'auto', NULL),
(212, '3', 'CMIA', 7, NULL, 'auto', NULL),
(211, '4', 'E-CLIA', 7, NULL, 'auto', NULL),
(273, '1', 'Amikacin', 26, NULL, '2', NULL),
(272, '2', 'Amoxicillin-calvulonate', 26, NULL, '2', NULL),
(271, '3', 'Ampicillin', 26, NULL, '2', NULL),
(270, '4', 'Ampicillin-sulbactam', 26, NULL, '2', NULL),
(269, '5', 'Azithromycin', 26, NULL, '2', NULL),
(268, '6', 'Aztreonam', 26, NULL, '2', NULL),
(267, '7', 'Cefazolin', 26, NULL, '2', NULL),
(266, '8', 'Cefepime', 26, NULL, '2', NULL),
(265, '9', 'Cefotaxime', 26, NULL, '2', NULL),
(264, '10', 'Cefotetan', 26, NULL, '2', NULL),
(263, '11', 'Cefoxtin', 26, NULL, '2', NULL),
(262, '12', 'Ceftaroline', 26, NULL, '2', NULL),
(261, '13', 'Ceftazidime', 26, NULL, '2', NULL),
(260, '14', 'Ceftolozane-lazobactam', 26, NULL, '2', NULL),
(259, '15', 'Ceftriaxone', 26, NULL, '2', NULL),
(258, '16', 'Cefuroxime', 26, NULL, '2', NULL),
(257, '17', 'Chloramphenicol', 26, NULL, '2', NULL),
(256, '18', 'Ciprofloxacin', 26, NULL, '2', NULL),
(255, '19', 'Clarithomycin', 26, NULL, '2', NULL),
(254, '20', 'Clindamycin', 26, NULL, '2', NULL),
(159, '1', 'Amoeba trophozoite ', 2, NULL, NULL, NULL),
(160, '2', 'Ascaris lumbricoides egg ', 2, NULL, NULL, NULL),
(161, '3', 'Balantidium coli cyst ', 2, NULL, NULL, NULL),
(162, '4', 'Balantidium coli trophozoite ', 2, NULL, NULL, NULL),
(163, '5', 'Blastocystis hominis ', 2, NULL, NULL, NULL),
(164, '6', 'Capillaria philippinensis adult ', 2, NULL, NULL, NULL),
(165, '7', 'Capillaria philippinensis egg ', 2, NULL, NULL, NULL),
(166, '8', 'Capillaria philippinensis larva ', 2, NULL, NULL, NULL),
(167, '9', 'Chilomastix mesnili cyst ', 2, NULL, NULL, NULL),
(168, '10', 'Chilomastix mesnili trophozoite ', 2, NULL, NULL, NULL),
(169, '11', 'Cyclospora oocyst ', 2, NULL, NULL, NULL),
(170, '12', 'Diphyllobrothium latum egg ', 2, NULL, NULL, NULL),
(171, '13', 'Dipylidium caninum egg ', 2, NULL, NULL, NULL),
(172, '14', 'Endolimax nana cyst ', 2, NULL, NULL, NULL),
(173, '15', 'Entamoeba coli cyst ', 2, NULL, NULL, NULL),
(174, '16', 'Entamoeba histolytica cyst ', 2, NULL, NULL, NULL),
(175, '17', 'Enterobious vermicularis egg ', 2, NULL, NULL, NULL),
(176, '18', 'Fasciolopsis/Fasciola/Echinostoma egg ', 2, NULL, NULL, NULL),
(177, '19', 'Giardia lamblia cyst ', 2, NULL, NULL, NULL),
(178, '20', 'Giardia lamblia trophozoite ', 2, NULL, NULL, NULL),
(179, '21', 'Hookworm egg ', 2, NULL, NULL, NULL),
(180, '22', 'Hookworm filariform larva ', 2, NULL, NULL, NULL),
(181, '23', 'Hookworm rhabditiform larva ', 2, NULL, NULL, NULL),
(182, '24', 'Hymenolepis diminuta egg ', 2, NULL, NULL, NULL),
(183, '25', 'Hymenolepis nana egg ', 2, NULL, NULL, NULL),
(184, '26', 'Iodamoeba butschlii cyst ', 2, NULL, NULL, NULL),
(185, '27', 'Isospora belli oocyst ', 2, NULL, NULL, NULL),
(186, '28', 'Opisthorchis/MIF egg ', 2, NULL, NULL, NULL),
(187, '29', 'Paragonimus heterotremus egg ', 2, NULL, NULL, NULL),
(188, '30', 'Paragonimus westermani egg ', 2, NULL, NULL, NULL),
(189, '31', 'Plasmodium falciparum asexual form ', 2, NULL, NULL, NULL),
(190, '32', 'Plasmodium falciparum gametocyte ', 2, NULL, NULL, NULL),
(191, '33', 'Plasmodium malariae asexual form ', 2, NULL, NULL, NULL),
(192, '34', 'Plasmodium malariae gametocyte ', 2, NULL, NULL, NULL),
(193, '35', 'Plasmodium ovale asexual form ', 2, NULL, NULL, NULL),
(194, '36', 'Plasmodium ovale gametocyte ', 2, NULL, NULL, NULL),
(195, '37', 'Plasmodium vivax asexual form ', 2, NULL, NULL, NULL),
(196, '38', 'Plasmodium vivax gametocyte ', 2, NULL, NULL, NULL),
(197, '39', 'Sarcocystis hominis sporocyst/oocyst ', 2, NULL, NULL, NULL),
(198, '40', 'Schistosoma haematobium egg ', 2, NULL, NULL, NULL),
(199, '41', 'Schistosoma japonicum egg ', 2, NULL, NULL, NULL),
(200, '42', 'Schistosoma mansoni egg ', 2, NULL, NULL, NULL),
(201, '43', 'Schistosoma mekongi egg ', 2, NULL, NULL, NULL),
(202, '44', 'Strongyloides stercoralis female ', 2, NULL, NULL, NULL),
(203, '45', 'Strongyloides stercoralis filariform larva ', 2, NULL, NULL, NULL),
(204, '46', 'Strongyloides stercoralis male ', 2, NULL, NULL, NULL),
(205, '47', 'Strongyloides stercoralis rhabditiform larva ', 2, NULL, NULL, NULL),
(206, '48', 'Taenia solium/Taenia saginata egg ', 2, NULL, NULL, NULL),
(207, '49', 'Trichomonas hominis trophozoite ', 2, NULL, NULL, NULL),
(208, '50', 'Trichuris trichiura egg ', 2, NULL, NULL, NULL),
(209, '51', 'Not Found ', 2, NULL, NULL, NULL),
(218, '5', 'FEIA', 7, NULL, 'auto', NULL),
(219, '1', 'Positive', 7, NULL, '2', NULL),
(220, '2', 'Weakly Positive', 7, NULL, '2', NULL),
(221, '3', 'Negative', 7, NULL, '2', NULL),
(278, '21', 'Colistin', 26, NULL, '2', NULL),
(225, '32', 'Jaffe Kinetic', 1, NULL, '1', NULL),
(226, '33', 'Jendrassik - Grof ', 1, NULL, '1', NULL),
(227, '44', 'PNP.AMP buff; AACC', 1, NULL, '1', NULL),
(228, '45', 'PNP.DEA buff;  DGKC', 1, NULL, '1', NULL),
(277, '22', 'Daptomycin', 26, NULL, '2', NULL),
(275, '23', 'Doripenem', 26, NULL, '2', NULL),
(229, '46', 'Reflotron', 1, NULL, '1', NULL),
(230, '47', 'SSCC', 1, NULL, '1', NULL),
(231, '48', 'Vitros', 1, NULL, '1', NULL),
(232, '49', 'Vitros; ISE', 1, NULL, '1', NULL),
(293, '24', 'Doxycycline', 26, NULL, '2', NULL),
(292, '25', 'Ertapenem', 26, NULL, '2', NULL),
(291, '26', 'Erythomycin', 26, NULL, '2', NULL),
(274, '27', 'Fosfomycin', 26, NULL, '2', NULL),
(253, '28', 'Gentamycin', 26, NULL, '2', NULL),
(290, '29', 'Hight-level Gentamycin', 26, NULL, '2', NULL),
(289, '30', 'Hight-level Streptomycin ', 26, NULL, '2', NULL),
(288, '31', 'Imipenem', 26, NULL, '2', NULL),
(287, '32', 'Levofloxacin', 26, NULL, '2', NULL),
(286, '33', 'Linezolid', 26, NULL, '2', NULL),
(285, '34', 'Meropenem', 26, NULL, '2', NULL),
(284, '35', 'Minocycline', 26, NULL, '2', NULL),
(283, '36', 'Moxifloxacin', 26, NULL, '2', NULL),
(282, '37', 'Netilmicin', 26, NULL, '2', NULL),
(281, '38', 'Nitrofurantoin', 26, NULL, '2', NULL),
(280, '39', 'Oritavancin', 26, NULL, '2', NULL),
(279, '40', 'Oxacillin', 26, NULL, '2', NULL),
(276, '41', 'Penicillin', 26, NULL, '2', NULL),
(294, '42', 'Rifampin', 26, NULL, '2', NULL),
(295, '43', 'Piperracillin-tazobactam', 26, NULL, '2', NULL),
(296, '44', 'Sulfisoxazole', 26, NULL, '2', NULL),
(297, '45', 'Tedizolid', 26, NULL, '2', NULL),
(298, '46', 'Telavancin', 26, NULL, '2', NULL),
(299, '47', 'Tetracycline', 26, NULL, '2', NULL),
(300, '48', 'Tobramycin', 26, NULL, '2', NULL),
(301, '49', 'Trimethoprim', 26, NULL, '2', NULL),
(302, '50', 'Trimethoprim-sulfamethoxzole', 26, NULL, '2', NULL),
(303, '51', 'Vancomycin', 26, NULL, '2', NULL),
(305, '34', 'Kinetic 37C/ Kinetic - without pyridoxal ', 1, NULL, '1', NULL),
(306, '35', 'Kinetic - pyridoxal', 1, NULL, '1', NULL),
(309, '9', 'Others', 15, NULL, '9', NULL),
(310, '13', 'Others', 3, NULL, NULL, NULL),
(311, '36', 'CLIA', 6, NULL, 'TP', NULL),
(312, '36', 'Malloy - Evelyn ', 1, NULL, '1', NULL),
(313, '37', 'Margon/ Xylidyl blue', 1, NULL, '1', NULL),
(314, '38', 'Methylthymol blue', 1, NULL, '1', NULL),
(315, '39', 'Molybdenum EP', 1, NULL, '1', NULL),
(319, '40', 'Molybdenum UV', 1, NULL, '1', NULL),
(320, '41', 'Others', 1, NULL, '1', NULL),
(321, '42', 'Phospho. Precip./ Polyanion', 1, NULL, '1', NULL),
(322, '43', 'PNP AMP buff; IFCC', 1, NULL, '1', NULL),
(323, '1', 'Arsenazo/ Chlorophosphonazo', 1, NULL, '1', NULL),
(326, '5', 'Cell-Dyn ', 15, NULL, '5', NULL),
(332, '21', 'ABX Micros/Minos/ABC VET', 15, NULL, '66', NULL),
(336, '10', 'Pentra', 15, NULL, '61', NULL),
(487, '545', 'Medica', 1, NULL, '3', NULL),
(488, '546', 'Bt GEN', 1, NULL, '3', NULL),
(337, '2', 'Bromocresol green', 1, NULL, '1', NULL),
(338, '52', 'Not Tested', 2, NULL, NULL, NULL),
(339, '3', 'Bromocresol purple', 1, NULL, '1', NULL),
(340, '4', 'Beckman', 1, NULL, '1', NULL),
(341, '5', 'Biuret - Blank', 1, NULL, '1', NULL),
(342, '6', 'Biuret - Unblank', 1, NULL, '1', NULL),
(343, '7', 'CK-NAC/IFCC', 1, NULL, '1', NULL),
(344, '8', 'CNPG3', 1, NULL, '1', NULL),
(345, '9', 'Colorimetric', 1, NULL, '1', NULL),
(346, '10', 'CPC/ Arsenazo', 1, NULL, '1', NULL),
(347, '11', 'Dade Behring', 1, NULL, '1', NULL),
(348, '12', 'DCA/DPD', 1, NULL, '1', NULL),
(349, '13', 'DGKC', 1, NULL, '1', NULL),
(350, '14', 'Diazonium', 1, NULL, '1', NULL),
(351, '15', 'Direct Determination', 1, NULL, '1', NULL),
(352, '16', 'Direct ISE', 1, NULL, '1', NULL),
(353, '17', 'Enz Color Total TG', 1, NULL, '1', NULL),
(354, '18', 'Enzyme', 1, NULL, '1', NULL),
(355, '19', 'Enzyme Colorimetric', 1, NULL, '1', NULL),
(356, '20', 'Enzyme EP Blank', 1, NULL, '1', NULL),
(357, '21', 'Enzyme EP Unblank', 1, NULL, '1', NULL),
(358, '22', 'Enzyme Kinetic', 1, NULL, '1', NULL),
(359, '23', 'G7PNP', 1, NULL, '1', NULL),
(360, '24', 'Glucose Dehydrogenase', 1, NULL, '1', NULL),
(361, '25', 'Glycerol Blank', 1, NULL, '1', NULL),
(362, '26', 'Glucose Oxidase', 1, NULL, '1', NULL),
(363, '27', 'Hexokinase', 1, NULL, '1', NULL),
(364, '28', 'IFCC', 1, NULL, '1', NULL),
(365, '29', 'Indirect ISE', 1, NULL, '1', NULL),
(366, '30', 'ISE', 1, NULL, '1', NULL),
(367, '31', 'Jaffe EP', 1, NULL, '1', NULL),
(369, '101', 'Abbott Architect c Systems', 1, NULL, '2', NULL),
(370, '102', 'Audicom AC9000 Series electrolyte analyzer', 1, NULL, '2', NULL),
(374, '104', 'Beckman Coulter DxC600/ DxC800', 1, NULL, '2', NULL),
(373, '103', 'Beckman Coulter AU400/480/680/5800', 1, NULL, '2', NULL),
(375, '105', 'Beckman Coulter DxC700 AU', 1, NULL, '2', NULL),
(376, '106', 'Biosystems A15', 1, NULL, '2', NULL),
(377, '107', 'Biosystems BA400', 1, NULL, '2', NULL),
(378, '108', 'Caretium XI-921', 1, NULL, '2', NULL),
(379, '109', 'Roche Cobas Mira S', 1, NULL, '2', NULL),
(380, '110', 'Diasys BioMajesty JCA-BM6010/C', 1, NULL, '2', NULL),
(381, '111', 'Dirui CS Series', 1, NULL, '2', NULL),
(382, '112', 'Dirui CS-600B', 1, NULL, NULL, NULL),
(383, '113', 'Electa4 analyzer', 1, NULL, '2', NULL),
(384, '114', 'Erba XL Series', 1, NULL, '2', NULL),
(385, '115', 'Fuji Dri-Chem NX500i', 1, NULL, '2', NULL),
(386, '116', 'GASTAT-1820', 1, NULL, '2', NULL),
(387, '117', 'Hitachi 911', 1, NULL, '2', NULL),
(388, '118', 'Horiba Pentra 400', 1, NULL, '2', NULL),
(389, '119', 'ILab 600/650/Taurus', 1, NULL, NULL, NULL),
(390, '120', 'ILab 600/650/Taurus', 1, NULL, '2', NULL),
(391, '121', 'In4lyte', 1, NULL, '2', NULL),
(392, '122', 'Konelab 20/30/60 / Thermo Indiko', 1, NULL, '2', NULL),
(393, '123', 'Mindray BC 2000/3000 series', 1, NULL, '2', NULL),
(394, '124', 'Mindray BS Series', 1, NULL, '2', NULL),
(395, '125', 'Nova 4 electrolyte analyzer', 1, NULL, '2', NULL),
(396, '126', 'Ortho Vitros 250/350', 1, NULL, '2', NULL),
(397, '127', 'Ortho Vitros 4600/5600', 1, NULL, '2', NULL),
(398, '128', 'PKL PPC Series', 1, NULL, '2', NULL),
(399, '129', 'Q4-Lyte', 1, NULL, '2', NULL),
(400, '130', 'Randox RX series', 1, NULL, '2', NULL),
(401, '131', 'Reflotron', 1, NULL, '2', NULL),
(402, '132', 'Roche Cobas c111', 1, NULL, '2', NULL),
(403, '133', 'Roche Cobas c311', 1, NULL, '2', NULL),
(404, '134', 'Roche Cobas c501/502/503', 1, NULL, '2', NULL),
(405, '135', 'Roche Cobas Integra 400 Plus', 1, NULL, '2', NULL),
(406, '136', 'Rx Modena', 1, NULL, '2', NULL),
(407, '137', 'Rx-lyte v.4', 1, NULL, '2', NULL),
(408, '138', 'SFRI ISE electrolyte series', 1, NULL, '2', NULL),
(409, '139', 'Siemens Advia 1800', 1, NULL, '2', NULL),
(410, '140', 'Siemens Rapidlab 348Ex', 1, NULL, '2', NULL),
(411, '141', 'Siemens/Dade Dimension EXL', 1, NULL, '2', NULL),
(412, '142', 'Siemens/Dade Dimension RxL /Max/Xpand', 1, NULL, '2', NULL),
(413, '143', 'Sinnowa BS-3000', 1, NULL, '2', NULL),
(414, '144', 'Sinnowa DS301', 1, NULL, '2', NULL),
(415, '145', 'Sysmex BX-3010', 1, NULL, '2', NULL),
(416, '146', 'Sysmex BX-4000', 1, NULL, '2', NULL),
(417, '147', 'Sysmex JCA-BM6010/C', 1, NULL, NULL, NULL),
(418, '148', 'Tecom TC220', 1, NULL, '2', NULL),
(419, '149', 'Thermo Fisher Konelab Delta', 1, NULL, '2', NULL),
(420, '150', 'Tokyo Boeki/Biolis/ Prestige 24i/TMS 1024', 1, NULL, '2', NULL),
(421, '151', 'URIT-8031', 1, NULL, '2', NULL),
(422, '152', 'Vitalab Scientific Flexor E', 1, NULL, '2', NULL),
(423, '153', 'XD 687 Electrolyte Analyzer', 1, NULL, '2', NULL),
(424, '154', 'XD 697 Electrolyte Analyzer', 1, NULL, '2', NULL),
(425, '501', 'Abbott laboratories', 1, NULL, '3', NULL),
(426, '502', 'Beckman Coulter', 1, NULL, '3', NULL),
(427, '503', 'BioSystems', 1, NULL, '3', NULL),
(428, '504', 'Biozen', 1, NULL, '3', NULL),
(429, '505', 'Caretium ', 1, NULL, '3', NULL),
(430, '506', 'Centronic', 1, NULL, '3', NULL),
(431, '507', 'Diamond', 1, NULL, '3', NULL),
(432, '508', 'DiaSys', 1, NULL, '3', NULL),
(433, '509', 'Diazyme', 1, NULL, '3', NULL),
(434, '510', 'Dirui', 1, NULL, '3', NULL),
(435, '511', 'Electa', 1, NULL, '3', NULL),
(436, '512', 'Elitech', 1, NULL, '3', NULL),
(437, '513', 'Erba Lachema', 1, NULL, '3', NULL),
(438, '514', 'Fuji', 1, NULL, '3', NULL),
(439, '515', 'Furuno', 1, NULL, '3', NULL),
(440, '516', 'Horiba', 1, NULL, '3', NULL),
(441, '517', 'Iberlab', 1, NULL, '3', NULL),
(442, '518', 'I-med', 1, NULL, '3', NULL),
(443, '519', 'Infocus firming', 1, NULL, '3', NULL),
(444, '520', 'Instumentation laboratory', 1, NULL, '3', NULL),
(445, '521', 'Jiangsu Audicom ', 1, NULL, '3', NULL),
(446, '522', 'Meditop', 1, NULL, '3', NULL),
(447, '523', 'Mindray', 1, NULL, '3', NULL),
(448, '524', 'Olympus', 1, NULL, '3', NULL),
(449, '525', 'Ortho-Clinical Diagnostics', 1, NULL, '3', NULL),
(450, '526', 'PCL', 1, NULL, '3', NULL),
(451, '527', 'Randox', 1, NULL, '3', NULL),
(452, '528', 'Roche Diagnotics', 1, NULL, '3', NULL),
(453, '529', 'SFRI', 1, NULL, '3', NULL),
(454, '530', 'Shanghai Xunda', 1, NULL, '3', NULL),
(455, '531', 'Siemens', 1, NULL, '3', NULL),
(456, '532', 'Slidedrychem', 1, NULL, '3', NULL),
(457, '533', 'Spinreact', 1, NULL, '3', NULL),
(458, '534', 'Stanbio', 1, NULL, '3', NULL),
(459, '535', 'Sysmex', 1, NULL, '3', NULL),
(460, '536', 'Techno Medica', 1, NULL, '3', NULL),
(461, '537', 'Tecom', 1, NULL, '3', NULL),
(462, '538', 'Thermoscientific', 1, NULL, '3', NULL),
(463, '539', 'Toyobo', 1, NULL, '3', NULL),
(464, '540', 'URIT', 1, NULL, '3', NULL),
(465, '541', 'Wako', 1, NULL, '3', NULL),
(466, '542', 'YD diagnostic', 1, NULL, '3', NULL),
(469, NULL, NULL, 13, NULL, NULL, NULL),
(474, '155', 'Q4-LyteEx ', 1, NULL, '2', NULL),
(476, '157', 'Biotecnica BT Series', 1, NULL, '2', NULL),
(479, '543', 'Biotecnica Instruments', 1, NULL, '3', NULL),
(480, '158', 'URIT 8280', 1, NULL, '2', NULL),
(481, '159', 'GE300 electrolyte analyzer', 1, NULL, '2', NULL),
(482, '544', 'Genrui Biotech', 1, NULL, '3', NULL),
(483, '160', 'Biosystems BA200', 1, NULL, '2', NULL),
(485, '161', 'Roche Cobas c701/702', 1, NULL, '2', NULL),
(486, '162', 'HumaStar 200', 1, NULL, '2', NULL),
(489, '547', 'Q4-Lyte', 1, NULL, '3', NULL),
(490, '548', 'Q4-LyteEx', 1, NULL, '3', NULL),
(491, '50', 'Direct with PVS/PEGMS', 1, NULL, '1', NULL),
(492, '51', 'Imm.Inhibition', 1, NULL, '1', NULL),
(493, '52', 'Water & Gerarde Method', 1, NULL, '1', NULL),
(494, '53', 'Vanadate', 1, NULL, '1', NULL),
(495, '156', 'Furuno CA-800', 1, NULL, '2', NULL),
(496, '163', 'Diasys Respons 920', 1, NULL, '2', NULL),
(497, '164', 'Rayto Chemray 120', 1, NULL, '2', NULL),
(498, '549', 'Rayto', 1, NULL, '3', NULL),
(499, '550', 'QuantILab', 1, NULL, '3', NULL),
(500, '165', 'Roche Cobas c501/502/503', 1, NULL, NULL, NULL),
(501, '166', 'URIT-910 Plus', 1, NULL, '2', NULL),
(502, '167', 'Siemens Atellica Solution', 1, NULL, '2', NULL),
(509, '24', 'DxH 600 / 800 / 900', 15, NULL, '24', NULL),
(511, '168', 'Erba Lyte Series', 1, NULL, '2', NULL),
(513, '169', 'ABAXIS VetScan VS2', 1, NULL, '2', NULL),
(514, '170', 'Rayto Chemray 240', 1, NULL, '2', NULL),
(515, '171', 'Abbott Alinity c Systems', 1, NULL, '2', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `mhd_admin`
--

CREATE TABLE `mhd_admin` (
  `id` int(11) NOT NULL,
  `username` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `password` longtext COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_login` datetime DEFAULT NULL,
  `date_added` datetime DEFAULT NULL,
  `date_modify` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `mhd_admin`
--

INSERT INTO `mhd_admin` (`id`, `username`, `password`, `date_login`, `date_added`, `date_modify`) VALUES
(1, 'admin', 'f5fde0dc484da753a9ebb354c1fe1f65', '2021-02-08 16:26:14', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `mhd_company`
--

CREATE TABLE `mhd_company` (
  `id` int(11) NOT NULL,
  `member_id` int(11) DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `room` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `address_1` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `address_2` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `district` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `country` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `province` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `postcode` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `telephone` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fax` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `del` int(1) DEFAULT 0,
  `date_added` datetime DEFAULT NULL,
  `date_modify` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `mhd_company`
--

INSERT INTO `mhd_company` (`id`, `member_id`, `name`, `room`, `address_1`, `address_2`, `district`, `country`, `province`, `postcode`, `telephone`, `fax`, `del`, `date_added`, `date_modify`) VALUES
(1, 1, 'fsoftpro', 'room', '44/263, ซ.8, หมู่บ้าน Villaggio พระราม2, ซอยบางกระดี่ 35/1, เขตบางขุนเทียน, แขวงแสมดำ, กทมฯ.', '35/1', 'บางขุนเทียน', 'จอมทอง', 'กรุงเทพมหานคร', '10150', '+66863498778', NULL, 0, '2021-01-12 13:43:45', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `mhd_content`
--

CREATE TABLE `mhd_content` (
  `id` int(11) NOT NULL,
  `cat` int(11) DEFAULT NULL,
  `text_name` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `model_no` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `warranty` int(1) UNSIGNED ZEROFILL DEFAULT NULL,
  `price` float(11,0) DEFAULT NULL,
  `s_price` float DEFAULT NULL,
  `seq` int(11) DEFAULT NULL,
  `del` int(1) DEFAULT NULL,
  `hide` int(1) DEFAULT NULL,
  `sold` int(11) DEFAULT NULL,
  `selected` int(11) DEFAULT NULL,
  `code` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'à¸£à¸«à¸±à¸ªà¸ªà¸´à¸™à¸„à¹‰à¸²',
  `youtube` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `slug` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `color` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `color2` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `picture1` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `picture_thumb` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `picture2` varchar(25) COLLATE utf8_unicode_ci DEFAULT NULL,
  `picture3` varchar(25) COLLATE utf8_unicode_ci DEFAULT NULL,
  `picture4` varchar(25) COLLATE utf8_unicode_ci DEFAULT NULL,
  `picture5` varchar(25) COLLATE utf8_unicode_ci DEFAULT NULL,
  `link` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `vdo` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `variations` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tags` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `time` int(11) DEFAULT NULL,
  `time_update` int(11) DEFAULT NULL,
  `show_hot` int(1) DEFAULT NULL,
  `show_new` int(1) DEFAULT NULL,
  `show_cat` int(11) DEFAULT NULL,
  `show_menu` int(11) DEFAULT NULL,
  `count` int(11) DEFAULT 0,
  `premium_gift` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `article` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `category` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `location` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `type` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `room` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `optional` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `area` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `kind` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `bath` int(11) DEFAULT NULL,
  `bedroom` int(11) DEFAULT NULL,
  `gym` int(11) DEFAULT NULL,
  `pool` int(11) DEFAULT NULL,
  `showOnIndex` int(1) DEFAULT 0,
  `bestSeller` int(1) DEFAULT 0,
  `inPromotion` int(1) DEFAULT 0,
  `map_longitude` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `map_latitude` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `map_z` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `busstop` int(11) DEFAULT NULL,
  `library` int(11) DEFAULT NULL,
  `smarket` int(11) DEFAULT NULL,
  `school` int(11) DEFAULT NULL,
  `weight` int(11) DEFAULT NULL,
  `weight_s` int(11) DEFAULT NULL,
  `weight_m` int(11) DEFAULT NULL,
  `weight_l` int(11) DEFAULT NULL,
  `weight_xl` int(11) DEFAULT NULL,
  `weight_xxl` int(11) DEFAULT NULL,
  `price_s` int(11) DEFAULT NULL,
  `price_m` int(11) DEFAULT NULL,
  `price_l` int(11) DEFAULT NULL,
  `price_xl` int(11) DEFAULT NULL,
  `price_xxl` int(11) DEFAULT NULL,
  `promotion_price` int(11) DEFAULT 0,
  `promotion_price_s` int(11) DEFAULT 0,
  `promotion_price_m` int(11) DEFAULT 0,
  `promotion_price_l` int(11) DEFAULT 0,
  `promotion_price_xl` int(11) DEFAULT 0,
  `promotion_price_xxl` int(11) DEFAULT 0,
  `total_stock` int(11) DEFAULT 0,
  `stock` int(11) DEFAULT 0,
  `stock_s` int(11) DEFAULT NULL,
  `stock_m` int(11) DEFAULT NULL,
  `stock_l` int(11) DEFAULT NULL,
  `stock_xl` int(11) DEFAULT NULL,
  `stock_xxl` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=DYNAMIC;

--
-- Dumping data for table `mhd_content`
--

INSERT INTO `mhd_content` (`id`, `cat`, `text_name`, `model_no`, `warranty`, `price`, `s_price`, `seq`, `del`, `hide`, `sold`, `selected`, `code`, `youtube`, `slug`, `color`, `color2`, `picture1`, `picture_thumb`, `picture2`, `picture3`, `picture4`, `picture5`, `link`, `vdo`, `variations`, `tags`, `time`, `time_update`, `show_hot`, `show_new`, `show_cat`, `show_menu`, `count`, `premium_gift`, `article`, `category`, `location`, `type`, `room`, `optional`, `area`, `kind`, `bath`, `bedroom`, `gym`, `pool`, `showOnIndex`, `bestSeller`, `inPromotion`, `map_longitude`, `map_latitude`, `map_z`, `busstop`, `library`, `smarket`, `school`, `weight`, `weight_s`, `weight_m`, `weight_l`, `weight_xl`, `weight_xxl`, `price_s`, `price_m`, `price_l`, `price_xl`, `price_xxl`, `promotion_price`, `promotion_price_s`, `promotion_price_m`, `promotion_price_l`, `promotion_price_xl`, `promotion_price_xxl`, `total_stock`, `stock`, `stock_s`, `stock_m`, `stock_l`, `stock_xl`, `stock_xxl`) VALUES
(1, 2, NULL, NULL, NULL, NULL, NULL, 1, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1487063226, NULL, NULL, NULL, NULL, NULL, 0, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL),
(2, 2, NULL, NULL, NULL, NULL, NULL, 2, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1487063234, NULL, NULL, NULL, NULL, NULL, 0, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL),
(3, 2, NULL, NULL, NULL, NULL, NULL, 3, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1487063242, NULL, NULL, NULL, NULL, NULL, 0, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL),
(4, 2, NULL, NULL, NULL, NULL, NULL, 4, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1487063250, NULL, NULL, NULL, NULL, NULL, 0, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL),
(5, 1, NULL, NULL, NULL, NULL, NULL, 1, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '_1554117368.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1487065107, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL),
(6, 3, NULL, NULL, NULL, NULL, NULL, 1, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1487069434, NULL, NULL, NULL, NULL, NULL, 0, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL),
(7, 3, NULL, NULL, NULL, NULL, NULL, 2, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1487069458, NULL, NULL, NULL, NULL, NULL, 0, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL),
(8, 3, NULL, NULL, NULL, NULL, NULL, 3, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1487069493, NULL, NULL, NULL, NULL, NULL, 0, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL),
(9, 3, NULL, NULL, NULL, NULL, NULL, 4, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1487069504, NULL, NULL, NULL, NULL, NULL, 0, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL),
(10, 3, NULL, NULL, NULL, NULL, NULL, 5, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1487069521, NULL, NULL, NULL, NULL, NULL, 0, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL),
(11, 3, NULL, NULL, NULL, NULL, NULL, 6, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1487069541, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL),
(12, 41, NULL, NULL, NULL, NULL, NULL, 1, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '_1487150765.jpg', '_thumb_1487150765.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1487150765, NULL, NULL, NULL, NULL, NULL, 0, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL),
(13, 6, NULL, NULL, NULL, NULL, NULL, 1, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1487151447, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL),
(14, 6, NULL, NULL, NULL, NULL, NULL, 2, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1487151508, NULL, NULL, NULL, NULL, NULL, 0, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL),
(15, 6, NULL, NULL, NULL, NULL, NULL, 3, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1487151565, NULL, NULL, NULL, NULL, NULL, 0, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL),
(16, 6, NULL, NULL, NULL, NULL, NULL, 4, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1487151615, NULL, NULL, NULL, NULL, NULL, 0, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL),
(17, 6, NULL, NULL, NULL, NULL, NULL, 5, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1487151647, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL),
(18, 7, NULL, NULL, NULL, NULL, NULL, 1, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '_1487151711.jpg', '_thumb_1487151711.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1487151711, NULL, NULL, NULL, NULL, NULL, 0, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL),
(19, 10, NULL, NULL, NULL, NULL, NULL, 1, 0, 0, NULL, NULL, NULL, NULL, NULL, 'color5', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1487224470, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL),
(20, 10, NULL, NULL, NULL, NULL, NULL, 2, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1487224477, NULL, NULL, NULL, NULL, NULL, 0, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL),
(21, 29, NULL, NULL, NULL, NULL, NULL, 1, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '_1488261969.jpg', '_thumb_1487228638.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1487228638, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL),
(22, 29, NULL, NULL, NULL, NULL, NULL, 2, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '_1488262202.jpg', '_thumb_1487228662.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1487228662, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL),
(23, 29, NULL, NULL, NULL, NULL, NULL, 3, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '_1488262235.jpg', '_thumb_1487228673.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1487228673, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL),
(24, 29, NULL, NULL, NULL, NULL, NULL, 4, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '_1488262281.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1487228679, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL),
(25, 45, NULL, NULL, NULL, NULL, NULL, 1, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1487234485, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL),
(26, 45, NULL, NULL, NULL, NULL, NULL, 2, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1487234490, NULL, NULL, NULL, NULL, NULL, 0, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL),
(27, 45, NULL, NULL, NULL, NULL, NULL, 3, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1487234495, NULL, NULL, NULL, NULL, NULL, 0, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL),
(28, 45, NULL, NULL, NULL, NULL, NULL, 4, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1487234500, NULL, NULL, NULL, NULL, NULL, 0, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL),
(29, NULL, NULL, NULL, NULL, NULL, NULL, 1, 0, 0, NULL, NULL, NULL, NULL, NULL, 'color3', NULL, '_1487235227.jpg', '_thumb_1487235227.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1487235227, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL),
(30, 46, NULL, NULL, NULL, NULL, NULL, 2, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '_1487235247.jpg', '_thumb_1487235247.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1487235247, NULL, NULL, NULL, NULL, NULL, 0, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL),
(31, 46, NULL, NULL, NULL, NULL, NULL, 3, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '_1487235259.jpg', '_thumb_1487235259.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1487235259, NULL, NULL, NULL, NULL, NULL, 0, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL),
(32, 46, NULL, NULL, NULL, NULL, NULL, 4, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '_1487235270.jpg', '_thumb_1487235270.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1487235270, NULL, NULL, NULL, NULL, NULL, 0, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL),
(33, 46, NULL, NULL, NULL, NULL, NULL, 5, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '_1487235674.jpg', '_thumb_1487235674.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1487235674, NULL, NULL, NULL, NULL, NULL, 0, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL),
(34, 39, NULL, NULL, NULL, NULL, NULL, 1, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1487749213, NULL, NULL, NULL, NULL, NULL, 0, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL),
(35, 39, NULL, NULL, NULL, NULL, NULL, 2, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1487749367, NULL, NULL, NULL, NULL, NULL, 0, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL),
(36, 55, NULL, NULL, NULL, NULL, NULL, 1, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1487827068, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL),
(37, 55, NULL, NULL, NULL, NULL, NULL, 2, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1487827239, NULL, NULL, NULL, NULL, NULL, 0, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL),
(38, 55, NULL, NULL, NULL, NULL, NULL, 3, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1487827382, NULL, NULL, NULL, NULL, NULL, 0, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL),
(39, 55, NULL, NULL, NULL, NULL, NULL, 4, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1487827384, NULL, NULL, NULL, NULL, NULL, 0, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL),
(40, 55, NULL, NULL, NULL, NULL, NULL, 5, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1487827395, NULL, NULL, NULL, NULL, NULL, 0, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL),
(41, 55, NULL, NULL, NULL, NULL, NULL, 6, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1487827555, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL),
(42, 55, NULL, NULL, NULL, NULL, NULL, 7, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1487827663, NULL, NULL, NULL, NULL, NULL, 0, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL),
(43, 6, NULL, NULL, NULL, NULL, NULL, 6, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1487830160, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL),
(44, 6, NULL, NULL, NULL, NULL, NULL, 7, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1487830448, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL),
(45, 6, NULL, NULL, NULL, NULL, NULL, 8, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1487830582, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL),
(46, 6, NULL, NULL, NULL, NULL, NULL, 9, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1487830692, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL),
(47, 6, NULL, NULL, NULL, NULL, NULL, 10, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1487830761, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL),
(48, 12, NULL, NULL, NULL, NULL, NULL, 1, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1487832665, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL),
(49, 55, NULL, NULL, NULL, NULL, NULL, 8, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1487832826, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL),
(50, 55, NULL, NULL, NULL, NULL, NULL, 9, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1487833552, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL),
(51, 55, NULL, NULL, NULL, NULL, NULL, 10, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1487835075, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL),
(52, 55, NULL, NULL, NULL, NULL, NULL, 11, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '_1491298261.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1487836061, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL),
(53, 55, NULL, NULL, NULL, NULL, NULL, 12, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1487836288, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL),
(54, 55, NULL, NULL, NULL, NULL, NULL, 13, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1487837340, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL),
(55, 7, NULL, NULL, NULL, NULL, NULL, 2, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1487841045, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL),
(56, 36, NULL, NULL, NULL, NULL, NULL, 1, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1488178008, NULL, NULL, NULL, NULL, NULL, 0, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL),
(57, 37, NULL, NULL, NULL, NULL, NULL, 1, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1488178030, NULL, NULL, NULL, NULL, NULL, 0, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL),
(58, 38, NULL, NULL, NULL, NULL, NULL, 1, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1488178047, NULL, NULL, NULL, NULL, NULL, 0, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL),
(59, 29, NULL, NULL, NULL, NULL, NULL, 5, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '_1488262363.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1488261572, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL),
(60, 5, NULL, NULL, NULL, NULL, NULL, 1, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1488363435, NULL, NULL, NULL, NULL, NULL, 0, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL),
(61, 9, NULL, NULL, NULL, NULL, NULL, 1, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1488363751, NULL, NULL, NULL, NULL, NULL, 0, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL),
(62, 19, NULL, NULL, NULL, NULL, NULL, 1, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1488363859, NULL, NULL, NULL, NULL, NULL, 0, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL),
(63, 46, NULL, NULL, NULL, NULL, NULL, 6, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '_1489659181.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1488772104, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL),
(64, 41, NULL, NULL, NULL, NULL, NULL, 2, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1488952748, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL),
(65, 41, NULL, NULL, NULL, NULL, NULL, 3, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1488952825, NULL, NULL, NULL, NULL, NULL, 0, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL),
(66, 41, NULL, NULL, NULL, NULL, NULL, 4, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1488952847, NULL, NULL, NULL, NULL, NULL, 0, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL),
(67, 41, NULL, NULL, NULL, NULL, NULL, 5, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1488952864, NULL, NULL, NULL, NULL, NULL, 0, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL),
(68, 41, NULL, NULL, NULL, NULL, NULL, 6, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1488952880, NULL, NULL, NULL, NULL, NULL, 0, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL),
(69, 41, NULL, NULL, NULL, NULL, NULL, 7, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1488953025, NULL, NULL, NULL, NULL, NULL, 0, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL),
(70, 41, NULL, NULL, NULL, NULL, NULL, 8, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1488953057, NULL, NULL, NULL, NULL, NULL, 0, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL),
(71, 44, NULL, NULL, NULL, NULL, NULL, 1, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1488953191, NULL, NULL, NULL, NULL, NULL, 0, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL),
(72, 44, NULL, NULL, NULL, NULL, NULL, 2, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1488953387, NULL, NULL, NULL, NULL, NULL, 0, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL),
(73, 29, NULL, NULL, NULL, NULL, NULL, 6, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '_1489658745.jpg', '_thumb_1489658745.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1489658745, NULL, NULL, NULL, NULL, NULL, 0, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL),
(74, 29, NULL, NULL, NULL, NULL, NULL, 7, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '_1489658790.jpg', '_thumb_1489658790.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1489658790, NULL, NULL, NULL, NULL, NULL, 0, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL),
(75, 29, NULL, NULL, NULL, NULL, NULL, 8, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '_1489658826.png', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1489658826, NULL, NULL, NULL, NULL, NULL, 0, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL),
(76, 6, NULL, NULL, NULL, NULL, NULL, 11, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1489661821, NULL, NULL, NULL, NULL, NULL, 0, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL),
(77, 6, NULL, NULL, NULL, NULL, NULL, 12, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1489661997, NULL, NULL, NULL, NULL, NULL, 0, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL),
(78, 6, NULL, NULL, NULL, NULL, NULL, 13, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1489662271, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL),
(79, 41, NULL, NULL, NULL, NULL, NULL, 9, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1489664893, NULL, NULL, NULL, NULL, NULL, 0, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL),
(80, 41, NULL, NULL, NULL, NULL, NULL, 10, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1489664972, NULL, NULL, NULL, NULL, NULL, 0, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL),
(81, 41, NULL, NULL, NULL, NULL, NULL, 11, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1489665063, NULL, NULL, NULL, NULL, NULL, 0, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL),
(82, 41, NULL, NULL, NULL, NULL, NULL, 12, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1489665158, NULL, NULL, NULL, NULL, NULL, 0, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL),
(83, 41, NULL, NULL, NULL, NULL, NULL, 13, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1489665231, NULL, NULL, NULL, NULL, NULL, 0, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL),
(84, 41, NULL, NULL, NULL, NULL, NULL, 14, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1489665294, NULL, NULL, NULL, NULL, NULL, 0, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL),
(85, 6, NULL, NULL, NULL, NULL, NULL, 14, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1489665605, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL),
(86, 6, NULL, NULL, NULL, NULL, NULL, 15, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1489666050, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL),
(87, 38, NULL, NULL, NULL, NULL, NULL, 2, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '_1489666525.pdf', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1489666525, NULL, NULL, NULL, NULL, NULL, 0, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL),
(88, 36, NULL, NULL, NULL, NULL, NULL, 2, 0, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '_1489667457.pdf', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1489667457, NULL, NULL, NULL, NULL, NULL, 0, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL),
(89, 15, NULL, NULL, NULL, NULL, NULL, 1, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1489668370, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL),
(90, 55, NULL, NULL, NULL, NULL, NULL, 14, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1489716469, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL),
(91, 55, NULL, NULL, NULL, NULL, NULL, 15, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1489716787, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL),
(92, 38, NULL, NULL, NULL, NULL, NULL, 3, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1489716907, NULL, NULL, NULL, NULL, NULL, 0, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL),
(93, 38, NULL, NULL, NULL, NULL, NULL, 4, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1489716933, NULL, NULL, NULL, NULL, NULL, 0, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL),
(94, 54, NULL, NULL, NULL, NULL, NULL, 1, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1489723721, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL),
(95, 54, NULL, NULL, NULL, NULL, NULL, 2, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1489723754, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL),
(96, 54, NULL, NULL, NULL, NULL, NULL, 3, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1489723778, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL),
(97, 53, NULL, NULL, NULL, NULL, NULL, 1, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1489724785, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL),
(98, 53, NULL, NULL, NULL, NULL, NULL, 2, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1489725011, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL),
(99, 53, NULL, NULL, NULL, NULL, NULL, 3, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1489725306, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL),
(100, 53, NULL, NULL, NULL, NULL, NULL, 4, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1489725562, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL),
(101, 53, NULL, NULL, NULL, NULL, NULL, 5, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1489726179, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL),
(102, 26, NULL, NULL, NULL, NULL, NULL, 1, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1489743147, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL),
(103, 55, NULL, NULL, NULL, NULL, NULL, 16, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1490064916, NULL, NULL, NULL, NULL, NULL, 0, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL),
(104, 54, NULL, NULL, NULL, NULL, NULL, 4, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1496714362, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL),
(105, 14, NULL, NULL, NULL, NULL, NULL, 1, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1496720151, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL),
(106, 14, NULL, NULL, NULL, NULL, NULL, 2, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1496720612, NULL, NULL, NULL, NULL, NULL, 0, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL),
(107, 14, NULL, NULL, NULL, NULL, NULL, 3, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1496720753, NULL, NULL, NULL, NULL, NULL, 0, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL),
(108, 54, NULL, NULL, NULL, NULL, NULL, 5, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1496720829, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL),
(109, 14, NULL, NULL, NULL, NULL, NULL, 4, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1496721523, NULL, NULL, NULL, NULL, NULL, 0, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `mhd_content` (`id`, `cat`, `text_name`, `model_no`, `warranty`, `price`, `s_price`, `seq`, `del`, `hide`, `sold`, `selected`, `code`, `youtube`, `slug`, `color`, `color2`, `picture1`, `picture_thumb`, `picture2`, `picture3`, `picture4`, `picture5`, `link`, `vdo`, `variations`, `tags`, `time`, `time_update`, `show_hot`, `show_new`, `show_cat`, `show_menu`, `count`, `premium_gift`, `article`, `category`, `location`, `type`, `room`, `optional`, `area`, `kind`, `bath`, `bedroom`, `gym`, `pool`, `showOnIndex`, `bestSeller`, `inPromotion`, `map_longitude`, `map_latitude`, `map_z`, `busstop`, `library`, `smarket`, `school`, `weight`, `weight_s`, `weight_m`, `weight_l`, `weight_xl`, `weight_xxl`, `price_s`, `price_m`, `price_l`, `price_xl`, `price_xxl`, `promotion_price`, `promotion_price_s`, `promotion_price_m`, `promotion_price_l`, `promotion_price_xl`, `promotion_price_xxl`, `total_stock`, `stock`, `stock_s`, `stock_m`, `stock_l`, `stock_xl`, `stock_xxl`) VALUES
(110, 14, NULL, NULL, NULL, NULL, NULL, 5, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1496721807, NULL, NULL, NULL, NULL, NULL, 0, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL),
(111, 54, NULL, NULL, NULL, NULL, NULL, 6, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1496721955, NULL, NULL, NULL, NULL, NULL, 0, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL),
(112, 14, NULL, NULL, NULL, NULL, NULL, 6, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1496734862, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL),
(113, 14, NULL, NULL, NULL, NULL, NULL, 7, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1496735728, NULL, NULL, NULL, NULL, NULL, 0, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL),
(114, 54, NULL, NULL, NULL, NULL, NULL, 7, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1496992909, NULL, NULL, NULL, NULL, NULL, 0, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL),
(115, 54, NULL, NULL, NULL, NULL, NULL, 8, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1496992932, NULL, NULL, NULL, NULL, NULL, 0, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL),
(116, 37, NULL, NULL, NULL, NULL, NULL, 2, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '_1497839133.jpeg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1497838911, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL),
(117, 7, NULL, NULL, NULL, NULL, NULL, 3, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1497839838, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL),
(118, 7, NULL, NULL, NULL, NULL, NULL, 4, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1497844557, NULL, NULL, NULL, NULL, NULL, 0, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL),
(119, 14, NULL, NULL, NULL, NULL, NULL, 8, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1497866718, NULL, NULL, NULL, NULL, NULL, 0, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL),
(120, 56, NULL, NULL, NULL, NULL, NULL, 1, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '_1498550816.jpeg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1498036830, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL),
(121, 57, NULL, NULL, NULL, NULL, NULL, 1, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1498552502, NULL, NULL, NULL, NULL, NULL, 0, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL),
(122, 58, NULL, NULL, NULL, NULL, NULL, 1, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1498553015, NULL, NULL, NULL, NULL, NULL, 0, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL),
(123, 58, NULL, NULL, NULL, NULL, NULL, 2, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1498553037, NULL, NULL, NULL, NULL, NULL, 0, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL),
(124, 58, NULL, NULL, NULL, NULL, NULL, 3, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1498553047, NULL, NULL, NULL, NULL, NULL, 0, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL),
(125, 58, NULL, NULL, NULL, NULL, NULL, 4, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1498553054, NULL, NULL, NULL, NULL, NULL, 0, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL),
(126, 58, NULL, NULL, NULL, NULL, NULL, 5, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1498553061, NULL, NULL, NULL, NULL, NULL, 0, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL),
(127, 58, NULL, NULL, NULL, NULL, NULL, 6, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1498553068, NULL, NULL, NULL, NULL, NULL, 0, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL),
(128, 59, NULL, NULL, NULL, NULL, NULL, 1, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1498553131, NULL, NULL, NULL, NULL, NULL, 0, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL),
(129, 59, NULL, NULL, NULL, NULL, NULL, 2, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1498553137, NULL, NULL, NULL, NULL, NULL, 0, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL),
(130, 58, NULL, NULL, NULL, NULL, NULL, 10, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1498553776, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL),
(131, 58, NULL, NULL, NULL, NULL, NULL, 7, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1498553780, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL),
(132, 58, NULL, NULL, NULL, NULL, NULL, 1, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1498553783, NULL, NULL, NULL, NULL, NULL, 0, NULL, 'าาต', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL),
(133, 58, NULL, NULL, NULL, NULL, NULL, 2, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1498553787, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL),
(134, 58, NULL, NULL, NULL, NULL, NULL, 4, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1498553790, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL),
(135, 59, NULL, NULL, NULL, NULL, NULL, 1, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '_1540280260.pdf', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1498553864, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL),
(136, 59, NULL, NULL, NULL, NULL, NULL, 4, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '_1498871668.doc', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1498553869, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL),
(137, 59, NULL, NULL, NULL, NULL, NULL, 5, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1498553874, NULL, NULL, NULL, NULL, NULL, 0, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL),
(138, 59, NULL, NULL, NULL, NULL, NULL, 6, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1498553877, NULL, NULL, NULL, NULL, NULL, 0, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL),
(139, 59, NULL, NULL, NULL, NULL, NULL, 7, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1498553881, NULL, NULL, NULL, NULL, NULL, 0, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL),
(140, 71, NULL, NULL, NULL, NULL, NULL, 3, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '_1498871743.doc', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1498553920, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL),
(141, 71, NULL, NULL, NULL, NULL, NULL, 2, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '_1498871841.docx', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1498553923, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL),
(142, 71, NULL, NULL, NULL, NULL, NULL, 3, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1498553926, NULL, NULL, NULL, NULL, NULL, 0, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL),
(143, 71, NULL, NULL, NULL, NULL, NULL, 4, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1498553929, NULL, NULL, NULL, NULL, NULL, 0, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL),
(144, 71, NULL, NULL, NULL, NULL, NULL, 5, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1498553932, NULL, NULL, NULL, NULL, NULL, 0, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL),
(145, 72, NULL, NULL, NULL, NULL, NULL, 1, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '_1498871980.pdf', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1498553948, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL),
(146, 72, NULL, NULL, NULL, NULL, NULL, 2, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1498553959, NULL, NULL, NULL, NULL, NULL, 0, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL),
(147, 72, NULL, NULL, NULL, NULL, NULL, 3, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1498553961, NULL, NULL, NULL, NULL, NULL, 0, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL),
(148, 72, NULL, NULL, NULL, NULL, NULL, 4, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1498553965, NULL, NULL, NULL, NULL, NULL, 0, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL),
(149, 72, NULL, NULL, NULL, NULL, NULL, 5, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1498553968, NULL, NULL, NULL, NULL, NULL, 0, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL),
(150, 72, NULL, NULL, NULL, NULL, NULL, 6, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '_1498872026.doc', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1498872026, NULL, NULL, NULL, NULL, NULL, 0, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL),
(151, 58, NULL, NULL, NULL, NULL, NULL, 3, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1498872109, NULL, NULL, NULL, NULL, NULL, 0, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL),
(152, 58, NULL, NULL, NULL, NULL, NULL, 8, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1498872127, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL),
(153, 58, NULL, NULL, NULL, NULL, NULL, 9, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1498872155, NULL, NULL, NULL, NULL, NULL, 0, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL),
(182, 59, NULL, NULL, NULL, NULL, NULL, 8, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1540280326, NULL, NULL, NULL, NULL, NULL, 0, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL),
(154, 71, NULL, NULL, NULL, NULL, NULL, 1, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '_1500272421.docx', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1500272421, NULL, NULL, NULL, NULL, NULL, 0, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL),
(155, 74, NULL, NULL, NULL, NULL, NULL, 1, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1532411266, NULL, NULL, NULL, NULL, NULL, 0, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL),
(156, 74, NULL, NULL, NULL, NULL, NULL, 2, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1532411275, NULL, NULL, NULL, NULL, NULL, 0, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL),
(157, 74, NULL, NULL, NULL, NULL, NULL, 3, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1532411281, NULL, NULL, NULL, NULL, NULL, 0, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL),
(158, 75, NULL, NULL, NULL, NULL, NULL, 1, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1532411300, NULL, NULL, NULL, NULL, NULL, 0, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL),
(159, 75, NULL, NULL, NULL, NULL, NULL, 2, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1532411305, NULL, NULL, NULL, NULL, NULL, 0, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL),
(160, 75, NULL, NULL, NULL, NULL, NULL, 3, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1532411315, NULL, NULL, NULL, NULL, NULL, 0, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL),
(161, 76, NULL, NULL, NULL, NULL, NULL, 1, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1532411342, NULL, NULL, NULL, NULL, NULL, 0, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL),
(162, 77, NULL, NULL, NULL, NULL, NULL, 1, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1532411356, NULL, NULL, NULL, NULL, NULL, 0, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL),
(163, 77, NULL, NULL, NULL, NULL, NULL, 2, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1532411363, NULL, NULL, NULL, NULL, NULL, 0, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL),
(164, 78, NULL, NULL, NULL, NULL, NULL, 1, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1532411375, NULL, NULL, NULL, NULL, NULL, 0, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL),
(165, 78, NULL, NULL, NULL, NULL, NULL, 2, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1532411381, NULL, NULL, NULL, NULL, NULL, 0, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL),
(166, 78, NULL, NULL, NULL, NULL, NULL, 3, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1532411388, NULL, NULL, NULL, NULL, NULL, 0, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL),
(167, 79, NULL, NULL, NULL, NULL, NULL, 1, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1532411832, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL),
(168, 79, NULL, NULL, NULL, NULL, NULL, 2, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1532411839, NULL, NULL, NULL, NULL, NULL, 0, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL),
(169, 79, NULL, NULL, NULL, NULL, NULL, 3, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1532411847, NULL, NULL, NULL, NULL, NULL, 0, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL),
(170, 79, NULL, NULL, NULL, NULL, NULL, 4, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1532411856, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL),
(171, 79, NULL, NULL, NULL, NULL, NULL, 5, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1532411867, NULL, NULL, NULL, NULL, NULL, 0, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL),
(172, 79, NULL, NULL, NULL, NULL, NULL, 6, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1532411877, NULL, NULL, NULL, NULL, NULL, 0, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL),
(173, 79, NULL, NULL, NULL, NULL, NULL, 7, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1532411888, NULL, NULL, NULL, NULL, NULL, 0, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL),
(174, 79, NULL, NULL, NULL, NULL, NULL, 8, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1532411897, NULL, NULL, NULL, NULL, NULL, 0, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL),
(175, 79, NULL, NULL, NULL, NULL, NULL, 9, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1532411906, NULL, NULL, NULL, NULL, NULL, 0, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL),
(176, 80, NULL, NULL, NULL, NULL, NULL, 1, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1532428209, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL),
(177, 81, NULL, NULL, NULL, NULL, NULL, 1, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1534304854, NULL, NULL, NULL, NULL, NULL, 0, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL),
(178, 81, NULL, NULL, NULL, NULL, NULL, 2, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1534304866, NULL, NULL, NULL, NULL, NULL, 0, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL),
(179, 82, NULL, NULL, NULL, NULL, NULL, 1, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1534305242, NULL, NULL, NULL, NULL, NULL, 0, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL),
(180, 58, NULL, NULL, NULL, NULL, NULL, 5, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1540279763, NULL, NULL, NULL, NULL, NULL, 0, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL),
(181, 58, NULL, NULL, NULL, NULL, NULL, 6, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1540279783, NULL, NULL, NULL, NULL, NULL, 0, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL),
(183, 1, NULL, NULL, NULL, NULL, NULL, 2, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1554117330, NULL, NULL, NULL, NULL, NULL, 0, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL),
(184, 57, NULL, NULL, NULL, NULL, NULL, 2, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '_1554263008.gif', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1554179700, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL),
(185, 57, NULL, NULL, NULL, NULL, NULL, 3, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '_1554264448.jpg', '_thumb_1554179868.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1554179868, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `mhd_content_cat`
--

CREATE TABLE `mhd_content_cat` (
  `id` int(11) NOT NULL,
  `parent` int(11) NOT NULL,
  `picture1` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `picture2` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `picture3` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `picture4` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `picture5` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `picture_thumb` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `hide` int(1) DEFAULT NULL,
  `del` int(1) DEFAULT 0,
  `seq` int(11) DEFAULT NULL,
  `shows` int(11) DEFAULT NULL,
  `time` int(11) DEFAULT NULL,
  `time_update` int(11) DEFAULT NULL,
  `show_menu` int(11) DEFAULT NULL,
  `show_sub` int(11) DEFAULT NULL,
  `color` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `link` text COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=DYNAMIC;

--
-- Dumping data for table `mhd_content_cat`
--

INSERT INTO `mhd_content_cat` (`id`, `parent`, `picture1`, `picture2`, `picture3`, `picture4`, `picture5`, `picture_thumb`, `hide`, `del`, `seq`, `shows`, `time`, `time_update`, `show_menu`, `show_sub`, `color`, `link`) VALUES
(1, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, 1487063039, NULL, NULL, NULL, NULL, NULL),
(2, 1, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, 1487063205, NULL, NULL, NULL, NULL, NULL),
(3, 1, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, 1487069395, NULL, NULL, NULL, NULL, NULL),
(4, 1, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, 1487071703, NULL, NULL, NULL, NULL, NULL),
(5, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, 1487146439, NULL, NULL, NULL, NULL, NULL),
(6, 5, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, 1487146463, 1487225550, NULL, NULL, NULL, NULL),
(7, 5, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, 1487146472, 1488251095, NULL, NULL, 'color1', NULL),
(8, 5, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, 1487146482, NULL, NULL, NULL, NULL, NULL),
(9, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, 1487146525, NULL, NULL, NULL, NULL, NULL),
(10, 9, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, 1487146555, 1490857190, NULL, NULL, 'color4', NULL),
(11, 9, NULL, NULL, NULL, NULL, NULL, NULL, 0, 1, NULL, NULL, 1487146567, NULL, NULL, NULL, NULL, NULL),
(12, 9, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, 1487146567, 1487662222, NULL, NULL, 'color1', NULL),
(13, 9, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, 1487146581, 1487838501, NULL, NULL, 'color2', NULL),
(14, 9, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, 1487146600, 1496734925, NULL, NULL, 'color3', NULL),
(15, 9, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, 1487146612, 1487838512, NULL, NULL, 'color4', NULL),
(16, 9, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, 1487146761, 1490845821, NULL, NULL, 'color3', NULL),
(17, 9, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, 1487146772, 1487838523, NULL, NULL, 'color1', NULL),
(18, 9, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, 1487146786, 1487838527, NULL, NULL, 'color2', NULL),
(19, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, 1487146817, NULL, NULL, NULL, NULL, NULL),
(20, 19, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, 1487146839, 1487838669, NULL, NULL, 'color1', NULL),
(21, 19, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, 1487146855, 1487838675, NULL, NULL, 'color2', NULL),
(22, 19, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, 1487146870, 1488532224, NULL, NULL, 'color3', 'index.php?route=page_person_search&type=0'),
(23, 19, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, 1487146881, 1488532267, NULL, NULL, 'color4', 'index.php?route=page_person_search&type=1'),
(24, 19, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, 1487146891, 1490845781, NULL, NULL, 'color3', NULL),
(25, 19, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, 1487146900, 1487838694, NULL, NULL, 'color1', NULL),
(26, 19, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, 1487146917, 1487838699, NULL, NULL, 'color2', NULL),
(27, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, 1487146934, NULL, NULL, NULL, NULL, NULL),
(28, 27, NULL, NULL, NULL, NULL, NULL, NULL, 0, 1, NULL, NULL, 1487146956, NULL, NULL, NULL, NULL, NULL),
(29, 27, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, 1487146965, 1488251052, NULL, NULL, NULL, NULL),
(30, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 1, NULL, NULL, 1487146980, NULL, NULL, NULL, NULL, NULL),
(31, 30, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, 1487146989, 1487230589, NULL, NULL, NULL, NULL),
(32, 30, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, 1487146996, 1487233521, NULL, NULL, NULL, NULL),
(33, 30, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, 1487147001, 1487230721, NULL, NULL, NULL, NULL),
(34, 30, NULL, NULL, NULL, NULL, NULL, NULL, 0, 1, NULL, NULL, 1487147009, NULL, NULL, NULL, NULL, NULL),
(35, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, 1487147054, NULL, NULL, NULL, NULL, NULL),
(36, 35, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, 1487147068, NULL, NULL, NULL, NULL, NULL),
(37, 35, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, 1487147072, NULL, NULL, NULL, NULL, NULL),
(38, 35, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, 1487147079, 1489666464, NULL, NULL, NULL, NULL),
(39, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, 1487147096, 1487746126, NULL, NULL, NULL, NULL),
(40, 5, NULL, NULL, NULL, NULL, NULL, NULL, 0, 1, NULL, NULL, 1487148706, NULL, NULL, NULL, NULL, NULL),
(41, 40, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, 1487148720, NULL, NULL, NULL, NULL, NULL),
(42, 40, NULL, NULL, NULL, NULL, NULL, NULL, 0, 1, NULL, NULL, 1487148727, NULL, NULL, NULL, NULL, NULL),
(43, 40, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, 1487148733, NULL, NULL, NULL, NULL, NULL),
(44, 40, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, 1487148738, 1488176767, NULL, NULL, NULL, NULL),
(45, 27, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, 1487234439, NULL, NULL, NULL, NULL, NULL),
(46, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, 1487234992, NULL, NULL, NULL, NULL, NULL),
(47, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 1, NULL, NULL, 1487299611, NULL, NULL, NULL, NULL, NULL),
(48, 29, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, 1487744838, NULL, NULL, NULL, NULL, NULL),
(49, 29, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, 1487744854, NULL, NULL, NULL, NULL, NULL),
(50, 29, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, 1487744867, NULL, NULL, NULL, NULL, NULL),
(51, 9, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, 1487744939, 1487838534, NULL, NULL, 'color3', NULL),
(52, 9, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, 1487744947, 1487838536, NULL, NULL, 'color4', NULL),
(53, 19, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, 1487744986, 1487838709, NULL, NULL, 'color3', NULL),
(54, 19, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, 1487744999, 1487838715, NULL, NULL, 'color4', NULL),
(55, 5, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, 1487745037, NULL, NULL, NULL, NULL, NULL),
(56, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, 1498036823, 1498553087, NULL, NULL, NULL, NULL),
(57, 56, '_1554263738.jpg', NULL, NULL, NULL, NULL, '_thumb_1554263738.jpg', 0, 0, NULL, NULL, 1498552480, 1554263753, NULL, NULL, NULL, NULL),
(58, 56, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, 1498552946, NULL, NULL, NULL, NULL, NULL),
(59, 56, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, 1498553120, NULL, NULL, NULL, NULL, NULL),
(60, 58, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, 1498553347, NULL, NULL, NULL, NULL, NULL),
(61, 58, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, 1498553370, NULL, NULL, NULL, NULL, NULL),
(62, 58, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, 1498553376, NULL, NULL, NULL, NULL, NULL),
(63, 58, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, 1498553385, NULL, NULL, NULL, NULL, NULL),
(64, 58, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, 1498553390, NULL, NULL, NULL, NULL, NULL),
(65, 58, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, 1498553396, NULL, NULL, NULL, NULL, NULL),
(66, 59, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, 1498553522, NULL, NULL, NULL, NULL, NULL),
(67, 59, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, 1498553526, NULL, NULL, NULL, NULL, NULL),
(68, 59, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, 1498553530, NULL, NULL, NULL, NULL, NULL),
(69, 59, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, 1498553534, NULL, NULL, NULL, NULL, NULL),
(70, 59, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, 1498553541, NULL, NULL, NULL, NULL, NULL),
(71, 56, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, 1498553903, NULL, NULL, NULL, NULL, NULL),
(72, 56, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, 1498553944, NULL, NULL, NULL, NULL, NULL),
(73, 56, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, 1532411179, 1534305169, NULL, NULL, NULL, NULL),
(74, 73, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, 1532411208, NULL, NULL, NULL, NULL, NULL),
(75, 73, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, 1532411217, NULL, NULL, NULL, NULL, NULL),
(76, 73, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, 1532411223, NULL, NULL, NULL, NULL, NULL),
(77, 73, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, 1532411244, NULL, NULL, NULL, NULL, NULL),
(78, 73, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, 1532411251, NULL, NULL, NULL, NULL, NULL),
(79, 56, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, 1532411810, 1534305729, NULL, NULL, NULL, NULL),
(80, 56, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, 1532428105, NULL, NULL, NULL, NULL, NULL),
(81, 56, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, 1534304841, NULL, NULL, NULL, NULL, NULL),
(82, 56, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, 1534305161, 1534305228, NULL, NULL, NULL, NULL),
(83, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, 1540280439, NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `mhd_content_pic`
--

CREATE TABLE `mhd_content_pic` (
  `id` int(11) NOT NULL,
  `pid` int(11) NOT NULL,
  `picture1` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `seq` int(11) NOT NULL,
  `link` text COLLATE utf8_unicode_ci NOT NULL,
  `title` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `textPic` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `time` int(11) NOT NULL,
  `type` int(1) UNSIGNED ZEROFILL NOT NULL DEFAULT 0
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=DYNAMIC;

--
-- Dumping data for table `mhd_content_pic`
--

INSERT INTO `mhd_content_pic` (`id`, `pid`, `picture1`, `seq`, `link`, `title`, `textPic`, `time`, `type`) VALUES
(44, 60, 'pic_1488428405_2.png', 2, 'http://www.cgd.go.th/', '', '', 0, 0),
(45, 60, 'pic_1488428405_3.png', 3, '', '', '', 0, 0),
(46, 60, 'pic_1488428405_4.png', 4, '', NULL, NULL, 0, 0),
(42, 60, 'pic_1488428405_0.png', 1, 'http://www.dla.go.th/', '', '', 0, 0),
(43, 60, 'pic_1488428405_1.png', 5, 'http://www.thaigov.go.th/', '', '', 0, 0),
(61, 62, 'pic_1488428638_1.png', 3, 'http://www.nhso.go.th/FrontEnd/Index.aspx', '', '', 0, 0),
(62, 62, 'pic_1488428638_2.png', 1, 'http://www.doe.go.th', '', '', 0, 0),
(52, 61, 'pic_1488428556_0.png', 1, 'http://www.laas.go.th/', '', '', 0, 0),
(60, 62, 'pic_1488428638_0.png', 2, 'http://newskm.moi.go.th/', '', '', 0, 0),
(51, 61, 'pic_1488428546_0.png', 2, 'http://e-plan.dla.go.th/', '', '', 0, 0),
(48, 61, 'pic_1488428514_0.png', 4, 'http://www.thaigov.go.th', '', '', 0, 0),
(49, 61, 'pic_1488428526_0.png', 3, 'http://www.cgd.go.th/', '', '', 0, 0),
(47, 61, 'pic_1488428496_0.png', 5, 'http://www.dla.go.th/', '', '', 0, 0),
(58, 62, 'pic_1488428615_0.png', 4, 'http://process3.gprocurement.go.th/', '', '', 0, 0),
(59, 62, 'pic_1488428615_1.png', 5, 'http://www.mict.go.th', '', '', 0, 0),
(139, 5, 'pic_1496732225_3.jpg', 1, '', NULL, NULL, 0, 0),
(138, 5, 'pic_1496732225_2.jpg', 1, '', NULL, NULL, 0, 0),
(136, 5, 'pic_1496732225_0.jpg', 1, '', NULL, NULL, 0, 0),
(137, 5, 'pic_1496732225_1.jpg', 1, '', NULL, NULL, 0, 0),
(135, 5, 'pic_1496732206_0.jpg', 1, '', NULL, NULL, 0, 0),
(143, 120, 'pic_1498550442_0.jpeg', 1, '', NULL, NULL, 0, 0),
(142, 120, 'pic_1498550361_0.jpg', 1, '', NULL, NULL, 0, 0),
(144, 120, 'pic_1498550442_1.jpg', 1, '', NULL, NULL, 0, 0),
(145, 120, 'pic_1498550442_2.jpeg', 1, '', NULL, NULL, 0, 0),
(157, 121, 'pic_1498554799_4.jpg', 1, '', 'EQAI', '', 0, 0),
(156, 121, 'pic_1498554799_3.jpg', 1, '', NULL, NULL, 0, 0),
(155, 121, 'pic_1498554799_2.jpg', 1, '', 'EQAI', '', 0, 0),
(154, 121, 'pic_1498554799_1.jpg', 1, '', NULL, NULL, 0, 0),
(153, 121, 'pic_1498554799_0.jpg', 1, '', 'EQAI', '', 0, 0),
(158, 121, 'pic_1498554799_5.jpg', 1, '', NULL, NULL, 0, 0),
(159, 121, 'pic_1498554799_6.jpg', 1, '', 'EQAM', '', 0, 0),
(160, 121, 'pic_1498554799_7.jpg', 1, '', 'EQAM', '', 0, 0),
(161, 121, 'pic_1498554799_8.jpg', 1, '', 'EQAM', '', 0, 0),
(162, 121, 'pic_1498554799_9.jpg', 1, '', NULL, NULL, 0, 0),
(163, 121, 'pic_1498554799_10.jpg', 1, '', 'EQAM', '', 0, 0),
(164, 121, 'pic_1498554799_11.jpg', 1, '', NULL, NULL, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `mhd_language`
--

CREATE TABLE `mhd_language` (
  `id` int(11) NOT NULL,
  `language_name` text DEFAULT NULL,
  `sort` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

--
-- Dumping data for table `mhd_language`
--

INSERT INTO `mhd_language` (`id`, `language_name`, `sort`) VALUES
(1, 'TH', 0);

-- --------------------------------------------------------

--
-- Table structure for table `mhd_language_detail`
--

CREATE TABLE `mhd_language_detail` (
  `id` int(11) NOT NULL,
  `language_id` int(11) DEFAULT NULL,
  `ref_id` int(11) DEFAULT NULL,
  `name` text CHARACTER SET utf8 DEFAULT NULL,
  `type` int(11) DEFAULT 1,
  `detail` text CHARACTER SET utf8 DEFAULT NULL,
  `detail_2` text CHARACTER SET utf8 DEFAULT NULL,
  `detail_3` text CHARACTER SET utf8 DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

--
-- Dumping data for table `mhd_language_detail`
--

INSERT INTO `mhd_language_detail` (`id`, `language_id`, `ref_id`, `name`, `type`, `detail`, `detail_2`, `detail_3`) VALUES
(1, 1, 1, 'home', 0, '', NULL, NULL),
(2, 1, 2, 'suggest', 0, '', NULL, NULL),
(3, 1, 1, 'แนะนำที่ท่องเที่ยว', 1, '', NULL, NULL),
(4, 1, 2, 'อปภร.', 1, '', NULL, NULL),
(5, 1, 3, 'แนะนำร้านอาหาร', 1, '', NULL, NULL),
(6, 1, 4, 'ประมวลจริยธรรม', 1, '', NULL, NULL),
(7, 1, 5, 'banner', 1, NULL, NULL, NULL),
(8, 1, 3, 'องค์การบริหารส่วนตำบลศรีสมเด็จ', 0, '', NULL, NULL),
(9, 1, 6, 'โครงการจัดเก็บภาษี', 1, '', NULL, NULL),
(10, 1, 7, 'กิจกรรมงานแข่งขันกีฬา', 1, '', NULL, NULL),
(11, 1, 8, 'กิจกรรมปลูกต้นไม้ลดภาวะโรคร้อน', 1, '', NULL, NULL),
(12, 1, 9, 'ฉีดพ่นหมอกควัน ป้องกันโรคไข้เลือดออก', 1, '', NULL, NULL),
(13, 1, 10, 'ช่วยเหลือประชาชน *', 1, '', NULL, NULL),
(14, 1, 11, 'รับ – ส่ง เสด็จ สมเด็จพระเทพพฯ', 1, NULL, NULL, NULL),
(15, 1, 4, 'เมนู', 0, '', NULL, NULL),
(16, 1, 5, 'เมนูด้านบน', 0, '', NULL, NULL),
(17, 1, 6, 'เกี่ยวกับหน่วยงาน', 0, NULL, NULL, NULL),
(18, 1, 7, 'ข่าวประชาสัมพันธ์', 0, NULL, NULL, NULL),
(19, 1, 8, 'รับเรื่องร้องเรียน', 0, '', NULL, NULL),
(20, 1, 9, 'เมนูด้านซ้าย', 0, '', NULL, NULL),
(21, 1, 10, 'รับแจ้งเรื่องร้องทุกข์', 0, NULL, NULL, NULL),
(22, 1, 11, 'แบบสอบถามความพึงพอใจ', 0, '', NULL, NULL),
(23, 1, 12, 'แบบสอบถามความพึงพอใจ', 0, NULL, NULL, NULL),
(24, 1, 13, 'รางวัลแห่งความภาคภูมิใจ', 0, '', NULL, NULL),
(25, 1, 14, 'รายงานกิจการสภา', 0, NULL, NULL, NULL),
(26, 1, 15, 'คู่มือประชาชน', 0, '', NULL, NULL),
(27, 1, 16, 'แบบฟอร์มดาวน์โหลด', 0, NULL, NULL, NULL),
(28, 1, 17, 'แบบฟอร์มออนไลน์', 0, '', NULL, NULL),
(29, 1, 18, 'ระบบจัดการความรู้', 0, '', NULL, NULL),
(30, 1, 19, 'เมนูด้านขวา', 0, '', NULL, NULL),
(31, 1, 20, 'ศูนย์ข้อมูลข่าวสาร', 0, '', NULL, NULL),
(32, 1, 21, 'เงินอุดหนนุนดูแลเด็กแรกเกิด', 0, '', NULL, NULL),
(33, 1, 22, 'เบี้ยยังชีพผู้สูงอายุ', 0, NULL, NULL, NULL),
(34, 1, 23, 'เบี้ยยังชีพผู้พิการ', 0, NULL, NULL, NULL),
(35, 1, 24, ' กลุ่มสตรีเทศบาล', 0, NULL, NULL, NULL),
(36, 1, 25, 'E-Book', 0, '', NULL, NULL),
(37, 1, 26, 'ข้อมูลวารสาร', 0, '', NULL, NULL),
(38, 1, 27, 'ข้อมูลที่น่าสนใจ', 0, '', NULL, NULL),
(39, 1, 28, 'หนังสือราชการจากกรมส่งเสริม', 0, '', NULL, NULL),
(40, 1, 29, 'ข่าวกิจกรรม', 0, NULL, NULL, NULL),
(41, 1, 30, 'เกี่ยวกับหน่วยงาน', 0, '', NULL, NULL),
(42, 1, 31, ' สภาพและข้อมูลพื้นฐาน', 0, '<p>สภาพทั่วไปขององค์การบริหารส่วนตำบลศรีสมเด็จองค์การบริหารส่วนตำบลศรีสมเด็จ มีพื้นที่โดยประมาณ 35 ตารางกิโลเมตร หรือประมาณ &nbsp;21,875 ไร่ องค์การบริหารส่วนตำบลศรีสมเด็จ เป็นเขตปกครองของอำเภอสมเด็จ จังหวัดกาฬสินธุ์ อยู่ทางทิศเหนือ ของจังหวัดกาฬสินธุ์ ตั้งอยู่รอบนอกเทศบาลตำบลสมเด็จ อยู่ทางทิศเหนือ ของจังหวัดกาฬสินธุ์ ห่างจากจังหวัดกาฬสินธุ์ ประมาณ &nbsp;45 กิโลเมตร</p>\r\n', NULL, NULL),
(43, 1, 32, 'นโยบายการบริหาร', 0, '<p>ท่านประธานสภาองค์การบริหารส่วนตำบลศรีสมเด็จที่เคารพ</p>\r\n\r\n<p>ตามที่ได้มีประกาศคณะกรรมการการเลือกตั้ง ลงวันที่ ๑๓ พฤศจิกายน ๒๕๕๖ เรื่อง ผลการเลือกตั้งนายกองค์การบริหารส่วนตำบลศรีสมเด็จ อำเภอสมเด็จ จังหวัดกาฬสินธุ์ นั้น บัดนี้ นายกองค์การบริหารส่วนตำบลศรีสมเด็จ ได้กำหนดนโยบายการบริหารราชการองค์การบริหารส่วนตำบลศรีสมเด็จเรียบร้อยแล้ว โดยยึดมั่นในการปกครองระบอบประชาธิปไตยในระบบรัฐสภาอันมีพระมหากษัตริย์ทรงเป็นประมุข นายกองค์การบริหารส่วนตำบลศรีสมเด็จจึงขอแถลงนโยบายดังกล่าวต่อที่ประชุมสภาองค์การบริหารส่วนตำบลศรีสมเด็จเพื่อให้ทราบถึงเจตนารมณ์ ยุทธศาสตร์ และนโยบายของนายกองค์การบริหารส่วนตำบลศรีสมเด็จ ที่มุ่งมั่นจะสร้างความสามัคคี ปรองดอง ให้เกิดขึ้นในชุมชนซึ่งจะนำไปสู่ความร่วมมือในการพัฒนาตำบลทั้งในด้านเศรษฐกิจ สังคม และวัฒนธรรม ให้เจริญก้าวหน้าเพื่อประโยชน์สุขของประชาชนชาวตำบลศรีสมเด็จทุกคน</p>\r\n', NULL, NULL),
(44, 1, 33, 'กฎ ระเบียบ ข้อบังคับ', 0, '<p><span style=\"font-family:arial; font-size:18px\">พระราชบัญญัติสภาตำบลและองค์การบริหารส่วนตำบล พ.ศ.2537</span></p>\r\n', NULL, NULL),
(45, 1, 34, 'ประกาศจัดซื้อจัดจ้าง', 0, '', NULL, NULL),
(46, 1, 35, 'ประกาศจัดซื้อจัดจ้าง', 0, '', NULL, NULL),
(47, 1, 36, 'ประกวดราคาจ้างโครงการ', 0, '', NULL, NULL),
(48, 1, 37, 'สอบราคา', 0, '', NULL, NULL),
(49, 1, 38, 'หนังสือสั่งการ สถ', 0, NULL, NULL, NULL),
(50, 1, 39, 'VDO ', 0, '', NULL, NULL),
(51, 1, 40, 'ลิงค์แนะนำ', 0, '', NULL, NULL),
(52, 1, 41, 'แนะนำที่ท่องเที่ยว', 0, '', NULL, NULL),
(53, 1, 42, 'อปภร.', 0, '', NULL, NULL),
(54, 1, 43, 'แนะนำร้านอาหาร', 0, '', NULL, NULL),
(55, 1, 44, 'สินค้า OTOP', 0, NULL, NULL, NULL),
(56, 1, 12, 'ธนาคารสัตว์น้ำ', 1, '<p>ธนาคารสัตว์น้ำ</p>\r\n', NULL, NULL),
(57, 1, 13, 'สภาพและข้อมูลพื้นฐาน', 1, '<p><span style=\"color:rgb(153, 153, 153); font-family:lato; font-size:14px\">สภาพทั่วไปขององค์การบริหารส่วนตำบลศรีสมเด็จองค์การบริหารส่วนตำบลศรีสมเด็จ มีพื้นที่โดยประมาณ 35 ตารางกิโลเมตร หรือประมาณ&nbsp; 21,875 ไร่ องค์การบริหารส่วนตำบลศรีสมเด็จ เป็นเขตปกครองของอำเภอสมเด็จ จังหวัดกาฬสินธุ์ อยู่ทางทิศเหนือ ของจังหวัดกาฬสินธุ์ ตั้งอยู่รอบนอกเทศบาลตำบลสมเด็จ อยู่ทางทิศเหนือ ของจังหวัดกาฬสินธุ์ ห่างจากจังหวัดกาฬสินธุ์ ประมาณ&nbsp; 45 กิโลเมตร</span></p>\r\n', NULL, NULL),
(58, 1, 14, 'ข้อมูลผู้บริหาร', 1, '<div class=\"personnel\" style=\"box-sizing: border-box; border: 0px; font-family: Lato; font-size: 14px; margin: 0px; outline: 0px; padding: 0px; vertical-align: baseline; color: rgb(153, 153, 153);\">\r\n<div class=\"row text-center\" style=\"box-sizing: border-box; border: 0px; font-family: inherit; font-size: 0px; font-style: inherit; font-weight: inherit; margin: 0px -15px; outline: 0px; padding: 0px; vertical-align: baseline;\">\r\n<div class=\"col-xs-12\" style=\"box-sizing: border-box; border: 0px; font-family: inherit; font-size: 14px; font-style: inherit; font-weight: inherit; margin: 0px; outline: 0px; padding: 0px 15px; vertical-align: top; min-height: 1px; display: inline-block; float: none; width: 1170px;\">\r\n<h2 style=\"font-style: inherit; text-align: center;\">&nbsp;</h2>\r\n</div>\r\n</div>\r\n</div>\r\n\r\n<p style=\"text-align: center;\"><img alt=\"IMG1นายก\" class=\"alignnone size-medium wp-image-413\" src=\"http://srisomdet.localgov59.in.th/wp-content/uploads/2016/03/IMG1%E0%B8%99%E0%B8%B2%E0%B8%A2%E0%B8%81-221x300.jpg\" style=\"box-sizing:border-box; height:auto; max-width:100%; vertical-align:top; width:221px\" /></p>\r\n\r\n<p style=\"text-align: center;\">นายเตียง &nbsp;บุญสิงห์</p>\r\n\r\n<p style=\"text-align: center;\">นายกองค์การบริหารส่วนตำบลศรีสมเด็จ</p>\r\n\r\n<p style=\"text-align: center;\">&nbsp;</p>\r\n\r\n<p style=\"text-align: center;\"><img alt=\"รูปผู้บริหาร\" class=\"aligncenter wp-image-494\" src=\"http://srisomdet.localgov59.in.th/wp-content/uploads/2016/02/%E0%B8%A3%E0%B8%B9%E0%B8%9B%E0%B8%9C%E0%B8%B9%E0%B9%89%E0%B8%9A%E0%B8%A3%E0%B8%B4%E0%B8%AB%E0%B8%B2%E0%B8%A3-300x242.png\" style=\"box-sizing:border-box; color:rgb(153, 153, 153); display:block; font-family:lato; font-size:14px; height:auto; margin:5px auto; max-width:100%; vertical-align:top; width:469px\" /></p>\r\n', NULL, NULL),
(59, 1, 15, 'นโยบายการบริหาร', 1, '<p>คำแถลงนโยบาย</p>\r\n\r\n<p>ของ</p>\r\n\r\n<p>นายกองค์การบริหารส่วนตำบลศรีสมเด็จ</p>\r\n\r\n<p>นายเตียง &nbsp;บุญสิงห์</p>\r\n\r\n<p>แถลงต่อสภาองค์การบริหารส่วนตำบลศรีสมเด็จ</p>\r\n\r\n<p>วันที่ &nbsp;๒๖ &nbsp;พฤศจิกายน &nbsp;๒๕๕๖</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>ท่านประธานสภาองค์การบริหารส่วนตำบลศรีสมเด็จที่เคารพ</p>\r\n\r\n<p>ตามที่ได้มีประกาศคณะกรรมการการเลือกตั้ง &nbsp;ลงวันที่ &nbsp;๑๓ &nbsp;พฤศจิกายน &nbsp;๒๕๕๖ &nbsp;เรื่อง &nbsp;ผลการเลือกตั้งนายกองค์การบริหารส่วนตำบลศรีสมเด็จ &nbsp;อำเภอสมเด็จ &nbsp;จังหวัดกาฬสินธุ์ &nbsp;นั้น</p>\r\n\r\n<p>บัดนี้ &nbsp;นายกองค์การบริหารส่วนตำบลศรีสมเด็จ &nbsp;ได้กำหนดนโยบายการบริหารราชการองค์การบริหารส่วนตำบลศรีสมเด็จเรียบร้อยแล้ว &nbsp;โดยยึดมั่นในการปกครองระบอบประชาธิปไตยในระบบรัฐสภาอันมีพระมหากษัตริย์ทรงเป็นประมุข &nbsp;นายกองค์การบริหารส่วนตำบลศรีสมเด็จจึงขอแถลงนโยบายดังกล่าวต่อที่ประชุมสภาองค์การบริหารส่วนตำบลศรีสมเด็จเพื่อให้ทราบถึงเจตนารมณ์ &nbsp;ยุทธศาสตร์ &nbsp;และนโยบายของนายกองค์การบริหารส่วนตำบลศรีสมเด็จ &nbsp;ที่มุ่งมั่นจะสร้างความสามัคคี &nbsp;ปรองดอง &nbsp;ให้เกิดขึ้นในชุมชนซึ่งจะนำไปสู่ความร่วมมือในการพัฒนาตำบลทั้งในด้านเศรษฐกิจ &nbsp;สังคม &nbsp;และวัฒนธรรม &nbsp;ให้เจริญก้าวหน้าเพื่อประโยชน์สุขของประชาชนชาวตำบลศรีสมเด็จทุกคน</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>ท่านประธานสภาองค์การบริหารส่วนตำบลศรีสมเด็จที่เคารพ</p>\r\n\r\n<p>หลักการของนโยบายการบริหารราชการองค์การบริหารส่วนตำบลศรีสมเด็จ &nbsp;จะยึดหลักการบริหารกิจการบ้านเมืองที่ดีและยึดหลักบริหารราชการที่มีความยืดหยุ่นที่คำนึงถึงพลวัตรการเปลี่ยนแปลงของปัจจัยภายนอกที่มีผลกระทบต่อการดำเนินนโยบายของนายกองค์การบริหารส่วนตำบลศรีสมเด็จ &nbsp;โดยนายกองค์การบริหารส่วนตำบลศรีสมเด็จจะรายงานต่อสภาองค์การบริหารส่วนตำบลศรีสมเด็จเมื่อมีความจำเป็นต้องปรับปรุงนโยบายให้เกิดประโยชน์ต่อตำบลศรีสมเด็จให้มากที่สุด &nbsp;นโยบายของนายกองค์การบริหารส่วนตำบลศรีสมเด็จภายใต้กรอบแนวคิดเศรษฐกิจพอเพียงและแนวคิดที่ว่าครอบครัวอบอุ่นชุมชนเข้มแข็ง &nbsp;โดยมีจุดมุ่งหมาย &nbsp;๓ &nbsp;ประการ &nbsp; &nbsp;สานคุณธรรม &nbsp;นำพัฒนา &nbsp;ประชามีส่วนร่วม</p>\r\n\r\n<p>ข้อ &nbsp;๑. &nbsp;สานคุณธรรม &nbsp;ทุกคนที่มีอายุตั้งแต่ &nbsp;๑๐ &nbsp;ปี &nbsp;ขึ้นไป &nbsp;ต้องกล่าวคำสมาทานศีล ๕ &nbsp;ได้และถือปฏิบัติอย่างเคร่งครัด &nbsp;เพื่อนำไปสู่การพัฒนาต่างๆ &nbsp;ถูกต้องแม่นยำ &nbsp;เช่น &nbsp;จริยาวาจา &nbsp;วัฒนธรรมการแต่งกายและวิธีคิดระดับปัจเจกชน</p>\r\n\r\n<p>ข้อ &nbsp;๒. &nbsp;การพัฒนาตำบลศรีสมเด็จ &nbsp; ต้องเกิดจากมิติคิดของชุมชนทุกชุมชนภายใต้ศีลธรรมอันดีงามในบริบทนั้นๆ &nbsp;แต่มีความโปร่งใส &nbsp;เป็นธรรม &nbsp;ประหยัด &nbsp;มีประสิทธิภาพและตรวจสอบได้</p>\r\n\r\n<p>ข้อ &nbsp;๓. &nbsp;การมีส่วนร่วม &nbsp;ทุกภาคส่วนได้ร่วมคิด &nbsp;ร่วมทำ &nbsp;รับประโยชน์อย่างเท่าเทียมกันภายใต้กรอบของกฎหมายและงบประมาณที่มีอยู่อย่างเหมาะสม</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>/ด้านครอบครัว&hellip;.</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&ndash; &nbsp;๒ &nbsp;&ndash;</p>\r\n\r\n<p>ด้านครอบครัว</p>\r\n\r\n<p>๑. ครอบครัว &nbsp;หมายความว่า เป็นครอบครัวที่มีทั้งพ่อแม่ลูกอยู่ร่วมกัน &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; ๒. ครัวเรือน &nbsp;หมายความว่า ในครัวเรือนนั้นมีหลายครอบครัวอยู่อาศัยร่วมกัน เช่น ปู่ย่า ตายาย ลุงป้า น้าอา</p>\r\n\r\n<p>๓. ครอบครัวเลี้ยงเดี่ยว &nbsp;หมายความว่า &nbsp;เป็นครอบครัวที่มีแต่พ่อหรือแม่ &nbsp;ด้วยการหย่าร้างที่ฝ่ายใดฝ่ายหนึ่งเสียชีวิตหรืออื่นๆ &nbsp;แม่ลูกหรือพ่อลูก</p>\r\n\r\n<p>ครอบครัวเหล่านี้ต้องได้ทำกิจกรรมร่วมกันอย่างน้อยอาทิตย์ละ &nbsp;๒ &nbsp;ครั้ง</p>\r\n\r\n<p>ด้านชุมชน&nbsp;</p>\r\n\r\n<p>๑. &nbsp;หนึ่งชุมชนต้องร่วมกันจัดตั้งองค์กรอย่างน้อย &nbsp;๒ &nbsp;องค์กร &nbsp;เช่น &nbsp;กลุ่มสตรี,กลุ่มเด็กและเยาวชนและกลุ่มอื่นๆ เป็นต้น</p>\r\n\r\n<p>๒. &nbsp;กิจกรรมบุญประเพณีฮีตสิบสอง &nbsp;ครองสิบสี่</p>\r\n\r\n<p>๓. &nbsp;กิจกรรมด้านการศึกษา &nbsp;การเรียนรู้ด้านเทคโนโลยีสารสนเทศ &nbsp;การกีฬาทั้งภายในและภายนอกระบบสถานศึกษา</p>\r\n\r\n<p>๔. &nbsp;กิจกรรมการพัฒนาอาชีพและ</p>\r\n\r\n<p>๕. &nbsp;การพัฒนาอาชีพการเข้าถึงระบบข้อมูลข่าวสาร &nbsp;อาทิเช่น &nbsp;พ.ร.บ.การสหกรณ์,พ.ร.บ.การสาธารณสุข,ประมวลกฎหมายแพ่งและพาณิชย์,ประมวลกฎหมายพิจารณาความอาญาเบื้องต้น,พ.ร.บ.จัดตั้งองค์กรปกครองส่วนท้องถิ่นที่จำเป็นและที่เกี่ยวข้องกับชีวิตประจำวัน</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>พื้นที่รับผิดชอบ &nbsp;ตำบลศรีสมเด็จ &nbsp;อำเภอสมเด็จ &nbsp;จังหวัดกาฬสินธุ์</p>\r\n\r\n<p>จำนวน &nbsp;8 &nbsp;หมู่บ้าน &nbsp;คือ</p>\r\n\r\n<p>๑. &nbsp;บ้านหลุบเปลือย &nbsp;หมู่ที่ &nbsp;๑ &nbsp; &nbsp; จำนวน &nbsp;๒๕๘ &nbsp;ครัวเรือน &nbsp;ประชากร &nbsp;๑,๐๘๘ คน</p>\r\n\r\n<p>๒. &nbsp;บ้านหนองแสง &nbsp; &nbsp;หมู่ที่ &nbsp;๒ &nbsp; &nbsp; จำนวน &nbsp;๑๖๓ &nbsp;ครัวเรือน &nbsp;ประชากร &nbsp; &nbsp;๕๙๓ &nbsp;คน</p>\r\n\r\n<p>๓. &nbsp;บ้านโนนสะอาด &nbsp;หมู่ที่ &nbsp;๓ &nbsp; &nbsp; &nbsp;จำนวน &nbsp;๒๓๔ &nbsp;ครัวเรือน &nbsp;ประชากร &nbsp; &nbsp;๘๖๓ &nbsp;คน &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; ๔. &nbsp;บ้านคำกั้ง &nbsp;หมู่ที่ &nbsp;๔ &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;จำนวน &nbsp;๑๒๘ &nbsp;ครัวเรือน &nbsp;ประชากร &nbsp; &nbsp;๕๐๙ &nbsp;คน &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; ๕. &nbsp;บ้านคำกุง &nbsp;หมู่ที่ &nbsp;๕ &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;จำนวน &nbsp;๑๙๖ &nbsp;ครัวเรือน &nbsp;ประชากร &nbsp; &nbsp;๘๐๐ &nbsp;คน &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;๖. &nbsp;บ้านหนองอิดุม &nbsp;หมู่ที่ &nbsp;๖ &nbsp; &nbsp; &nbsp; จำนวน &nbsp;๑๗๒ &nbsp;ครัวเรือน &nbsp;ประชากร &nbsp; &nbsp;๖๘๘ &nbsp;คน &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; ๗. &nbsp;บ้านหลุบเปลือย &nbsp;หมู่ที่ &nbsp;๗ &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;จำนวน &nbsp;๑๓๓ &nbsp;ครัวเรือน &nbsp;ประชากร &nbsp; &nbsp;๕๖๕ &nbsp;คน &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; ๘. &nbsp;บ้านหนองแสง &nbsp;หมู่ที่ &nbsp;๘ &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;จำนวน &nbsp; &nbsp;๘๖ &nbsp;ครัวเรือน &nbsp;ประชากร &nbsp; &nbsp;๓๓๙ &nbsp;คน &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; รวม &nbsp;จำนวนครัวเรือน &nbsp;๑,๓๗๐ &nbsp;ครัวเรือน &nbsp;ประชากร &nbsp;๕,๔๔๕ &nbsp;คน</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&ndash; &nbsp;๓ &nbsp;&ndash;</p>\r\n\r\n<p>นโยบาย</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>๑.ด้านเศรษฐกิจ</p>\r\n\r\n<p>๑. &nbsp;ส่งเสริมสนับสนุนการตลาดเพื่อพัฒนาอาชีพชุมชน</p>\r\n\r\n<p>(๑) &nbsp;ผลิตภัณฑ์จากภูมิปัญญาชุมชน</p>\r\n\r\n<p>(๒) &nbsp;ส่งเสริมสนับสนุนแรงงานคืนถิ่น &nbsp;เช่น &nbsp;การตัดเย็บเสื้อผ้าและอื่นๆเป็นต้น</p>\r\n\r\n<p>(๓) &nbsp;ส่งเสริมอาชีพตามกระบวนการบริหารจัดการของกลุ่มองค์กรในชุมชนที่มีทุนอยู่แล้วให้เข้มแข็งพึ่งตนเองและช่วยเหลือองค์กรอื่นได้</p>\r\n\r\n<p>(๔) &nbsp;เชื่อมโยงและประสานความร่วมมือกับทุกภาคส่วนเพื่อบูรณการ &nbsp;การพัฒนาชุมชนอย่างเป็นระบบ</p>\r\n\r\n<p>(๕) &nbsp;การพัฒนาอาชีพและการเข้าถึงระบบข้อมูลข่าวสาร &nbsp;เช่นพ.ร.บ.การสหกรณ์,พ.ร.บ.การสาธารณสุข,ประมวลกฎหมายแพ่งและพาณิชย์,ประมวลกฎหมายพิจารณาความอาญาเบื้องต้น,พ.ร.บ.องค์กรปกครองส่วนท้องถิ่นที่จำเป็นและที่เกี่ยวข้องกับชีวิตประจำวัน</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>๒.ด้านสังคม &nbsp;การศึกษา &nbsp;ศาสนา &nbsp;และวัฒนธรรม</p>\r\n\r\n<p>๓.๑ &nbsp; การส่งเสริมสนับสนุนการเรียนรู้อย่างมีส่วนร่วม</p>\r\n\r\n<p>(๑) &nbsp;การจัดให้มีกลุ่มองค์กร &nbsp;เช่น</p>\r\n\r\n<p>&ndash; กลุ่มผู้สูงอายุ &nbsp;อสม. , &nbsp;สมาชิก อปพร., กลุ่มอาชีพต่างๆ , กลุ่มเด็กและเยาวชน</p>\r\n\r\n<p>กลุ่มผู้พิการ &nbsp;กลุ่มผู้ด้อยโอกาสทางสังคมและกลุ่มผู้ป่วยเอดส์</p>\r\n\r\n<p>&ndash; กลุ่มองค์กรต่างๆที่กล่าวถึงข้างต้น &nbsp;ต้องได้รับการขึ้นทะเบียนให้ถูกต้องตามกฎหมาย &nbsp;ทั้งที่</p>\r\n\r\n<p>เป็นกลุ่มมุ่งผลกำไรและไม่มุ่งผลกำไร &nbsp;เพื่อรองรับงบประมาณสนับสนุน</p>\r\n\r\n<p>(๒) &nbsp;การเรียนรู้อย่างมีส่วนร่วม</p>\r\n\r\n<p>&ndash; การเรียนในระบบ</p>\r\n\r\n<p>บ้าน-วัด-โรงเรียน-โรงพยาบาลส่งเสริมสุขภาพชุมชนประจำตำบล &nbsp;องค์กรปกครองส่วนท้องถิ่น &nbsp;มีกระบวนการบริหารจัดการที่แตกต่างกัน &nbsp;หากแต่สามารถหลอมรวมบริบทต่างๆได้หลายอย่าง &nbsp;ยกเว้นหลักการบริหารภายในขององค์กร &nbsp;เราต่างเคารพไม่ก้าวก่ายแทรกแซงกันและเป็นเครือญาติกัน</p>\r\n\r\n<p>&ndash; การเรียนรู้นอกระบบ</p>\r\n\r\n<p>องค์กรภาครัฐ &nbsp;องค์กรอิสระและองค์กรภาคเอกชน &nbsp;เปิดโอกาสให้ทุกกลุ่มองค์กรในชุมชน &nbsp;ขอสนับสนุนงบประมาณในการจัดเวทีเรียนรู้ต่างๆ &nbsp;ภายใต้กรอบและแนวทางตามวิธีงบประมาณของแหล่งทุนนั้นกำหนด</p>\r\n\r\n<p>-พัฒนาศูนย์พัฒนาเด็กเล็กตำบลศรีสมเด็จ</p>\r\n\r\n<p>พัฒนาศูนย์พัฒนาเด็กเล็กในทุกด้าน &nbsp; อาทิเช่น &nbsp;ด้านวัสดุอุปกรณ์ให้มีอย่างเหมาะสม &nbsp;เครื่องไม้เครื่องมือสำหรับการเรียนการสอน &nbsp;คอมพิวเตอร์สำหรับเด็กนักเรียน</p>\r\n\r\n<p>-พัฒนาระบบสื่อการเรียนการสอนให้ทันสมัย</p>\r\n\r\n<p>-พัฒนาเพิ่มศักยภาพครูผู้สอนและบุคลากรทางการศึกษา &nbsp;ส่งเสริมให้มีการฝึกอบรม &nbsp;พัฒนาทักษะการสอน &nbsp;ส่งเสริมให้การศึกษาที่เพิ่มสูงขึ้น</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>/๓. &nbsp;ด้านโครงสร้างพื้นฐาน &hellip;..</p>\r\n\r\n<p>&ndash; &nbsp;๔ &nbsp;&ndash;</p>\r\n\r\n<p>๓. &nbsp;ด้านโครงสร้างพื้นฐาน &nbsp;สาธารณูปโภค &nbsp;สาธารณูปการ</p>\r\n\r\n<p>-ส่งเสริมการพัฒนาโครงสร้างพื้นฐาน &nbsp;สาธารณูปโภค &ndash; สาธารณูปการ &nbsp;โดยจัดให้มีการก่อสร้างและบูรณะซ่อมแซม &nbsp;ถนนคอนกรีตเสริมเหล็ก &nbsp;ถนนแอสฟัลส์ติก (ถนนลาดยาง) &nbsp;ถนนลูกรัง ถนนเพื่อการเกษตร</p>\r\n\r\n<p>ท่อระบายน้ำ &nbsp;รางระบายน้ำ &nbsp;ถนนสู่นา &nbsp;ไฟฟ้าสู่ไร่ &nbsp;ถนนเชื่อมระหว่างหมู่บ้าน &nbsp;ระหว่างตำบล</p>\r\n\r\n<p>-ไฟฟ้าเพื่อการเกษตร &nbsp;ปรับปรุงไฟฟ้าส่งสว่างทั่วทั้งตำบล</p>\r\n\r\n<p>-พัฒนาแหล่งน้ำ &nbsp;น้ำเพื่อการอุปโภค-บริโภค &nbsp;น้ำเพื่อการเกษตร &nbsp;แก้ไขปัญหาด้านการขาดแคลนน้ำ &nbsp;เช่น &nbsp;จัดหาภาชนะกักเก็บน้ำ</p>\r\n\r\n<p>-พัฒนาแหล่งน้ำตามธรรมชาติ &nbsp;เช่น &nbsp;การขุดลอกลำห้วย &nbsp;หนอง &nbsp;คลอง &nbsp;บึง &nbsp;ซ่อมแซมและก่อสร้างฝายน้ำล้น &nbsp;ขุดเจาะน้ำเพื่อการเกษตร</p>\r\n\r\n<p>-ปรับปรุงภูมิทัศน์ตำบลศรีสมเด็จให้สวยงาม &nbsp;ปรับปรุงภูมิทัศน์สระน้ำโคกหนองกุงให้สวยงามเป็นที่พักผ่อนหย่อนใจแก่ประชาชน</p>\r\n\r\n<p>-ปรับปรุง &nbsp;ซ่อมแซม &nbsp;ต่อเติม &nbsp;ก่อสร้างอาคารสำนักงานองค์การบริหารส่วนตำบลเพื่ออำนวยความสะดวกรองรับการบริการให้กับประชาชน</p>\r\n\r\n<p>-บำรุงซ่อมแซมทรัพย์สินในด้านสาธารณประโยชน์เพื่ออำนวยความสะดวกแก่ประชาชน</p>\r\n\r\n<p>๓.๑ &nbsp;ทางระบายน้ำต้องจัดให้มีอย่างเหมาะสมและทั่วถึงทั้งตำบล</p>\r\n\r\n<p>๓.๒ &nbsp;น้ำเพื่อการเกษตร &nbsp;เช่น &nbsp;ฝายกักเก็บน้ำเพื่อการเกษตร &nbsp;ลำห้วย &nbsp;หนอง &nbsp;คลองส่งน้ำ</p>\r\n\r\n<p>๓.๓ &nbsp;การนำน้ำใต้ดินมาใช้เพื่อการเกษตรโดยคำนึงถึงธรณีพิบัติภัย</p>\r\n\r\n<p>๓.๔ &nbsp;การปรับปรุงพัฒนาคุณภาพน้ำประปา &nbsp;ทั้งปริมาณน้ำประปาอย่างเพียงพอต่อการอุปโภค</p>\r\n\r\n<p>และบริโภคทุกชุมชน</p>\r\n\r\n<p>๓.๕ &nbsp;การจัดให้มีหน่วยบรรเทาสาธารณภัย</p>\r\n\r\n<p>&ndash; รถดับเพลิง(รถน้ำ)</p>\r\n\r\n<p>&ndash; รถกู้ภัยฉุกเฉิน(EMS)</p>\r\n\r\n<p>&ndash; รถเก็บขยะ</p>\r\n\r\n<p>๓.๖ &nbsp;การขยายเขตไฟฟ้า</p>\r\n\r\n<p>&ndash; จัดให้มีไฟฟ้าส่องสว่าง</p>\r\n\r\n<p>&ndash; จัดให้มีไฟฟ้าเพื่อการเกษตร</p>\r\n\r\n<p>&ndash; จัดให้มีไฟฟ้าเพื่อการอุตสาหกรรม</p>\r\n\r\n<p>๓.๗ &nbsp;ถนนและผังเมือง</p>\r\n\r\n<p>&ndash; ลูกรัง &nbsp;คอนกรีต &nbsp;ลาดยาง</p>\r\n\r\n<p>๔.ด้านสาธารณสุข</p>\r\n\r\n<p>๑. &nbsp;สานต่อโครงการตามนโยบาย &nbsp;กาฬสินธุ์ &nbsp;๓ &nbsp;ดี &nbsp;คนดี &nbsp;สุขภาพดี &nbsp;รายได้ดี &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp;</p>\r\n\r\n<p>(๑) &nbsp;สร้างและส่งเสริมคนดีให้มีโอกาสทำงานให้กับชุมชน</p>\r\n\r\n<p>(๒) &nbsp;ส่งเสริมสนับสนุนบุคลากรทางด้านสาธารณสุขให้มีความรู้ความสามารถในการให้ความรู้กับชุมชน &nbsp;กลุ่มองค์กรในชุมชนและปัจเจกบุคคลให้สามารถดูแลสุขภาพอนามัยตนเอง ชุมชน เพื่อเป็นตำบลต้นแบบ &nbsp;ด้านสุขภาพและแนะนำผู้อื่นได้</p>\r\n\r\n<p>(๓) อปท.ต้องสร้างงานสร้างอาชีพเสริมเพื่อให้บุคคลมีงานทำอย่างต่อเนื่องยั่งยืนอันจะส่งให้ครอบครัว &nbsp;ชุมชน &nbsp;มีรายได้มากขึ้นเพื่อความสมดุลกับแนวทางหลักเศรษฐกิจพอเพียงที่มุ่งสู่การลดรายจ่ายที่เป็นองค์รวมเพื่อความอยู่ดีมีสุขของบุคคล &nbsp;ครอบครัวและชุมชน</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>/๕.ด้านการบริหารงานทั่วไปและพัฒนาองค์กร&hellip;</p>\r\n\r\n<p>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &ndash; &nbsp;๕ &nbsp;&ndash;&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>๕.ด้านการบริหารงานทั่วไปและพัฒนาองค์กร</p>\r\n\r\n<p>แนวทางการพัฒนาปรับปรุงกระบวนการพัฒนายึดหลัก &nbsp;๔ &nbsp;ป.เน้นการบริการสร้างความพึงพอใจให้แก่ประชาชน</p>\r\n\r\n<p>(๑)ประหยัด</p>\r\n\r\n<p>(๒)ประโยชน์</p>\r\n\r\n<p>(๓)ประสิทธิภาพประสิทธิผล</p>\r\n\r\n<p>(๔)เป็นธรรม</p>\r\n\r\n<p>๕.๑ &nbsp;ปรับปรุงส่งเสริมกระบวนการทำงาน &nbsp;เพิ่มศักยภาพด้านเครื่องไม้เครื่องมือทางการบริหารและการบริการที่สะดวกรวดเร็ว &nbsp;อาทิเช่น &nbsp;เพิ่มเลขหมายโทรศัพท์ &nbsp;ปรับปรุงเครื่องโทรสาร &nbsp;ปรับปรุงระบบอินเตอร์เน็ตความเร็วสูง &nbsp;เป็นต้น</p>\r\n\r\n<p>๕.๒ &nbsp;จัดวางแผนผังหรือโครงสร้างสายการบังคับบัญชาของข้าราชการ &nbsp;พนักงาน &nbsp;เจ้าหน้าที่และบทบาทหน้าที่ทุกส่วนงานให้มีความชัดเจน</p>\r\n\r\n<p>๕.๓ &nbsp;การมอบหมายหน้าที่อย่างเป็นลายลักษณ์อักษร &nbsp;ส่งเสริมให้ข้าราชการ &nbsp;พนักงาน &nbsp;เจ้าหน้าที่ &nbsp;มีความเจริญก้าวหน้า &nbsp;อาจสับเปลี่ยนหน้าที่รับผิดชอบตามความเหมาะสมภายใต้กรอบคุณวุฒิทางการศึกษา</p>\r\n\r\n<p>๕.๔ &nbsp;การประเมินผลการปฏิบัติหน้าที่ตามหลักเกณฑ์และตัวชี้วัด</p>\r\n\r\n<p>๕.๕ &nbsp;ปฏิบัติหน้าที่อื่นตามที่ได้ทางราชการมอบหมายโดยจะยึดหลักการบริหารงานตาม</p>\r\n\r\n<p>หลักธรรมาภิบาล &nbsp;ดังนี้</p>\r\n\r\n<p>(๑) หลักคุณธรรมและนิติธรรม</p>\r\n\r\n<p>(๒) หลักความรับผิดชอบ</p>\r\n\r\n<p>(๓) หลักความโปร่งใสและการตรวจสอบได้</p>\r\n\r\n<p>(๔) หลักการมีส่วนร่วม</p>\r\n\r\n<p>(๕) หลักการประสิทธิภาพและประสิทธิผล</p>\r\n\r\n<p>๕.๖ &nbsp;ส่งเสริมให้ข้าราชการ พนักงานและลูกจ้างขององค์การบริหารส่วนตำบลศรีสมเด็จ มีหน้าที่ดําเนินการให้เป็นไปตามกฎหมาย &nbsp;เพื่อรักษาประโยชน์ส่วนรวมและเทศชาติ อํานวยความสะดวกและให้บริการแก่ประชาชนตามหลักธรรมาภิบาล โดยจะต้องยึดมั่นในค่านิยมหลักของมาตรฐานจริยธรรม เพื่อยึดถือเป็นหลักการ แนวทางปฏิบัติ และเป็นเครื่องกํากับ ความประพฤติของตน ดังนี้</p>\r\n\r\n<p>๑) การยึดมั่นในคุณธรรมและจริยธรรม</p>\r\n\r\n<p>๒) การมีจิตสํานึกที่ดี ซื่อสัตย์ สุจริต และรับผิดชอบ</p>\r\n\r\n<p>๓) การยึดถือประโยชน์ของประเทศชาติเหนือกว่าประโยชน์ส่วนตน และไม่มีผลประโยชน์ทับซ้อน</p>\r\n\r\n<p>๔) การยืนหยัดทำในส่งที่ถูกต้อง เป็นธรรม และถูกกฎหมาย</p>\r\n\r\n<p>๕) การให้บริการแก่ประชาชนด้วยความรวดเร็ว มีอัธยาศัย และไม่เลือกปฏิบัติ</p>\r\n\r\n<p>๖) การให้ข้อมูลข่าวสารแก่ประชาชนอย่างครบถ้วน ถูกต้อง และไม่บิดเบือนข้อเท็จจริง</p>\r\n\r\n<p>๗) การมุ่งผลสัมฤทธิ์ของงาน รักษามาตรฐาน มีคุณภาพโปร่งใส และตรวจสอบได้</p>\r\n\r\n<p>๘) การยึดมั่นในระบอบประชาธิปไตยอันมีพระมหากษัตริย์ทรงเป็นประมุข</p>\r\n\r\n<p>๙) การยึดมั่นในหลักจรรยาวิชาชีพขององค์กร</p>\r\n\r\n<p>ทั้งนี้ การฝ่าฝืนหรือไม่ปฏิบัติตามมาตรฐานทางจริยธรรม ให้ถือว่าเป็นการกระทําผิดทางวินัย</p>\r\n\r\n<p>&ndash; &nbsp;๖ &nbsp;&ndash;</p>\r\n\r\n<p>๕.๗ &nbsp;ส่งเสริมการพัฒนาศักยภาพบุคลากร &nbsp;ทั้งฝ่ายประจำและฝ่ายการเมืองเพื่อเพิ่มประสิทธิภาพการบริหารงานขององค์การบริหารส่วนตำบลอย่างต่อเนื่องทุกปี &nbsp;ทั้งทางด้านการศึกษา &nbsp;ด้านการฝึกอบรม &nbsp;ศึกษาดูงาน &nbsp;ด้านเทคโนโลยีเพิ่มพูนความรู้ให้ทันสมัยอยู่เสมอ &nbsp;เพื่อรองรับการเปิดการค้าเสรีอาเซียน &nbsp;(AEC)</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>๖.ด้านทรัพยากรธรรมชาติและสิ่งแวดล้อม</p>\r\n\r\n<p>-การพัฒนาแหล่งน้ำตามธรรมชาติทุกแหล่งน้ำ &nbsp;เช่นการขุดลอกห้วย &nbsp;หนองคลอง &nbsp;บึง</p>\r\n\r\n<p>-ซ่อมแซมและปรับปรุง &nbsp;ก่อสร้างฝายน้ำล้น &nbsp;ขุดเจาะน้ำเพื่อการเกษตร</p>\r\n\r\n<p>-จัดการแก้ไขปัญหาเรื่องขยะมูลฝอยสิ่งปฎิกูล &nbsp;ทำให้ตำบลศรีสมเด็จสะอาดและมีความสวยงาม</p>\r\n\r\n<p>&ndash;ปรับปรุงภูมิทัศน์ตำบลศรีสมเด็จให้สวยงาม</p>\r\n\r\n<p>-ปรับปรุงภูมิทัศน์สระน้ำโคกหนองกุงให้สวยงานเป็นที่พักผ่อนหย่อนใจแก่ประชาชน</p>\r\n\r\n<p>-จัดให้มีรถเก็บขยะมูลกำจัดขยะฝอยสิ่งปฏิกูล</p>\r\n\r\n<p>๖.๑ &nbsp;การจัดให้มีเขตทิ้งขยะ</p>\r\n\r\n<p>-จัดให้มีสถานที่ทิ้งขยะ</p>\r\n\r\n<p>-จัดให้มีรถเก็บขยะ</p>\r\n\r\n<p>&ndash; ขยะเปียก</p>\r\n\r\n<p>&ndash; ขยะแห้ง</p>\r\n\r\n<p>&ndash; ขยะที่นำกลับมาใช้ใหม่ได้ &nbsp;( Recycle )</p>\r\n\r\n<p>๖.๒ &nbsp;การพัฒนาทรัพยากรธรรมชาติและสิ่งแวดล้อม</p>\r\n\r\n<p>&ndash; ป่าชุมชนและป่าสาธารณะ</p>\r\n\r\n<p>&ndash; การพัฒนาป่าเชิงนิเวศวิทยาและการท่องเที่ยว</p>\r\n\r\n<p>๖.๓ &nbsp;ปรับปรุงภูมิทัศน์ตำบลศรีสมเด็จให้สวยงาม</p>\r\n\r\n<p>ท่านประธานสภาองค์การบริหารส่วนตำบลศรีสมเด็จที่เคารพ</p>\r\n\r\n<p>นโยบายทั้งหมดที่ได้นำเสนอมานี้ &nbsp;นายกองค์การบริหารส่วนตำบลศรีสมเด็จได้กำหนดขึ้นโดยคำนึงถึงเจตจำนงของบทกฎหมายที่เกี่ยวข้อง รวมทั้งความมุ่งมั่นของนายกองค์การบริหารส่วนตำบลศรีสมเด็จที่จะแก้ไขปัญหาของตำบลศรีสมเด็จที่กำลังเผชิญอยู่ &nbsp;โดยเฉพาะการสร้างความสามัคคี &nbsp;ปรองดอง &nbsp;ให้เกิดขึ้นในชุมชน &nbsp;ซึ่งในการบริหารราชการองค์การบริหารส่วนตำบลศรีสมเด็จจะได้เร่งดำเนินการให้เป็นรูปธรรม &nbsp;โดยจัดทำรายละเอียดการดำเนินการ &nbsp;ประกอบด้วย &nbsp;แผนปฏิบัติราชการของส่วนราชการต่างๆ &nbsp;แผนยุทธศาสตร์การพัฒนา &nbsp;แผนพัฒนาสามปี &nbsp;แผนการดำเนินงานประจำปี &nbsp;เพื่อเป็นแนวทางการบริหารราชการองค์การบริหารส่วนตำบลศรีสมเด็จ &nbsp;อย่างไรก็ดี &nbsp;กรณีมีความจำเป็นจะต้องปรับปรุงนโยบายของนายกองค์การบริหารส่วนตำบลศรีสมเด็จอันเนื่องมาจากปัจจัยที่มีผลกระทบจากสถานการณ์ด้านเศรษฐกิจ &nbsp;สังคมและวัฒนธรรมที่เปลี่ยนแปลงอย่างรวดเร็วตลอดเวลาและอยู่เหนือการคาดการณ์ &nbsp;นายกองค์การบริหารส่วนตำบลศรีสมเด็จจะรายงานให้สภาองค์การบริหารส่วนตำบลศรีสมเด็จทราบต่อไป</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>นายกองค์การบริหารส่วนตำบลศรีสมเด็จจะบริหารราชการองค์การบริหารส่วนตำบลศรีสมเด็จ &nbsp;ด้วยความซื่อสัตย์สุจริต &nbsp;และมีประสิทธิภาพ &nbsp;มุ่งมั่นที่จะให้ตำบลศรีสมเด็จมีความเจริญรุ่งเรือง &nbsp;มีความสามัคคี &nbsp;ปรองดอง &nbsp;และมีความยุติธรรม &nbsp;นายกองค์การบริหารส่วนตำบลศรีสมเด็จมุ่งมั่นจะทำให้พี่น้องประชาชนตำบลศรีสมเด็จมีความสุขทุกคน</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>ทั้งนี้ &nbsp;ตั้งแต่บัดนี้เป็นต้นไป</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>นายเตียง &nbsp;บุญสิงห์</p>\r\n\r\n<p>นายกองค์การบริหารส่วนตำบลศรีสมเด็จ</p>\r\n\r\n<p>&nbsp; พฤศจิกายน &nbsp;๒๕๕๖</p>\r\n\r\n<p>ขอขอบคุณครับ</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&nbsp;วิสัยทัศน์</p>\r\n\r\n<p>&ldquo; &nbsp;ชุมชนน่าอยู่ &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; สู่เศรษฐกิจพอเพียง</p>\r\n\r\n<p>พัฒนาโครงสร้างพื้นฐานและการศึกษา &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; ฟื้นฟูประเพณีวัฒนธรรมภูมิปัญญา</p>\r\n\r\n<p>สุขภาพดีถ้วนหน้า &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;อนุรักษ์ทรัพยากรธรรมชาติและสิ่งแวดล้อม &rdquo;</p>\r\n\r\n<p>พันธกิจ</p>\r\n\r\n<p>มุ่งเน้นการแก้ไขปัญหาความยากจน ให้พ้นเกณฑ์ จปฐ. โดยใช้หลักเศรษฐกิจพอเพียง<br />\r\nส่งเสริมการศึกษา &nbsp;ศาสนา &nbsp;วัฒนธรรมและฟื้นฟูภูมิปัญญาท้องถิ่น<br />\r\nส่งเสริมสนับสนุนการให้บริการสาธารณสุขแก่ชุมชน<br />\r\nเสริมสร้างความเข้มแข็งให้ชุมชนและให้สังคมสงบสุข<br />\r\nส่งเสริมการพัฒนาผลผลิตทางการเกษตรและอุตสาหกรรมในครัวเรือนให้มีคุณภาพ<br />\r\nอนุรักษ์ทรัพยากรธรรมชาติและสิ่งแวดล้อม</p>\r\n', NULL, NULL),
(60, 1, 16, 'กฎ ระเบียบ ข้อบังคับ', 1, '', NULL, NULL),
(61, 1, 17, 'ประวัติและความเป็นมา', 1, NULL, NULL, NULL),
(62, 1, 18, 'นำมวลชนเฝ้ารับ-ส่งเสด็จฯสมเด็จพระเทพรัตนราชสุดาฯ สยามบรมราชกุมารี', 1, '', NULL, NULL),
(63, 1, 19, 'ร้องทุกข์ - ร้องเรียน', 1, '<p style=\"text-align:center\"><img alt=\"\" src=\"http://website-thai.com/project/kudnokplao/upload/userfile/images/1839.jpg\" style=\"height:317px; width:784px\" /></p>\r\n\r\n<p>ศูนย์รับเรื่องร้องเรียน/ร้องทุกข์ เทศบาลตำบลกุดนกเปล้า</p>\r\n\r\n<p>&nbsp;ศูนย์รับเรื่องร้องเรียน/ร้องทุกข์ เทศบาลตำบลกุดนกเปล้า &nbsp;จัดตั้งขึ้นตามพระราชกฤษฎีกาว่าด้วย หลักเกณฑ์และวิธีการบริหารกิจการบ้านเมืองที่ดี พ.ศ.2546 มาตรา 41 ซึ่งกำหนดให้ส่วนราชการที่ได้รับคำร้องเรียน เสนอแนะ หรือความคิดเห็นเกี่ยวกับวิธีปฏิบัติราชการ อุปสรรค ความยุ่งยาก หรือปัญหาอื่นใดจากบุคคลใด โดยมีข้อมูลและสาระตามสมควร ให้เป็นหน้าที่ของส่วนราชการนั้นที่จะต้องพิจารณาดำเนินการให้ลุล่วงไป และในกรณีที่มีที่อยู่ของบุคคลนั้นให้แจ้งให้บุคคลนั้นทราบผลการดำเนินการด้วย</p>\r\n\r\n<p>&nbsp;&nbsp;&nbsp;&nbsp; ดังนั้น เพื่อให้การดำเนินการเรื่องร้องเรียนร้องทุกข์ของประชาชนเป็นไปด้วยความเรียบร้อยและมีประสิทธิภาพ ตอบสนองความต้องการของประชาชนในเขตเทศบาล เทศบาลตำบลกุดนกเปล้าจัดตั้ง&nbsp;&quot;<span style=\"color:#0000FF\"><strong>ศูนย์รับเรื่องร้องเรียน/ร้องทุกข์ เทศบาลตำบลกุดนกเปล้า </strong></span>ขึ้น ณ จุดประชาสัมพันธ์ และงานป้องกันและบรรเทาสาธารณภัย &nbsp;อาคารสำนักงานเทศบาลตำบลกุดนกเปล้า &nbsp;เพื่อให้ประชาชนสามารถยื่นเรื่องร้องเรียน/ร้องทุกข์ ได้โดยสะดวก และให้งานป้องกันและบรรเทาสาธารณภัย เป็นผู้ควบคุมดูแลรับผิดชอบการดำเนินงานของศูนย์ฯ</p>\r\n\r\n<p><strong><span style=\"background-color:#00FFFF\">สถานที่ตั้ง &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp;</span></strong></p>\r\n\r\n<p style=\"text-align:center\">สำนักงานเทศบาลตำบลกุดนกเปล้า</p>\r\n\r\n<p style=\"text-align:center\">งานประชาสัมพันธ์/งานป้องกันและบรรเทาสาธารณภัย</p>\r\n\r\n<p style=\"text-align:center\">&nbsp;99&nbsp; หมู่ที่ 1 ตำบลกุดนกเปล้า&nbsp; อำเภอเมืองสระบุรี&nbsp; จังหวัดสระบุรี</p>\r\n\r\n<p><strong><span style=\"background-color:rgb(0, 255, 255)\">ช่องทางให้บริการ/ขั้นตอนการปฏิบัติการดำเนินการเรื่องร้องเรียน/ ร้องทุกข์ เทศบาลตำบลกุดนกเปล้า &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;</span></strong></p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&nbsp; &nbsp; &nbsp;1. ร้องเรียน/ร้องทุกข์ด้วยตนเองที่ ศูนย์รับเรื่องร้องเรียน/ร้องทุกข์ จุดประชาสัมพันธ์ / งานป้องกันและบรรเทาสาธารณภัย อาคารสำนักงานเทศบาลตำบลกุดนกเปล้า</p>\r\n\r\n<p>&nbsp;&nbsp;&nbsp;&nbsp; 2. ทางโทรศัพท์ หมายเลข&nbsp;036-901313 &nbsp;(ในเวลาราชการ) หรือ&nbsp;036-901913 (นอกเวลาราชการ)</p>\r\n\r\n<p>&nbsp;&nbsp;&nbsp;&nbsp; 3. ทางโทรสาร หมายเลข&nbsp;036-901914</p>\r\n\r\n<p>&nbsp;&nbsp;&nbsp;&nbsp; 4. คลื่นความถี่วิทยุ &nbsp;หมายเลข&nbsp;162.775</p>\r\n\r\n<p>&nbsp;&nbsp;&nbsp;&nbsp; 5. ทาง ตู้ ปณ.&nbsp; สำนักงานเทศบาลตำบลกุดนกเปล้า 99 หมู่ที่ 1 ตำบลกุดนกเปล้า&nbsp; อำเภอเมืองสระบุรี</p>\r\n\r\n<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; จังหวัดสระบุรี&nbsp; 18000</p>\r\n\r\n<p>&nbsp;&nbsp;&nbsp;&nbsp; 6. ทางจดหมายอิเล็กทรอนิกส์(e-mail) :&nbsp;<a href=\"mailto:aissara1973@hotmail.com\">aissara1973@hotmail.com</a></p>\r\n\r\n<p>&nbsp;&nbsp;&nbsp;&nbsp; 7. ทาง Facebook Fanpage :&nbsp;<a href=\"https://www.facebook.com/%E0%B9%80%E0%B8%97%E0%B8%A8%E0%B8%9A%E0%B8%B2%E0%B8%A5%E0%B8%95%E0%B8%B3%E0%B8%9A%E0%B8%A5%E0%B8%81%E0%B8%B8%E0%B8%94%E0%B8%99%E0%B8%81%E0%B9%80%E0%B8%9B%E0%B8%A5%E0%B9%89%E0%B8%B2-426010670930606/?ref=ts&amp;fref=ts\"><strong>เทศบาลตำบลกุดนกเปล้า</strong></a></p>\r\n\r\n<p>&nbsp;&nbsp;&nbsp;&nbsp; 8. ทาง Website :&nbsp;<a href=\"http://www.kudnokplao.go.th/\">www.kudnokplao.go.th</a> &nbsp;ที่เมนู&nbsp;&quot;<a href=\"http://www.kudnokplao.go.th/index.php?route=page_forum\">กระดานถาม-ตอบ</a>&quot;&nbsp;ห้องรับเรื่องร้องเรียน-ร้องทุกข์&nbsp;&nbsp;(ซึ่งจะต้องสมัครเป็นสมาชิกเว็บก่อน จึงจะเขียนเรื่องร้องเรียน/ร้องทุกข์ได้ วิธีการสมัครดูที่หน้า&nbsp;&quot;<a href=\"http://www.kudnokplao.go.th/index.php?route=page_forum\">กระดานถาม-ตอบ</a>&quot;&nbsp;)</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p style=\"text-align:center\">&nbsp;</p>\r\n', NULL, NULL),
(64, 1, 20, 'ทดสอบ2', 1, '', NULL, NULL),
(65, 1, 21, 'ข่าวกิจกรรม 1', 1, '<p>03 ก.พ. 2560 การบันทึกข้อมูลจากการสำรวจข้อมูลเพื่อจัดทำแผนพัฒนาเศรษฐกิจพอเพียงท้องถิ่น (ด้านการเกษตรและแหล่งน้ำ) (Local Sufficiency Economy Plan : LSEP) ประจำปีงบประมาณ พ.ศ.2560 ในระบบข้อมูลกลางองค์กรปกครองส่วนท้องถิ่น</p>\r\n', NULL, NULL),
(66, 1, 22, 'ข่าวกิจกรรม 2', 1, '<p><span style=\"color:rgb(129, 139, 149); font-family:arial; font-size:18px\">03 ก.พ. 2560 การบันทึกข้อมูลจากการสำรวจข้อมูลเพื่อจัดทำแผนพัฒนาเศรษฐกิจพอเพียงท้องถิ่น (ด้านการเกษตรและแหล่งน้ำ) (Local Sufficiency Economy Plan : LSEP) ประจำปีงบประมาณ พ.ศ.2560 ในระบบข้อมูลกลางองค์กรปกครองส่วนท้องถิ่น</span></p>\r\n', NULL, NULL),
(67, 1, 23, 'ข่าวกิจกรรม 3', 1, '<p><span style=\"color:rgb(129, 139, 149); font-family:arial; font-size:18px\">03 ก.พ. 2560 การบันทึกข้อมูลจากการสำรวจข้อมูลเพื่อจัดทำแผนพัฒนาเศรษฐกิจพอเพียงท้องถิ่น (ด้านการเกษตรและแหล่งน้ำ) (Local Sufficiency Economy Plan : LSEP) ประจำปีงบประมาณ พ.ศ.2560 ในระบบข้อมูลกลางองค์กรปกครองส่วนท้องถิ่น</span></p>\r\n', NULL, NULL),
(68, 1, 24, 'ข่าวกิจกรรม 4', 1, '<p><span style=\"color:rgb(129, 139, 149); font-family:arial; font-size:18px\">03 ก.พ. 2560 การบันทึกข้อมูลจากการสำรวจข้อมูลเพื่อจัดทำแผนพัฒนาเศรษฐกิจพอเพียงท้องถิ่น (ด้านการเกษตรและแหล่งน้ำ) (Local Sufficiency Economy Plan : LSEP) ประจำปีงบประมาณ พ.ศ.2560 ในระบบข้อมูลกลางองค์กรปกครองส่วนท้องถิ่น</span></p>\r\n', NULL, NULL),
(69, 1, 45, 'กระดานกระทู้', 0, '', NULL, NULL),
(70, 1, 25, '03 ก.พ. 2560 เครื่องกดบัตรคิว 1', 1, NULL, NULL, NULL),
(71, 1, 26, '03 ก.พ. 2560 เครื่องกดบัตรคิว', 1, '', NULL, NULL),
(72, 1, 27, '03 ก.พ. 2560 เครื่องกดบัตรคิว', 1, '', NULL, NULL),
(73, 1, 28, '03 ก.พ. 2560 เครื่องกดบัตรคิว', 1, '', NULL, NULL),
(74, 1, 46, 'รูปสไลด์', 0, '', NULL, NULL),
(75, 1, 29, 'รูปสไลด์ที่ 1', 1, '<p>ss</p>\r\n', NULL, NULL),
(76, 1, 30, 'รูปสไลด์ที่ 2', 1, '', NULL, NULL),
(77, 1, 31, 'รูปสไลด์ที่ 3', 1, '', NULL, NULL),
(78, 1, 32, 'รูปสไลด์ที่ 4', 1, '', NULL, NULL),
(80, 1, 47, 'เมนูด้านซ้าย(รูป)', 0, '', NULL, NULL),
(81, 1, 48, 'ข่าวประชาสัมพันธ์', 0, '', NULL, NULL),
(82, 1, 49, 'ข่าวจัดซื้อจัดจ้าง', 0, '', NULL, NULL),
(83, 1, 50, 'หนังสือสั่งการจากกรมส่งเสริมการปกครองท้องถิ่น', 0, '', NULL, NULL),
(84, 1, 51, 'ข้อมูลพื้นฐาน', 0, '', NULL, NULL),
(85, 1, 52, 'ผลการดำเนินงาน', 0, '', NULL, NULL),
(86, 1, 53, 'อำนาจหน้าที่', 0, '', NULL, NULL),
(87, 1, 54, 'แผนพัฒนาท้องถิ่น', 0, '', NULL, NULL),
(88, 1, 55, 'บุคลากร', 0, '', NULL, NULL),
(89, 1, 0, '', 1, '', NULL, NULL),
(90, 1, 0, 'ev2', 1, '', NULL, NULL),
(91, 1, 0, 'คณะผู้บริหาร', 1, '<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" style=\"width:100%\">\r\n	<tbody>\r\n		<tr>\r\n			<td>&nbsp;</td>\r\n			<td style=\"text-align: center;\">\r\n			<p><img alt=\"\" src=\"http://www.website-thai.com/project/huayjod/upload/userfile/images/0(1).png\" style=\"height:175px; width:150px\" /></p>\r\n\r\n			<p>&nbsp;</p>\r\n			</td>\r\n			<td>&nbsp;</td>\r\n		</tr>\r\n		<tr>\r\n			<td style=\"text-align: center;\"><img alt=\"\" src=\"http://www.website-thai.com/project/huayjod/upload/userfile/images/2.png\" style=\"height:175px; width:150px\" /></td>\r\n			<td>&nbsp;</td>\r\n			<td>&nbsp;</td>\r\n		</tr>\r\n		<tr>\r\n			<td>&nbsp;</td>\r\n			<td>&nbsp;</td>\r\n			<td>&nbsp;</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n\r\n<p>&nbsp;</p>\r\n', NULL, NULL),
(92, 1, 0, 'คณะผู้บริหาร', 1, '<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" style=\"width:100%\">\r\n	<tbody>\r\n		<tr>\r\n			<td>&nbsp;</td>\r\n			<td>&nbsp;</td>\r\n			<td>&nbsp;</td>\r\n		</tr>\r\n		<tr>\r\n			<td>&nbsp;</td>\r\n			<td>&nbsp;</td>\r\n			<td>&nbsp;</td>\r\n		</tr>\r\n		<tr>\r\n			<td>&nbsp;</td>\r\n			<td>&nbsp;</td>\r\n			<td>&nbsp;</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n\r\n<p>&nbsp;</p>\r\n', NULL, NULL),
(93, 1, 0, 'คณะผู้บริหาร', 1, '', NULL, NULL),
(94, 1, 0, 'คณะผู้บริหาร', 1, '', NULL, NULL),
(95, 1, 0, 'คณะผู้บริหาร', 1, '', NULL, NULL),
(96, 1, 41, 'โครงสร้างองค์กร', 1, '<p style=\"text-align: center;\"><img alt=\"\" src=\"http://www.website-thai.com/project/kudnokplao/upload/userfile/images/screencapture-kudnokplao-go-th-orgchart-php-1489666150597.png\" style=\"height:1200px; width:869px\" /></p>\r\n', NULL, NULL),
(97, 1, 42, 'อิื', 1, '', NULL, NULL),
(98, 1, 43, ' วิสัยทัศน์และพันธกิจ', 1, NULL, NULL, NULL),
(99, 1, 44, 'สภาพทางเศรษฐกิจ', 1, NULL, NULL, NULL);
INSERT INTO `mhd_language_detail` (`id`, `language_id`, `ref_id`, `name`, `type`, `detail`, `detail_2`, `detail_3`) VALUES
(100, 1, 45, 'สภาพทั่วไป ', 1, '<h2 style=\"text-align:center\"><strong>ประวัติตำบล&nbsp;</strong></h2>\r\n\r\n<p style=\"text-align:center\"><span style=\"color:rgb(0, 153, 0); font-family:ms sans serif; font-size:14px\">เดิมสภาพพื้นที่ของตำบล เป็นป่าโปรงและทุ่งหญ้า มีลำคลอง 2 สาย คือคลองสาริกา คลองกุดนกเปล้า มีต้นไม้เบญจพรรณ จำนวนมากและบริเวณหมู่3 มีกุดและบึงซึ่งเป็นที่อยู่อาศัยของนกเปล้า ลักษณะของนกเปล้าจะเป็นนกประเภทเดียวกับนกเขา ตัวผู้ปีกหลัง และคอจะมีสีแดง ส่วนตัวเมียจะเป็นสีเขียวล้วน เมื่อมีการอพยพ ของราษฎรมาจากภาคอีสานและบางส่วนมาจากเวียงจันทร์ ประเทศลาวและตั้งชุมชนขึ้นเรียกว่าบ้านกุดนกเปล้าและต่อมายกขึ้น เป็นตำบล มีเขตการปกครองจำนวน 8 หมู่บ้าน</span></p>\r\n\r\n<p style=\"text-align:center\"><img src=\"http://www.kudnokplao.go.th/image/condition/condition_11.jpg\" style=\"color:rgb(0, 0, 0); font-family:times new roman; font-size:medium; height:154px; text-align:-webkit-center; width:250px\" /></p>\r\n\r\n<p style=\"text-align:center\">&nbsp;</p>\r\n\r\n<h2 style=\"text-align:center\"><strong>ประวัติหน่วยงาน</strong></h2>\r\n\r\n<p style=\"text-align: center;\"><span style=\"color:rgb(0, 102, 255); font-family:ms sans serif; font-size:14px\">เทศบาลตำบลกุดนกเปล้าได้รับการยกฐานะเป็นเทศบาลตำบล ตามพระราชบัญญัติสภาตำบลและองค์การ บริหารส่วนตำบล พ.ศ. 2537 ซึ่งแก้ไขเพิ่มเติมโดยพระราชบัญญัติสภาตำบลและองค์การบริหารส่วนตำบล (ฉบับที่5) พ.ศ. 2546 และมาตรา 7 แห่งพระราชบัญญัติเทศบาล พ.ศ. 2496 ตามประกาศกระทรวงมหาดไทย เมื่อวันที่ 19 เดือน กรกฎาคม พ.ศ. 2550 ให้องค์การบริหารส่วนตำบลกุดนกเปล้ายกฐานะเป็นเทศบาลตำบล</span></p>\r\n\r\n<h2 style=\"text-align: center;\"><strong>ที่ตั้งและอาณาเขต</strong></h2>\r\n\r\n<p style=\"text-align: center;\"><span style=\"color:rgb(255, 102, 0); font-family:ms sans serif; font-size:14px\">เทศบาลตำบลกุดนกเปล้า ตั้งอยู่เลขที่ 99 หมู่ที่ 1 ตำบลกุดนกเปล้า อำเภอเมือง จังหวัดสระบุรี อยู่ทางทิศตะวันออกของอำเภอเมืองสระบุรี อยู่ห่างจากอำเภอเมืองสระบุรีประมาณ 7 กิโลเมตร มีเนื้อที่โดยรวมประมาณ 31.25 ตารางกิโลเมตร หรือประมาณ 19,531.87 / ไร่</span></p>\r\n\r\n<h2 style=\"text-align:center\"><strong>อาณาเขตติดต่อ</strong></h2>\r\n\r\n<p style=\"text-align: center;\"><img alt=\"\" src=\"http://www.website-thai.com/project/kudnokplao/upload/userfile/images/123.JPG\" style=\"height:134px; width:518px\" /></p>\r\n\r\n<p style=\"text-align: center;\"><img alt=\"\" src=\"http://www.website-thai.com/project/kudnokplao/upload/userfile/images/condition_29 - Copy.jpg\" style=\"height:284px; width:445px\" /></p>\r\n\r\n<h2 style=\"text-align:center\"><strong>จำนวนประชากร</strong></h2>\r\n\r\n<p style=\"text-align: center;\"><span style=\"color:rgb(0, 102, 255); font-family:ms sans serif; font-size:14px\">ประชากรทั้งสิ้น 5,326 คน</span></p>\r\n\r\n<p style=\"text-align: center;\">&nbsp;</p>\r\n\r\n<p style=\"text-align: center;\">เป็นชาย 2,576 คน<span class=\"Apple-tab-span\" style=\"white-space:pre\"> </span>คิดเป็นร้อยละ 48.37</p>\r\n\r\n<p style=\"text-align: center;\">เป็นหญิง 2,750 คน<span class=\"Apple-tab-span\" style=\"white-space:pre\"> </span>คิดเป็นร้อยละ 51.63</p>\r\n\r\n<p style=\"text-align: center;\"><span style=\"color:rgb(0, 102, 255); font-family:ms sans serif; font-size:14px; text-align:start\">ความหนาแน่นเฉลี่ย 170 คน/ตารางกิโลเมตร &nbsp;</span><span style=\"color:rgb(0, 102, 255); font-family:ms sans serif; font-size:14px\">จำนวนครัวเรือนทั้งหมด 1,389 ครัวเรือน</span></p>\r\n\r\n<p style=\"text-align: center;\">&nbsp;</p>\r\n\r\n<h2 style=\"text-align: center;\"><strong>สภาพภูมิประเทศ</strong></h2>\r\n\r\n<p style=\"text-align: center;\"><img src=\"http://www.kudnokplao.go.th/image/condition/condition_41.jpg\" style=\"color:rgb(0, 0, 0); font-family:times new roman; font-size:medium; height:154px; width:250px\" /></p>\r\n\r\n<p style=\"text-align: center;\"><span style=\"color:rgb(0, 153, 0); font-family:ms sans serif; font-size:14px\">พื้นที่เทศบาลตำบลกุดนกเปล้า ส่วนใหญ่เป็นที่ราบสลับ ภูเขา เหมาะแก่การเพาะปลูกพืชไร่ ทำนา พืชสวนและเลี้ยงสัตว์ ซึ่งมี ความสำคัญต่อเศรษฐกิจของประเทศ</span></p>\r\n\r\n<p style=\"text-align: center;\">&nbsp;</p>\r\n\r\n<h2 style=\"text-align: center;\"><strong>เขตการปกครอง</strong></h2>\r\n\r\n<p style=\"text-align: center;\">&nbsp;</p>\r\n\r\n<table align=\"center\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" style=\"color:rgb(0, 0, 0); font-family:times new roman; font-size:medium; width:500px\">\r\n	<tbody>\r\n		<tr>\r\n			<td>\r\n			<table align=\"center\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" style=\"width:500px\">\r\n				<tbody>\r\n					<tr>\r\n						<td>&nbsp;</td>\r\n					</tr>\r\n					<tr>\r\n						<td valign=\"top\">\r\n						<table align=\"center\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" style=\"width:500px\">\r\n							<tbody>\r\n								<tr>\r\n									<td background=\"http://www.kudnokplao.go.th/image/condition/condition_51.gif\" width=\"10\"><img src=\"http://www.kudnokplao.go.th/image/58_08_07/condition_48.gif\" style=\"height:51px; width:1px\" /></td>\r\n									<td align=\"center\" background=\"http://www.kudnokplao.go.th/image/condition/condition_51.gif\" class=\"txt_white\" style=\"font-family: &quot;MS Sans Serif&quot;; font-size: 14px; line-height: 25px; color: rgb(255, 255, 255);\" width=\"50\">ชุมชนที่</td>\r\n									<td align=\"center\" background=\"http://www.kudnokplao.go.th/image/condition/condition_51.gif\" class=\"txt_white\" style=\"font-family: &quot;MS Sans Serif&quot;; font-size: 14px; line-height: 25px; color: rgb(255, 255, 255);\" width=\"20\">&nbsp;</td>\r\n									<td align=\"center\" background=\"http://www.kudnokplao.go.th/image/condition/condition_51.gif\" class=\"txt_white\" style=\"font-family: &quot;MS Sans Serif&quot;; font-size: 14px; line-height: 25px; color: rgb(255, 255, 255);\" width=\"124\">ชื่อชุมชน</td>\r\n									<td background=\"http://www.kudnokplao.go.th/image/condition/condition_51.gif\" class=\"txt_white\" colspan=\"3\" style=\"font-family: &quot;MS Sans Serif&quot;; font-size: 14px; line-height: 25px; color: rgb(255, 255, 255);\" valign=\"middle\">\r\n									<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" style=\"width:210px\">\r\n										<tbody>\r\n											<tr>\r\n												<td align=\"center\" colspan=\"3\">จำนวนประชากร(คน)</td>\r\n											</tr>\r\n											<tr>\r\n												<td align=\"center\" width=\"70\">ชาย</td>\r\n												<td align=\"center\" width=\"70\">หญิง</td>\r\n												<td align=\"center\" width=\"70\">รวม</td>\r\n											</tr>\r\n										</tbody>\r\n									</table>\r\n									</td>\r\n									<td align=\"center\" background=\"http://www.kudnokplao.go.th/image/condition/condition_51.gif\" class=\"txt_white\" style=\"font-family: &quot;MS Sans Serif&quot;; font-size: 14px; line-height: 25px; color: rgb(255, 255, 255);\" width=\"70\">จำนวน<br />\r\n									ครัวเรือน</td>\r\n									<td align=\"right\" background=\"http://www.kudnokplao.go.th/image/condition/condition_51.gif\" width=\"16\"><img src=\"http://www.kudnokplao.go.th/image/58_08_07/condition_48.gif\" style=\"height:51px; width:1px\" /></td>\r\n								</tr>\r\n								<tr>\r\n									<td height=\"25\">&nbsp;</td>\r\n									<td align=\"center\" class=\"txt_blue\" style=\"font-family: &quot;MS Sans Serif&quot;; font-size: 14px; line-height: 25px; color: rgb(0, 102, 255);\">1</td>\r\n									<td class=\"txt_blue\" style=\"font-family: &quot;MS Sans Serif&quot;; font-size: 14px; line-height: 25px; color: rgb(0, 102, 255);\">&nbsp;</td>\r\n									<td class=\"txt_blue\" style=\"font-family: &quot;MS Sans Serif&quot;; font-size: 14px; line-height: 25px; color: rgb(0, 102, 255);\">&nbsp;</td>\r\n									<td align=\"center\" class=\"txt_blue\" style=\"font-family: &quot;MS Sans Serif&quot;; font-size: 14px; line-height: 25px; color: rgb(0, 102, 255);\">207</td>\r\n									<td align=\"center\" class=\"txt_blue\" style=\"font-family: &quot;MS Sans Serif&quot;; font-size: 14px; line-height: 25px; color: rgb(0, 102, 255);\">249</td>\r\n									<td align=\"center\" class=\"txt_blue\" style=\"font-family: &quot;MS Sans Serif&quot;; font-size: 14px; line-height: 25px; color: rgb(0, 102, 255);\">456</td>\r\n									<td align=\"center\" class=\"txt_blue\" style=\"font-family: &quot;MS Sans Serif&quot;; font-size: 14px; line-height: 25px; color: rgb(0, 102, 255);\">110</td>\r\n									<td align=\"right\">&nbsp;</td>\r\n								</tr>\r\n								<tr>\r\n									<td background=\"http://www.kudnokplao.go.th/image/condition/condition_24.gif\"><img src=\"http://www.kudnokplao.go.th/image/condition/condition_22.gif\" style=\"height:29px; width:1px\" /></td>\r\n									<td align=\"center\" background=\"http://www.kudnokplao.go.th/image/condition/condition_24.gif\" class=\"txt_black\" style=\"font-family: &quot;MS Sans Serif&quot;; font-size: 14px; line-height: 25px; color: rgb(51, 51, 51);\">2</td>\r\n									<td background=\"http://www.kudnokplao.go.th/image/condition/condition_24.gif\" class=\"txt_black\" style=\"font-family: &quot;MS Sans Serif&quot;; font-size: 14px; line-height: 25px; color: rgb(51, 51, 51);\">&nbsp;</td>\r\n									<td background=\"http://www.kudnokplao.go.th/image/condition/condition_24.gif\" class=\"txt_black\" style=\"font-family: &quot;MS Sans Serif&quot;; font-size: 14px; line-height: 25px; color: rgb(51, 51, 51);\">&nbsp;</td>\r\n									<td align=\"center\" background=\"http://www.kudnokplao.go.th/image/condition/condition_24.gif\" class=\"txt_black\" style=\"font-family: &quot;MS Sans Serif&quot;; font-size: 14px; line-height: 25px; color: rgb(51, 51, 51);\" width=\"70\">329</td>\r\n									<td align=\"center\" background=\"http://www.kudnokplao.go.th/image/condition/condition_24.gif\" class=\"txt_black\" style=\"font-family: &quot;MS Sans Serif&quot;; font-size: 14px; line-height: 25px; color: rgb(51, 51, 51);\" width=\"70\">317</td>\r\n									<td align=\"center\" background=\"http://www.kudnokplao.go.th/image/condition/condition_24.gif\" class=\"txt_black\" style=\"font-family: &quot;MS Sans Serif&quot;; font-size: 14px; line-height: 25px; color: rgb(51, 51, 51);\" width=\"70\">646</td>\r\n									<td align=\"center\" background=\"http://www.kudnokplao.go.th/image/condition/condition_24.gif\" class=\"txt_black\" style=\"font-family: &quot;MS Sans Serif&quot;; font-size: 14px; line-height: 25px; color: rgb(51, 51, 51);\">161</td>\r\n									<td align=\"right\" background=\"http://www.kudnokplao.go.th/image/condition/condition_24.gif\"><img src=\"http://www.kudnokplao.go.th/image/condition/condition_22.gif\" style=\"height:29px; width:1px\" /></td>\r\n								</tr>\r\n								<tr>\r\n									<td height=\"25\">&nbsp;</td>\r\n									<td align=\"center\" class=\"txt_blue\" style=\"font-family: &quot;MS Sans Serif&quot;; font-size: 14px; line-height: 25px; color: rgb(0, 102, 255);\">3</td>\r\n									<td class=\"txt_blue\" style=\"font-family: &quot;MS Sans Serif&quot;; font-size: 14px; line-height: 25px; color: rgb(0, 102, 255);\">&nbsp;</td>\r\n									<td class=\"txt_blue\" style=\"font-family: &quot;MS Sans Serif&quot;; font-size: 14px; line-height: 25px; color: rgb(0, 102, 255);\">&nbsp;</td>\r\n									<td align=\"center\" class=\"txt_blue\" style=\"font-family: &quot;MS Sans Serif&quot;; font-size: 14px; line-height: 25px; color: rgb(0, 102, 255);\">709</td>\r\n									<td align=\"center\" class=\"txt_blue\" style=\"font-family: &quot;MS Sans Serif&quot;; font-size: 14px; line-height: 25px; color: rgb(0, 102, 255);\">744</td>\r\n									<td align=\"center\" class=\"txt_blue\" style=\"font-family: &quot;MS Sans Serif&quot;; font-size: 14px; line-height: 25px; color: rgb(0, 102, 255);\">1,453</td>\r\n									<td align=\"center\" class=\"txt_blue\" style=\"font-family: &quot;MS Sans Serif&quot;; font-size: 14px; line-height: 25px; color: rgb(0, 102, 255);\">354</td>\r\n									<td align=\"right\">&nbsp;</td>\r\n								</tr>\r\n								<tr>\r\n									<td background=\"http://www.kudnokplao.go.th/image/condition/condition_24.gif\"><img src=\"http://www.kudnokplao.go.th/image/condition/condition_22.gif\" style=\"height:29px; width:1px\" /></td>\r\n									<td align=\"center\" background=\"http://www.kudnokplao.go.th/image/condition/condition_24.gif\" class=\"txt_black\" style=\"font-family: &quot;MS Sans Serif&quot;; font-size: 14px; line-height: 25px; color: rgb(51, 51, 51);\">4</td>\r\n									<td background=\"http://www.kudnokplao.go.th/image/condition/condition_24.gif\" class=\"txt_black\" style=\"font-family: &quot;MS Sans Serif&quot;; font-size: 14px; line-height: 25px; color: rgb(51, 51, 51);\">&nbsp;</td>\r\n									<td background=\"http://www.kudnokplao.go.th/image/condition/condition_24.gif\" class=\"txt_black\" style=\"font-family: &quot;MS Sans Serif&quot;; font-size: 14px; line-height: 25px; color: rgb(51, 51, 51);\">&nbsp;</td>\r\n									<td align=\"center\" background=\"http://www.kudnokplao.go.th/image/condition/condition_24.gif\" class=\"txt_black\" style=\"font-family: &quot;MS Sans Serif&quot;; font-size: 14px; line-height: 25px; color: rgb(51, 51, 51);\">304</td>\r\n									<td align=\"center\" background=\"http://www.kudnokplao.go.th/image/condition/condition_24.gif\" class=\"txt_black\" style=\"font-family: &quot;MS Sans Serif&quot;; font-size: 14px; line-height: 25px; color: rgb(51, 51, 51);\">327</td>\r\n									<td align=\"center\" background=\"http://www.kudnokplao.go.th/image/condition/condition_24.gif\" class=\"txt_black\" style=\"font-family: &quot;MS Sans Serif&quot;; font-size: 14px; line-height: 25px; color: rgb(51, 51, 51);\">631</td>\r\n									<td align=\"center\" background=\"http://www.kudnokplao.go.th/image/condition/condition_24.gif\" class=\"txt_black\" style=\"font-family: &quot;MS Sans Serif&quot;; font-size: 14px; line-height: 25px; color: rgb(51, 51, 51);\">192</td>\r\n									<td align=\"right\" background=\"http://www.kudnokplao.go.th/image/condition/condition_24.gif\"><img src=\"http://www.kudnokplao.go.th/image/condition/condition_22.gif\" style=\"height:29px; width:1px\" /></td>\r\n								</tr>\r\n								<tr>\r\n									<td height=\"25\">&nbsp;</td>\r\n									<td align=\"center\" class=\"txt_blue\" style=\"font-family: &quot;MS Sans Serif&quot;; font-size: 14px; line-height: 25px; color: rgb(0, 102, 255);\">5</td>\r\n									<td class=\"txt_blue\" style=\"font-family: &quot;MS Sans Serif&quot;; font-size: 14px; line-height: 25px; color: rgb(0, 102, 255);\">&nbsp;</td>\r\n									<td class=\"txt_blue\" style=\"font-family: &quot;MS Sans Serif&quot;; font-size: 14px; line-height: 25px; color: rgb(0, 102, 255);\">&nbsp;</td>\r\n									<td align=\"center\" class=\"txt_blue\" style=\"font-family: &quot;MS Sans Serif&quot;; font-size: 14px; line-height: 25px; color: rgb(0, 102, 255);\">293</td>\r\n									<td align=\"center\" class=\"txt_blue\" style=\"font-family: &quot;MS Sans Serif&quot;; font-size: 14px; line-height: 25px; color: rgb(0, 102, 255);\">323</td>\r\n									<td align=\"center\" class=\"txt_blue\" style=\"font-family: &quot;MS Sans Serif&quot;; font-size: 14px; line-height: 25px; color: rgb(0, 102, 255);\">616</td>\r\n									<td align=\"center\" class=\"txt_blue\" style=\"font-family: &quot;MS Sans Serif&quot;; font-size: 14px; line-height: 25px; color: rgb(0, 102, 255);\">138</td>\r\n									<td align=\"right\">&nbsp;</td>\r\n								</tr>\r\n								<tr>\r\n									<td background=\"http://www.kudnokplao.go.th/image/condition/condition_24.gif\"><img src=\"http://www.kudnokplao.go.th/image/condition/condition_22.gif\" style=\"height:29px; width:1px\" /></td>\r\n									<td align=\"center\" background=\"http://www.kudnokplao.go.th/image/condition/condition_24.gif\" class=\"txt_black\" style=\"font-family: &quot;MS Sans Serif&quot;; font-size: 14px; line-height: 25px; color: rgb(51, 51, 51);\">6</td>\r\n									<td background=\"http://www.kudnokplao.go.th/image/condition/condition_24.gif\" class=\"txt_black\" style=\"font-family: &quot;MS Sans Serif&quot;; font-size: 14px; line-height: 25px; color: rgb(51, 51, 51);\">&nbsp;</td>\r\n									<td background=\"http://www.kudnokplao.go.th/image/condition/condition_24.gif\" class=\"txt_black\" style=\"font-family: &quot;MS Sans Serif&quot;; font-size: 14px; line-height: 25px; color: rgb(51, 51, 51);\">&nbsp;</td>\r\n									<td align=\"center\" background=\"http://www.kudnokplao.go.th/image/condition/condition_24.gif\" class=\"txt_black\" style=\"font-family: &quot;MS Sans Serif&quot;; font-size: 14px; line-height: 25px; color: rgb(51, 51, 51);\">274</td>\r\n									<td align=\"center\" background=\"http://www.kudnokplao.go.th/image/condition/condition_24.gif\" class=\"txt_black\" style=\"font-family: &quot;MS Sans Serif&quot;; font-size: 14px; line-height: 25px; color: rgb(51, 51, 51);\">301</td>\r\n									<td align=\"center\" background=\"http://www.kudnokplao.go.th/image/condition/condition_24.gif\" class=\"txt_black\" style=\"font-family: &quot;MS Sans Serif&quot;; font-size: 14px; line-height: 25px; color: rgb(51, 51, 51);\">575</td>\r\n									<td align=\"center\" background=\"http://www.kudnokplao.go.th/image/condition/condition_24.gif\" class=\"txt_black\" style=\"font-family: &quot;MS Sans Serif&quot;; font-size: 14px; line-height: 25px; color: rgb(51, 51, 51);\">145</td>\r\n									<td align=\"right\" background=\"http://www.kudnokplao.go.th/image/condition/condition_24.gif\"><img src=\"http://www.kudnokplao.go.th/image/condition/condition_22.gif\" style=\"height:29px; width:1px\" /></td>\r\n								</tr>\r\n								<tr>\r\n									<td height=\"25\">&nbsp;</td>\r\n									<td align=\"center\" class=\"txt_blue\" style=\"font-family: &quot;MS Sans Serif&quot;; font-size: 14px; line-height: 25px; color: rgb(0, 102, 255);\">7</td>\r\n									<td class=\"txt_blue\" style=\"font-family: &quot;MS Sans Serif&quot;; font-size: 14px; line-height: 25px; color: rgb(0, 102, 255);\">&nbsp;</td>\r\n									<td class=\"txt_blue\" style=\"font-family: &quot;MS Sans Serif&quot;; font-size: 14px; line-height: 25px; color: rgb(0, 102, 255);\">&nbsp;</td>\r\n									<td align=\"center\" class=\"txt_blue\" style=\"font-family: &quot;MS Sans Serif&quot;; font-size: 14px; line-height: 25px; color: rgb(0, 102, 255);\">128</td>\r\n									<td align=\"center\" class=\"txt_blue\" style=\"font-family: &quot;MS Sans Serif&quot;; font-size: 14px; line-height: 25px; color: rgb(0, 102, 255);\">130</td>\r\n									<td align=\"center\" class=\"txt_blue\" style=\"font-family: &quot;MS Sans Serif&quot;; font-size: 14px; line-height: 25px; color: rgb(0, 102, 255);\">258</td>\r\n									<td align=\"center\" class=\"txt_blue\" style=\"font-family: &quot;MS Sans Serif&quot;; font-size: 14px; line-height: 25px; color: rgb(0, 102, 255);\">57</td>\r\n									<td align=\"right\">&nbsp;</td>\r\n								</tr>\r\n								<tr>\r\n									<td background=\"http://www.kudnokplao.go.th/image/condition/condition_24.gif\"><img src=\"http://www.kudnokplao.go.th/image/condition/condition_22.gif\" style=\"height:29px; width:1px\" /></td>\r\n									<td align=\"center\" background=\"http://www.kudnokplao.go.th/image/condition/condition_24.gif\" class=\"txt_black\" style=\"font-family: &quot;MS Sans Serif&quot;; font-size: 14px; line-height: 25px; color: rgb(51, 51, 51);\">8</td>\r\n									<td background=\"http://www.kudnokplao.go.th/image/condition/condition_24.gif\" class=\"txt_black\" style=\"font-family: &quot;MS Sans Serif&quot;; font-size: 14px; line-height: 25px; color: rgb(51, 51, 51);\">&nbsp;</td>\r\n									<td background=\"http://www.kudnokplao.go.th/image/condition/condition_24.gif\" class=\"txt_black\" style=\"font-family: &quot;MS Sans Serif&quot;; font-size: 14px; line-height: 25px; color: rgb(51, 51, 51);\">&nbsp;</td>\r\n									<td align=\"center\" background=\"http://www.kudnokplao.go.th/image/condition/condition_24.gif\" class=\"txt_black\" style=\"font-family: &quot;MS Sans Serif&quot;; font-size: 14px; line-height: 25px; color: rgb(51, 51, 51);\">332</td>\r\n									<td align=\"center\" background=\"http://www.kudnokplao.go.th/image/condition/condition_24.gif\" class=\"txt_black\" style=\"font-family: &quot;MS Sans Serif&quot;; font-size: 14px; line-height: 25px; color: rgb(51, 51, 51);\">336</td>\r\n									<td align=\"center\" background=\"http://www.kudnokplao.go.th/image/condition/condition_24.gif\" class=\"txt_black\" style=\"font-family: &quot;MS Sans Serif&quot;; font-size: 14px; line-height: 25px; color: rgb(51, 51, 51);\">668</td>\r\n									<td align=\"center\" background=\"http://www.kudnokplao.go.th/image/condition/condition_24.gif\" class=\"txt_black\" style=\"font-family: &quot;MS Sans Serif&quot;; font-size: 14px; line-height: 25px; color: rgb(51, 51, 51);\">169</td>\r\n									<td align=\"right\" background=\"http://www.kudnokplao.go.th/image/condition/condition_24.gif\"><img src=\"http://www.kudnokplao.go.th/image/condition/condition_22.gif\" style=\"height:29px; width:1px\" /></td>\r\n								</tr>\r\n								<tr>\r\n									<td height=\"10\">&nbsp;</td>\r\n									<td>&nbsp;</td>\r\n									<td>&nbsp;</td>\r\n									<td>&nbsp;</td>\r\n									<td>&nbsp;</td>\r\n									<td>&nbsp;</td>\r\n									<td>&nbsp;</td>\r\n									<td>&nbsp;</td>\r\n									<td align=\"right\">&nbsp;</td>\r\n								</tr>\r\n								<tr>\r\n									<td background=\"http://www.kudnokplao.go.th/image/condition/condition_59.gif\"><img src=\"http://www.kudnokplao.go.th/image/condition/condition_48.gif\" style=\"height:25px; width:1px\" /></td>\r\n									<td background=\"http://www.kudnokplao.go.th/image/condition/condition_59.gif\" class=\"txt_white\" style=\"font-family: &quot;MS Sans Serif&quot;; font-size: 14px; line-height: 25px; color: rgb(255, 255, 255);\">&nbsp;</td>\r\n									<td background=\"http://www.kudnokplao.go.th/image/condition/condition_59.gif\" class=\"txt_white\" style=\"font-family: &quot;MS Sans Serif&quot;; font-size: 14px; line-height: 25px; color: rgb(255, 255, 255);\">&nbsp;</td>\r\n									<td align=\"center\" background=\"http://www.kudnokplao.go.th/image/condition/condition_59.gif\" class=\"txt_white\" style=\"font-family: &quot;MS Sans Serif&quot;; font-size: 14px; line-height: 25px; color: rgb(255, 255, 255);\">รวม</td>\r\n									<td align=\"center\" background=\"http://www.kudnokplao.go.th/image/condition/condition_59.gif\" class=\"txt_white\" style=\"font-family: &quot;MS Sans Serif&quot;; font-size: 14px; line-height: 25px; color: rgb(255, 255, 255);\">2,579</td>\r\n									<td align=\"center\" background=\"http://www.kudnokplao.go.th/image/condition/condition_59.gif\" class=\"txt_white\" style=\"font-family: &quot;MS Sans Serif&quot;; font-size: 14px; line-height: 25px; color: rgb(255, 255, 255);\">2,729</td>\r\n									<td align=\"center\" background=\"http://www.kudnokplao.go.th/image/condition/condition_59.gif\" class=\"txt_white\" style=\"font-family: &quot;MS Sans Serif&quot;; font-size: 14px; line-height: 25px; color: rgb(255, 255, 255);\">5,308</td>\r\n									<td align=\"center\" background=\"http://www.kudnokplao.go.th/image/condition/condition_59.gif\" class=\"txt_white\" style=\"font-family: &quot;MS Sans Serif&quot;; font-size: 14px; line-height: 25px; color: rgb(255, 255, 255);\">1,326</td>\r\n									<td align=\"right\" background=\"http://www.kudnokplao.go.th/image/condition/condition_59.gif\"><img src=\"http://www.kudnokplao.go.th/image/condition/condition_48.gif\" style=\"height:25px; width:1px\" /></td>\r\n								</tr>\r\n							</tbody>\r\n						</table>\r\n						</td>\r\n					</tr>\r\n				</tbody>\r\n			</table>\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td class=\"txt_org\" height=\"60\" style=\"font-family: &quot;MS Sans Serif&quot;; font-size: 14px; line-height: 25px; color: rgb(255, 102, 0);\">&nbsp;</td>\r\n		</tr>\r\n		<tr>\r\n			<td align=\"center\" class=\"txt_org\" style=\"font-family: &quot;MS Sans Serif&quot;; font-size: 14px; line-height: 25px; color: rgb(255, 102, 0);\"><img src=\"http://www.kudnokplao.go.th/image/condition/condition_57.jpg\" style=\"height:182px; width:306px\" /></td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n\r\n<p style=\"text-align: center;\">&nbsp;</p>\r\n\r\n<h2 style=\"text-align: center;\"><strong>อาชีพในตำบล</strong></h2>\r\n\r\n<p style=\"text-align: center;\"><span style=\"color:rgb(0, 153, 0); font-family:ms sans serif; font-size:14px\">อาชีพของประชาชนในเขตตำบลเทศบาลตำบลกุดนกเปล้า แบ่งเป็นกลุ่มใหญ่ๆ ตามลำดับดังนี้</span></p>\r\n\r\n<p style=\"text-align: center;\">&nbsp;&nbsp; &nbsp;เกษตรกรรม&nbsp;&nbsp; &nbsp;คิดเป็น 40 %<br />\r\n&nbsp;&nbsp;&nbsp; &nbsp;รับจ้างทั่วไป&nbsp;&nbsp; &nbsp;คิดเป็น 25 %<br />\r\n&nbsp;&nbsp;&nbsp; &nbsp;พนักงานบริษัท&nbsp;&nbsp; &nbsp;คิดเป็น 20 %<br />\r\n&nbsp;&nbsp;&nbsp; &nbsp;ราชการ&nbsp;&nbsp; &nbsp;คิดเป็น 10 %<br />\r\n&nbsp;&nbsp;&nbsp; &nbsp;รัฐวิสาหกิจ&nbsp;&nbsp; &nbsp;คิดเป็น 5 %<br />\r\n&nbsp;</p>\r\n', NULL, NULL),
(101, 1, 46, 'สภาพทางสังคม', 1, NULL, NULL, NULL),
(102, 1, 47, 'การบริการขั้นพื้นฐาน', 1, NULL, NULL, NULL),
(103, 1, 48, 'แบบสอบถามความพึงพอใจ', 1, '<hr />\r\n<div class=\"embed-responsive embed-responsive-16by9\" style=\"height: 1160px;\"><iframe class=\"embed-responsive-item\" frameborder=\"0\" src=\"https://docs.google.com/forms/d/e/1FAIpQLSdIK6OUtrOedYH-0qti1vF4hv-tgqdDdgtsQsaMbwBAhmv0cg/viewform?embedded=true\" width=\"760\">กำลังโหลด...</iframe></div>\r\n', NULL, NULL),
(104, 1, 49, 'ผู้บริหาร', 1, '<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" style=\"width:100%\">\r\n	<tbody>\r\n		<tr>\r\n			<td>&nbsp;</td>\r\n			<td style=\"text-align:center\">\r\n			<p><img alt=\"\" src=\"http://www.website-thai.com/project/kudnokplao/upload/userfile/images/นายภูฐิติพัศ ภัทรวุฒิโชติพงศ์(1).jpg\" style=\"height:151px; width:125px\" /></p>\r\n\r\n			<p>นาย ภูฐิติพัศ ภัทรวุฒิโชติพงศ์<br />\r\n			ปลัดเทศบาล ปฎิบัติหน้าที่<br />\r\n			นายกเทศมนตรีกุดนกเปล้า&nbsp;</p>\r\n			</td>\r\n			<td>&nbsp;</td>\r\n		</tr>\r\n		<tr>\r\n			<td>&nbsp;</td>\r\n			<td>&nbsp;</td>\r\n			<td>&nbsp;</td>\r\n		</tr>\r\n		<tr>\r\n			<td>&nbsp;</td>\r\n			<td>&nbsp;</td>\r\n			<td>&nbsp;</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n\r\n<p>&nbsp;</p>\r\n', NULL, NULL),
(105, 1, 50, 'ทำเนียบเทศบาล', 1, '<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" style=\"width:100%\">\r\n	<tbody>\r\n		<tr>\r\n			<td>&nbsp;</td>\r\n			<td style=\"text-align:center\">\r\n			<p><img alt=\"\" src=\"http://www.website-thai.com/project/kudnokplao/upload/userfile/images/นายชุ่ม ฤทธิ์จันทึก.jpg\" style=\"height:151px; width:125px\" /></p>\r\n\r\n			<p>นายชุ่ม ฤทธิ์จันทึก<br />\r\n			ประธานสภาเทศบาล</p>\r\n			</td>\r\n			<td>&nbsp;</td>\r\n		</tr>\r\n		<tr>\r\n			<td style=\"text-align: center;\">\r\n			<p><img alt=\"\" src=\"http://www.website-thai.com/project/kudnokplao/upload/userfile/images/นางโสภี ลายเงิน.jpg\" style=\"height:151px; width:125px\" /></p>\r\n\r\n			<p>นางโสภี ลายเงิน<br />\r\n			รองประธานสภาเทศบาลฯ</p>\r\n			</td>\r\n			<td style=\"text-align:center\">&nbsp;</td>\r\n			<td style=\"text-align: center;\">\r\n			<p><img alt=\"\" src=\"http://www.website-thai.com/project/kudnokplao/upload/userfile/images/Capture(2).JPG\" style=\"height:151px; width:125px\" /></p>\r\n\r\n			<p>นายสมศักดิ์ เนตรสุวรรณ์<br />\r\n			เลขานุการประธานสภาเทศบาล</p>\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td style=\"text-align:center\">\r\n			<p>&nbsp;</p>\r\n			</td>\r\n			<td style=\"text-align: center;\">\r\n			<h2><span style=\"color:#FF0000\"><strong>สมาชิกสภาเขตเทศบาล 1</strong></span></h2>\r\n			</td>\r\n			<td style=\"text-align:center\">\r\n			<p>&nbsp;</p>\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td style=\"text-align:center\">\r\n			<p><img alt=\"\" src=\"http://www.website-thai.com/project/kudnokplao/upload/userfile/images/นายสมบุญ บัวดี.jpg\" style=\"height:151px; width:125px\" /></p>\r\n\r\n			<p>นายสมบุญ บัวดี<br />\r\n			สมาชิกสภาเทศบาล เขต 1</p>\r\n			</td>\r\n			<td style=\"text-align: center;\">\r\n			<p><img alt=\"\" src=\"http://www.website-thai.com/project/kudnokplao/upload/userfile/images/นายภัทรพล ภูเลาสิงห์.jpg\" style=\"height:151px; width:125px\" /></p>\r\n\r\n			<p>นายภัทรพล ภูเลาสิงห์&nbsp;<br />\r\n			สมาชิกสภาเทศบาล เขต 1</p>\r\n			</td>\r\n			<td style=\"text-align:center\">\r\n			<p><img alt=\"\" src=\"http://www.website-thai.com/project/kudnokplao/upload/userfile/images/Capture(2).JPG\" style=\"height:151px; opacity:0.9; text-align:center; width:125px\" /><br />\r\n			นายสมศักดิ์ เนตรสุวรรณ์<br />\r\n			สมาชิกสภาเทศบาล เขต 1</p>\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td style=\"text-align:center\">\r\n			<p><img alt=\"\" src=\"http://www.website-thai.com/project/kudnokplao/upload/userfile/images/นายคำพันธ์ หมวดมหิงษ์.jpg\" style=\"height:151px; width:125px\" /></p>\r\n\r\n			<p>นายคำพันธ์ หมวดมหิงษ์<br />\r\n			สมาชิกสภาเทศบาล เขต 1</p>\r\n			</td>\r\n			<td style=\"text-align: center;\">\r\n			<p><img alt=\"\" src=\"http://www.website-thai.com/project/kudnokplao/upload/userfile/images/นางเจตสุภา นิตยพัฒน์.jpg\" style=\"height:151px; width:125px\" /></p>\r\n\r\n			<p>นางเจตสุภา นิตยพัฒน์&nbsp;<br />\r\n			สมาชิกสภาเทศบาลเขต 1</p>\r\n			</td>\r\n			<td style=\"text-align:center\">\r\n			<p><img alt=\"\" src=\"http://www.website-thai.com/project/kudnokplao/upload/userfile/images/นายชุ่ม ฤทธิ์จันทึก.jpg\" style=\"height:151px; opacity:0.9; text-align:center; width:125px\" /></p>\r\n\r\n			<p>นายชุ่ม ฤทธิ์จันทึก<br />\r\n			สมาชิกสภาเทศบาล เขต 2<br />\r\n			</p>\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td style=\"text-align:center\">&nbsp;</td>\r\n			<td>\r\n			<h2 style=\"text-align:center\"><span style=\"color:rgb(255, 0, 0)\"><strong>สมาชิกสภาเขตเทศบาล 2</strong></span></h2>\r\n			</td>\r\n			<td style=\"text-align:center\">&nbsp;</td>\r\n		</tr>\r\n		<tr>\r\n			<td style=\"text-align:center\">\r\n			<p><img alt=\"\" src=\"http://www.website-thai.com/project/kudnokplao/upload/userfile/images/นายคมสัน หมวดมหิงษ์.jpg\" style=\"height:151px; width:125px\" /></p>\r\n\r\n			<p>นายคมสัน หมวดมหิงษ์&nbsp;<br />\r\n			สมาชิกสภาเทศบาล เขต 2</p>\r\n			</td>\r\n			<td style=\"text-align: center;\">\r\n			<p><img alt=\"\" src=\"http://www.website-thai.com/project/kudnokplao/upload/userfile/images/นายสนั่น วรรณะมา.jpg\" style=\"height:151px; width:125px\" /></p>\r\n\r\n			<p>นายสนั่น วรรณะมา<br />\r\n			สมาชิกสภาเทศบาล เขต 2</p>\r\n			</td>\r\n			<td style=\"text-align:center\">\r\n			<p><img alt=\"\" src=\"http://www.website-thai.com/project/kudnokplao/upload/userfile/images/นายสมชาย ศรีเจือทอง.jpg\" style=\"height:151px; width:125px\" /></p>\r\n\r\n			<p>นายสมชาย ศรีเจือทอง<br />\r\n			สมาชิกสภาเทศบาล เขต 2</p>\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td style=\"text-align:center\">\r\n			<p style=\"text-align:center\"><img alt=\"\" src=\"http://www.website-thai.com/project/kudnokplao/upload/userfile/images/นางโสภี ลายเงิน.jpg\" style=\"height:151px; width:125px\" /></p>\r\n\r\n			<p style=\"text-align:center\">นางโสภี ลายเงิน<br />\r\n			สมาชิกสภาเทศบาล เขต 2</p>\r\n			</td>\r\n			<td style=\"text-align: center;\">\r\n			<p><img alt=\"\" src=\"http://www.website-thai.com/project/kudnokplao/upload/userfile/images/นางสุพรรณ์ คำพันธ์.jpg\" style=\"height:151px; width:125px\" /></p>\r\n\r\n			<p>นางสุพรรณ์ คำพันธ์&nbsp;<br />\r\n			สมาชิกสภาเทศบาล เขต 2</p>\r\n			</td>\r\n			<td style=\"text-align:center\">&nbsp;</td>\r\n		</tr>\r\n		<tr>\r\n			<td style=\"text-align:center\">&nbsp;</td>\r\n			<td>&nbsp;</td>\r\n			<td style=\"text-align:center\">&nbsp;</td>\r\n		</tr>\r\n		<tr>\r\n			<td style=\"text-align:center\">&nbsp;</td>\r\n			<td>&nbsp;</td>\r\n			<td style=\"text-align:center\">&nbsp;</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n\r\n<p>&nbsp;</p>\r\n', NULL, NULL),
(106, 1, 51, 'สำนักงานปลัด', 1, '<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" style=\"width:100%\">\r\n	<tbody>\r\n		<tr>\r\n			<td>&nbsp;</td>\r\n			<td style=\"text-align:center\">\r\n			<p>&nbsp;</p>\r\n\r\n			<p><img alt=\"\" src=\"http://website-thai.com/project/kudnokplao/upload/userfile/images/ปลัดเทศบาล11.JPG\" style=\"height:250px; width:350px\" /></p>\r\n			</td>\r\n			<td>&nbsp;</td>\r\n		</tr>\r\n		<tr>\r\n			<td style=\"text-align:center\">\r\n			<p>&nbsp;</p>\r\n			</td>\r\n			<td>\r\n			<p style=\"text-align:center\">&nbsp;</p>\r\n\r\n			<p style=\"text-align:center\"><img alt=\"\" src=\"http://website-thai.com/project/kudnokplao/upload/userfile/images/รองปลัด.jpg\" style=\"height:250px; width:350px\" /></p>\r\n			</td>\r\n			<td style=\"text-align:center\">\r\n			<p>&nbsp;</p>\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td style=\"text-align:center\">\r\n			<p>&nbsp;</p>\r\n\r\n			<p>&nbsp;</p>\r\n			</td>\r\n			<td style=\"text-align:center\">\r\n			<p><img alt=\"\" src=\"http://website-thai.com/project/kudnokplao/upload/userfile/images/หัวหน้าสำนัก555.jpg\" style=\"height:250px; width:350px\" /></p>\r\n\r\n			<p>&nbsp;</p>\r\n			</td>\r\n			<td style=\"text-align:center\">\r\n			<p>&nbsp;</p>\r\n\r\n			<p>&nbsp;</p>\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td style=\"text-align:center\">\r\n			<p><img alt=\"\" src=\"http://website-thai.com/project/kudnokplao/upload/userfile/images/11111(1).jpg\" style=\"height:250px; width:125px\" /></p>\r\n\r\n			<p>&nbsp;</p>\r\n			</td>\r\n			<td style=\"text-align:center\">\r\n			<p><img alt=\"\" src=\"http://website-thai.com/project/kudnokplao/upload/userfile/images/22222.jpg\" style=\"height:250px; width:125px\" /></p>\r\n\r\n			<p>&nbsp;</p>\r\n			</td>\r\n			<td style=\"text-align:center\">\r\n			<p><img alt=\"\" src=\"http://website-thai.com/project/kudnokplao/upload/userfile/images/33333.jpg\" style=\"height:250px; line-height:1.6em; width:125px\" /></p>\r\n\r\n			<p>&nbsp;</p>\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td>\r\n			<p style=\"text-align:center\"><img alt=\"\" src=\"http://website-thai.com/project/kudnokplao/upload/userfile/images/44444.jpg\" style=\"height:250px; width:125px\" /></p>\r\n\r\n			<p style=\"text-align:center\">&nbsp;</p>\r\n\r\n			<p style=\"text-align:center\">&nbsp;</p>\r\n\r\n			<p style=\"text-align:center\">&nbsp;</p>\r\n\r\n			<p style=\"text-align:center\">&nbsp;</p>\r\n\r\n			<p style=\"text-align:center\">&nbsp;</p>\r\n\r\n			<p style=\"text-align:center\">&nbsp;</p>\r\n\r\n			<p style=\"text-align:center\">&nbsp;</p>\r\n\r\n			<p style=\"text-align:center\">&nbsp;</p>\r\n\r\n			<p style=\"text-align:center\">&nbsp;</p>\r\n\r\n			<p style=\"text-align:center\">&nbsp;</p>\r\n\r\n			<p style=\"text-align:center\">&nbsp;</p>\r\n\r\n			<p style=\"text-align:center\">&nbsp;</p>\r\n\r\n			<p style=\"text-align:center\">&nbsp;</p>\r\n\r\n			<p style=\"text-align:center\"><img alt=\"\" src=\"http://website-thai.com/project/kudnokplao/upload/userfile/images/10101.jpg\" style=\"height:250px; width:125px\" /></p>\r\n\r\n			<p style=\"text-align:center\">&nbsp;</p>\r\n\r\n			<p style=\"text-align:center\">&nbsp;</p>\r\n\r\n			<p style=\"text-align:center\">&nbsp;</p>\r\n\r\n			<p style=\"text-align:center\">&nbsp;</p>\r\n\r\n			<p style=\"text-align:center\">&nbsp;</p>\r\n			</td>\r\n			<td style=\"text-align:center\">\r\n			<p><img alt=\"\" src=\"http://website-thai.com/project/kudnokplao/upload/userfile/images/55555.jpg\" style=\"height:250px; width:125px\" /></p>\r\n\r\n			<p>&nbsp;</p>\r\n\r\n			<p>&nbsp;</p>\r\n\r\n			<p><img alt=\"\" src=\"http://website-thai.com/project/kudnokplao/upload/userfile/images/88888.jpg\" style=\"height:250px; width:125px\" /></p>\r\n\r\n			<p>&nbsp;</p>\r\n\r\n			<p>&nbsp;</p>\r\n\r\n			<p>&nbsp;</p>\r\n\r\n			<p>&nbsp;</p>\r\n\r\n			<p>&nbsp;</p>\r\n\r\n			<p>&nbsp;</p>\r\n\r\n			<p>&nbsp;</p>\r\n\r\n			<p>&nbsp;</p>\r\n\r\n			<p>&nbsp;</p>\r\n\r\n			<p>&nbsp;</p>\r\n			</td>\r\n			<td style=\"text-align:center\">\r\n			<p><img alt=\"\" src=\"http://website-thai.com/project/kudnokplao/upload/userfile/images/77777(1).jpg\" style=\"height:250px; width:125px\" /></p>\r\n\r\n			<p>&nbsp;</p>\r\n\r\n			<p>&nbsp;</p>\r\n\r\n			<p><img alt=\"\" src=\"http://website-thai.com/project/kudnokplao/upload/userfile/images/99999.jpg\" style=\"height:250px; width:125px\" /></p>\r\n\r\n			<p>&nbsp;</p>\r\n\r\n			<p>&nbsp;</p>\r\n\r\n			<p>&nbsp;</p>\r\n\r\n			<p>&nbsp;</p>\r\n\r\n			<p>&nbsp;</p>\r\n\r\n			<p>&nbsp;</p>\r\n\r\n			<p>&nbsp;</p>\r\n\r\n			<p>&nbsp;</p>\r\n			</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n', NULL, NULL),
(107, 1, 52, 'กองคลัง', 1, '<p>&nbsp;</p>\r\n\r\n<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" style=\"width:100%\">\r\n	<tbody>\r\n		<tr>\r\n			<td>&nbsp;</td>\r\n			<td style=\"text-align:center\">\r\n			<p><span style=\"color:#B22222\">่่่่่่<img alt=\"\" src=\"http://website-thai.com/project/kudnokplao/upload/userfile/images/1111.jpg\" style=\"height:250px; width:350px\" /></span></p>\r\n\r\n			<p>&nbsp;</p>\r\n			</td>\r\n			<td>&nbsp;</td>\r\n		</tr>\r\n		<tr>\r\n			<td>\r\n			<p style=\"text-align:center\"><img alt=\"\" src=\"http://website-thai.com/project/kudnokplao/upload/userfile/images/2222(6).jpg\" style=\"height:250px; width:125px\" /></p>\r\n\r\n			<p style=\"text-align:center\"><img alt=\"\" src=\"http://website-thai.com/project/kudnokplao/upload/userfile/images/พี่จุ๋ม(7).bmp\" style=\"height:60px; width:135px\" /></p>\r\n\r\n			<p style=\"text-align:center\">&nbsp;</p>\r\n			</td>\r\n			<td style=\"text-align:center\">\r\n			<p><img alt=\"\" src=\"http://website-thai.com/project/kudnokplao/upload/userfile/images/3333(13).jpg\" style=\"height:250px; width:125px\" /></p>\r\n\r\n			<p><img alt=\"\" src=\"http://website-thai.com/project/kudnokplao/upload/userfile/images/ขอบส้ม1(4).JPG\" style=\"height:60px; width:135px\" /></p>\r\n\r\n			<p>&nbsp;</p>\r\n			</td>\r\n			<td style=\"text-align:center\">\r\n			<p><img alt=\"\" src=\"http://website-thai.com/project/kudnokplao/upload/userfile/images/3333(14).jpg\" style=\"height:250px; width:125px\" /></p>\r\n\r\n			<p><img alt=\"\" src=\"http://website-thai.com/project/kudnokplao/upload/userfile/images/ทิพ(8).JPG\" style=\"height:60px; width:135px\" /></p>\r\n\r\n			<p>&nbsp;</p>\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td style=\"text-align:center\">\r\n			<p>&nbsp;</p>\r\n			</td>\r\n			<td style=\"text-align:center\">\r\n			<p>&nbsp;</p>\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td style=\"text-align:center\">\r\n			<p><img alt=\"\" src=\"http://website-thai.com/project/kudnokplao/upload/userfile/images/4444(6).jpg\" style=\"height:250px; width:125px\" /></p>\r\n\r\n			<p><img alt=\"\" src=\"http://website-thai.com/project/kudnokplao/upload/userfile/images/หน่อย(4).JPG\" style=\"height:60px; width:135px\" /></p>\r\n			</td>\r\n			<td style=\"text-align:center\">\r\n			<p>&nbsp;</p>\r\n\r\n			<p><img alt=\"\" src=\"http://website-thai.com/project/kudnokplao/upload/userfile/images/5555(7).jpg\" style=\"height:250px; width:125px\" /></p>\r\n\r\n			<p><img alt=\"\" src=\"http://website-thai.com/project/kudnokplao/upload/userfile/images/มด(4).JPG\" style=\"height:60px; width:135px\" /></p>\r\n\r\n			<p>&nbsp;</p>\r\n			</td>\r\n			<td>\r\n			<p><img alt=\"\" src=\"http://website-thai.com/project/kudnokplao/upload/userfile/images/6666(6).jpg\" style=\"height:250px; width:125px\" /></p>\r\n\r\n			<p><img alt=\"\" src=\"http://website-thai.com/project/kudnokplao/upload/userfile/images/ส้ม(6).JPG\" style=\"height:60px; width:135px\" /></p>\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td style=\"text-align:center\">&nbsp;</td>\r\n			<td style=\"text-align:center\">&nbsp;</td>\r\n			<td>&nbsp;</td>\r\n		</tr>\r\n		<tr>\r\n			<td style=\"text-align:center\">&nbsp;</td>\r\n			<td style=\"text-align:center\">&nbsp;</td>\r\n			<td>&nbsp;</td>\r\n		</tr>\r\n		<tr>\r\n			<td style=\"text-align:center\">&nbsp;</td>\r\n			<td style=\"text-align:center\">&nbsp;</td>\r\n			<td>&nbsp;</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n\r\n<p>&nbsp;</p>\r\n', NULL, NULL),
(108, 1, 53, 'กองช่าง', 1, '<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" style=\"width:100%\">\r\n	<tbody>\r\n		<tr>\r\n			<td>&nbsp;</td>\r\n			<td style=\"text-align:center\">\r\n			<p><img alt=\"\" src=\"http://www.website-thai.com/project/kudnokplao/upload/userfile/images/นายธนัช อินทนิล.jpg\" style=\"height:151px; width:125px\" /></p>\r\n\r\n			<p>นายธนัช อินทนิล<br />\r\n			นายช่างโยธา รก. ผอ.กองช่าง</p>\r\n			</td>\r\n			<td>&nbsp;</td>\r\n		</tr>\r\n		<tr>\r\n			<td style=\"text-align:center\">\r\n			<p><img alt=\"\" src=\"http://www.website-thai.com/project/kudnokplao/upload/userfile/images/สิบเอกชาญวิทย์ จอมพล.jpg\" style=\"height:151px; width:125px\" /></p>\r\n\r\n			<p>สิบเอกชาญวิทย์ จอมพล&nbsp;<br />\r\n			เจ้าพนักงานธุรการ</p>\r\n			</td>\r\n			<td style=\"text-align:center\">\r\n			<p><img alt=\"\" src=\"http://www.website-thai.com/project/kudnokplao/upload/userfile/images/นางสาวสุดารัตน์ หมวกนาค.jpg\" style=\"height:151px; width:125px\" /></p>\r\n\r\n			<p>นางสาวสุดารัตน์ หมวกนาค<br />\r\n			ผู้ช่วยเจ้าหน้าที่ธุรการ</p>\r\n			</td>\r\n			<td style=\"text-align:center\">\r\n			<p><img alt=\"\" src=\"http://www.website-thai.com/project/kudnokplao/upload/userfile/images/นายศรีไพร หวานจันทร์.jpg\" style=\"height:151px; width:125px\" /></p>\r\n\r\n			<p>นายศรีไพร หวานจันทร์<br />\r\n			คนงานทั่วไป</p>\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td style=\"text-align:center\">\r\n			<p><img alt=\"\" src=\"http://www.website-thai.com/project/kudnokplao/upload/userfile/images/นายไพบูลย์ ประจบดี.jpg\" style=\"height:151px; width:125px\" /></p>\r\n\r\n			<p>นายไพบูลย์ ประจบดี<br />\r\n			คนงานทั่วไป</p>\r\n			</td>\r\n			<td style=\"text-align:center\">\r\n			<p><img alt=\"\" src=\"http://www.website-thai.com/project/kudnokplao/upload/userfile/images/นายสมศักดิ์ คำมูล.jpg\" style=\"height:151px; width:125px\" /></p>\r\n\r\n			<p>นายสมศักดิ์ คำมูล<br />\r\n			คนงานทั่วไป</p>\r\n			</td>\r\n			<td>&nbsp;</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n\r\n<p>&nbsp;</p>\r\n', NULL, NULL),
(109, 1, 54, 'กองการศึกษา', 1, '<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" style=\"width:100%\">\r\n	<tbody>\r\n		<tr>\r\n			<td>&nbsp;</td>\r\n			<td style=\"text-align:center\">\r\n			<p>&nbsp;</p>\r\n\r\n			<p><img alt=\"\" src=\"http://website-thai.com/project/kudnokplao/upload/userfile/images/11111.jpg\" style=\"height:250px; width:350px\" /></p>\r\n			</td>\r\n			<td>&nbsp;</td>\r\n		</tr>\r\n		<tr>\r\n			<td>\r\n			<p>&nbsp;<img alt=\"\" src=\"http://website-thai.com/project/kudnokplao/upload/userfile/images/ก333(1).jpg\" style=\"height:250px; width:125px\" /></p>\r\n\r\n			<p><img alt=\"\" src=\"http://website-thai.com/project/kudnokplao/upload/userfile/images/ป11.jpg\" style=\"height:60px; width:135px\" /></p>\r\n			</td>\r\n			<td style=\"text-align: center;\">\r\n			<p>&nbsp;</p>\r\n\r\n			<p><img alt=\"\" src=\"http://website-thai.com/project/kudnokplao/upload/userfile/images/ก111.jpg\" style=\"height:250px; width:125px\" /></p>\r\n\r\n			<p><img alt=\"\" src=\"http://website-thai.com/project/kudnokplao/upload/userfile/images/ป22.jpg\" style=\"height:60px; width:135px\" /></p>\r\n\r\n			<p>&nbsp;</p>\r\n			</td>\r\n			<td>\r\n			<p><img alt=\"\" src=\"http://website-thai.com/project/kudnokplao/upload/userfile/images/ก222.jpg\" style=\"height:250px; width:125px\" /></p>\r\n\r\n			<p><img alt=\"\" src=\"http://website-thai.com/project/kudnokplao/upload/userfile/images/ป33(1).jpg\" style=\"height:60px; width:135px\" /></p>\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td>\r\n			<p>&nbsp;<img alt=\"\" src=\"http://website-thai.com/project/kudnokplao/upload/userfile/images/ก444.jpg\" style=\"height:250px; width:125px\" /></p>\r\n\r\n			<p><img alt=\"\" src=\"http://website-thai.com/project/kudnokplao/upload/userfile/images/ป44.jpg\" style=\"height:60px; width:135px\" /></p>\r\n			</td>\r\n			<td>&nbsp;</td>\r\n			<td>&nbsp;</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n\r\n<p>&nbsp;</p>\r\n', NULL, NULL),
(110, 1, 55, 'ประชาสัมพันธ์ 1', 1, '<p>แซนด์วิชวีไอพีอพาร์ตเมนท์เซ็นเตอร์เป่ายิงฉุบ สตรอว์เบอร์รีโรแมนติคแอปพริคอท แฟนซีคอนเทนเนอร์ กาญจนาภิเษกรามาธิบดีเทรด เปเปอร์มลภาวะรีเสิร์ชจิ๊กคอนโดมิเนียม คอนแทค ออดิชั่นเทรดเทรนด์เหี่ยวย่นภารตะ อวอร์ดแอ็กชั่นรุสโซ เรตปิยมิตรสไตรค์ ซินโดรม เคลม ไฮเอนด์โบว์ โปรเจคท์ฮาร์ด หน่อมแน้ม อุเทนทัวร์นาเมนท์อพาร์ทเมนต์ แฮนด์ครูเสดไอติมฮัมเฉิ่ม</p>\r\n', NULL, NULL),
(111, 1, 56, 'ประกวดราคาจ้างโครงการ 1', 1, '<p>ประกวดราคาจ้างโครงการ 1</p>\r\n', NULL, NULL),
(112, 1, 57, 'สอบราคา 1', 1, '<p>สอบราคา 1</p>\r\n', NULL, NULL),
(113, 1, 58, 'สอบราคาจ้างโครงการก่อสร้าง 1', 1, '<p>สอบราคาจ้างโครงการก่อสร้าง 1</p>\r\n', NULL, NULL),
(114, 1, 59, 'ข่าวกิจกรรม 5', 1, NULL, NULL, NULL),
(115, 1, 60, 'ลิงค์รูป', 1, '', NULL, NULL),
(116, 1, 61, 'รูปลิงค์ซ้าย', 1, '', NULL, NULL),
(117, 1, 62, 'รูปลิงค์ขวา', 1, '', NULL, NULL),
(118, 1, 63, 'รูปนายก', 1, '<h2 style=\"text-align:center\"><span style=\"font-size:22px\"><span style=\"color:#0000FF\">นายภูฐิติพัศ ภัทรวุฒิโชติพงศ์</span></span></h2>\r\n\r\n<h2 style=\"text-align:center\"><span style=\"font-size:22px\"><span style=\"color:#0000FF\">ปลัดเทศบาล ปฎิบัติหน้าที่</span></span></h2>\r\n\r\n<h2 style=\"text-align:center\"><span style=\"font-size:22px\"><span style=\"color:#0000FF\">นายกเทศมนตรีตำบลกุดนกเปล้า&nbsp;</span></span></h2>\r\n\r\n<h2 style=\"text-align:center\"><span style=\"font-size:22px\"><span style=\"color:#0000FF\">สายตรงปลัดเทศบาล</span></span></h2>\r\n\r\n<h2 style=\"text-align:center\"><span style=\"font-size:22px\"><span style=\"color:#0000FF\">094&nbsp;- 519&nbsp;- 9789</span></span></h2>\r\n', NULL, NULL),
(119, 1, 64, 'โรงพยาบาลส่งเสริมสุขภาพตำบล', 1, '<p style=\"text-align:center\"><img alt=\"\" src=\"http://www.website-thai.com/project/huayjod/upload/userfile/images/โรงพยาบาลส่งเสริงสุขภาพตำบล.jpg\" style=\"height:424px; width:640px\" /></p>\r\n', NULL, NULL),
(120, 1, 65, 'โรงเรียนไทยรัฐวิทยา', 1, '<p style=\"text-align: center;\"><img alt=\"\" src=\"http://www.website-thai.com/project/huayjod/upload/userfile/images/โรงเรียนไทยรัฐวิทยา.jpg\" style=\"height:225px; width:400px\" /></p>\r\n\r\n<p style=\"text-align: center;\"><img alt=\"\" src=\"http://www.website-thai.com/project/huayjod/upload/userfile/images/โรงเรียนไทยรัฐวิทยา.jpg.jpg\" style=\"height:265px; width:400px\" /></p>\r\n', NULL, NULL),
(121, 1, 66, 'วัดห้วยโจด', 1, '<p style=\"text-align: center;\"><img alt=\"\" src=\"http://www.website-thai.com/project/huayjod/upload/userfile/images/วัดห้วยโจด.jpg\" style=\"height:424px; width:640px\" /></p>\r\n', NULL, NULL),
(122, 1, 67, 'ศาลพ่อทองคำ', 1, '<p style=\"text-align: center;\"><img alt=\"\" src=\"http://www.website-thai.com/project/huayjod/upload/userfile/images/ศาลพ่อทองคำ.jpg\" style=\"height:424px; width:640px\" /></p>\r\n', NULL, NULL),
(123, 1, 68, 'ศูนย์พัฒนาเด็กเล็กบ่อนางชิง', 1, '<p style=\"text-align: center;\"><img alt=\"\" src=\"http://www.website-thai.com/project/huayjod/upload/userfile/images/ศูนย์พัฒนาเด็กเล็กบ่อนางชิง.jpg\" style=\"height:424px; width:640px\" /></p>\r\n', NULL, NULL),
(124, 1, 69, 'ศูนย์พัฒนาเด็กเล็กห้วยโจด', 1, '<p style=\"text-align: center;\"><img alt=\"\" src=\"http://www.website-thai.com/project/huayjod/upload/userfile/images/ศูนย์พัฒนาเด็ก้เล็กห้วยโจด.jpg\" style=\"height:424px; width:640px\" /></p>\r\n\r\n<p style=\"text-align: center;\"><img alt=\"\" src=\"http://www.website-thai.com/project/huayjod/upload/userfile/images/ศูนย์พัฒนาเด็ก้เล็กห้วยโจดๅ(1).jpg\" style=\"height:424px; width:640px\" /></p>\r\n', NULL, NULL),
(125, 1, 70, 'ศูนย์พัฒนาเด็กเล็กบ้านคลองยาง', 1, '<p style=\"text-align: center;\"><img alt=\"\" src=\"http://www.website-thai.com/project/huayjod/upload/userfile/images/ศูนย์พัฒนาเด็กเลฏบ้านคลองยาง.jpg\" style=\"height:424px; width:640px\" /></p>\r\n\r\n<p style=\"text-align: center;\"><img alt=\"\" src=\"http://www.website-thai.com/project/huayjod/upload/userfile/images/ศูนย์พัฒนาเด็กเลฏบ้านคลองยาง_jpgๅ.jpg\" style=\"height:424px; width:640px\" /></p>\r\n', NULL, NULL),
(126, 1, 71, 'กลุ่มผลิตภัณฑ์ชิงช้าโยกบ้านเสาสูง', 1, '<p style=\"text-align: center;\"><img alt=\"\" src=\"http://www.website-thai.com/project/huayjod/upload/userfile/images/DSC_0335.png\" style=\"height:424px; width:640px\" /></p>\r\n\r\n<p style=\"text-align: center;\"><img alt=\"\" src=\"http://www.website-thai.com/project/huayjod/upload/userfile/images/DSC_0335(1).png\" style=\"height:424px; width:640px\" /></p>\r\n', NULL, NULL),
(127, 1, 72, 'กลุ่มวิสาหกิจชุมชน บ้านเสาสูง', 1, '<p style=\"text-align: center;\"><img alt=\"\" src=\"http://www.website-thai.com/project/huayjod/upload/userfile/images/ป้าย.png\" style=\"height:129px; width:400px\" /></p>\r\n\r\n<p style=\"text-align: center;\"><img alt=\"\" src=\"http://www.website-thai.com/project/huayjod/upload/userfile/images/ข้าว.png\" style=\"height:265px; width:400px\" /></p>\r\n\r\n<p style=\"text-align: center;\">&nbsp;</p>\r\n\r\n<p style=\"text-align: center;\"><img alt=\"\" src=\"http://www.website-thai.com/project/huayjod/upload/userfile/images/DSC_0340(1).jpg\" style=\"height:424px; width:640px\" /></p>\r\n\r\n<p style=\"text-align: center;\">&nbsp;</p>\r\n', NULL, NULL),
(128, 1, 73, '  โครงการป้องกันสถานบันสำคัญของชาติ ประจำ2559', 1, '', NULL, NULL),
(129, 1, 74, 'โครงการสานสัมพันธ์ความอบอุ่นในครอบครัว ประจำปี 2559', 1, '', NULL, NULL),
(130, 1, 75, 'เทศบาลตำบลกุดนกเปล้า พนักงานเทศบาลได้ร่วมกัน ', 1, '<p>&nbsp;<br />\r\nเทศบาลตำบลกุดนกเปล้า พนักงานเทศบาลได้ร่วมกัน ปลูกต้นไม้ เนื่องใน &quot;โครงการฉลองศิริราชสมบัติครบ ๗๐ ปี พระบาทสมเด็จพระเจ้าอยู่หัว&quot; &quot;เฉลิมประขนมพรรษา ๗ รอบ สมเด็จพระนางเจ้า ฯ พระบรมราชินีนาถ&quot; ณ บริเวณเทศบาลตำบลกุดนกเปล้า</p>\r\n', NULL, NULL);
INSERT INTO `mhd_language_detail` (`id`, `language_id`, `ref_id`, `name`, `type`, `detail`, `detail_2`, `detail_3`) VALUES
(131, 1, 76, 'สภาพสังคม', 1, '<h2 style=\"text-align: center;\"><strong>สภาพสังคม</strong></h2>\r\n\r\n<p style=\"text-align: center;\"><span style=\"color:rgb(0, 102, 255); font-family:ms sans serif; font-size:14px\">ชาวบ้านในตำบลกุดนกเปล้า มีวิถีชีวิตที่เรียบง่าย เอื้อเฟื้อ เผื่อแผ่ พึ่งพาอาศัยซึ่งกันและกัน ใช้ชีวิตแบบพอเพียง ตามปรัชญา เศรษฐกิจพอเพียงของในหลวง และมีวัด เป็นศูนย์รวมจิตใจของ ชาวบ้านในตำบล</span></p>\r\n\r\n<p style=\"text-align: center;\"><img src=\"http://www.kudnokplao.go.th/image/condition/social_11.jpg\" style=\"color:rgb(0, 0, 0); font-family:times new roman; font-size:medium; height:154px; text-align:-webkit-center; width:250px\" /></p>\r\n\r\n<h2 style=\"text-align: center;\"><strong>ความปลอดภัยในชีวิตและทรัพย์สิน</strong></h2>\r\n\r\n<p style=\"text-align: center;\">สถานีตำรวจชุมชนประจำตำบลกุดนกเปล้า&nbsp;&nbsp; &nbsp;จำนวน&nbsp;&nbsp; &nbsp;1&nbsp;&nbsp; &nbsp;แห่ง<br />\r\n&nbsp;ตั้งอยู่บ้านกุดนกเปล้า หมู่ที่ 3 ตำบลกุดนกเปล้า อำเภอเมือง จังหวัดสระบุรี<br />\r\nไฟฟ้าสาธารณะ หมู่ที่ 1 &ndash; 8 ตำบลกุดนกเปล้า&nbsp;&nbsp; &nbsp;จำนวน&nbsp;&nbsp; &nbsp;371&nbsp;&nbsp; &nbsp;สาย<br />\r\nหอกระจายข่าวประจำหมู่บ้าน&nbsp;&nbsp; &nbsp;จำนวน&nbsp;&nbsp; &nbsp;10&nbsp;&nbsp; &nbsp;แห่ง<br />\r\nไฟโซล่าเซลล์&nbsp;&nbsp; &nbsp;จำนวน&nbsp;&nbsp; &nbsp;30&nbsp;&nbsp; &nbsp;จุด<br />\r\nระบบเสียงตามสาย&nbsp;&nbsp; &nbsp;จำนวน&nbsp;&nbsp; &nbsp;1&nbsp;&nbsp; &nbsp;แห่ง</p>\r\n\r\n<h2 style=\"text-align: center;\"><strong>การศึกษาในตำบล</strong></h2>\r\n\r\n<p style=\"text-align: center;\">&nbsp;&nbsp; &nbsp;โรงเรียนวัดกุดนกเปล้า&nbsp;&nbsp; &nbsp;<br />\r\n&nbsp;&nbsp; &nbsp;โรงเรียนวัดโนนสภาราม&nbsp;&nbsp; &nbsp;<br />\r\n&nbsp;&nbsp; &nbsp;โรงเรียนวัดทุ่งสาริกา</p>\r\n\r\n<h2 style=\"text-align: center;\"><strong>สถาบันและองค์กรศาสนา</strong></h2>\r\n\r\n<p style=\"text-align: center;\"><img src=\"http://www.kudnokplao.go.th/image/condition/social_18.jpg\" style=\"color:rgb(0, 0, 0); font-family:times new roman; font-size:medium; height:154px; text-align:-webkit-center; width:250px\" /></p>\r\n\r\n<p style=\"text-align: center;\">วัดโนนสภาราม&nbsp;&nbsp; &nbsp;ตั้งอยู่หมู่ที่ 2&nbsp;&nbsp; &nbsp;ตำบลกุดนกเปล้า&nbsp;&nbsp; &nbsp;อำเภอเมือง&nbsp;&nbsp; &nbsp;จังหวัดสระบุรี<br />\r\nวัดกุดนกเปล้า&nbsp;&nbsp; &nbsp;ตั้งอยู่หมู่ที่ 3&nbsp;&nbsp; &nbsp;ตำบลกุดนกเปล้า&nbsp;&nbsp; &nbsp;อำเภอเมือง&nbsp;&nbsp; &nbsp;จังหวัดสระบุรี<br />\r\nวัดทุ่งสาริกา&nbsp;&nbsp; &nbsp;ตั้งอยู่หมู่ที่ 5&nbsp;&nbsp; &nbsp;ตำบลกุดนกเปล้า&nbsp;&nbsp; &nbsp;อำเภอเมือง&nbsp;&nbsp; &nbsp;จังหวัดสระบุรี<br />\r\nวัดโคกเพ็ก&nbsp;&nbsp; &nbsp;ตั้งอยู่หมู่ที่ 6&nbsp;&nbsp; &nbsp;ตำบลกุดนกเปล้า&nbsp;&nbsp; &nbsp;อำเภอเมือง&nbsp;&nbsp; &nbsp;จังหวัดสระบุรี<br />\r\nวัดโนนคล้อ&nbsp;&nbsp; &nbsp;ตั้งอยู่หมู่ที่ 7&nbsp;&nbsp; &nbsp;ตำบลกุดนกเปล้า&nbsp;&nbsp; &nbsp;อำเภอเมือง&nbsp;&nbsp; &nbsp;จังหวัดสระบุรี</p>\r\n\r\n<h2 style=\"text-align: center;\"><strong>การสาธารณสุข</strong></h2>\r\n\r\n<p style=\"text-align: center;\">สถานีอนามัยประจำตำบล จำนวน 1 แห่ง มีเจ้าหน้าที่ 3 คน แม่บ้าน 1 คน ตั้งอยู่ที่บ้านโนนสภาราม หมู่ที่ 2 ตำบลกุดนกเปล้า อำเภอเมือง จังหวัดสระบุรี</p>\r\n\r\n<p style=\"text-align: center;\"><img src=\"http://www.kudnokplao.go.th/image/condition/social_27.jpg\" style=\"color:rgb(0, 0, 0); font-family:times new roman; font-size:medium; height:154px; text-align:-webkit-center; width:250px\" /></p>\r\n', NULL, NULL),
(132, 1, 77, 'บริการขึ้นพื้นฐาน', 1, '<p style=\"text-align: center;\">&nbsp;</p>\r\n\r\n<h2 style=\"text-align: center;\"><strong>การคมนาคม</strong></h2>\r\n\r\n<p style=\"text-align: center;\"><img alt=\"\" src=\"http://www.website-thai.com/project/kudnokplao/upload/userfile/images/การคมนาคม.JPG\" style=\"height:186px; width:802px\" /></p>\r\n\r\n<h2 style=\"text-align:center\"><strong>การคมนาคม</strong></h2>\r\n\r\n<p style=\"text-align: center;\"><strong><img alt=\"\" src=\"http://www.website-thai.com/project/kudnokplao/upload/userfile/images/Capture.JPG\" style=\"height:516px; width:357px\" /></strong></p>\r\n\r\n<h2 style=\"text-align: center;\"><strong>ทรัพยากรในพื้นที่</strong></h2>\r\n\r\n<p style=\"text-align: center;\"><img src=\"http://www.kudnokplao.go.th/image/condition/service_23.jpg\" style=\"color:rgb(0, 0, 0); font-family:times new roman; font-size:medium; height:154px; text-align:-webkit-center; width:250px\" /></p>\r\n\r\n<p style=\"text-align: center;\"><span style=\"color:rgb(255, 102, 0); font-family:ms sans serif; font-size:14px\">พื้นที่ของเทศบาลตำบลกุดนกเปล้า เป็นพื้นที่เหมาะแก่การพัฒนา ซึ่งมีพื้นที่ติดกับ เขตเมืองสระบุรี ซึ่งเป็นพื้นที่ที่เหมาะสมในการขยายเป็นเขตพาณิชกรรม ที่อยู่อาศัย สถานศึกษา หรือเขตอุตสาหกรรมในอนาคตได้ และมีการจัดตั้งองค์กรขึ้นหลายองค์กรเพื่อร่วมมือกัน ในการพัฒนาชุมชนของตนเองในด้านอาชีพการอนุรักษ์ทรัพยากรธรรมชาติ เช่น อาสาสมัคร สาธารณสุข, กลุ่มออมทรัพย์เพื่อการผลิต,กลุ่มแม่บ้าน, ผู้นำกลุ่มอาชีพ ฯลฯ ซึ่งองค์กรต่าง ๆ ได้รับการฝึกอบรมและการสนับสนุนจากหน่วยงานจากราชการ</span></p>\r\n\r\n<p style=\"text-align: center;\">&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n', NULL, NULL),
(133, 1, 78, 'สาธารณูปโภค', 1, '<h2 style=\"text-align:center\"><strong>การไฟฟ้า</strong></h2>\r\n\r\n<p style=\"text-align:center\"><img src=\"http://www.kudnokplao.go.th/image/condition/utility_23.jpg\" style=\"color:rgb(0, 0, 0); font-family:times new roman; font-size:medium; height:154px; text-align:-webkit-center; width:250px\" /></p>\r\n\r\n<p style=\"text-align:center\"><span style=\"color:rgb(0, 102, 255); font-family:ms sans serif; font-size:14px\">ไฟฟ้าสาธารณะ หมู่ที่ 1&ndash;8 ตำบลกุดนกเปล้า จำนวน 371 สาย</span></p>\r\n\r\n<h2 style=\"text-align:center\"><strong>การสื่อสาร</strong></h2>\r\n\r\n<p style=\"text-align:center\"><img src=\"http://www.kudnokplao.go.th/image/condition/utility_25.jpg\" style=\"color:rgb(0, 0, 0); font-family:times new roman; font-size:medium; height:154px; text-align:-webkit-center; width:250px\" /></p>\r\n\r\n<p style=\"text-align:center\"><span style=\"color:rgb(0, 153, 0); font-family:ms sans serif; font-size:14px\">มีตู้โทรศัพท์สาธารณะ ตั้งอยู่หมู่ที่ 2 , 3 , 5 , 8ที่ทำการไปรษณีย์โทรเลข</span></p>\r\n\r\n<h2 style=\"text-align:center\"><strong>การประปา</strong></h2>\r\n\r\n<p style=\"text-align:center\"><img src=\"http://www.kudnokplao.go.th/image/condition/utility_33.jpg\" style=\"color:rgb(0, 0, 0); font-family:times new roman; font-size:medium; height:154px; text-align:-webkit-center; width:250px\" /></p>\r\n\r\n<p style=\"text-align:center\"><img src=\"http://www.kudnokplao.go.th/image/condition/utility_35.jpg\" style=\"color:rgb(0, 0, 0); font-family:times new roman; font-size:medium; height:154px; text-align:-webkit-center; width:250px\" /></p>\r\n\r\n<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" style=\"width:100%\">\r\n	<tbody>\r\n		<tr>\r\n			<td>&nbsp;</td>\r\n			<td>\r\n			<p>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;ประปาหมู่ที่ 1 &nbsp; &nbsp;บ้านโง้ง &nbsp; &nbsp;สถานที่ตั้ง ณ บ้านนายสวน สืบสาย</p>\r\n\r\n			<p>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; ประปาหมู่ที่ 2 &nbsp; &nbsp;บ้านโนนสภาราม &nbsp; &nbsp;สถานที่ตั้ง ณ วัดโนนสภาราม</p>\r\n\r\n			<p>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; ประปาหมู่ที่ 3 &nbsp; &nbsp;บ้านกุดนกเปล้า &nbsp; &nbsp;สถานที่ตั้ง ณ โรงเรียนวัดกุดนกเปล้า</p>\r\n\r\n			<p>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; ประปาหมู่ที่ 3 &nbsp; &nbsp;บ้านกุดนกเปล้า &nbsp; &nbsp;สถานที่ตั้ง ณ บ้านนายจรูญ สิทธิการะนา</p>\r\n\r\n			<p>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; ประปาหมู่ที่ 3 &nbsp; &nbsp;บ้านกุดนกเปล้า &nbsp; &nbsp;สถานที่ตั้ง ณ บ้านนายทวน บุญสีมา</p>\r\n\r\n			<p>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; ประปาหมู่ที่ 3 &nbsp; &nbsp;บ้านกุดนกเปล้า &nbsp; &nbsp;สถานที่ตั้ง ณ บ้านนางระเบียบ รอดรักษา</p>\r\n\r\n			<p>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;ประปาหมู่ที่ 4 &nbsp; &nbsp;บ้านป่ากล้วย &nbsp; &nbsp;สถานที่ตั้ง ณ บ้านนายดอน ภักดี</p>\r\n\r\n			<p>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;ประปาหมู่ที่ 4 &nbsp; &nbsp;บ้านป่ากล้วย &nbsp; &nbsp;สถานที่ตั้ง ณ บ้านนางสาววรรณา กุหลาบ</p>\r\n\r\n			<p>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;ประปาหมู่ที่ 4 &nbsp; &nbsp;บ้านป่ากล้วย &nbsp; &nbsp;สถานที่ตั้ง ณ บ้านนายสกุล คำมูล</p>\r\n\r\n			<p>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;ประปาหมู่ที่ 5 &nbsp; &nbsp;บ้านทุ่งสาริกา &nbsp; &nbsp;สถานที่ตั้ง ณ บ้านโรงเรียนวัดทุ่งสาลิกา</p>\r\n\r\n			<p>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;ประปาหมู่ที่ 6 &nbsp; &nbsp;บ้านโคกเพ็ก &nbsp; &nbsp;สถานที่ตั้ง ณ วัดโคกเพ็ก</p>\r\n\r\n			<p>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; ประปาหมู่ที่ 6 &nbsp; &nbsp;บ้านโคกเพ็ก &nbsp; &nbsp;สถานที่ตั้ง ณ บ้านนางจำเนียร ดีนี</p>\r\n\r\n			<p>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; ประปาหมู่ที่ 7 &nbsp; &nbsp;บ้านโน้นคล้อ &nbsp; &nbsp;สถานที่ตั้ง ณ บ้านถนอม กุหลาบ</p>\r\n\r\n			<p>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;ประปาหมู่ที่ 8 &nbsp; &nbsp;บ้านวังยาง &nbsp; &nbsp;สถานที่ตั้ง ณ บ้านสนั่น ยอดเพชร</p>\r\n			</td>\r\n			<td>&nbsp;</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n\r\n<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" style=\"width:100%\">\r\n	<tbody>\r\n		<tr>\r\n			<td style=\"text-align:center\">&nbsp;</td>\r\n		</tr>\r\n		<tr>\r\n			<td>&nbsp;</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n', NULL, NULL),
(134, 1, 79, 'วัดโนนสภาราม ', 1, '<p>ชื่อสถานที่&nbsp;&nbsp; &nbsp;:&nbsp;&nbsp; &nbsp;วัดโนนสภาราม&nbsp;&nbsp; &nbsp;<br />\r\n&nbsp;<br />\r\nที่ตั้ง&nbsp;&nbsp; &nbsp;:&nbsp;&nbsp; &nbsp;ตำบลกุดนกเปล้า อำเภอเมือง จังหวัดสระบุรี&nbsp;&nbsp; &nbsp;<br />\r\n&nbsp;<br />\r\nข้อมูล&nbsp;&nbsp; &nbsp;:&nbsp;&nbsp; &nbsp;วัดโนนสภาราม เป็นวัดประจำตำบลกุดนกเปล้า เป็นสถานที่สำคัญที่ชาวบ้านให้ความเคารพนับถือ เป็นที่ยึดเหนี่ยวจิตใจ และเป็นศูนย์รวมจิตใจของชาวบ้านในตำบล&nbsp;&nbsp; &nbsp;<br />\r\n&nbsp;</p>\r\n\r\n<p style=\"text-align: center;\"><img alt=\"\" src=\"http://www.website-thai.com/project/kudnokplao/upload/userfile/images/วัดโนนสภาราม 1.jpg\" style=\"height:212px; width:320px\" /><img alt=\"\" src=\"http://www.website-thai.com/project/kudnokplao/upload/userfile/images/วัดโนนสภาราม 3.jpg\" style=\"height:212px; width:320px\" /><img alt=\"\" src=\"http://www.website-thai.com/project/kudnokplao/upload/userfile/images/วัดโนนสภาราม 4.jpg\" style=\"height:212px; width:320px\" /></p>\r\n', NULL, NULL),
(135, 1, 80, 'วัดโคกเพ็ก', 1, '<p>ชื่อสถานที่&nbsp;&nbsp; &nbsp;:&nbsp;&nbsp; &nbsp;วัดโคกเพ็ก&nbsp;&nbsp; &nbsp;<br />\r\n&nbsp;<br />\r\nที่ตั้ง&nbsp;&nbsp; &nbsp;:&nbsp;&nbsp; &nbsp;ตำบลกุดนกเปล้า อำเภอเมือง จังหวัดนครสวรรค์&nbsp;&nbsp; &nbsp;<br />\r\n&nbsp;<br />\r\nข้อมูล&nbsp;&nbsp; &nbsp;:&nbsp;&nbsp; &nbsp;วัดโคกเพ็ก เป็นวัดประจำตำบลกุดนกเปล้า ที่ชาวบ้านให้ความเคารพนับถือ มีพระนอนเป็นจุดเด่น อีกยังเป็นศูนย์รวมจิตใจของชาวบ้านในตำบล อีกด้วย</p>\r\n\r\n<p style=\"text-align: center;\"><img alt=\"\" src=\"http://www.website-thai.com/project/kudnokplao/upload/userfile/images/วัดโคกเพ็ก1.jpg\" style=\"height:212px; width:320px\" /><img alt=\"\" src=\"http://www.website-thai.com/project/kudnokplao/upload/userfile/images/วัดโคกเพ็ก2.jpg\" style=\"height:212px; width:320px\" /></p>\r\n', NULL, NULL),
(136, 1, 81, 'วัดกุดนกเปล้า', 1, '<p>ชื่อสถานที่&nbsp;&nbsp; &nbsp;:&nbsp;&nbsp; &nbsp;วัดกุดนกเปล้า&nbsp;&nbsp; &nbsp;<br />\r\n&nbsp;<br />\r\nที่ตั้ง&nbsp;&nbsp; &nbsp;:&nbsp;&nbsp; &nbsp;ตำบลกุดนกเปล้า อำเภอเมือง จังหวัดสระบุรี&nbsp;&nbsp; &nbsp;<br />\r\n&nbsp;<br />\r\nข้อมูล&nbsp;&nbsp; &nbsp;:&nbsp;&nbsp; &nbsp;วัดกุดนกเปล้า เป็นวัดประจำตำบลกุดนกเปล้า ที่ชาวบ้านให้ความเคารพบูชา เป็นศูนย์รวมจิตใจของชาวบ้านในตำบล&nbsp;&nbsp; &nbsp;<br />\r\n&nbsp;</p>\r\n\r\n<p style=\"text-align: center;\"><img alt=\"\" src=\"http://www.website-thai.com/project/kudnokplao/upload/userfile/images/วัดกุดนกเปล้า1.jpg\" style=\"height:212px; width:320px\" /><img alt=\"\" src=\"http://www.website-thai.com/project/kudnokplao/upload/userfile/images/วัดกุดนกเปล้า2.jpg\" style=\"height:240px; width:159px\" /></p>\r\n', NULL, NULL),
(137, 1, 82, 'วัดทุ่งสาริกา', 1, '<p>ชื่อสถานที่&nbsp;&nbsp; &nbsp;:&nbsp;&nbsp; &nbsp;วัดทุ่งสาริกา&nbsp;&nbsp; &nbsp;<br />\r\n&nbsp;<br />\r\nที่ตั้ง&nbsp;&nbsp; &nbsp;:&nbsp;&nbsp; &nbsp;ตำบลกุดนกเปล้า อำเภอเมือง จ.สระบุรี&nbsp;&nbsp; &nbsp;<br />\r\n&nbsp;<br />\r\nข้อมูล&nbsp;&nbsp; &nbsp;:&nbsp;&nbsp; &nbsp;วัดทุ่งสาริกา เป็นวัดที่อยู่ในตำบลกุดนกเปล้า เป็นที่เคารพบูชาของชาวบ้านในตำบลกุดนกเปล้า</p>\r\n\r\n<p style=\"text-align: center;\"><img alt=\"\" src=\"http://www.website-thai.com/project/kudnokplao/upload/userfile/images/ทุ่ง1.jpg\" style=\"height:212px; width:320px\" /><img alt=\"\" src=\"http://www.website-thai.com/project/kudnokplao/upload/userfile/images/ทุ่ง2.jpg\" style=\"height:212px; width:320px\" /></p>\r\n', NULL, NULL),
(138, 1, 83, 'รพสต.กุดนกเปล้า  (จังหวัด สระบุรี)', 1, '<p>ชื่อสถานที่&nbsp;&nbsp; &nbsp;:&nbsp;&nbsp; &nbsp;รพสต.กุดนกเปล้า&nbsp;&nbsp; &nbsp;<br />\r\n&nbsp;<br />\r\nที่ตั้ง&nbsp;&nbsp; &nbsp;:&nbsp;&nbsp; &nbsp;ตำบลกุดนกเปล้า อำเภอเมือง จังหวัดสระบุรี&nbsp;&nbsp; &nbsp;<br />\r\n&nbsp;<br />\r\nข้อมูล&nbsp;&nbsp; &nbsp;:&nbsp;&nbsp; &nbsp;โรงพยาบาลส่งเสริมสุขภาพตำบลกุดนกเปล้า เป็นศูนย์ อนามัยที่คอยให้บริการแก่ชาวบ้าน ในเรื่องของสุขภาพอนามัย ในตำบล</p>\r\n\r\n<p style=\"text-align: center;\"><img alt=\"\" src=\"http://www.website-thai.com/project/kudnokplao/upload/userfile/images/รพสต1.jpg\" style=\"height:212px; width:320px\" /><img alt=\"\" src=\"http://www.website-thai.com/project/kudnokplao/upload/userfile/images/รพสต22.jpg\" style=\"height:212px; width:320px\" /></p>\r\n', NULL, NULL),
(139, 1, 84, 'วัดโนนคล้อ', 1, '<p>ชื่อสถานที่&nbsp;&nbsp; &nbsp;:&nbsp;&nbsp; &nbsp;วัดโนนคล้อ&nbsp;&nbsp; &nbsp;<br />\r\n&nbsp;<br />\r\nที่ตั้ง&nbsp;&nbsp; &nbsp;:&nbsp;&nbsp; &nbsp;ตำบลกุดนกเปล้า อำเภอเมือง จังหวัดนครสวรรค์&nbsp;&nbsp; &nbsp;<br />\r\n&nbsp;<br />\r\nข้อมูล&nbsp;&nbsp; &nbsp;:&nbsp;&nbsp; &nbsp;วัดโนนคล้อ เป็นวัดที่อยู่ในตำบลกุดนกเปล้า เป็นวัดที่ชาวบ้านเคารพนับถือ เป็นที่ยึดเหนี่ยวจิตใจของคนในตำบล</p>\r\n\r\n<p style=\"text-align: center;\"><img alt=\"\" src=\"http://www.website-thai.com/project/kudnokplao/upload/userfile/images/วัดโนนคล้อ1.jpg\" style=\"height:212px; width:320px\" /><img alt=\"\" src=\"http://www.website-thai.com/project/kudnokplao/upload/userfile/images/วัดโนนคล้อ2.jpg\" style=\"height:212px; width:320px\" /></p>\r\n\r\n<p>&nbsp;</p>\r\n', NULL, NULL),
(140, 1, 85, 'วิสัยทัศน์', 1, '<p style=\"text-align:center\"><img alt=\"\" src=\"http://www.website-thai.com/project/kudnokplao/upload/userfile/images/Capture(1).JPG\" style=\"height:238px; width:880px\" /></p>\r\n\r\n<h2><span style=\"color:#FF0000\"><strong>พันธกิจ</strong></span></h2>\r\n\r\n<p><img alt=\"enlightened\" src=\"http://www.website-thai.com/project/kudnokplao/required/ckeditor/plugins/smiley/images/lightbulb.gif\" style=\"height:20px; width:20px\" title=\"enlightened\" />&nbsp;&nbsp; &nbsp; จัดการบริการขั้นพื้นฐานด้านสาธารณูปโภค สาธารณูปการ อย่างพอเพียงและทั่วถึงโดยควบคุมให้สอดคล้องกับระบบผังเมืองรวมและมีความพร้อมในการรองรับการขยายตัวของชุมชน</p>\r\n\r\n<p><img alt=\"enlightened\" src=\"http://www.website-thai.com/project/kudnokplao/required/ckeditor/plugins/smiley/images/lightbulb.gif\" style=\"height:20px; width:20px\" title=\"enlightened\" />&nbsp;&nbsp; &nbsp; พัฒนาเทศบาลตำบลกุดนกเปล้าให้เป็นเมืองน่าอยู่ มีสภาพภูมิทัศน์สวยงาม มีความสะอาดและความเป็นระเบียบเรียบร้อย ปราศจากมลภาวะ</p>\r\n\r\n<p><img alt=\"enlightened\" src=\"http://www.website-thai.com/project/kudnokplao/required/ckeditor/plugins/smiley/images/lightbulb.gif\" style=\"height:20px; width:20px\" title=\"enlightened\" />&nbsp;&nbsp; &nbsp; เทศบาลบาลตำบลกุดนกเปล้า มีระบบการบริหารงานที่มีประสิทธิภาพโปร่งใส มีขีดความสามารถในการแก้ไขปัญหาความเดือดร้อนได้ตรงความต้องการของประชาชน โดยเสริมสร้างเครือข่ายการประสานงานทั้งภาครัฐและเอกชน รวมทั้งแสวงหาแหล่งรายได้ใหม่ เพื่อนำมาพัฒนาตำบล</p>\r\n\r\n<p><img alt=\"enlightened\" src=\"http://www.website-thai.com/project/kudnokplao/required/ckeditor/plugins/smiley/images/lightbulb.gif\" style=\"height:20px; width:20px\" title=\"enlightened\" />&nbsp;&nbsp; &nbsp; ประชาชนได้รับการพัฒนาด้านการศึกษาอย่างมีคุณภาพและมีมาตรฐาน เป็นสังคมแห่งภูมิปัญญาท้องถิ่นและการเรียนรู้ คิดเป็น ทำเป็น แก้ไขปัญหาเป็น มีช่องทางรับรู้ข้อมูลข่าวสารที่ทันสมัย สามารถปรับตัวต่อสภาพการที่เปลี่ยนแปลงและดำรงตนในสังคมได้อย่างมีคุณค่า</p>\r\n\r\n<p><img alt=\"enlightened\" src=\"http://www.website-thai.com/project/kudnokplao/required/ckeditor/plugins/smiley/images/lightbulb.gif\" style=\"height:20px; width:20px\" title=\"enlightened\" />&nbsp;&nbsp; &nbsp; ประชาชนมีคุณภาพชีวิตที่ดี มีอาชีพ รายได้ มีความมั่นคงทางสังคม มีความปลอดภัยในชีวิตและทรัพย์สิน มีสุขอนามัยและความเป็นอยู่ที่ดี ปลอดภัยจากโรคภัยไข้เจ็บและยาเสพติดผู้สูงอายุ ผู้ด้อยโอกาสได้รับการดูแลเอาใจใส่อย่างทั่วถึง&nbsp;พัฒนาชุมชนภายในเทศบาลตำบลกุดนกเปล้าให้เป็นชุมชนเข้มแข็ง มีจิตสำนึก มีศักยภาพในการร่วมคิด ร่วมทำ ร่วมรับผิดชอบ สามารถแก้ไขปัญหาและพัฒนาชุมชนของตนเองอย่างมีประสิทธิภาพ</p>\r\n\r\n<p><img alt=\"enlightened\" src=\"http://www.website-thai.com/project/kudnokplao/required/ckeditor/plugins/smiley/images/lightbulb.gif\" style=\"height:20px; width:20px\" title=\"enlightened\" />&nbsp;&nbsp; &nbsp; ประชาชน เจ้าหน้าที่ของรัฐ ผู้นำท้องถิ่น ตระหนักถึงภาระหน้าที่ความรับผิดชอบในการปกครองระบอบประชาธิปไตย มีคุณภาพ คุณธรรม โปร่งใส และยุติธรรม ประชาชนมีส่วนร่วมในการแสดงความคิดเห็นและมีส่วนร่วมในการเลือกตั้งทุกระดับ</p>\r\n\r\n<p><img alt=\"enlightened\" src=\"http://www.website-thai.com/project/kudnokplao/required/ckeditor/plugins/smiley/images/lightbulb.gif\" style=\"height:20px; width:20px\" title=\"enlightened\" />&nbsp;&nbsp; &nbsp; ส่งเสริมการปฏิบัติตามแนวทางพระราชดำริเศรษฐกิจพอเพียง ไร่นาสวนผสม และระบบเกษตรอินทรีย์หรือเกษตรชีวภาพ เพื่อลดการใช้สารเคมี ให้ประชาชนปลอดภัยจากสารพิษ</p>\r\n\r\n<p><img alt=\"enlightened\" src=\"http://www.website-thai.com/project/kudnokplao/required/ckeditor/plugins/smiley/images/lightbulb.gif\" style=\"height:20px; width:20px\" title=\"enlightened\" />&nbsp;&nbsp; &nbsp; บริหารจัดการทรัพยากรธรรมชาติและสิ่งแวดล้อมภายในเทศบาลตำบลกุดนกเปล้า โดยส่งเสริมให้ประชาชนมีความตระหนักและมีจิตสำนึกที่ดีในการป้องกันและรักษาทรัพยากรธรรมชาติให้สวยงามยั่งยืน</p>\r\n', NULL, NULL),
(141, 1, 86, 'ยุทธศาสตร์', 1, '<h1><span style=\"color:#3399ff\"><strong>ยุทธศาสตร์ที่ 1 การพัฒนาด้านคุณภาพชีวิตตามปรัชญาเศรษฐกิจพอเพียง</strong></span></h1>\r\n\r\n<p><img alt=\"enlightened\" src=\"http://www.website-thai.com/project/kudnokplao/required/ckeditor/plugins/smiley/images/lightbulb.gif\" style=\"height:20px; width:20px\" title=\"enlightened\" />&nbsp;&nbsp; &nbsp; การส่งเสริมและพัฒนาการศึกษา</p>\r\n\r\n<p><img alt=\"enlightened\" src=\"http://www.website-thai.com/project/kudnokplao/required/ckeditor/plugins/smiley/images/lightbulb.gif\" style=\"height:20px; width:20px\" title=\"enlightened\" />&nbsp;&nbsp; &nbsp; ส่งเสริมและการจัดสวัสดิการสังคม สงเคราะห์</p>\r\n\r\n<p><img alt=\"enlightened\" src=\"http://www.website-thai.com/project/kudnokplao/required/ckeditor/plugins/smiley/images/lightbulb.gif\" style=\"height:20px; width:20px\" title=\"enlightened\" />&nbsp;&nbsp; &nbsp; ส่งเสริมการบริการด้านสาธารณสุขรวมถึงการส่งเสริมสร้างสุขภาวะทางกายและทางใจ</p>\r\n\r\n<p><img alt=\"enlightened\" src=\"http://www.website-thai.com/project/kudnokplao/required/ckeditor/plugins/smiley/images/lightbulb.gif\" style=\"height:20px; width:20px\" title=\"enlightened\" />&nbsp;&nbsp; &nbsp; พัฒนาด้านโครงสร้างพื้นฐานสาธารณูปโภคสาธารณูปการ</p>\r\n\r\n<p><img alt=\"enlightened\" src=\"http://www.website-thai.com/project/kudnokplao/required/ckeditor/plugins/smiley/images/lightbulb.gif\" style=\"height:20px; width:20px\" title=\"enlightened\" />&nbsp;&nbsp; &nbsp; การสร้างความเข้มแข็งของชุมชนและสังคม</p>\r\n\r\n<p><img alt=\"enlightened\" src=\"http://www.website-thai.com/project/kudnokplao/required/ckeditor/plugins/smiley/images/lightbulb.gif\" style=\"height:20px; width:20px\" title=\"enlightened\" />&nbsp;&nbsp; &nbsp; การเพิ่มศักยภาพและพัฒนาอาชีพของชุมชน</p>\r\n\r\n<p><img alt=\"enlightened\" src=\"http://www.website-thai.com/project/kudnokplao/required/ckeditor/plugins/smiley/images/lightbulb.gif\" style=\"height:20px; width:20px\" title=\"enlightened\" />&nbsp;&nbsp; &nbsp; ส่งเสริมและสนับสนุนการสร้างความเข้มแข็งของชุมชนด้านเศรษฐกิจ</p>\r\n\r\n<p><img alt=\"enlightened\" src=\"http://www.website-thai.com/project/kudnokplao/required/ckeditor/plugins/smiley/images/lightbulb.gif\" style=\"height:20px; width:20px\" title=\"enlightened\" />&nbsp;&nbsp; &nbsp; การพัฒนาแหล่งน้ำเพื่อการเกษตร</p>\r\n\r\n<p><img alt=\"enlightened\" src=\"http://www.website-thai.com/project/kudnokplao/required/ckeditor/plugins/smiley/images/lightbulb.gif\" style=\"height:20px; width:20px\" title=\"enlightened\" />&nbsp;&nbsp; &nbsp; การส่งเสริมการพัฒนาเกษตรทฤษฎีใหม่</p>\r\n\r\n<p><img alt=\"enlightened\" src=\"http://www.website-thai.com/project/kudnokplao/required/ckeditor/plugins/smiley/images/lightbulb.gif\" style=\"height:20px; width:20px\" title=\"enlightened\" />&nbsp;&nbsp; &nbsp; ส่งเสริมศูนย์บริการและถ่ายทอดเทคโนโลยีด้านการเกษตร</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<h1><span style=\"color:rgb(51, 153, 255)\"><strong>ยุทธศาสตร์ที่ 2&nbsp;การพัฒนาการบริหารจัดการทรัพยากรธรรมชาติและสิ่งแวดล้อม</strong></span></h1>\r\n\r\n<p><img alt=\"enlightened\" src=\"http://www.website-thai.com/project/kudnokplao/required/ckeditor/plugins/smiley/images/lightbulb.gif\" style=\"height:20px; width:20px\" title=\"enlightened\" />&nbsp;&nbsp; &nbsp; อนุรักษ์และพัฒนาทรัพยากรธรรมชาติและสิ่งแวดล้อม</p>\r\n\r\n<p><img alt=\"enlightened\" src=\"http://www.website-thai.com/project/kudnokplao/required/ckeditor/plugins/smiley/images/lightbulb.gif\" style=\"height:20px; width:20px\" title=\"enlightened\" />&nbsp;&nbsp; &nbsp; สร้างจิตสำนึกและตระหนักในการรักษาทรัพยากรธรรมชาติและสิ่งแวดล้อม</p>\r\n\r\n<p><img alt=\"enlightened\" src=\"http://www.website-thai.com/project/kudnokplao/required/ckeditor/plugins/smiley/images/lightbulb.gif\" style=\"height:20px; width:20px\" title=\"enlightened\" />&nbsp;&nbsp; &nbsp; การบริหารจัดการขยะมูลฝอยและสิ่งแวดล้อม</p>\r\n\r\n<p><img alt=\"enlightened\" src=\"http://www.website-thai.com/project/kudnokplao/required/ckeditor/plugins/smiley/images/lightbulb.gif\" style=\"height:20px; width:20px\" title=\"enlightened\" />&nbsp;&nbsp; &nbsp; การป้องกันและแก้ไขปัญหาสิ่งแวดล้อม</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<h1><span style=\"color:rgb(51, 153, 255)\"><strong>ยุทธศาสตร์ที่ 3&nbsp;การอนุรักษ์ฟื้นฟู ศาสนา ศิลปะ วัฒนธรรม ขนบธรรมเนียมประเพณีและภูมิปัญญาท้องถิ่น</strong></span></h1>\r\n\r\n<p><img alt=\"enlightened\" src=\"http://www.website-thai.com/project/kudnokplao/required/ckeditor/plugins/smiley/images/lightbulb.gif\" style=\"height:20px; width:20px\" title=\"enlightened\" />&nbsp;&nbsp; &nbsp; ส่งเสริมอนุรักษ์และฟื้นฟูวัฒนธรรมขนบธรรมเนียมประเพณีและวันสำคัญ</p>\r\n\r\n<p><img alt=\"enlightened\" src=\"http://www.website-thai.com/project/kudnokplao/required/ckeditor/plugins/smiley/images/lightbulb.gif\" style=\"height:20px; width:20px\" title=\"enlightened\" />&nbsp;&nbsp; &nbsp; สร้างจิตสำนึกและตระหนักในคุณค่าและความสำคัญศิลปวัฒนธรรม ขนบธรรมเนียมประเพณีท้องถิ่น</p>\r\n\r\n<p><img alt=\"enlightened\" src=\"http://www.website-thai.com/project/kudnokplao/required/ckeditor/plugins/smiley/images/lightbulb.gif\" style=\"height:20px; width:20px\" title=\"enlightened\" />&nbsp;&nbsp; &nbsp; ส่งเสริมและเผยแพร่ภูมิปัญญาท้องถิ่น</p>\r\n\r\n<p><img alt=\"enlightened\" src=\"http://www.website-thai.com/project/kudnokplao/required/ckeditor/plugins/smiley/images/lightbulb.gif\" style=\"height:20px; width:20px\" title=\"enlightened\" />&nbsp;&nbsp; &nbsp; ส่งเสริมศาสนา พัฒนาคุณธรรมจริยธรรม</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<h1><span style=\"color:rgb(51, 153, 255)\"><strong>ยุทธศาสตร์ที่ 4&nbsp;การพัฒนาด้านองค์กรและบุคลากรและบุคลากรภาครัฐสู่การบริหารการจัดการที่ดี</strong></span></h1>\r\n\r\n<p><img alt=\"enlightened\" src=\"http://www.website-thai.com/project/kudnokplao/required/ckeditor/plugins/smiley/images/lightbulb.gif\" style=\"height:20px; width:20px\" title=\"enlightened\" />&nbsp;&nbsp; &nbsp; พัฒนาศักยภาพและประสิทธิภาพบุคลากรของท้องถิ่น</p>\r\n\r\n<p><img alt=\"enlightened\" src=\"http://www.website-thai.com/project/kudnokplao/required/ckeditor/plugins/smiley/images/lightbulb.gif\" style=\"height:20px; width:20px\" title=\"enlightened\" />&nbsp;&nbsp; &nbsp; พัฒนาระบบบริหารงานองค์กร</p>\r\n\r\n<p><img alt=\"enlightened\" src=\"http://www.website-thai.com/project/kudnokplao/required/ckeditor/plugins/smiley/images/lightbulb.gif\" style=\"height:20px; width:20px\" title=\"enlightened\" />&nbsp;&nbsp; &nbsp; พัฒนาคุณภาพการให้บริการประชาชน</p>\r\n\r\n<p><img alt=\"enlightened\" src=\"http://www.website-thai.com/project/kudnokplao/required/ckeditor/plugins/smiley/images/lightbulb.gif\" style=\"height:20px; width:20px\" title=\"enlightened\" />&nbsp;&nbsp; &nbsp; พัฒนาระบบเทคโนโลยีสารสนเทศ</p>\r\n\r\n<p><img alt=\"enlightened\" src=\"http://www.website-thai.com/project/kudnokplao/required/ckeditor/plugins/smiley/images/lightbulb.gif\" style=\"height:20px; width:20px\" title=\"enlightened\" />&nbsp;&nbsp; &nbsp; ส่งเสริมการมีส่วนร่วมของประชาชนในการจัดทำแผนชุมชน</p>\r\n\r\n<p><img alt=\"enlightened\" src=\"http://www.website-thai.com/project/kudnokplao/required/ckeditor/plugins/smiley/images/lightbulb.gif\" style=\"height:20px; width:20px\" title=\"enlightened\" />&nbsp;&nbsp; &nbsp;ส่งเสริมการเรียนรู้และการบริหารจัดการที่ดี</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<h1><span style=\"color:rgb(51, 153, 255)\"><strong>ยุทธศาสตร์ที่ 5&nbsp;การพัฒนาด้านการท่องเที่ยว</strong></span></h1>\r\n\r\n<p><img alt=\"enlightened\" src=\"http://www.website-thai.com/project/kudnokplao/required/ckeditor/plugins/smiley/images/lightbulb.gif\" style=\"height:20px; width:20px\" title=\"enlightened\" />&nbsp;&nbsp; &nbsp; ประชาสัมพันธ์การท่องเที่ยว</p>\r\n\r\n<p><img alt=\"enlightened\" src=\"http://www.website-thai.com/project/kudnokplao/required/ckeditor/plugins/smiley/images/lightbulb.gif\" style=\"height:20px; width:20px\" title=\"enlightened\" />&nbsp;&nbsp; &nbsp; พัฒนาแหล่งท่องเที่ยวอย่างเป็นธรรม</p>\r\n\r\n<p><img alt=\"enlightened\" src=\"http://www.website-thai.com/project/kudnokplao/required/ckeditor/plugins/smiley/images/lightbulb.gif\" style=\"height:20px; width:20px\" title=\"enlightened\" />&nbsp;&nbsp; &nbsp; ส่งเสริมการสนับสนุนงบประมาณและบุคลากรด้านการท่องเที่ยว</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<h1><span style=\"color:rgb(51, 153, 255)\"><strong>ยุทธศาสตร์ที่ 6&nbsp;การพัฒนาด้านการส่งเสริมพัฒนาประชาธิปไตยและกระบวนการประชาสังคม</strong></span></h1>\r\n\r\n<p><img alt=\"enlightened\" src=\"http://www.website-thai.com/project/kudnokplao/required/ckeditor/plugins/smiley/images/lightbulb.gif\" style=\"height:20px; width:20px\" title=\"enlightened\" />&nbsp;&nbsp; &nbsp; ส่งเสริมกระบวนการเรียนรู้การมีส่วนร่วมทางการเมือง</p>\r\n\r\n<p><img alt=\"enlightened\" src=\"http://www.website-thai.com/project/kudnokplao/required/ckeditor/plugins/smiley/images/lightbulb.gif\" style=\"height:20px; width:20px\" title=\"enlightened\" />&nbsp;&nbsp; &nbsp; พัฒนาระบบการให้บริการและเผยแพร่ข้อมูลข่าวสารการเมืองการปกครองระบอบประชาธิปไตย</p>\r\n\r\n<p><img alt=\"enlightened\" src=\"http://www.website-thai.com/project/kudnokplao/required/ckeditor/plugins/smiley/images/lightbulb.gif\" style=\"height:20px; width:20px\" title=\"enlightened\" />&nbsp;&nbsp; &nbsp; ส่งเสริมและพัฒนากระบวนการประชาสังคม</p>\r\n', NULL, NULL),
(142, 1, 87, 'ขอส่งหนังสือมาตรฐานการดำเนินงานศูนย์พัฒนาเด็กเล็กขององค์กรปกครองส่วนท้องถิ่น ประจำปีงบประมาณ พ.ศ. 2559 กศ. มท0816.4/ว405    ', 1, '', NULL, NULL),
(143, 1, 88, 'test', 1, '<p>sss</p>\r\n', NULL, NULL),
(144, 1, 89, 'คู่มือต่างๆ', 1, NULL, NULL, NULL),
(145, 1, 90, 'สาธารณสุขและสิ่งเเวดล้อม', 1, '<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" style=\"width:100%\">\r\n	<tbody>\r\n		<tr>\r\n			<td>&nbsp;</td>\r\n			<td style=\"text-align:center\">\r\n			<p>&nbsp;</p>\r\n\r\n			<p><img alt=\"\" src=\"http://website-thai.com/project/kudnokplao/upload/userfile/images/897(1).png\" style=\"height:250px; width:350px\" /></p>\r\n			</td>\r\n			<td>&nbsp;</td>\r\n		</tr>\r\n		<tr>\r\n			<td style=\"text-align:center\">\r\n			<p>&nbsp;</p>\r\n\r\n			<p><img alt=\"\" src=\"http://website-thai.com/project/kudnokplao/upload/userfile/images/66666.JPG\" style=\"height:250px; width:125px\" /></p>\r\n\r\n			<p><img alt=\"\" src=\"http://website-thai.com/project/kudnokplao/upload/userfile/images/ช666(1).jpg\" style=\"height:60px; width:135px\" /></p>\r\n\r\n			<p>&nbsp;</p>\r\n			</td>\r\n			<td style=\"text-align:center\">\r\n			<p><img alt=\"\" src=\"http://website-thai.com/project/kudnokplao/upload/userfile/images/1111111.JPG\" style=\"height:250px; width:125px\" /></p>\r\n\r\n			<p><img alt=\"\" src=\"http://website-thai.com/project/kudnokplao/upload/userfile/images/ช111(2).jpg\" style=\"height:60px; width:135px\" /></p>\r\n			</td>\r\n			<td style=\"text-align:center\">\r\n			<p><img alt=\"\" src=\"http://website-thai.com/project/kudnokplao/upload/userfile/images/2222222(2).JPG\" style=\"height:250px; width:125px\" /></p>\r\n\r\n			<p><img alt=\"\" src=\"http://website-thai.com/project/kudnokplao/upload/userfile/images/ช222(2).jpg\" style=\"height:60px; width:125px\" /></p>\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td style=\"text-align:center\">\r\n			<p><img alt=\"\" src=\"http://website-thai.com/project/kudnokplao/upload/userfile/images/333333.JPG\" style=\"height:250px; width:125px\" /></p>\r\n\r\n			<p><img alt=\"\" src=\"http://website-thai.com/project/kudnokplao/upload/userfile/images/ช444.jpg\" style=\"height:60px; width:135px\" /></p>\r\n			</td>\r\n			<td style=\"text-align:center\">\r\n			<p><img alt=\"\" src=\"http://website-thai.com/project/kudnokplao/upload/userfile/images/777777.JPG\" style=\"height:250px; width:125px\" /></p>\r\n\r\n			<p><img alt=\"\" src=\"http://website-thai.com/project/kudnokplao/upload/userfile/images/ช555.jpg\" style=\"height:60px; width:135px\" /></p>\r\n			</td>\r\n			<td style=\"text-align:center\">\r\n			<p><img alt=\"\" src=\"http://website-thai.com/project/kudnokplao/upload/userfile/images/444444.JPG\" style=\"height:250px; width:125px\" /></p>\r\n\r\n			<p><img alt=\"\" src=\"http://website-thai.com/project/kudnokplao/upload/userfile/images/ช777.jpg\" style=\"height:60px; width:135px\" /></p>\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td style=\"text-align:center\">\r\n			<p><img alt=\"\" src=\"http://website-thai.com/project/kudnokplao/upload/userfile/images/555555.JPG\" style=\"height:250px; width:125px\" /></p>\r\n\r\n			<p><img alt=\"\" src=\"http://website-thai.com/project/kudnokplao/upload/userfile/images/ช333.jpg\" style=\"height:60px; width:135px\" /></p>\r\n			</td>\r\n			<td style=\"text-align:center\">\r\n			<p>&nbsp;</p>\r\n			</td>\r\n			<td style=\"text-align:center\">\r\n			<p>&nbsp;</p>\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td>&nbsp;</td>\r\n			<td>&nbsp;</td>\r\n			<td>&nbsp;</td>\r\n		</tr>\r\n		<tr>\r\n			<td>&nbsp;</td>\r\n			<td>&nbsp;</td>\r\n			<td>&nbsp;</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n\r\n<p>&nbsp;</p>\r\n', NULL, NULL),
(146, 1, 91, 'ผู้นำชุมชน', 1, '<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" style=\"width:100%\">\r\n	<tbody>\r\n		<tr>\r\n			<td>&nbsp;</td>\r\n			<td style=\"text-align:center\">\r\n			<p><img alt=\"\" src=\"http://www.website-thai.com/project/kudnokplao/upload/userfile/images/นายสมนึก กล้วยป่า.jpg\" style=\"height:151px; width:125px\" /></p>\r\n\r\n			<p>นายสมนึก กล้วยป่า<br />\r\n			กำนันตำบลกุดนกเปล้า</p>\r\n			</td>\r\n			<td>&nbsp;</td>\r\n		</tr>\r\n		<tr>\r\n			<td style=\"text-align:center\">\r\n			<p><img alt=\"\" src=\"http://www.website-thai.com/project/kudnokplao/upload/userfile/images/นายวิเชียร ศิริกุล.jpg\" style=\"height:151px; width:125px\" /></p>\r\n\r\n			<p><span style=\"font-family:ms sans serif; font-size:14px\">นายวิเชียร ศิริกุล&nbsp;</span><br />\r\n			<span style=\"font-family:ms sans serif; font-size:14px\">ผู่ใหญ่บ้าน หมู่ที่ 1</span></p>\r\n			</td>\r\n			<td style=\"text-align:center\">\r\n			<p><img alt=\"\" src=\"http://www.website-thai.com/project/kudnokplao/upload/userfile/images/นายวิรชัย บัวดี.jpg\" style=\"height:151px; width:125px\" /></p>\r\n\r\n			<p>นายวิรชัย บัวดี<br />\r\n			ผู้ใหญ่บ้าน หมู่ที่ 2</p>\r\n			</td>\r\n			<td style=\"text-align:center\">\r\n			<p>&nbsp;</p>\r\n\r\n			<p>นายยืนยง อินทรพันธ์&nbsp;<br />\r\n			ผู้ใหญ่บ้าน หมู่ที่ 3</p>\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td style=\"text-align:center\">\r\n			<p>&nbsp;</p>\r\n\r\n			<p>นายสนั่น ถากา<br />\r\n			ผู้ใหญ่บ้าน หมู่ที่ 4</p>\r\n			</td>\r\n			<td style=\"text-align:center\">\r\n			<p><img alt=\"\" src=\"http://www.website-thai.com/project/kudnokplao/upload/userfile/images/นายสันทัด คำพันธ์.jpg\" style=\"height:151px; width:125px\" /></p>\r\n\r\n			<p>นายสันทัด คำพันธ์<br />\r\n			ผู้ใหญ่บ้าน หมู่ที่ 5</p>\r\n			</td>\r\n			<td style=\"text-align:center\">\r\n			<p><img alt=\"\" src=\"http://www.website-thai.com/project/kudnokplao/upload/userfile/images/นายสมัย มณีแก้ว.jpg\" style=\"height:151px; width:125px\" /></p>\r\n\r\n			<p>นายสมัย มณีแก้ว<br />\r\n			ผู่ใหญ่บ้าน หมู่ที่ 6</p>\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td style=\"text-align:center\">\r\n			<p><img alt=\"\" src=\"http://www.website-thai.com/project/kudnokplao/upload/userfile/images/นายสุทิน น่วมแก้ว.jpg\" style=\"height:151px; width:125px\" /></p>\r\n\r\n			<p>นายสุทิน น่วมแก้ว<br />\r\n			ผู้ใหญ่บ้าน หมู่ที่ 7</p>\r\n			</td>\r\n			<td>&nbsp;</td>\r\n			<td>&nbsp;</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n\r\n<p>&nbsp;</p>\r\n', NULL, NULL),
(147, 1, 92, 'การวางอุปกรณ์รับชำระเงินทางอิเล็กทรอนิกส์ ด่วนที่สุด กค. มท 0803.3/ว591', 1, '', NULL, NULL),
(148, 1, 93, 'ประกาศผลการประกวดสื่อเทคโนโลยีสารสนเทศเพื่อการเรียนการสอนท้องถิ่น ประจำปี 2559 ด่วนที่สุด กศ. มท 0816.1/ว587 ', 1, '', NULL, NULL),
(149, 1, 94, 'ยุทธศาสตร์ ที่ 1 ', 1, '<ul>\r\n	<li>\r\n	<p><strong>การพัฒนาคุณภาพชีวิตตามปรัชญาเศรษกิจพอเพียง</strong></p>\r\n	</li>\r\n</ul>\r\n\r\n<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" style=\"width:100%\">\r\n	<tbody>\r\n		<tr>\r\n			<td>\r\n			<ul>\r\n				<li>การส่งเสริมและพัฒนาการศึกษา</li>\r\n				<li>ส่งเสริมและการจัดสวัสดิการสังคม สงเคราะห์</li>\r\n				<li>ส่งเสริมการบริการด้านสาธารณสุขรวมถึงการส่งเสริมสร้างสุขภาวะทางกายและทางใจ</li>\r\n				<li>พัฒนาด้านโครงสร้างพื้นฐานสาธารณูปโภคสาธารณูปการ</li>\r\n				<li>การสร้างความเข้มแข็งของชุมชนและสังคม</li>\r\n				<li>การเพิ่มศักยภาพและพัฒนาอาชีพของชุมชน</li>\r\n				<li>ส่งเสริมและสนับสนุนการสร้างความเข้มแข็งของชุมชนด้านเศรษฐกิจ</li>\r\n				<li>การพัฒนาแหล่งน้ำเพื่อการเกษตร</li>\r\n				<li>การส่งเสริมการพัฒนาเกษตรทฤษฎีใหม่</li>\r\n				<li>ส่งเสริมศูนย์บริการและถ่ายทอดเทคโนโลยีด้านการเกษตร</li>\r\n			</ul>\r\n			</td>\r\n			<td style=\"text-align:center\"><img alt=\"\" src=\"http://www.website-thai.com/project/kudnokplao/upload/userfile/images/11.jpg\" style=\"height:195px; width:354px\" /></td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n', NULL, NULL),
(150, 1, 95, 'ยุทธศาสตร์ ที่ 2', 1, '<ul>\r\n	<li>&nbsp;&nbsp;<strong>การพัฒนาการบริหารจัดการทรพยากรธรรมชาติและสิ่งแวดล้อม</strong></li>\r\n</ul>\r\n\r\n<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" style=\"width:100%\">\r\n	<tbody>\r\n		<tr>\r\n			<td>\r\n			<ul>\r\n				<li>อนุรักษ์และพัฒนาทรัพยากรธรรมชาติและสิ่งแวดล้อม</li>\r\n				<li>สร้างจิตสำนึกและตระหนักในการรักษาทรัพยากรธรรมชาติและสิ่งแวดล้อม</li>\r\n				<li>การบริหารจัดการขยะมูลฝอยและสิ่งแวดล้อม</li>\r\n				<li>การป้องกันและแก้ไขปัญหาสิ่งแวดล้อม</li>\r\n			</ul>\r\n			</td>\r\n			<td style=\"text-align:center\"><img alt=\"\" src=\"http://www.website-thai.com/project/kudnokplao/upload/userfile/images/12.jpg\" style=\"height:195px; width:354px\" /></td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n', NULL, NULL),
(151, 1, 96, 'ยุทธศาสตร์ ที่ 3', 1, '<ul>\r\n	<li>\r\n	<p><strong>&nbsp;การนุรักษ์ฟื้นฟู ศาสนา ศิลปะ วัฒนธรรม ขนมธรรมเนียมประเพณี และภูมิปัญญาท้องถิ่น</strong></p>\r\n	</li>\r\n</ul>\r\n\r\n<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" style=\"width:100%\">\r\n	<tbody>\r\n		<tr>\r\n			<td>\r\n			<ul>\r\n				<li>ส่งเสริมอนุรักษ์และฟื้นฟูวัฒนธรรมขนบธรรมเนียมประเพณีและวันสำคัญ</li>\r\n				<li>สร้างจิตสำนึกและตระหนักในคุณค่าและความสำคัญศิลปวัฒนธรรม ขนบธรรมเนียมประเพณีท้องถิ่น</li>\r\n				<li>ส่งเสริมและเผยแพร่ภูมิปัญญาท้องถิ่น</li>\r\n				<li>ส่งเสริมศาสนา พัฒนาคุณธรรมจริยธรรม</li>\r\n			</ul>\r\n			</td>\r\n			<td style=\"text-align:center\"><img alt=\"\" src=\"http://www.website-thai.com/project/kudnokplao/upload/userfile/images/13.jpg\" style=\"height:195px; width:354px\" /></td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n', NULL, NULL),
(152, 1, 97, 'บทบาทหน้าที่สำนักปลด', 1, '<p>&nbsp; &nbsp; &nbsp; <span style=\"color:#0000FF\">&nbsp; &nbsp; มีหน้าที่คอยให้บริการประชาชนที่เข้ามาติดต่อ อีกทั้งยังมีหน้าที่รับผิดชอบในด้านการกำกับเร่งรัดการปฏิบัติงานให้ดำเนินไปตาม นโยบายแผนงาน และแนวทางการปฏิบัติราชการ มีงานที่ต้องรับผิดชอบดูแลได้แก่ งานธุรการ งานการเจ้าหน้าที่ งานทะเบียนราษฎร งานวิเคราะห์นโยบายและแผน งานจัดทำงบประมาณงานประชาสัมพันธ์ งานป้องกันและบรรเทาสาธารณภัย และงานอื่นๆ ที่เกี่ยวข้องหรือ ได้รับมอบหมาย โดยแบ่งส่วนงานภายในออกเป็นส่วนๆ ดังนี้</span></p>\r\n\r\n<p><span style=\"color:#FF0000\">งานธุรการ</span></p>\r\n\r\n<p><span style=\"color:#008000\">- งานรับส่งหนังสือ</span></p>\r\n\r\n<p><span style=\"color:#008000\">-&nbsp;งานรับเรื่องราวร้องทุกข์</span></p>\r\n\r\n<p><span style=\"color:#008000\">-&nbsp;งานประชาสัมพันธ์</span></p>\r\n\r\n<p><span style=\"color:#008000\">-&nbsp;งานบริการอินเตอร์เน็ต</span></p>\r\n\r\n<p><span style=\"color:#008000\">-&nbsp;งานกิจกรรมสภา</span></p>\r\n\r\n<p><span style=\"color:#008000\">-&nbsp;งานเลือกตั้ง</span></p>\r\n\r\n<p><span style=\"color:#008000\">-&nbsp;งานนโยบายและแผนงาน</span></p>\r\n\r\n<p><span style=\"color:#008000\">-&nbsp;งานแผนพัฒนา</span></p>\r\n\r\n<p><span style=\"color:#008000\">-&nbsp;งานงบประมาณ</span></p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p><span style=\"color:#FF0000\">งานพัฒนาชุมชน</span></p>\r\n\r\n<p><span style=\"color:#008000\">-&nbsp;งานผู้สูงอายุ, คนพิการ, ผู้ติดเชื้อเอดส์</span></p>\r\n\r\n<p><span style=\"color:#008000\">-&nbsp;งาน อพม.กลุ่มอาชีพ, กลุ่มสตรี</span></p>\r\n\r\n<p><span style=\"color:#008000\">-&nbsp;งานสภาเด็ก,ศูนย์พัฒนาครอบครัว</span>​</p>\r\n\r\n<p><span style=\"color:#FF0000\">งานบริหารงานบุคคล</span></p>\r\n\r\n<p><span style=\"color:#008000\">-&nbsp;งานบรรจุแต่งตั้งโอนย้ายและเลื่อนระดับ</span></p>\r\n\r\n<p><span style=\"color:#008000\">-&nbsp;งานทะเบียนประวัติ,ขอพระราชทานเครื่องราชฯ</span></p>\r\n\r\n<p><span style=\"color:#008000\">-&nbsp;งานป้องกันและบรรเทาสาธารณภัย</span></p>\r\n\r\n<p><span style=\"color:#008000\">-&nbsp;งานรักษาความปลอดภัยในสถานที่ราชการ</span></p>\r\n\r\n<p><span style=\"color:#008000\">-&nbsp;งานจัดระเบียบสังคม</span></p>\r\n\r\n<p><span style=\"color:#008000\">-&nbsp;งานป้องกันและบรรเทาสาธารณภัย เช่น อัคคีภัย อุทกภัย วาตภัย ฯลฯ</span></p>\r\n\r\n<p><span style=\"color:#008000\">-&nbsp;งานรักษาความสงบเรียบร้อย</span></p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p><span style=\"color:#FF0000\">งานทะเบียนราษฎร์</span></p>\r\n\r\n<p><span style=\"color:#008000\">-&nbsp;งานทะเบียนราษฎร์,งานย้ายเข้า,ย้ายออก,แจ้งเกิด,แจ้งตาย</span></p>\r\n\r\n<p><span style=\"color:#008000\">-&nbsp;งานขึ้นทะเบียนคนต่างด้าว</span></p>\r\n\r\n<p><span style=\"color:#008000\">-&nbsp;งานบริหารงานบุคคล</span></p>\r\n', NULL, NULL),
(153, 1, 98, 'บทบาทหน้าที่กองคลัง', 1, '<p>&nbsp; <span style=\"color:#0000FF\">&nbsp; &nbsp; &nbsp; &nbsp;มีหน้าที่รับผิดชอบเกี่ยวกับการรับเงิน การเบิกจ่ายเงิน การฝากเงินเพื่อให้เป็นไปตามงบประมาณ การจัดทำงบแสดงฐานะทางการเงิน บันทึกบัญชี จัดทำทะเบียนและรายงานทางการเงิน ตรวจสอบหลักฐาน ใบสำคัญจ่ายเงิน ดำเนินการจัดซื้อ จัดจ้าง เร่งรัดจัดเก็บรายได้ ค่าธรรมเนียม ใบอนุญาตต่างๆ ซึ่งรายได้จากการจัดเก็บจะถูกจัดสรรและผลักดันไปสู่โครงการต่างๆ ให้สัมฤทธิ์ผล โดยแบ่งส่วนงานภายในออกเป็นส่วนๆ ดังนี้</span></p>\r\n\r\n<p><span style=\"color:#FF0000\">งานการเงินและบัญชี</span></p>\r\n\r\n<p><span style=\"color:#008000\">- งานควบคุมจัดทำทะเบียนงบประมาณ &nbsp; &nbsp;<br />\r\n-&nbsp;งานจัดทำรายงาน รายรับ &ndash; รายจ่าย ประจำเดือน ไตรมาส ประจำปีและรายงานอื่นๆ<br />\r\n-&nbsp;งานการเงิน ตรวจสอบหลักฐาน ใบสำคัญจ่ายเงิน &nbsp; &nbsp;<br />\r\n-&nbsp;รายงานสถานการณ์เงินประจำวันและจัดทำรายจ่ายส่วนที่เกี่ยวข้อง<br />\r\n-&nbsp;งานจัดทำเช็คและจัดเก็บเอกสารการจ่ายเงิน &nbsp; &nbsp;<br />\r\n-&nbsp;จัดทำใบรับรองภาษี หัก ณ ที่จ่าย และ นำส่งภาษี ณ ที่จ่ายให้แก่สรรพากร<br />\r\n-&nbsp;งานจัดทำบัญชีและทะเบียนที่เกี่ยวข้องทุกประเภท</span><br />\r\n&nbsp;</p>\r\n\r\n<p><span style=\"color:#FF0000\">​งานพัฒนาและจัดเก็บรายได้</span></p>\r\n\r\n<p><span style=\"color:#008000\">-&nbsp;รับชำระภาษีโรงเรือนและที่ดิน &nbsp; &nbsp;<br />\r\n-&nbsp;รับชำระค่าธรรมเนียมต่างๆ<br />\r\n-&nbsp;รับชำระภาษีบำรุงท้องที่ &nbsp; &nbsp;<br />\r\n-&nbsp;รับประชาสัมพันธ์เกี่ยวกับการชำระภาษี<br />\r\n-&nbsp;รับชำระภาษีป้า</span></p>\r\n\r\n<p><span style=\"color:#FF0000\">งานพัสดุและทรัพย์สิน</span></p>\r\n\r\n<p><span style=\"color:#008000\">-&nbsp;งานจักซื้อและจัดจ้าง &nbsp; &nbsp;<br />\r\n-&nbsp;งานจัดทำทะเบียนและพัสดุ<br />\r\n-&nbsp;งานซ้อมบำรุงและรักษา &nbsp; &nbsp;<br />\r\n-&nbsp;งานการตรวจสอบการจัดซื้อพัสดุและรักษาพัสดุ</span></p>\r\n', NULL, NULL),
(154, 1, 99, 'บทบาทหน้าที่กองช่าง', 1, '<p>&nbsp; &nbsp; &nbsp; &nbsp;<span style=\"color:#0000FF\">มีหน้าที่รับผิดชอบเกี่ยวกับการสำรวจออกแบบและเขียนแบบการจัดทำข้อมูลทางด้านวิศวกรรมการัดเก็บและทดสอบคุณภาพวัสดุ งานออกแบบและเขียนแบบการตรวจสอบก่อสร้าง งานควบคุมอาคารตามระเบียบกฎหมาย แผนการปฏิบัติงาน ก่อสร้าง และซ่อมแซมบำรุง กองช่างจึงถือเป็นกลไกลสำคัญในการขับเคลื่อนนโยบาย และแผนงาน ในการวางโครงสร้างพื้นฐานต่าง ๆ อาทิเช่น ซ่อมแซมถนนหนทาง ไฟฟ้า ทางเท้า ฯลฯ ให้ได้มาตรฐาน โดยแบ่งส่วนงานภายในออกเป็นส่วนๆ ดังนี้</span></p>\r\n\r\n<p><span style=\"color:#FF0000\">งานวิศวกรรมโยธา</span></p>\r\n\r\n<p><span style=\"color:#008000\">-&nbsp;งานวิศวกรรมโยธาและการผังเมือง &nbsp; &nbsp;<br />\r\n-&nbsp;ตรวจแบบการขออนุญาตก่อสร้างอาคาร ทางด้านสถาปัตยกรรม<br />\r\n&nbsp;-&nbsp;ตรวจโครงการด้านสาธารณูปโภค สาธารณูปการ และระบบคมนาคมการขนส่ง &nbsp; &nbsp;<br />\r\n-&nbsp;เป็นนายตรวจเขต ควบคุมการก่อสร้าง ดัดแปลง รื้อถอนอาคารในเขตเทศบาล<br />\r\n-&nbsp;การออกแบบและคำนวณ พิจารณาตรวจสอบ ค้นคว้า ทดลอง วิเคราะห์และวิจัย วางโครงการก่อสร้าง ให้คำปรึกษาแนะนำในงานวิศวกรรมโยธา เช่น อาคาร -&nbsp;โรงงาน อุตสาหกรรม ถนน สะพาน ท่าเทียบเรือ อู่เรือหรือ คานเรือ กำแพงคันดิน โครงสร้าง สำหรับรองรับถังน้ำ ถังน้ำมัน อุโมงค์สาธารณะ<br />\r\n-&nbsp;งานดูแลรักษา จัดเตรียมและให้บริการเรื่องสถานที่ วัสดุอุปกรณ์ การติดต่อและอำนวย ความสะดวกในด้านต่างๆ</span></p>\r\n\r\n<p><span style=\"color:#FF0000\">งานสาธารณูปโภค</span></p>\r\n\r\n<p><span style=\"color:#008000\">-&nbsp;การขนส่งและวิศวกรรมจราจร &nbsp; &nbsp;<br />\r\n-&nbsp;งานก่อสร้าง ต่างๆ เช่น งานถนน อาคาร ท่อระบายน้ำ ฯลฯ<br />\r\n-&nbsp;งานไฟฟ้าสาธารณะ งานประสานสาธารณูปโภคและกิจการประปา งานประปา &nbsp; &nbsp;<br />\r\n-&nbsp;งานการระบายน้ำ แก้ไขปัญหาน้ำท่วมขัง การบำรุงรักษาคูคลองท่อระบายน้ำ ทำการสำรวจพื้นที่และโครงการป้องกันน้ำท่วมขัง<br />\r\n-&nbsp;ควบคุมการก่อสร้างถนนและสะพาน อาคาร ท่อระบายน้ำ ฯลฯ &nbsp; &nbsp;<br />\r\n-&nbsp;ตรวจแบบการขออนุญาตก่อสร้างอาคาร ทางด้านสถาปัตยกรรม<br />\r\n&nbsp;-&nbsp;เป็นนายตรวจเขต ควบคุมการก่อสร้าง ดัดแปลง รื้อถอนอาคารในเขตเทศบาล &nbsp; &nbsp;<br />\r\n-&nbsp;งานดูแลรักษา จัดเตรียมและให้บริการเรื่องสถานที่ วัสดุอุปกรณ์ การติดต่อและอำนวยความสะดวกในด้านต่างๆ<br />\r\n-&nbsp;การจัดทำแผนโครงการบำรุงรักษาดูแลคลองสาธารณะ แผนโครงการล้างท่อระบายน้ำ และแผนการดูแลบำรุงรักษาเครื่องจักร เครื่องสูบน้ำ อุปกรณ์เกี่ยวกับการระบายน้ำ ให้มีความพร้อมที่จะใช้ในการปฏิบัติงาน ตลอดจนการแก้ไขเรื่องร้องเรียนเกี่ยวกับปัญหาน้ำท่วมขัง &nbsp; &nbsp;<br />\r\n-&nbsp;การระบายน้ำและจัดตั้งงบประมาณขุดลอกคูคลอง คูน้ำ สร้างเขื่อนสร้างทำนบ เป็นต้น ทำหน้าที่ สำรวจ ออกแบบ เขียนแบบ และคำนวณ การก่อสร้าง -&nbsp;ประมาณการราคาโครงการ&nbsp;</span></p>\r\n\r\n<p><span style=\"color:#FF0000\">งานธุรการ</span></p>\r\n\r\n<p><span style=\"color:#008000\">-&nbsp;ปฏิบัติงานธุรการและงานสารบรรณ ภายในกองช่าง &nbsp; &nbsp;<br />\r\n-&nbsp;งานสนับสนุนและบริการประชาชน<br />\r\n-&nbsp;ดูแลเก็บรักษาเอกสาร ระเบียบ คำสั่ง ของกองช่างให้เรียบร้อย และสามารถตรวจสอบเอกสารดังกล่าวได้ &nbsp; &nbsp;<br />\r\n-&nbsp;งานสนับสนุนและบริการข้อมูลข่าวสารด้านงานสำรวจ ออกแบบ ควบคุมอาคารและการก่อสร้าง<br />\r\n&nbsp;-&nbsp;งานอำนวยการและประสานราชการ &nbsp; &nbsp;<br />\r\n-&nbsp;ปฏิบัติงานอื่นๆ ตามที่ผู้บังคับบัญชามอบหมาย<br />\r\n&nbsp;-&nbsp;งานจัดทำฎีกาเบิกจ่ายเงินของกองช่าง&nbsp;</span></p>\r\n\r\n<p><span style=\"color:#FF0000\">ปฏิบัติงานอื่นๆ</span></p>\r\n\r\n<p><span style=\"color:#008000\">-&nbsp;ออกสำรวจโครงการพัฒนาตำบลเมื่อเป็นงานเร่งด่วนจากจังหวัด &nbsp; &nbsp;<br />\r\n-&nbsp;งานอื่นๆ ที่เกี่ยวข้องหรือตามที่ได้รับมอบหมาย<br />\r\n-&nbsp;งานที่ต้องใช้แรงงานทั่วไป &nbsp; &nbsp;<br />\r\n-&nbsp;ปฏิบัติงานที่เกี่ยวกับงานด้านการก่อสร้างต่างๆ ภายในเทศบาลตำบลกุดนกเปล้า เช่น ซ่อมท่อระบายน้ำ , งานขึ้นป้ายต่างๆ ฯลฯ&nbsp;</span></p>\r\n', NULL, NULL);
INSERT INTO `mhd_language_detail` (`id`, `language_id`, `ref_id`, `name`, `type`, `detail`, `detail_2`, `detail_3`) VALUES
(155, 1, 100, 'บทบาทหน้าที่กองการศึกษา', 1, '<p>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;<span style=\"color:#0000FF\">มีหน้าที่รับผิดชอบเกี่ยวกับการบริหารการศึกษา และพัฒนาการศึกษาในระบบการศึกษา และนอกระบบการศึกษา การศึกษาตามอัธยาศัย เช่น การจัดการปฐมวัยการจัดการศึกษาขั้นพื้นฐาน โดยมีงานที่ต้องรับผิดชอบ เช่น งานธุรการ งานบริหารการศึกษา งานกิจกรรมศาสนา ส่งเสริมงานกีฬาและนันทนาการ โดยแบ่งส่วนงานภายในออกเป็นส่วนๆ ดังนี้</span></p>\r\n\r\n<p><span style=\"color:#FF0000\">งานบริหารการศึกษา</span></p>\r\n\r\n<p><span style=\"color:#008000\">-&nbsp;&nbsp;รับผิดชอบเกี่ยวกับการบริหารการศึกษาและพัฒนาการศึกษา ทั้งการศึกษาในระบบการศึกษา นอกระบบการศึกษาและการศึกษาตามอัธยาศัย เช่น การจัดการศึกษาปฐมวัย อนุบาลศึกษา ประถมศึกษา มัธยมศึกษา โดยให้มีงานธุรการ งานโรงเรียน งานการศึกษาปฐมวัย งานส่งเสริมศาสนา ประเพณี ศิลปวัฒนธรรม งานกีฬาและนันทนาการ งานกิจกรรมเด็กและเยาวชน และงานอื่น ๆ ที่เกี่ยวข้องตามที่ได้รับมอบหมาย</span></p>\r\n\r\n<p><span style=\"color:#FF0000\">​งานธุรการ</span></p>\r\n\r\n<p><span style=\"color:#008000\">-&nbsp;งานสารบรรณ การรับ - ส่ง โต้ตอบหนังสือของกองการศึกษา &nbsp; &nbsp;<br />\r\n-&nbsp;งานจัดทำฎีกาเบิกจ่ายเงินของกองการศึกษา<br />\r\n-&nbsp;งานตรวจสอบเกี่ยวกับงานสารบรรณ และเอกสารสำคัญของทางราชการ งานดูแลเก็บรักษาเอกสาร ควบคุมทะเบียน ประกาศ คำสั่ง ของกองการศึกษา ทุกเรื่องให้เรียบร้อยเป็นปัจจุบันและสามารถตรวจสอบได้ &nbsp; &nbsp;<br />\r\n-&nbsp;งานรักษาความสะอาด ความปลอดภัย สถานที่ราชการและควบคุมดูแล พัสดุ เครื่องมือ เครื่องใช้ของกองการศึกษา<br />\r\n-&nbsp;งานรวบรวมข้อมูล และจัดทำแผนพัฒนาการศึกษาของกองการศึกษา &nbsp; &nbsp;<br />\r\n-&nbsp;งานประสานงานส่วนราชการต่างๆ<br />\r\n&nbsp;-&nbsp;งานเผยแพร่ข้อมูลข่าวสารของกองการศึกษา &nbsp; &nbsp;<br />\r\n-&nbsp;ปฏิบัติงานอื่น ๆ ที่เกี่ยวข้องหรือตามที่ผู้บังคับบัญชามอบหมาย</span></p>\r\n\r\n<p><span style=\"color:#FF0000\">งานกิจการเด็กและเยาวชน</span></p>\r\n\r\n<p><span style=\"color:#008000\">-&nbsp;งานสำรวจรวบรวมข้อมูลต่าง ๆ เกี่ยวกับเด็กและเยาวชน &nbsp; &nbsp;<br />\r\n-&nbsp;งานกีฬาเยาวชนและประชาชน งานประสานหน่วยงานอื่นๆ เกี่ยวกับกิจกรรมเยาวชน<br />\r\n-&nbsp;งานโครงการกิจกรรมวันเด็กแห่งชาติ &nbsp; &nbsp;<br />\r\n-&nbsp;ปฏิบัติงานอื่น ๆ ที่เกี่ยวข้องหรือตามที่ผู้บังคับบัญชามอบหมาย<br />\r\n&nbsp;-&nbsp;งานกีฬานักเรียนระดับตำบล อำเภอและจังหวัด &nbsp; &nbsp; &nbsp; &nbsp;&nbsp;</span></p>\r\n\r\n<p><span style=\"color:#FF0000\">งานกีฬาและนันทนาการ</span></p>\r\n\r\n<p><span style=\"color:#008000\">&nbsp;-&nbsp;ส่งเสริมการกีฬาเพื่อสุขภาพของเด็ก เยาวชน และประชาชนทั่วไป &nbsp; &nbsp;<br />\r\n-&nbsp;ปฏิบัติงานอื่น ๆ ที่เกี่ยวข้องหรือตามที่ผู้บังคับบัญชามอบหมาย<br />\r\n&nbsp;-&nbsp;งานการจัดการแข่งขันกีฬาเด็กและเยาวชน ประชาชน กีฬานักเรียน&nbsp;<br />\r\n​-&nbsp;งานส่งเสริมศาสนา ประเพณี ศิลปะ วัฒนธรรม</span></p>\r\n\r\n<p><span style=\"color:#FF0000\">งานจัดเก็บข้อมูลสารสนเทศวัฒนธรรมท้องถิ่น วัฒนธรรมพื้นบ้าน </span><span style=\"color:#008000\">&nbsp; &nbsp;<br />\r\n-&nbsp;งานส่งเสริมประเพณีท้องถิ่น ภูมิปัญญาท้องถิ่น<br />\r\n-&nbsp;งานประเพณีที่เกี่ยวข้องกับศาสนา &nbsp; &nbsp;<br />\r\n-&nbsp;งานส่งเสริมอนุรักษ์ศิลปวัฒนธรรมท้องถิ่น งานประเพณีที่สำคัญในรอบปี<br />\r\n-&nbsp;งานส่งเสริมศิลปะ วัฒนธรรม ได้แก่ งานเกี่ยวกับการส่งเสริมศิลปะ การสืบทอดส่งเสริมและอนุรักษ์ภูมิปัญญาท้องถิ่น การพัฒนาและเผยแพร่ วัฒนธรรม -&nbsp;ขนบธรรมเนียมประเพณีพื้นบ้าน เพื่อเสริมสร้างและพัฒนา ให้เป็นเอกลักษณ์ของท้องถิ่น &nbsp; &nbsp;<br />\r\n-&nbsp;ปฏิบัติงานอื่น ๆ ที่เกี่ยวข้องหรือตามที่ผู้บังคับบัญชามอบหมาย</span></p>\r\n\r\n<p>&nbsp;</p>\r\n', NULL, NULL),
(156, 1, 101, 'บทบาทหน้าที่กองสาธารณสุข', 1, '<p>&nbsp; &nbsp; &nbsp; &nbsp;<span style=\"color:#0000FF\"> &nbsp; &nbsp; &nbsp;มีหน้าที่ส่วนเกี่ยวกับสาธารณสุขชุมชน ส่งเสริมสุขภาพและอนามัยการป้องกันโรคติดต่อ งานสุขาภิบาล สิ่งแวดล้อมอื่นๆ เกี่ยวกับ การให้บริการด้านสาธารณสุข งานสัตวแพทย์ และการให้บริการประชาชน ติดต่อขออนุญาตต่างๆ และงานอื่นๆ ที่ได้รับมอบหมาย โดยแบ่ง ฝ่ายงานภายในออกเป็น 3 ฝ่าย ดังนี้</span></p>\r\n\r\n<p style=\"text-align: center;\"><strong>1. ฝ่ายบริหารงานสาธารณสุข มีหน้าที่รับผิดชอบ ดังนี้</strong></p>\r\n\r\n<p><span style=\"color:#FF0000\">&nbsp;แผนงานสาธารณสุข</span></p>\r\n\r\n<p><span style=\"color:#008000\">-&nbsp;งานวางแผนด้านสาธารณสุข<br />\r\n-&nbsp;งานข้อมูลข่าวสารจัดทำและสนับสนุนระเบียบ<br />\r\n-&nbsp;งานจัดทำแผนตามโครงการบริหารงานสาธารณสุข<br />\r\n-&nbsp;งานประเมินผลทางด้านการสาธารณสุข<br />\r\n-&nbsp;งานประสานแผนการปฏิบัติงานต่างๆ<br />\r\n-&nbsp;งานนิเทศและติดตามผลงานด้านสาธารณสุข<br />\r\n-&nbsp;งานรวมแผนปฏิบัติงานสาธารณสุข<br />\r\n-&nbsp;งานสุขาภิบาลและอนามัยสิ่งแวดล้อม</span></p>\r\n\r\n<p><span style=\"color:#FF0000\">งานควบคุมด้านสุขาภิบาลและอนามัยสิ่งแวดล้อม &nbsp; &nbsp;</span><br />\r\n<span style=\"color:#008000\">-&nbsp;งานป้องกัน ควบคุมแก้ไขเหตุรำคาญ<br />\r\n-&nbsp;งานสุขาภิบาลอาหารและโภชนาการ &nbsp; &nbsp;<br />\r\n-&nbsp;งานสุขาภิบาลโรงงาน<br />\r\n-&nbsp;งานควบคุมการประกอบกิจการที่เป็นอันตรายต่อสุภาพ &nbsp; &nbsp;<br />\r\n-&nbsp;งานอาชีวอนามัย</span></p>\r\n\r\n<p><span style=\"color:#FF0000\">งานรักษาความสะอาด</span></p>\r\n\r\n<p><span style=\"color:#008000\">-&nbsp;งานกวาดล้างทำความสะอาด &nbsp; &nbsp;<br />\r\n-&nbsp;งานขนถ่ายขยะมูลฝอย<br />\r\n-&nbsp;งานเก็บรวบรวมขยะมูลฝอย &nbsp; &nbsp;<br />\r\n-&nbsp;งานขนถ่ายสิ่งปฏิกูล​<br />\r\n&nbsp;-&nbsp;งานเผยแพร่และฝึกอบรม</span></p>\r\n\r\n<p><span style=\"color:#FF0000\">&nbsp;งานเผยแพร่กิจกรรมทางวิชาการด้านสาธารณสุข &nbsp;</span> &nbsp;<br />\r\n<span style=\"color:#008000\">-&nbsp;งานฝึกอบรมและศึกษาดูงาน<br />\r\n&nbsp;-&nbsp;งานพัฒนาบุคลากรด้านสาธารณสุข &nbsp; &nbsp;<br />\r\n-&nbsp;งานประเมินผล &nbsp; &nbsp;</span></p>\r\n\r\n<p style=\"text-align: center;\"><br />\r\n<strong>2. ฝ่ายบริหารและส่งเสริมการอนามัย มีหน้าที่รับผิดชอบ ดังนี้</strong></p>\r\n\r\n<p><span style=\"color:#FF0000\">งานส่งเสริมสุขภาพ</span></p>\r\n\r\n<p><span style=\"color:#008000\">-&nbsp;งานด้านสุขศึกษา &nbsp; &nbsp;<br />\r\n-&nbsp;งานวางแผนครอบครัว<br />\r\n-&nbsp;งานอนามัยโรงเรียน &nbsp; &nbsp;<br />\r\n-&nbsp;งานสาธารณสุขมูลฐาน<br />\r\n-&nbsp;งานอนามัยแม่และเด็ก &nbsp; &nbsp;<br />\r\n-&nbsp;งานโภชนาการ</span></p>\r\n\r\n<p><span style=\"color:#FF0000\">งานป้องกันและควบคุมโรคติดต่อ</span></p>\r\n\r\n<p><span style=\"color:#008000\">-&nbsp;ป้องกันและสร้างเสริมภูมิคุ้มกันโรค &nbsp; &nbsp;<br />\r\n-&nbsp;งานป้องกันโรคติดต่อ<br />\r\n-&nbsp;งานควบคุมแมลงและสัตว์พาหะนำโรค &nbsp; &nbsp;<br />\r\n-&nbsp;งานป้องกันการติดยาและสารเสพติด</span><br />\r\n​</p>\r\n\r\n<p><span style=\"color:#FF0000\">งานสัตวแพทย์</span></p>\r\n\r\n<p><span style=\"color:#008000\">-&nbsp;งานควบคุมโรคสัตว์ &nbsp; &nbsp;<br />\r\n-&nbsp;งานควบคุมการฆ่าสัตว์และโรงฆ่าสัตว์<br />\r\n-&nbsp;งานควบคุมโรคที่เกิดจากสัตว์เลี้ยง &nbsp; &nbsp;<br />\r\n-&nbsp;งานเฝ้าระวังโรค ในบุคคลประกอบอาชีพที่เสี่ยงต่อการเกิดโรคสัตว์<br />\r\n-&nbsp;งานควบคุมโรคพิษสุนัขบ้า &nbsp; &nbsp;<br />\r\n-&nbsp;งานสถิติข้อมูลการวิจัยเกี่ยวกับงานด้านสัตวแพทย์<br />\r\n-&nbsp;งานป้องกันโรคติดเชื้อหรือเหตุรำคาญจากสัตว์ &nbsp;</span> &nbsp; &nbsp; &nbsp; &nbsp;<br />\r\n&nbsp; &nbsp; &nbsp;</p>\r\n\r\n<p style=\"text-align: center;\"><strong>&nbsp;3. งานธุรการ มีหน้าที่รับผิดชอบ ดังนี้</strong></p>\r\n\r\n<p><span style=\"color:#FF0000\">งานสารบรรณ &nbsp; </span>&nbsp;</p>\r\n\r\n<p><span style=\"color:#008000\">-&nbsp;งานพระราชทานเครื่องราชอิสริยาภรณ์<br />\r\n-&nbsp;งานประสานงานเกี่ยวกับการประชุมต่างๆ</span> &nbsp; &nbsp;</p>\r\n\r\n<p><span style=\"color:#FF0000\">งานจัดทำคำสั่งและประกาศ</span><br />\r\n<span style=\"color:#008000\">-&nbsp;งานตรวจสอบและแสดงรายการ เกี่ยวกับเอกสารสำคัญของทางราชการ &nbsp; &nbsp;<br />\r\n-&nbsp;งานรับเรื่องราวร้องทุกข์และร้องเรียน<br />\r\n-&nbsp;งานสาธารณกุศลของเทศบาลและหน่วยงานต่างๆ &nbsp; &nbsp;<br />\r\n-&nbsp;งานพิจารณาเลื่อนขั้นเงินเดือนและการให้บำเหน็จบำนาญ<br />\r\n-&nbsp;งานดูและรักษาจัดเตรียมและให้บริการเรื่องสถานที่ วัสดุอุปกรณ์ ติดต่อและอำนวยความสะดวกในด้านต่างๆ &nbsp; &nbsp;<br />\r\n-&nbsp;งานการลาพักผ่อนประจำปีและการลาอื่นๆ</span></p>\r\n\r\n<p>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n', NULL, NULL),
(157, 1, 102, 'รายงานกิจการ ประจำปี 58-59', 1, '<p style=\"text-align:center\"><img alt=\"\" src=\"http://www.website-thai.com/project/kudnokplao/upload/userfile/images/1.jpg\" style=\"height:1200px; width:848px\" /></p>\r\n\r\n<p style=\"text-align:center\"><img alt=\"\" src=\"http://www.website-thai.com/project/kudnokplao/upload/userfile/images/2.jpg\" style=\"height:1200px; width:848px\" /><img alt=\"\" src=\"http://www.website-thai.com/project/kudnokplao/upload/userfile/images/3.jpg\" style=\"height:1200px; width:848px\" /><img alt=\"\" src=\"http://www.website-thai.com/project/kudnokplao/upload/userfile/images/4.jpg\" style=\"height:1200px; width:848px\" /><img alt=\"\" src=\"http://www.website-thai.com/project/kudnokplao/upload/userfile/images/5.jpg\" style=\"height:1200px; width:848px\" /><img alt=\"\" src=\"http://www.website-thai.com/project/kudnokplao/upload/userfile/images/6.jpg\" style=\"height:1200px; width:848px\" /><img alt=\"\" src=\"http://www.website-thai.com/project/kudnokplao/upload/userfile/images/7.jpg\" style=\"height:1200px; width:848px\" /><img alt=\"\" src=\"http://www.website-thai.com/project/kudnokplao/upload/userfile/images/8.jpg\" style=\"height:1200px; width:848px\" /><img alt=\"\" src=\"http://www.website-thai.com/project/kudnokplao/upload/userfile/images/9.jpg\" style=\"height:1200px; width:848px\" /><img alt=\"\" src=\"http://www.website-thai.com/project/kudnokplao/upload/userfile/images/10.jpg\" style=\"height:1200px; width:848px\" /></p>\r\n', NULL, NULL),
(158, 1, 103, 'test', 1, '', NULL, NULL),
(159, 1, 104, 'คำนำแผนดำเนินงาน-2559', 1, '<p style=\"text-align:center\">&nbsp;</p>\r\n\r\n<p style=\"text-align:center\"><img alt=\"\" src=\"http://www.kudnokplao.go.th/kudnokplao/assets/images/1.jpg\" style=\"height:152px; width:160px\" /></p>\r\n\r\n<h1 style=\"text-align: center;\"><strong>แผนดำเนินงาน&nbsp;<br />\r\nประจำปีงบประมาณ พ.ศ. 2559</strong></h1>\r\n\r\n<p style=\"text-align: center;\"><strong><img alt=\"\" src=\"http://www.kudnokplao.go.th/kudnokplao/assets/images/2.jpg\" style=\"height:406px; width:540px\" /></strong></p>\r\n\r\n<h1 style=\"text-align: center;\"><strong>เทศบาลตำบลกุดนกเปล้า&nbsp;<br />\r\nตำบลกุดนกเปล้า อำเภอเมืองสระบุรี จังหวัดสระบุรี</strong></h1>\r\n\r\n<p style=\"text-align: center;\">&nbsp;</p>\r\n\r\n<p style=\"text-align:center\">&nbsp;</p>\r\n\r\n<p style=\"text-align:center\">&nbsp;</p>\r\n\r\n<p style=\"text-align:center\">&nbsp;</p>\r\n\r\n<p style=\"text-align:center\">&nbsp;</p>\r\n\r\n<p style=\"text-align:center\">&nbsp;</p>\r\n\r\n<p style=\"text-align:center\"><strong>คำนำ<br />\r\n&hellip;&hellip;&hellip;&hellip;&hellip;&hellip;&hellip;&hellip;&hellip;&hellip;&hellip;&hellip;&hellip;&hellip;&hellip;&hellip;&hellip;&hellip;&hellip;&hellip;&hellip;&hellip;&hellip;.</strong></p>\r\n\r\n<p>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;แผนดำเนินงานเป็นเครื่องมือสำคัญในการบริหารงานของผู้บริหารท้องถิ่น &nbsp;เพื่อควบคุมการดำเนินงานต่างๆ อย่างเหมาะสมและมีประสิทธิภาพ &nbsp;รวมทั้งยังเป็นเครื่องมือในการติดตามการดำเนินงานและประสิทธิผลตามระเบียบกระทรวงมหาดไทย &nbsp;ว่าด้วยการจัดทำและประสานแผนพัฒนาขององค์กรปกครองส่วนท้องถิ่น<br />\r\n&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;กำหนดให้องค์กรปกครองส่วนท้องถิ่นจัดทำแผนยุทธศาสตร์ &nbsp; &nbsp;แผนพัฒนาสามปีและแผนดำเนินงานการดำเนินงานมีจุดมุ่งหมายเพื่อแสดงถึงรายละเอียดแผนงาน / โครงการพัฒนาและกิจกรรมที่ดำเนินงานในปีงบประมาณขององค์กรปกครองส่วนท้องถิ่น &nbsp;ทำให้แนวทางในการปฏิบัติงานมีความชัดเจนมากขึ้น &nbsp;มีการประสานการทำงานกับหน่วยงานและการจำแนกรายละเอียดต่างๆ &nbsp;ของแผนงาน &nbsp;/ &nbsp;โครงการ &nbsp;ในแผนการดำเนินงานการติดตามประเมินผลเมื่อสิ้นปีงบประมาณมีความสะดวกมากขึ้น<br />\r\n&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; จึงหวังเป็นอย่างยิ่งว่าแผนดำเนินงานของเทศบาลตำบลกุดนกเปล้า &nbsp;จะเป็นเครื่องมือการบริหารอย่างมีประสิทธิภาพ &nbsp;และจะสามารถบรรลุวัตถุประสงค์ในการพัฒนาต่างๆของเทศบาลตำบลได้เป็นอย่างดี</p>\r\n\r\n<p style=\"text-align:right\">เทศบาลตำบลกุดนกเปล้า<br />\r\nอำเภอเมืองสระบุรี จังหวัดสระบุรี</p>\r\n\r\n<p style=\"text-align:center\"><strong>ส่วนที่ 1<br />\r\nบทนำ<br />\r\n..................................................................................</strong></p>\r\n\r\n<p>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; แผนการดำเนินงานเครื่องมือสำคัญในการบริหารงานของผู้บริหารท้องถิ่น &nbsp;เพื่อควบคุมการดำเนินงานต่างๆให้เป็นไปอย่างเหมาะสมและมีประสิทธิภาพ &nbsp;รวมทั้งยังเป็นเครื่องมือในการติดตามการดำเนินงานและประเมินผลต่างๆ</p>\r\n\r\n<p>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;ตามระเบียบกระทรวงมหาดไทย &nbsp;ว่าด้วยการจัดทำและประสานแผนพัฒนาขององค์กรปกครองส่วนท้องถิ่น &nbsp;พ.ศ. ข้อ 27 &nbsp;กำหนดให้องค์กรปกครองส่วนท้องถิ่นจัดทำแผนดำเนินงาน &nbsp;แผนพัฒนาสามปีและแผนยุทธศาสตร์สำหรับแผนดำเนินงานมีจุดมุ่งหมายเพื่อแสดงรายละเอียดแผนงาน &nbsp; / โครงการพัฒนาและกิจกรรมที่ดำเนินงานในปีงบประมาณนั้นขององค์กรปกครองส่วนท้องถิ่น &nbsp;ทำให้แนวทางในการปฏิบัติงานมีความชัดเจนมากขึ้น &nbsp; มีการประสานและบูรณาการ &nbsp;การทำงานกับหน่วยงานและการจำแนกรายละเอียดต่างๆของแผนงาน / โครงการในแผนการดำเนินงานและทำให้การติดตามประเมินผลเมื่อสิ้นปีงบประมาณมีความสะดวกมากขึ้น</p>\r\n\r\n<p style=\"text-align:center\"><strong>วัตถุประสงค์ของแผนดำเนินงาน<br />\r\n..............................................................................</strong></p>\r\n\r\n<p>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; การจัดทำแผนดำเนินงานประจำปีของเทศบาลตำบลกุดนกเปล้า &nbsp; มีการจัดทำตามระเบียบกระทรวงมหาดไทยว่าด้วยการจัดทำและประสานแผนพัฒนาขององค์กรปกครองส่วนท้องถิ่น &nbsp;พ.ศ. 2548 &nbsp;ข้อ &nbsp;27 ได้กำหนดให้องค์กรปกครองส่วนท้องถิ่นจัดทำแผนดำเนินงาน &nbsp;โดยมีขั้นตอนต่างๆ &nbsp;มีคณะกรรมการสนับสนุนจัดทำแผนพัฒนาท้องถิ่น &nbsp;ทำหน้าที่เก็บรวบรวมแผนงาน / โครงการพัฒนาหน่วยงานของรัฐ &nbsp;เอกชน &nbsp;และหน่วยงานอื่นๆ ในเขตพื้นที่ดำเนินการมาจัดทำร่างแผนดำเนินงานประจำปี &nbsp; โดยมีคณะกรรมการสนับสนุนการจัดทำแผนพัฒนาท้องถิ่น &nbsp;ให้ความเห็นชอบและประกาศเป็นแผนดำเนินงาน<br />\r\n&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; แผนดำเนินงานตามความหมาย &nbsp;คือ &nbsp;แผนดำเนินงานขององค์กรปกครองส่วนท้องถิ่นที่แสดงถึงรายละเอียดแผนงาน / โครงการพัฒนาและกิจกรรมที่ดำเนินงานจริงทั้งหมดที่องค์กรปกครองส่วนท้องถิ่นปะจำปีงบประมาณ &nbsp;เป็นแผนงานที่จัดทำขึ้นและแสดงให้เห็นถึงการบริหารงานของผู้บริหารท้องถิ่น &nbsp;มีการวางแผนงานในการดำเนินงานที่ดี &nbsp;เป็นระบบ &nbsp;มีความโปร่งใส &nbsp;มีประสิทธิภาพและสามารถตรวจสอบได้ &nbsp;เพื่อให้เป็นประโยชน์แก่ประชาชนในท้องถิ่นสูงสุด</p>\r\n\r\n<p style=\"text-align:center\"><strong>ขั้นตอนการจัดทำแผนดำเนินงาน<br />\r\n&hellip;&hellip;&hellip;&hellip;&hellip;&hellip;&hellip;&hellip;&hellip;&hellip;&hellip;&hellip;&hellip;&hellip;&hellip;&hellip;&hellip;&hellip;&hellip;&hellip;&hellip;&hellip;&hellip;&hellip;&hellip;&hellip;..</strong></p>\r\n\r\n<p>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; ขั้นตอนการจัดทำแผนดำเนินงานของเทศบาลตำบลกุดนกเปล้า &nbsp;มีแนวทางในการจัดทำแผนดำเนินงานมีดังนี้<br />\r\n1.&nbsp;&nbsp; &nbsp;คณะกรรมการสนับสนุนการจัดทำแผนพัฒนาท้องถิ่น &nbsp;เก็บรวบรวมข้อมูลแผนงาน / โครงการพัฒนาของเทศบาลตำบลกุดนกเปล้า &nbsp;หน่วยงานราชการ &nbsp;เอกชน &nbsp;และหน่วยงานอื่นๆ &nbsp;ที่ต้องดำเนินการในเขตพื้นที่ตำบลกุดนกเปล้า<br />\r\n2.&nbsp;&nbsp; &nbsp;คณะกรรมการสนับสนุนการจัดทำแผนพัฒนาของเทศบาลตำบลกุดนกเปล้า &nbsp;จัดทำร่างแผนการดำเนินงานโดยพิจารณา &nbsp;แผนงาน / โครงการของเทศบาลตำบลกุดนกเปล้า<br />\r\n3.&nbsp;&nbsp; &nbsp;คณะกรรมการสนับสนุนการจัดทำแผนพัฒนาท้องถิ่น &nbsp;ทำร่างแผนการดำเนินงานเสนอต่อคณะกรรมการพัฒนาท้องถิ่น<br />\r\n4.&nbsp;&nbsp; &nbsp;คณะกรรมการพัฒนาท้องถิ่น &nbsp;พิจารณาร่างแผนดำเนินงาน &nbsp;และเสนอผู้บริหารท้องถิ่นเพื่อให้ความเห็นชอบ<br />\r\n5.&nbsp;&nbsp; &nbsp;เมื่อผู้บริหารท้องถิ่นพิจารณาให้ความเห็นชอบร่างแผนการดำเนินงานแล้วให้ประกาศเป็นแผนการดำเนินงานโดยให้ปิดประกาศแผนการดำเนินงาน &nbsp;เพื่อให้ประชาชนในท้องถิ่นทราบโดยทั่วกัน</p>\r\n\r\n<p style=\"text-align:center\"><strong>ประโยชน์ของแผนดำเนินงาน<br />\r\n&nbsp;&nbsp; &nbsp;&hellip;&hellip;&hellip;&hellip;&hellip;&hellip;&hellip;&hellip;&hellip;&hellip;&hellip;&hellip;&hellip;&hellip;&hellip;&hellip;&hellip;&hellip;&hellip;&hellip;&hellip;&hellip;&hellip;&hellip;&hellip;&hellip;&hellip;&hellip;..</strong></p>\r\n\r\n<p>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; แผนดำเนินงานที่ชี้ถึงความสามารถในการให้บริการและตอบสนองความต้องการของประชาชนในท้องถิ่น &nbsp;แนวทาง &nbsp;แผนงาน &nbsp;โครงการพัฒนา &nbsp;ที่บรรจุอยู่ในแผนการดำเนินงานจะครอบคลุมความเพียงพอและความครบถ้วน &nbsp;ของการให้บริการกลุ่มเป้าหมาย &nbsp;แสดงถึงภารกิจของหน่วยงานที่มีต่อสังคม &nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n', NULL, NULL),
(160, 1, 105, 'รายละเอียดงบประมาณรายจ่ายทั่วไป  ประจำปีงบประมาณ  พ.ศ. 2559 กองสาธารณสุขและสิ่งแวดล้อม', 1, '<p style=\"text-align:center\">&nbsp; &nbsp; &nbsp; &nbsp;<strong>&nbsp;รายละเอียดงบประมาณรายจ่ายทั่วไป&nbsp; ประจำปีงบประมาณ&nbsp; พ.ศ. 2559</strong></p>\r\n\r\n<p style=\"text-align:center\"><strong>เทศบาลตำบลกุดนกเปล้า&nbsp;&nbsp; อำเภอเมือง&nbsp; จังหวัดสระบุรี<br />\r\nรายจ่ายจำแนกตามหน่วยงาน<br />\r\nกองสาธารณสุขและสิ่งแวดล้อม</strong></p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p><strong>ประมาณการรายจ่ายรวมทั้งสิ้น&nbsp; </strong><strong>4,648,004.- บาท&nbsp; จ่ายจากรายได้จัดเก็บเอง&nbsp; หมวดภาษีจัดสรรและหมวดเงินอุดหนุนทั่วไป&nbsp; แยกเป็น</strong></p>\r\n\r\n<p>แผนงานสาธารณสุข&nbsp; งานบริการสาธารณสุขและงานสาธารณสุข<strong>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; รวม&nbsp; &nbsp;</strong><strong>&nbsp;&nbsp;&nbsp;4,298,004.-บาท&nbsp; </strong></p>\r\n\r\n<p><strong>1&nbsp; งบบุคลากร&nbsp; (520000)&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; รวม&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;2,</strong><strong>274,504.- บาท&nbsp; </strong></p>\r\n\r\n<p><strong>1.1&nbsp; เงินเดือน&nbsp; (ฝ่ายประจำ) (522000) &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; จำนวน &nbsp;&nbsp;2,</strong><strong>274,504.- บาท&nbsp; </strong></p>\r\n\r\n<p><strong>1.1.1&nbsp; ประเภทเงินเดือนพนักงาน (220100) &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; จำนวน &nbsp;&nbsp;&nbsp;&nbsp;</strong><strong>413,904.- บาท</strong></p>\r\n\r\n<p style=\"margin-left:36.0pt\">เพื่อจ่ายเป็นเงินเดือนให้พนักงานเทศบาลสามัญ จำนวน 3 อัตราพร้อมทั้งเงินปรับปรุงเงินเดือนประจำปี ตามตำแหน่งและอัตราที่ก.ท.กำหนดโดยคำนวณตั้งจ่ายไว้ไม่เกิน 12 เดือน</p>\r\n\r\n<p>ตั้งจ่ายจากเงินรายได้ (ปรากฏในแผนงานสาธารณสุข&nbsp; งานบริหารทั่วไปเกี่ยวกับสาธารณสุข)</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p><strong>1.1.2</strong><strong>&nbsp; ประเภทเงินเพิ่มต่าง ๆ&nbsp; (220200) &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; จำนวน&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;71,880.- บาท&nbsp; </strong></p>\r\n\r\n<p style=\"margin-left:36.0pt\">เพื่อจ่ายเป็นเงินเพิ่มค่าครองชีพชั่วคราวของพนักงานเทศบาล ตามระเบียบกระทรวงการคลังว่าด้วยการเบิกจ่ายเงินเพิ่มค่าครองชีพชั่วคราวของข้าราชการและลูกจ้างประจำส่วนราชการเพื่อจ่ายเป็นค่าตอบแทนรายเดือนของปลัดเทศบาล ระดับ 8 และเพื่อจ่ายเป็นค่าตอบแทนพิเศษของพนักงานเทศบาล ผู้ได้รับเงินเดือนถึงขั้นสูงของอันดับตำแหน่งเพื่อจ่ายเป็นเงินค่าการกำหนดอัตราเงินเดือนและจำนวนเงินที่ปรับเพิ่มสำหรับคุณวุฒิที่ ก.พ.หรือคณะกรรมการกลางพนักงานเทศบาลรับรองว่าคุณสมบัตินั้นเป็นคุณสมบัติเฉพาะตำแหน่งที่ได้รับแต่งตั้งและเงินเพิ่มต่างๆของพนักงานเทศบาล</p>\r\n\r\n<p>ตั้งจ่ายจากเงินรายได้&nbsp; (ปรากฏในแผนงานสาธารณสุข&nbsp; งานบริหารทั่วไปเกี่ยวกับสาธารณสุข)</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p><strong>1.1.3 &nbsp;ประเภทค่าจ้างพนักงานจ้าง&nbsp; (220700)&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; จำนวน &nbsp;&nbsp;1,305,600.- บาท </strong></p>\r\n\r\n<p>เพื่อจ่ายเป็นค่าตอบแทนให้แก่พนักงานจ้าง จำนวน 11 อัตรา ตามอัตราที่กำหนด โดยคำนวณ</p>\r\n\r\n<p>ตั้งจ่ายไว้ไม่เกิน 12 เดือน</p>\r\n\r\n<p>ตั้งจ่ายจากเงินรายได้&nbsp; (ปรากฏในแผนงานสาธารณสุข&nbsp; งานบริหารทั่วไปเกี่ยวกับสาธารณสุข)</p>\r\n\r\n<p><strong>1.1.4&nbsp; ประเภทเงินเพิ่มต่าง ๆ ของพนักงานจ้าง&nbsp; (220800) จำนวน&nbsp;&nbsp; 483,120.- บาท</strong></p>\r\n\r\n<p style=\"margin-left:36.0pt\">เพื่อจ่ายเป็นเงินเพิ่มค่าครองชีพชั่วคราวให้แก่พนักงานจ้าง จำนวน 11 อัตราตามระเบียกระทรวง</p>\r\n\r\n<p style=\"margin-left:36.0pt\">การคลังว่าด้วยการเบิกจ่ายเงินเพิ่มการครองชีพชั่วคราวของข้าราชการและลูกจ้างประจำส่วน</p>\r\n\r\n<p style=\"margin-left:36.0pt\">ราชการ (ฉบับที่ 5) พ.ศ.2555 ถือปฏิบัติโดยอนุโลมตามหนังสือด่วนที่สุด ที่ มท. 0809.3/ว 1259</p>\r\n\r\n<p style=\"margin-left:36.0pt\">ลงวันที่ 14 พฤษภาคม 2555&nbsp;</p>\r\n\r\n<p>ตั้งจ่ายจากเงินรายได้&nbsp; (ปรากฏในแผนงานสาธารณสุข&nbsp; งานบริหารทั่วไปเกี่ยวกับสาธารณสุข)</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p><strong>2.&nbsp; งบดำเนินการ&nbsp; (530000)</strong><strong>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; จำนวน &nbsp;&nbsp;1,903,500.- บาท </strong></p>\r\n\r\n<p><strong>2.1&nbsp; ค่าตอบแทน&nbsp; (531000)&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; จำนวน&nbsp; &nbsp;&nbsp;&nbsp;271,500.- บาท</strong></p>\r\n\r\n<p><strong>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 2.1.1 ประเภทค่าตอบแทนผู้ปฏิบัติราชการอันเป็นประโยชน์แก่องค์กรปกครองส่วนท้องถิ่น (310100) &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; จำนวน&nbsp;&nbsp; </strong><strong>100,000.- บาท</strong>&nbsp;</p>\r\n\r\n<p style=\"margin-left:36.0pt\">เพื่อจ่ายเป็นค่าประโยชน์ตอบแทนเป็นกรณีพิเศษ (โบนัส) แก่พนักงานเทศบาล&nbsp; พนักงานจ้างตามภารกิจ &nbsp;และพนักงานจ้างทั่วไป&nbsp; ของเทศบาลตำบลกุดนกเปล้า&nbsp;</p>\r\n\r\n<p>ตั้งจ่ายจากเงินรายได้&nbsp; (ปรากฏในแผนงานสาธารณสุข&nbsp; งานบริหารทั่วไปเกี่ยวกับสาธารณสุข)</p>\r\n\r\n<p><strong>2.1.2&nbsp; ประเภทค่าตอบแทนการปฏิบัติงานนอกเวลาราชการ &nbsp;(310300)</strong></p>\r\n\r\n<p style=\"margin-left:252.0pt\"><strong>จำนวน 150,000.-บาท</strong>&nbsp;</p>\r\n\r\n<p style=\"margin-left:36.0pt\">เพื่อจ่ายเป็นเงินตอบแทนการปฏิบัติงานนอกเวลาราชการให้แก่พนักงานเทศบาลและพนักงานจ้างกรณีที่มีความจำเป็นต้องปฏิบัติงานเร่งด่วนนอกเวลาราชการหรือในวันหยุดราชการ</p>\r\n\r\n<p>ตั้งจ่ายจากเงินรายได้&nbsp; (ปรากฏในแผนงานสาธารณสุข&nbsp; งานบริหารทั่วไปเกี่ยวกับสาธารณสุข)</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p><strong>2.1.</strong><strong>3 &nbsp;&nbsp;ประเภทเงินช่วยเหลือการศึกษาบุตร (310500) &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; จำนวน&nbsp;&nbsp; 21,500.- บาท&nbsp;&nbsp;&nbsp;&nbsp; </strong></p>\r\n\r\n<p>เพื่อจ่ายเป็นเงินช่วยเหลือการศึกษาบุตรของพนักงานเทศบาล ที่มีสิทธิได้รับตามระเบียบฯ&nbsp;</p>\r\n\r\n<p>ตั้งจ่ายจากเงินรายได้&nbsp; (ปรากฏในแผนงานสาธารณสุข&nbsp;&nbsp;&nbsp; งานบริหารทั่วไปเกี่ยวกับสาธารณสุข)</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p><strong>2.2</strong>&nbsp; <strong>ค่าใช้สอย</strong> &nbsp;<strong>(532000)</strong> &nbsp;<strong>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;รวม&nbsp; </strong><strong>620,000.- บาท</strong></p>\r\n\r\n<p><strong>งบดำเนินการ&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp; รวม&nbsp; </strong><strong>620,000.- บาท</strong></p>\r\n\r\n<p><strong>รายจ่ายเพื่อให้มาได้มาซึ่งบริการ&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp; จำนวน&nbsp; </strong><strong>280,000.- บาท</strong></p>\r\n\r\n<p><strong>2.2.1</strong><strong>&nbsp; ประเภทรายจ่ายเพื่อให้ได้มาซึ่งบริการ (320100) &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;จำนวน &nbsp;280,000.-บาท</strong>&nbsp;</p>\r\n\r\n<p>เพื่อจ่ายเป็น</p>\r\n\r\n<p style=\"margin-left:36.0pt\">-&nbsp; ค่าตอบแทนจ้างเหมาบริการ เช่น ค่าจ้างพนักงานจ้างเหมา ฝังกลบขยะมูลฝอย&nbsp; ฉีดพ่นเคมีกำจัดยุง&nbsp; ฉีดพ่นสารเคมีป้องกันโรคไข้หวัดนก &nbsp;กำจัดปลวก หรือแมลง&nbsp; ฯลฯ&nbsp;</p>\r\n\r\n<p><strong>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; -&nbsp; </strong>ค่าเย็บเล่ม&nbsp; เข้าปกหนังสือ&nbsp; และหนังสืออ้างอิงเกี่ยวกับราชการ ฯลฯ</p>\r\n\r\n<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; -&nbsp; ค่าธรรมเนียม&nbsp; และค่าลงทะเบียนต่าง ๆ</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p style=\"margin-left:36.0pt\">-&nbsp; ค่าโฆษณาและเผยแพร่ประชาสัมพันธ์&nbsp; ค่าผลิตเอกสารส่งเสริมสุขภาพ&nbsp; การป้องกันควบคุมโรค&nbsp; ฯลฯ</p>\r\n\r\n<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; -&nbsp; ค่าจ้างเหมาออกแบบ&nbsp; เขียนแบบ&nbsp;&nbsp; จัดสวน&nbsp; ตัดหญ้า&nbsp; จ้างคุมงาน&nbsp; ฯลฯ</p>\r\n\r\n<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; -&nbsp; ค่าวารสารการส่งเสริมสุขภาพและสิ่งแวดล้อม ฯลฯ</p>\r\n\r\n<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; -&nbsp; ค่าล้างฟิล์ม&nbsp; อัดขยายรูป&nbsp; ค่าถ่ายเอกสาร ฯลฯ</p>\r\n\r\n<p>&nbsp;ตั้งจ่ายจากเงินรายได้&nbsp; (ปรากฏในแผนงานสาธารณสุข&nbsp;&nbsp; งานบริหารทั่วไปเกี่ยวกับสาธารณสุข)</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p><strong>2.2.2&nbsp; ประเภทรายจ่ายเกี่ยวกับการรับรองและพิธีการ (320200) &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;จำนวน&nbsp; &nbsp;&nbsp;20,000.- บาท</strong>&nbsp;</p>\r\n\r\n<p style=\"margin-left:36.0pt\">เพื่อจ่ายเป็น ค่ารับรองในการต้อนรับคณะบุคคล&nbsp; ค่าอาหาร&nbsp; เครื่องดื่ม&nbsp; ค่าของขวัญ&nbsp; ค่าบริการต่างๆ ค่าใช้จ่ายที่เกี่ยวเนื่องในการเลี้ยงรับรอง&nbsp; รวมทั้งค่าใช้จ่ายอื่นๆ ฯลฯ&nbsp; ซึ่งจำเป็นต้องจ่ายที่เกี่ยวกับการรับรองในการต้อนรับบุคคล&nbsp; หรือคณะบุคคลที่ไปนิเทศงาน&nbsp; ตรวจงานหรือเยี่ยมชม หรือทัศนศึกษาดูงาน&nbsp; และเจ้าหน้าที่ที่เกี่ยวข้อง&nbsp; ซึ่งร่วมต้อนรับบุคคล หรือคณะบุคคล&nbsp;&nbsp;&nbsp;</p>\r\n\r\n<p>ตั้งจ่ายจากเงินอุดหนุนทั่วไป (ปรากฏในแผนงานสาธารณสุข&nbsp; งานบริหารทั่วไปเกี่ยวกับสาธารณสุข)</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p style=\"margin-left:36.0pt\"><strong>2.2.3&nbsp; ประเภทรายจ่ายเกี่ยวเนื่องกับการปฏิบัติราชการที่ไม่เข้าลักษณะ </strong></p>\r\n\r\n<p style=\"margin-left:36.0pt\"><strong>รายจ่ายหมวดอื่นๆ (</strong><strong>320300)<br />\r\n(1) ค่าใช้จ่ายในการฝึกอบรมและสัมมนา ค่าใช้จ่ายในการเดินทางไปราชการ&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;จำนวน&nbsp; 20,000.- บาท&nbsp;&nbsp;&nbsp; </strong></p>\r\n\r\n<p style=\"margin-left:36.0pt\">เพื่อจ่ายเป็นค่าลงทะเบียน ค่าใช้จ่ายในการเดินทางไปราชการ&nbsp; อบรมสัมมนาในราช</p>\r\n\r\n<p style=\"margin-left:36.0pt\">อาณาจักรของพนักงานเทศบาล พนักงานจ้าง&nbsp; ค่าเบี้ยเลี้ยง&nbsp; ค่าพาหนะ&nbsp; ค่าเช่าที่พัก&nbsp;</p>\r\n\r\n<p style=\"margin-left:36.0pt\">ค่าใช้จ่ายอื่นที่จำเป็น&nbsp;</p>\r\n\r\n<p>ตั้งจ่ายจากเงินรายได้ (ปรากฏในแผนงานสาธารณสุข งานบริหารทั่วไปเกี่ยวกับสาธารณสุข)</p>\r\n\r\n<p><br />\r\n<strong>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;2.2.</strong><strong>4 ประเภทรายจ่ายเพื่อบำรุงรักษาหรือซ่อมแซมทรัพย์สิน (320400) &nbsp;จำนวน 300,000.-บาท</strong></p>\r\n\r\n<p style=\"margin-left:36.0pt\">เพื่อจ่ายเป็นค่าบำรุงรักษา&nbsp; ซ่อมแซมครุภัณฑ์&nbsp; เช่น&nbsp; รถยนต์บรรทุกขยะ&nbsp; เครื่องคอมพิวเตอร์&nbsp;&nbsp;&nbsp;&nbsp; เครื่องพ่นเคมีกำจัดยุง&nbsp; ถังขยะ ฯลฯ</p>\r\n\r\n<p>&nbsp;ตั้งจ่ายจากเงินรายได้&nbsp; (ปรากฏในแผนงานสาธารณสุข&nbsp; งานบริหารทั่วไปเกี่ยวกับสาธารณสุข)&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p><strong>2.3&nbsp; ค่าวัสดุ&nbsp; (533000)</strong><strong>&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; รวม &nbsp;&nbsp;1,010,000.- บาท</strong></p>\r\n\r\n<p><strong>2.3.1&nbsp; ประเภทวัสดุสำนักงาน (330100) &nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; จำนวน&nbsp;&nbsp; &nbsp;40,000.- บาท</strong>&nbsp;</p>\r\n\r\n<p style=\"margin-left:36.0pt\">เพื่อจ่ายเป็นค่ากระดาษ หมึก ดินสอ ปากกา ไม้บรรทัด ยางลบ เครื่องเขียน&nbsp; แบบพิมพ์</p>\r\n\r\n<p style=\"margin-left:36.0pt\">&nbsp;แฟ้ม ตรายาง ฯลฯ</p>\r\n\r\n<p>ตั้งจ่ายจากเงินรายได้ (ปรากฏในแผนงานสาธารณสุข&nbsp; งานบริหารทั่วไปเกี่ยวกับสาธารณสุข)</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p><strong>2.3.2 ประเภทวัสดุงานบ้านงานครัว (330300) &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; จำนวน&nbsp; </strong><strong>200,000.- บาท</strong>&nbsp;</p>\r\n\r\n<p>เพื่อจ่ายเป็นค่าถังขยะแบบมีฝาปิด และไม่มีฝาปิด&nbsp; ไม้กวาด&nbsp; เข่ง&nbsp; ฯลฯ&nbsp;</p>\r\n\r\n<p>ตั้งจ่ายจากเงินอุดหนุนทั่วไป&nbsp; (ปรากฏในแผนงานสาธารณสุข&nbsp; งานบริหารทั่วไปเกี่ยวกับสาธารณสุข)</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p><strong>2.3.3 &nbsp;ประเภทวัสดุยานพาหนะและขนส่ง (330700) จำนวน&nbsp; 150,000.- บาท</strong>&nbsp;</p>\r\n\r\n<p style=\"margin-left:36.0pt\">เพื่อจ่ายเป็นค่าจัดซื้อวัสดุรถยนต์&nbsp;&nbsp; และรถจักรยานยนต์&nbsp; เช่น ยางนอก&nbsp; ยางใน สายไมล์</p>\r\n\r\n<p style=\"margin-left:36.0pt\">&nbsp;แบตเตอร์รี่&nbsp; หัวเทียน&nbsp; และวัสดุอื่นๆ ที่จำเป็น ฯลฯ&nbsp;</p>\r\n\r\n<p>ตั้งจ่ายจากเงินรายได้&nbsp; (ปรากฏในแผนงานสาธารณสุข&nbsp; งานบริหารทั่วไปเกี่ยวกับสาธารณสุข)</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p><strong>2.3.4 &nbsp;ประเภทวัสดุเชื้อเพลิงและหล่อลื่น (330800) &nbsp;&nbsp; จำนวน&nbsp; </strong><strong>400,000.- บาท</strong>&nbsp;</p>\r\n\r\n<p style=\"margin-left:36.0pt\">เพื่อจ่ายเป็นค่าน้ำมันเชื้อเพลิง&nbsp; เช่น&nbsp; น้ำมันดีเซล&nbsp; น้ำมันเบนซิน&nbsp; น้ำมันเครื่อง&nbsp; สำหรับ</p>\r\n\r\n<p style=\"margin-left:36.0pt\">รถยนต์บรรทุกขยะ&nbsp; รถจักรยานยนต์&nbsp;&nbsp; เครื่องพ่นเคมีกำจัดยุง&nbsp; รวมทั้งใช้ผสมน้ำยาฉีด</p>\r\n\r\n<p style=\"margin-left:36.0pt\">พ่นเคมีกำจัดยุง&nbsp;</p>\r\n\r\n<p>ตั้งจ่ายจากเงินรายได้&nbsp; (ปรากฏในแผนงานสาธารณสุข&nbsp; งานบริหารทั่วไปเกี่ยวกับสาธารณสุข)</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p><strong>2.3.5</strong><strong>&nbsp; ประเภทวัสดุวิทยาศาสตร์และการแพทย์ (330900) จำนวน&nbsp; 100,000.- บาท</strong>&nbsp;</p>\r\n\r\n<p style=\"margin-left:36.0pt\">เพื่อจ่ายเป็นค่าจัดซื้อน้ำยาพ่นเคมีกำจัดยุง&nbsp; น้ำยาต่างๆ&nbsp; ทรายอะเบท&nbsp; วัสดุอุปกรณ์</p>\r\n\r\n<p style=\"margin-left:36.0pt\">ป้องกันการปนเปื้อนสารเคมี&nbsp; วัสดุตรวจสอบสารปนเปื้อนในอาหาร&nbsp; เวชภัณฑ์ต่าง ๆ</p>\r\n\r\n<p style=\"margin-left:36.0pt\">เช่น&nbsp; ยารักษาโรค น้ำยาต่าง ๆ สำลี&nbsp; ผ้าพันแผล&nbsp; แอลกอฮอล์&nbsp; ฯลฯ&nbsp;</p>\r\n\r\n<p>ตั้งจ่ายจากเงินอุดหนุนทั่วไป&nbsp; (ปรากฏในแผนงานสาธารณสุข&nbsp; งานบริหารทั่วไปเกี่ยวกับสาธารณสุข)</p>\r\n\r\n<p style=\"margin-left:36.0pt\">&nbsp;</p>\r\n\r\n<p><strong>2.3.6 &nbsp;ประเภทวัสดุโฆษณาและเผยแพร่&nbsp; (331100) &nbsp;&nbsp;&nbsp; จำนวน&nbsp;&nbsp; </strong><strong>30,000.- บาท</strong>&nbsp;</p>\r\n\r\n<p style=\"margin-left:36.0pt\">เพื่อจ่ายเป็นค่ากระดาษเขียนโปสเตอร์&nbsp; พู่กันและสี ฟิล์ม แถบบันทึกเสียงหรือภาพ</p>\r\n\r\n<p style=\"margin-left:36.0pt\">รูปสีหรือขาวดำที่ได้จากการล้าง&nbsp; อัด&nbsp; ขยาย&nbsp; ฯลฯ&nbsp;</p>\r\n\r\n<p>ตั้งจ่ายจากเงินรายได้&nbsp; (ปรากฏในแผนงานสาธารณสุข&nbsp; งานบริหารทั่วไปเกี่ยวกับสาธารณสุข)</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p><strong>2.3.7 &nbsp;ประเภทวัสดุเครื่องแต่งกาย (331200) &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; จำนวน&nbsp; &nbsp;&nbsp;50,000.- บาท</strong></p>\r\n\r\n<p>เพื่อจ่ายเป็นค่าเสื้อ&nbsp; กางเกง &nbsp;ผ้า&nbsp; ถุงมือ&nbsp; รองเท้า&nbsp; เข็มขัด&nbsp; หมวก เสื้อกันฝน ฯลฯ</p>\r\n\r\n<p>&nbsp;ตั้งจ่ายจากเงินรายได้&nbsp; (ปรากฏในแผนงานสาธารณสุข&nbsp; งานบริหารทั่วไปเกี่ยวกับสาธารณสุข)</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p><strong>2.3.8&nbsp; ประเภทวัสดุคอมพิวเตอร์&nbsp; (331400)&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; จำนวน&nbsp; &nbsp;&nbsp;&nbsp;40,000.- บาท</strong>&nbsp;</p>\r\n\r\n<p style=\"margin-left:36.0pt\">เพื่อจ่ายเป็นค่าจัดซื้อวัสดุคอมพิวเตอร์&nbsp; เช่น&nbsp; แผ่นกรอง&nbsp; แผ่นดิสเกส&nbsp; หมึกพริ้นเตอร์</p>\r\n\r\n<p style=\"margin-left:36.0pt\">&nbsp;โปรแกรม&nbsp; Flash&nbsp; Drive&nbsp; และอื่นๆ ที่เกี่ยวข้องกับคอมพิวเตอร์&nbsp;</p>\r\n\r\n<p>ตั้งจ่ายจากเงินรายได้&nbsp; (ปรากฏในแผนงานสาธารณสุข&nbsp; งานบริหารทั่วไปเกี่ยวกับสาธารณสุข)</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p><strong>2.4&nbsp; ค่าสาธารณูปโภค&nbsp; (534000)&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; รวม &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;2,000&nbsp; บาท&nbsp; </strong></p>\r\n\r\n<p><strong>2.4.1&nbsp; ประเภทค่าไปรษณีย์&nbsp; (340400)&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; จำนวน&nbsp;&nbsp; 2,000.- บาท</strong>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</p>\r\n\r\n<p>เพื่อจ่ายเป็นค่าไปรษณีย์&nbsp; ค่าโทรเลข&nbsp; ค่าธนาณัติ&nbsp; ค่าซื้อดวงตราไปรษณีย์&nbsp;</p>\r\n\r\n<p>ตั้งจ่ายจากเงินรายได้&nbsp; (ปรากฏในแผนงานสาธารณสุข&nbsp; งานบริหารทั่วไปเกี่ยวกับสาธารณสุข)</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p><strong>3.&nbsp; งบเงินอุดหนุน&nbsp; (560000)&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;ตั้งไว้รวม &nbsp;120,000.-&nbsp; บาท&nbsp;&nbsp; </strong></p>\r\n\r\n<p><strong>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; เงินอุดหนุน</strong><strong>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; รวม &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;120,000.-&nbsp; บาท&nbsp;&nbsp; </strong></p>\r\n\r\n<p><strong>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; เงินอุดหนุนกิจการที่เป็นสาธารณประโยชน์&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; จำนวน&nbsp; &nbsp;120,000.-&nbsp; บาท&nbsp;&nbsp;&nbsp;&nbsp; </strong></p>\r\n\r\n<p><strong>4.1 ประเภทเงินอุดหนุนกิจการที่เป็นสาธารณประโยชน์ (610400)&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; จำนวน &nbsp;120,000.-&nbsp; บาท&nbsp; </strong></p>\r\n\r\n<p style=\"margin-left:36.0pt\">-&nbsp; เงินอุดหนุนโครงการพัฒนางานสาธารณสุขมูลฐานในเขตเทศบาล &nbsp;&nbsp;&nbsp;&nbsp;จำนวน&nbsp; 120,000.-บาท</p>\r\n\r\n<p style=\"margin-left:36.0pt\">เพื่อจ่ายเป็นค่าดำเนินงานของ อสม. ในเขตชุมชน / หมู่บ้าน เพื่อให้ อสม. ดำเนินการใน 3</p>\r\n\r\n<p style=\"margin-left:36.0pt\">กิจกรรม&nbsp; ได้แก่ การพัฒนาศักยภาพ ด้านสาธารณสุข&nbsp; การแก้ไขปัญหาด้านสาธารณสุขใน</p>\r\n\r\n<p style=\"margin-left:36.0pt\">เรื่องต่างๆ&nbsp; และการจัดบริการสุขภาพเบื้องต้นในศูนย์สาธารณสุขมูลฐานชุมชน (ศสมช.)</p>\r\n\r\n<p>&nbsp;ตั้งจ่ายจากเงินอุดหนุนทั่วไป (ปรากฏในแผนงานสาธารณสุข&nbsp; งานบริหารทั่วไปเกี่ยวกับสาธารณสุข)</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p><strong><u>งานบริการสาธารณสุขและงานสาธารณสุขอื่น&nbsp; </u></strong><strong>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;รวม &nbsp;</strong><strong>350,000.- บาท</strong></p>\r\n\r\n<p><strong>งบดำเนินงาน&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;รวม &nbsp;</strong><strong>350,000.- บาท</strong></p>\r\n\r\n<p><strong>รายจ่ายเกี่ยวกับการปฏิบัติราชการที่มาเข้าลักษณะรายจ่ายหมวดอื่นๆ&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;รวม &nbsp;&nbsp;&nbsp;</strong><strong>350,000.- บาท</strong></p>\r\n\r\n<p><strong>(1) โครงการรณรงค์ป้องกันโรคพิษสุนัขบ้า&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;ตั้งไว้ &nbsp;100</strong><strong>,000.- บาท</strong></p>\r\n\r\n<p>&nbsp;&nbsp; &nbsp;เพื่อจ่ายเป็นค่าใช้จ่ายในการรณรงค์โรคพิษสุนัขบ้า ตั้งจ่ายจากเงินอุดหนุนทั่วไป&nbsp; (ปรากฏในแผนงานสาธารณสุข&nbsp; งานบริหารทั่วไปเกี่ยวกับสาธารณสุขอื่น )</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p><strong>&nbsp;(</strong><strong>2)&nbsp; โครงการป้องกันและควบคุมโรคระบาดในคนและสัตว์ &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;ตั้งไว้&nbsp; 100,000.- บาท</strong><br />\r\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; เพื่อจ่ายเป็นค่าใช้จ่ายในการป้องกันควบคุมโรคระบาดในพื้นที่&nbsp; ตั้งจ่ายจากเงินอุดหนุนทั่วไป<br />\r\n&nbsp;(ปรากฏในแผนงานสาธารณสุข&nbsp; งานบริการสาธารณสุขและงานสาธารณสุขอื่น)</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p><strong>(</strong><strong>3)&nbsp; โครงการควบคุมป้องกันโรคไข้เลือดออก&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; ตั้งไว้&nbsp; 150,000.- บาท&nbsp;<br />\r\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </strong>เพื่อจ่ายเป็นค่าใช้จ่ายในการควบคุมป้องกันโรคไข้เลือดออก ตั้งจ่ายจากเงินอุดหนุนทั่วไป&nbsp;<br />\r\n(ปรากฏในแผนงานสาธารณสุข&nbsp; งานบริการสาธารณสุขและงานสาธารณสุขอื่น)</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n', NULL, NULL);
INSERT INTO `mhd_language_detail` (`id`, `language_id`, `ref_id`, `name`, `type`, `detail`, `detail_2`, `detail_3`) VALUES
(161, 1, 106, 'รายละเอียดงบประมาณรายจ่ายทั่วไปประจำปีงบประมาณ พ.ศ. 2559 แผนงานบริหารงานทั่วไป งานบริหารงานคลัง', 1, '<p style=\"text-align: center;\">&nbsp;</p>\r\n\r\n<p style=\"text-align: center;\"><strong>รายละเอียดงบประมาณรายจ่ายทั่วไปประจำปีงบประมาณ พ.ศ. 2559</strong></p>\r\n\r\n<p style=\"text-align: center;\"><strong>เทศบาลตำบลกุดนกเปล้า</strong></p>\r\n\r\n<p style=\"text-align: center;\"><strong>อำเภอเมืองสระบุรี&nbsp; จังหวัดสระบุรี</strong></p>\r\n\r\n<p style=\"text-align: center;\"><strong>รายจ่ายจำแนกตามหน่วยงาน</strong></p>\r\n\r\n<p style=\"text-align: center;\"><strong>แผนงานบริหารงานทั่วไป งานบริหารงานคลัง</strong></p>\r\n\r\n<p><strong>........................................................................</strong></p>\r\n\r\n<p><strong>ตั้งงบประมาณรายจ่ายทั้งสิ้น&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 2,</strong><strong>505,900.-&nbsp;&nbsp; บาท&nbsp;&nbsp; แยกเป็น </strong></p>\r\n\r\n<p><strong>1.&nbsp; งบบุคลากร &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; รวม&nbsp; 1,818,700.-&nbsp; บาท&nbsp; แยกเป็น</strong></p>\r\n\r\n<p><strong>1.1&nbsp; หมวดเงินเดือน(ฝ่ายประจำ) (52000) &nbsp;&nbsp;รวม&nbsp; 1,818,700.-&nbsp; บาท&nbsp; แยกเป็น </strong></p>\r\n\r\n<p>1.1.1&nbsp; ประเภทเงินเดือนพนักงาน&nbsp; (220100)&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; จำนวน &nbsp;829,800.-บาท&nbsp;</p>\r\n\r\n<p style=\"margin-left:72.0pt\">เพื่อจ่ายเป็นเงินเดือนพนักงานเทศบาลสามัญของกองคลัง&nbsp; จำนวน 5 อัตรา&nbsp;</p>\r\n\r\n<p style=\"margin-left:72.0pt\">พร้อมทั้งเงินปรับปรุงประจำปี โดยคำนวณตั้งไว้ไม่เกิน 12 เดือน &nbsp;&nbsp;</p>\r\n\r\n<p>ตั้งจ่ายจากเงินรายได้&nbsp; (ปรากฏในแผนงานบริหารงานทั่วไป&nbsp; งานบริหารงานคลัง)</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>1.1.2&nbsp; ประเภทเงินประจำตำแหน่ง (220300) &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; จำนวน&nbsp;&nbsp; 42,000.-บาท&nbsp;</p>\r\n\r\n<p style=\"margin-left:36.0pt\">&nbsp;เพื่อจ่ายเป็นเงินประจำตำแหน่งของพนักงานเทศบาล &nbsp;จำนวน&nbsp; 1&nbsp; อัตรา</p>\r\n\r\n<p>ตั้งจ่ายจากเงินรายได้ (ปรากฏในแผนงานบริหารงานทั่วไป&nbsp; งานบริหารงานคลัง)</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 1.1.3&nbsp; ประเภทค่าจ้างลูกจ้างประจำ&nbsp; (220500) &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; จำนวน &nbsp;242,300.-บาท&nbsp;</p>\r\n\r\n<p style=\"margin-left:36.0pt\">&nbsp;เพื่อจ่ายเป็นค่าจ้างลูกจ้างประจำ&nbsp; &nbsp;&nbsp;จำนวน&nbsp; 1&nbsp; อัตรา&nbsp;</p>\r\n\r\n<p style=\"margin-left:36.0pt\">พร้อมทั้งเงินปรับปรุงประจำปี</p>\r\n\r\n<p>&nbsp; ตั้งจ่ายจากเงินรายได้&nbsp; (ปรากฏในแผนงานบริหารงานทั่วไป&nbsp; งานบริหารงานคลัง)</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>1.1.4 &nbsp;ประเภทค่าจ้างพนักงานจ้าง&nbsp; (220700)&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; จำนวน &nbsp;641,600.- &nbsp;บาท&nbsp;</p>\r\n\r\n<p style=\"margin-left:36.0pt\">เพื่อจ่ายเป็นค่าตอบแทนพนักงานจ้างของกองคลัง&nbsp; จำนวน&nbsp; 5&nbsp; อัตรา</p>\r\n\r\n<p style=\"margin-left:36.0pt\">โดยคำนวณตั้งไว้ไม่เกิน 12 เดือน</p>\r\n\r\n<p>&nbsp; ตั้งจ่ายจากเงินรายได้&nbsp; (ปรากฏในแผนงานบริหารงานทั่วไป&nbsp;&nbsp; งานบริหารงานคลัง)</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 1.1.5&nbsp; ประเภทเงินเพิ่มต่าง ๆ ของพนักงานจ้าง&nbsp; (220700)&nbsp; &nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; จำนวน&nbsp; 63,000.-&nbsp; บาท</p>\r\n\r\n<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; เพื่อจ่ายเป็นเงินเพิ่มค่าครองชีพชั่วคราวและเงินเพิ่มอื่น ๆ ให้แก่พนักงานจ้าง&nbsp;</p>\r\n\r\n<p style=\"margin-left:36.0pt\">จำนวน&nbsp; 5&nbsp; อัตรา โดยคำนวณตั้งจ่ายไว้ไม่เกิน&nbsp; 12&nbsp;&nbsp;&nbsp; เดือน&nbsp;&nbsp; &nbsp;</p>\r\n\r\n<p>ตั้งจ่ายจากเงินรายได้&nbsp; (ปรากฏในแผนงานบริหารงานทั่วไป&nbsp; งานบริหารงานคลัง)</p>\r\n\r\n<p><strong>2.&nbsp; งบดำเนินการ&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; รวม&nbsp; &nbsp;630,000.-&nbsp;&nbsp;&nbsp; บาท&nbsp; แยกเป็น</strong></p>\r\n\r\n<p><strong>2.1&nbsp; หมวดค่าตอบแทน (531000)&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; รวม&nbsp; </strong><strong>180,000.-&nbsp;&nbsp; บาท&nbsp; </strong></p>\r\n\r\n<p style=\"margin-left:36.0pt\">2.1.1&nbsp; ประเภทค่าตอบแทนผู้ปฏิบัติราชการอันเป็นประโยชน์แก่องค์กรปกครองส่วนท้องถิ่น (310100) &nbsp;&nbsp;จำนวน&nbsp; 100,000.-&nbsp;&nbsp; บาท</p>\r\n\r\n<p style=\"margin-left:72.0pt\">เพื่อจ่ายเป็นเงินค่าประโยชน์ตอบแทนเป็นกรณีพิเศษ (โบนัส)&nbsp; ให้แก่ข้าราชการ&nbsp; ลูกจ้างประจำ และพนักงานจ้าง ของเทศบาลตำบลกุดนกเปล้า&nbsp;</p>\r\n\r\n<p>ตั้งจ่ายจากเงินรายได้&nbsp; (ปรากฏในแผนงานบริหารงานทั่วไป&nbsp; งานบริหารงานคลัง)</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 2.1.2&nbsp; ประเภทค่าตอบแทนการปฏิบัติงานนอกเวลาราชการ (310300)&nbsp; จำนวน&nbsp; 50,000.- บาท</p>\r\n\r\n<p style=\"margin-left:72.0pt\">เพื่อจ่ายเป็นค่าตอบแทนการปฏิบัติงานนอกเวลาราชการของพนักงานเทศบาล ลูกจ้างประจำ&nbsp;&nbsp; พนักงานจ้างตามภารกิจ และพนักงานทั่วไป&nbsp;</p>\r\n\r\n<p>ตั้งจ่ายจากเงินรายได้&nbsp; (ปรากฏในแผนงานบริหารงานทั่ว งานบริหารงานคลัง)</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 2.1.3&nbsp; ประเภทเงินช่วยเหลือการศึกษาบุตร (310500)&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; จำนวน&nbsp; 30,000.-&nbsp; บาท&nbsp;</p>\r\n\r\n<p style=\"margin-left:36.0pt\">เพื่อจ่ายเป็นเงินช่วยเหลือการศึกษาบุตรแก่พนักงานเทศบาลและลูกจ้างประจำ</p>\r\n\r\n<p>&nbsp;ตั้งจ่ายจากเงินรายได้&nbsp; (ปรากฏในแผนงานบริหารงานทั่วไป&nbsp; งานบริหารงานคลัง)</p>\r\n\r\n<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</p>\r\n\r\n<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <strong>2.2&nbsp; หมวดค่าใช้สอย&nbsp; (532000)&nbsp; จำนวน&nbsp; 250,000.- &nbsp;บาท</strong></p>\r\n\r\n<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 2.2.1&nbsp; ประเภทรายจ่ายเพื่อให้ได้มาซึ่งบริการ&nbsp; (320100)&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; จำนวน &nbsp;&nbsp;150,000.- บาท</p>\r\n\r\n<p style=\"margin-left:36.0pt\">&nbsp;เพื่อจ่ายเป็น</p>\r\n\r\n<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; -&nbsp; ค่าเย็บหนังสือ&nbsp; เข้าปกหนังสือและเทศบัญญัติต่าง ๆ</p>\r\n\r\n<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; -&nbsp; ค่าธรรมเนียม&nbsp; และค่าลงทะเบียนต่าง ๆ</p>\r\n\r\n<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; -&nbsp; ค่าจัดทำป้ายโฆษณาประชาสัมพันธ์</p>\r\n\r\n<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; -&nbsp; ค่าจ้างเหมาบริการ&nbsp; เช่น&nbsp; ค่าจ้างเหมาแบกหามสัมภาระ,&nbsp; ค่าถ่ายเอกสาร&nbsp; ฯลฯ</p>\r\n\r\n<p>&nbsp;ตั้งจ่ายจากเงินรายได้&nbsp; (ปรากฏในแผนงานบริหารงานทั่วไป&nbsp; งานบริหารงานคลัง)</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 2.2.2&nbsp; ประเภทรายจ่ายเกี่ยวเนื่องกับการปฏิบัติราชการที่ไม่เข้าลักษณะรายจ่ายหมวดอื่น &nbsp;(320300)&nbsp; จำนวน&nbsp;&nbsp; &nbsp;&nbsp;50,000.-&nbsp; บาท &nbsp;&nbsp;</p>\r\n\r\n<p style=\"margin-left:72.0pt\">เพื่อจ่ายเป็นค่าลงทะเบียน ใช้จ่ายในการเดินทางไปราชการในราชการอาณาจักรของพนักงานเทศบาล ลูกจ้างประจำ หรือพนักงานจ้างที่มีคำสั่งให้เดินทางไปราชการ&nbsp; สำหรับเป็นค่าเบี้ยเลี้ยง&nbsp; ค่าพาหนะ&nbsp; ค่าเช่าที่พัก&nbsp; ค่าใช้จ่ายอื่นที่จำเป็น&nbsp;</p>\r\n\r\n<p>ตั้งจ่ายจากเงินรายได้&nbsp; (ปรากฏในแผนงานบริหารงานทั่วไป&nbsp; งานบริหารงานคลัง)</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 2.2.3&nbsp; ประเภทค่าบำรุงรักษาและซ่อมแซม&nbsp; (320400)&nbsp; จำนวน &nbsp;&nbsp;&nbsp;50,000.-&nbsp; บาท</p>\r\n\r\n<p style=\"margin-left:72.0pt\">เพื่อจ่ายเป็นค่าบำรุงรักษาหรือซ่อมแซมครุภัณฑ์และทรัพย์สินอื่น ๆ เช่น&nbsp; เครื่องคอมพิวเตอร์&nbsp; เครื่องพิมพ์ดีด&nbsp; เครื่องโทรสาร ฯลฯ</p>\r\n\r\n<p>&nbsp;ตั้งจ่ายจากเงินรายได้&nbsp; (ปรากฏในแผนงานบริหารงานทั่วไป&nbsp; งานบริหารงานคลัง)</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p><strong>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 2.3&nbsp; หมวดค่าวัสดุ (533000)&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; จำนวน&nbsp;&nbsp; 180,000.-&nbsp; บาท&nbsp; </strong></p>\r\n\r\n<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 2.3.1&nbsp; ประเภท&nbsp; วัสดุสำนักงาน (330100)&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; จำนวน&nbsp; 80,000.-&nbsp; บาท</p>\r\n\r\n<p style=\"margin-left:72.0pt\">เพื่อจ่ายเป็นค่าจัดซื้อสิ่งของเครื่องใช้วัสดุสำนักงาน&nbsp; แบบพิมพ์ต่าง ๆ เช่น กระดาษ แฟ้ม ดินสอ ปากกา ใบเสร็จรับเงิน แบบพิมพ์ต่าง ๆ ฯลฯ&nbsp;</p>\r\n\r\n<p>ตั้งจ่ายจากเงินรายได้&nbsp; (ปรากฏในแผนงานบริหารงานทั่วไป&nbsp; งานบริหารงานคลัง)</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 2.3.2&nbsp; ประเภทวัสดุงานบ้านงานครัว (330300)&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; จำนวน&nbsp; 25,000.- บาท</p>\r\n\r\n<p style=\"margin-left:72.0pt\">เพื่อจ่ายเป็นค่าวัสดุงานบ้านงานครัว เช่น ไม้กวาด แปรง สบู่ ผงซักฟอก น้ำยาเช็ดกระจก ถ้วยชาม แก้วน้ำ ฯลฯ&nbsp;</p>\r\n\r\n<p>ตั้งจ่ายจากเงินรายได้&nbsp; (ปรากฏในแผนงานบริหารงานทั่วไป&nbsp; งานบริหารงานคลัง)</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 2.3.3&nbsp; ประเภทวัสดุยานพาหนะและขนส่ง (330700)&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; จำนวน&nbsp; 10,000.- &nbsp;บาท</p>\r\n\r\n<p style=\"margin-left:72.0pt\">เพื่อจ่ายเป็นค่าจัดซื้อวัสดุรถจักรยานยนต์&nbsp; เช่น ยางนอก ยางใน สายไมล์ แบตเตอรี่ หัวเทียนและวัสดุอื่น ๆ ที่จำเป็น ฯลฯ</p>\r\n\r\n<p>&nbsp;ตั้งจ่ายจากเงินอุดหนุนทั่วไป (ปรากฏในแผนงานเคหะและชุมชน งานบริหารงานคลัง)</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 2.3.4&nbsp; ประเภทวัสดุเชื้อเพลิงและหล่อลื่น (330800) &nbsp; &nbsp;จำนวน &nbsp;5,000.-&nbsp; บาท</p>\r\n\r\n<p style=\"margin-left:72.0pt\">เพื่อจ่ายเป็นค่าจัดซื้อวัสดุเชื้อเพลิงและหล่อลื่น&nbsp; เช่น&nbsp; น้ำมันเบนซิน&nbsp; น้ำมันแก๊สโซฮอล์&nbsp; น้ำมันเครื่อง&nbsp; สำหรับรถจักรยานยนต์&nbsp;</p>\r\n\r\n<p>ตั้งจ่ายจากเงินรายได้&nbsp; (ปรากฏในแผนงานบริหารงานทั่วไป&nbsp; งานบริหารงานคลัง)</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 2.3.5&nbsp; ประเภทวัสดุคอมพิวเตอร์&nbsp; (331400)&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; จำนวน&nbsp; 60,000.-&nbsp; บาท</p>\r\n\r\n<p style=\"margin-left:72.0pt\">เพื่อจ่ายเป็นค่าจัดซื้อวัสดุคอมพิวเตอร์ เช่น แผ่นดิสเกตต์ &nbsp;หมึกปริ้นเตอร์ โปรแกรมและอื่น ๆ ที่เกี่ยวข้องกับคอมพิวเตอร์</p>\r\n\r\n<p>ตั้งจ่ายจากเงินรายได้&nbsp; (ปรากฏในแผนงานบริหารงานทั่วไป&nbsp; งานบริหารงานคลัง)</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p><strong>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 2.4&nbsp; หมวดค่าสาธารณูปโภค&nbsp; (534000) &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; จำนวน&nbsp;&nbsp; 20,000.- &nbsp;บาท&nbsp; </strong></p>\r\n\r\n<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 2.4.1&nbsp; ประเภทค่าไปรษณีย์&nbsp; (340400)&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; จำนวน &nbsp;&nbsp;20,000.- &nbsp;&nbsp;บาท&nbsp; &nbsp;</p>\r\n\r\n<p style=\"margin-left:36.0pt\">เพื่อจ่ายเป็นค่าไปรษณีย์&nbsp; ค่าธนาณัติ&nbsp; ค่าจัดซื้อดวงตราไปรษณีย์ ค่าเช่าตู้ไปรษณีย์</p>\r\n\r\n<p>&nbsp;ตั้งจ่ายจากเงินรายได้&nbsp; (ปรากฏในแผนงานบริหารงานทั่วไป&nbsp; งานบริหารงานคลัง)</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p><strong>3.&nbsp; งบลงทุน &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;จำนวน&nbsp;&nbsp; 57,200.-&nbsp; บาท&nbsp; แยกเป็น&nbsp;&nbsp; </strong></p>\r\n\r\n<p><strong>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 3.1&nbsp; หมวดค่าครุภัณฑ์ (541000) &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;จำนวน&nbsp; &nbsp;&nbsp;57</strong><strong>,200.-&nbsp;&nbsp; &nbsp;บาท</strong></p>\r\n\r\n<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 3.1.1&nbsp; ประเภทครุภัณฑ์สำนักงาน (410100)&nbsp; จำนวน&nbsp; 57,200.- บาท&nbsp; มีรายละเอียดดังนี้</p>\r\n\r\n<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; (1)&nbsp; ค่าจัดซื้อตู้เอกสาร&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; จำนวน&nbsp; 11,600.- บาท</p>\r\n\r\n<p style=\"margin-left:36.0pt\">&nbsp;เพื่อจ่ายเป็นค่าจัดซื้อตู้เอกสารขนาด 2 บาน&nbsp; จำนวน&nbsp; 2&nbsp; ตู้ ๆ ละ 5,800.-&nbsp; บาท</p>\r\n\r\n<p>&nbsp;ตั้งจ่ายจากเงินอุดหนุนทั่วไป&nbsp; (ปรากฏในแผนงานบริหารงานทั่วไป งานบริหารงานคลัง)</p>\r\n\r\n<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>(2) ค่าจัดซื้อตู้เอกสาร &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; จำนวน&nbsp; 9,800.-&nbsp;&nbsp; บาท</p>\r\n\r\n<p style=\"margin-left:36.0pt\">เพื่อจ่ายเป็นค่าจัดซื้อตู้เอกสาร 1 บาน 4 ลิ้นชัก จำนวน&nbsp; 2 ตู้ ๆ ละ 4,900.-&nbsp; บาท</p>\r\n\r\n<p>ตั้งจ่ายจากเงินอุดหนุนทั่วไป (ปรากฏในแผนงานบริหารงานทั่วไป งานบริหารงานคลัง)</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>(3) ค่าจัดซื้อชั้นเก็บเอกสาร &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; จำนวน&nbsp;&nbsp; 7,800.-&nbsp; บาท</p>\r\n\r\n<p style=\"margin-left:36.0pt\">เพื่อจ่ายเป็นค่าจัดซื้อชั้นเก็บเอกสาร 20 ช่อง จำนวน&nbsp; 2&nbsp; หลัง ๆ ละ&nbsp; 3,900.-&nbsp; บาท</p>\r\n\r\n<p>&nbsp;ตั้งจ่ายจากเงินอุดหนุนทั่วไป (ปรากฏในแผนงานบริหารงานทั่วไป งานบริหารงานคลัง)</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; (4)&nbsp; ค่าจัดซื้อเครื่องปรับอากาศ&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; จำนวน &nbsp;&nbsp;28,000.-&nbsp; บาท&nbsp;</p>\r\n\r\n<p style=\"margin-left:72.0pt\">เพื่อจ่ายเป็นค่าจัดซื้อเครื่องปรับอากาศ ชนิดติดผนัง (มีระบบฟอกอากาศ) ขนาด 24,000&nbsp; บีทียู จำนวน 1&nbsp; เครื่อง ๆ ละ 28,000.-&nbsp; บาท&nbsp;</p>\r\n\r\n<p>ตั้งจ่ายจากเงินอุดหนุนทั่วไป&nbsp; (ปรากฏในแผนงานบริหารงานทั่วไป&nbsp; งานบริหารงานคลัง)</p>\r\n', NULL, NULL);
INSERT INTO `mhd_language_detail` (`id`, `language_id`, `ref_id`, `name`, `type`, `detail`, `detail_2`, `detail_3`) VALUES
(162, 1, 107, 'รายงานรายละเอียดงบประมาณรายจ่ายทั่วไป ประจำปีงบประมาณ  พ.ศ. 2559 แผนงานบริหารงานทั่วไป ', 1, '<p style=\"text-align: center;\">&nbsp;</p>\r\n\r\n<p style=\"text-align: center;\"><strong>รายงานรายละเอียดงบประมาณรายจ่ายทั่วไป </strong></p>\r\n\r\n<p style=\"text-align: center;\"><strong>ประจำปีงบประมาณ&nbsp; พ.ศ. </strong><strong>2559</strong></p>\r\n\r\n<p style=\"text-align: center;\"><strong>เทศบาลตำบลกุดนกเปล้า&nbsp; </strong></p>\r\n\r\n<p style=\"text-align: center;\"><strong>อำเภอเมืองสระบุรี&nbsp; จังหวัดสระบุรี</strong></p>\r\n\r\n<p style=\"text-align: center;\"><strong>ประมาณการรายจ่ายรวมทั้งสิ้น &nbsp;</strong><strong>38,000,000.-บาท จ่ายจากรายได้จัดเก็บเอง หมวดภาษีจัดสรร และหมวดเงินอุดหนุนทั่วไป แยกเป็น</strong></p>\r\n\r\n<p style=\"text-align: center;\"><strong>แผนงานบริหารงานทั่วไป (</strong><strong>00100)</strong></p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p><strong><u>งานบริหารงานทั่วไป</u></strong>&nbsp; <strong>(</strong><strong>00111)&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; รวมทั้งสิ้น 13,011,590.- บาท</strong></p>\r\n\r\n<p><strong>1.งบบุคลากร (520000)&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp; รวม&nbsp;&nbsp; &nbsp;&nbsp;8,402,390.-บาท</strong></p>\r\n\r\n<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <strong>1.1 หมวดเงินเดือนฝ่ายการเมือง&nbsp; (521000)&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; รวม&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp; 2,624,640.- บาท</strong></p>\r\n\r\n<p><strong>1.1.1 ประเภทเงินเดือนนายกเทศมนตรี/รองนายกเทศมนตรี&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; จำนวน&nbsp; &nbsp;&nbsp;&nbsp;&nbsp; 695,520.-บาท</strong></p>\r\n\r\n<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; เพื่อจ่ายเป็นเงินเดือนนายกเทศมนตรี รองนายกเทศมนตรี</p>\r\n\r\n<p>ดังนี้&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</p>\r\n\r\n<p>-เงินเดือนนายกเทศมนตรี ในอัตราเดือนละ &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 27,600.- บาท&nbsp;&nbsp;&nbsp;&nbsp;</p>\r\n\r\n<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; -เงินเดือนรองนายกเทศมนตรี 2 คน ในอัตราเดือนละ &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 15,180.- บาท</p>\r\n\r\n<p>ตั้งจ่ายจากเงินรายได้ (ปรากฏในแผนงานบริหารงานทั่วไป&nbsp; งานบริหารงานทั่วไป)</p>\r\n\r\n<p><strong>1.1.2 ประเภทเงินค่าตอบแทนประจำตำแหน่งนายกเทศมนตรี/รองนายกเทศมนตรี </strong></p>\r\n\r\n<p style=\"margin-left:288.0pt\"><strong>จำนวน </strong><strong>120,000.-บาท</strong></p>\r\n\r\n<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; เพื่อจ่ายเป็นเงินค่าตอบแทนประจำตำแหน่งนายกเทศมนตรี</p>\r\n\r\n<p>รองนายกเทศมนตรี ดังนี้</p>\r\n\r\n<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; -เงินค่าตอบแทนประจำตำแหน่งนายกเทศมนตรีในอัตราเดือนละ&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; 4,000.-บาท</p>\r\n\r\n<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; -เงินค่าตอบแทนพิเศษประจำตำแหน่งรองนายกเทศมนตรีในอัตราเดือนละ&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; 3,000.-บาท</p>\r\n\r\n<p>ตั้งจ่ายจากเงินรายได้ (ปรากฏในแผนงานบริหารงานทั่วไป&nbsp; งานบริหารงานทั่วไป)</p>\r\n\r\n<p><strong>1.1.3 ประเภทเงินค่าตอบแทนพิเศษนายกเทศมนตรี/รองนายกเทศมนตรี&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; จำนวน 120,000.-บาท</strong></p>\r\n\r\n<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; เพื่อจ่ายเป็นเงินค่าตอบแทนพิเศษของนายกเทศมนตรี</p>\r\n\r\n<p>รองนายกเทศมนตรี&nbsp; ดังนี้</p>\r\n\r\n<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; -เงินค่าตอบแทนพิเศษนายกเทศมนตรีในอัตราเดือนละ&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp; 4,000.-บาท</p>\r\n\r\n<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; -เงินค่าตอบแทนพิเศษรองนายกเทศมนตรีในอัตราเดือนละ&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp; 3,000.-บาท</p>\r\n\r\n<p>ตั้งจ่ายจากเงินรายได้ (ปรากฏในแผนงานบริหารงานทั่วไป&nbsp; งานบริหารงานทั่วไป)</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p><strong>1.1.4 ประเภทเงินค่าตอบแทนเลขานุการ/ที่ปรึกษานายกเทศมนตรี&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; จำนวน&nbsp;&nbsp; 198,720.-บาท</strong></p>\r\n\r\n<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; เพื่อจ่ายเป็นเงินค่าตอบแทนรายเดือนของเลขานุการและ</p>\r\n\r\n<p>ที่ปรึกษานายกเทศมนตรี&nbsp; ดังนี้</p>\r\n\r\n<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; -เงินค่าตอบแทนเลขานุการนายกเทศมนตรีในอัตราเดือนละ&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 9,660.-&nbsp; บาท</p>\r\n\r\n<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; -เงินค่าตอบแทนที่ปรึกษานายกเทศมนตรีในอัตราเดือนละ&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 6,900.-&nbsp; บาท</p>\r\n\r\n<p>ตั้งจ่ายจากเงินรายได้ (ปรากฏในแผนงานบริหารงานทั่วไป&nbsp; งานบริหารงานทั่วไป)</p>\r\n\r\n<p><strong>1.1.5 ประเภทเงินค่าตอบแทนสมาชิกสภาองค์กรปกครองส่วนท้องถิ่น จำนวน&nbsp; 1,490,400.-บาท</strong></p>\r\n\r\n<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; เพื่อจ่ายเป็นเงินค่าตอบแทนรายเดือนสำหรับประธานสภา</p>\r\n\r\n<p>เทศบาล รองประธานสภาเทศบาล สมาชิกสภาเทศบาล&nbsp; ดังนี้</p>\r\n\r\n<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; -เงินค่าตอบแทนประธานสภาเทศบาลในอัตราเดือนละ&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 15,180.-บาท</p>\r\n\r\n<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; -เงินค่าตอบแทนรองประธานสภาเทศบาลในอัตราเดือนละ&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 12,420.-บาท</p>\r\n\r\n<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; -เงินค่าตอบแทนสมาชิกสภาเทศบาลในอัตราเดือนละ&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 9,660.-บาท</p>\r\n\r\n<p>ตั้งจ่ายจากเงินรายได้ (ปรากฏในแผนงานบริหารงานทั่วไป&nbsp; งานบริหารงานทั่วไป)</p>\r\n\r\n<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <strong>1.2 หมวดเงินเดือนฝ่ายประจำ (522000)&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; รวม&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 5,777,750.-บาท</strong></p>\r\n\r\n<p><strong>1.2.1 ประเภทเงินเดือนพนักงาน (220100)&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; จำนวน&nbsp; 3,148,070.-บาท</strong></p>\r\n\r\n<p style=\"margin-left:36.0pt\">เพื่อจ่ายเป็นเงินเดือนให้พนักงานเทศบาลสามัญ จำนวน 11 อัตราพร้อมทั้งเงินปรับปรุงเงินเดือนประจำปี ตามตำแหน่งและอัตราที่ก.ท.กำหนดโดยคำนวณตั้งจ่ายไว้ไม่เกิน 12 เดือน</p>\r\n\r\n<p>ตั้งจ่ายจากเงินรายได้ (ปรากฏในแผนงานบริหารงานทั่วไป&nbsp; งานบริหารงานทั่วไป)</p>\r\n\r\n<p><strong>1.2.2 ประเภทเงินเพิ่มต่างๆของพนักงาน (220200)&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; จำนวน&nbsp;&nbsp;&nbsp; 88,500.-บาท</strong></p>\r\n\r\n<p style=\"margin-left:36.0pt\">เพื่อจ่ายเป็นเงินเพิ่มค่าครองชีพชั่วคราวของพนักงานเทศบาล ตามระเบียบกระทรวงการคลังว่าด้วยการเบิกจ่ายเงินเพิ่มค่าครองชีพชั่วคราวของข้าราชการและลูกจ้างประจำส่วนราชการเพื่อจ่ายเป็นค่าตอบแทนรายเดือนของปลัดเทศบาล ระดับ 8 และเพื่อจ่ายเป็นค่าตอบแทนพิเศษของพนักงานเทศบาล ผู้ได้รับเงินเดือนถึงขั้นสูงของอันดับตำแหน่งเพื่อจ่ายเป็นเงินค่าการกำหนดอัตราเงินเดือนและจำนวนเงินที่ปรับเพิ่มสำหรับคุณวุฒิที่ ก.พ.หรือคณะกรรมการกลางพนักงานเทศบาลรับรองว่าคุณสมบัตินั้นเป็นคุณสมบัติเฉพาะตำแหน่งที่ได้รับแต่งตั้งและเงินเพิ่มต่างๆของพนักงานเทศบาล</p>\r\n\r\n<p>ตั้งจ่ายจากเงินรายได้ (ปรากฏในแผนงานบริหารงานทั่วไป&nbsp; งานบริหารงานทั่วไป)</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p><strong>1.2.3 ประเภทเงินประจำตำแหน่ง (220300)&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; จำนวน&nbsp;&nbsp;&nbsp;&nbsp; 186,000.-บาท</strong></p>\r\n\r\n<p style=\"margin-left:36.0pt\">เพื่อจ่ายเป็นเงินประจำตำแหน่งประเภทบริหาร ประเภทวิชาชีพเฉพาะ และเชี่ยวชาญเฉพาะ</p>\r\n\r\n<p style=\"margin-left:36.0pt\">ให้กับพนักงานเทศบาลตามบัญชีอัตราเงินประจำตำแหน่งของพนักงานส่วนท้องถิ่นโดยคำนวณ</p>\r\n\r\n<p style=\"margin-left:36.0pt\">ตั้งจ่ายไว้ไม่เกิน 12 เดือน</p>\r\n\r\n<p>ตั้งจ่ายจากเงินรายได้ (ปรากฏในแผนงานบริหารงานทั่วไป&nbsp; งานบริหารงานทั่วไป)</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p><strong>1.2.4 ประเภทค่าจ้างลูกจ้างประจำ (220500)&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; จำนวน&nbsp;&nbsp;&nbsp; 150,720.-บาท</strong></p>\r\n\r\n<p style=\"margin-left:36.0pt\">เพื่อจ่ายเป็นค่าจ้างประจำให้แก่ลูกจ้างประจำ จำนวน 1 อัตรา พร้อมเงินปรับปรุงค่าจ้างประจำ</p>\r\n\r\n<p style=\"margin-left:36.0pt\">ตามตำแหน่งและอัตราที่ ก.ท. กำหนดโดยคำนวณตั้งจ่ายไว้ไม่เกิน 12 เดือน</p>\r\n\r\n<p>ตั้งจ่ายจากเงินรายได้ (ปรากฏในแผนงานบริหารงานทั่วไป&nbsp; งานบริหารงานทั่วไป)</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p><strong>1.2.5 ประเภทเงินเพิ่มต่างๆของลูกจ้างประจำ&nbsp; (220600)&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; จำนวน &nbsp;&nbsp;&nbsp;8,700.-บาท</strong></p>\r\n\r\n<p style=\"margin-left:36.0pt\">เพื่อจ่ายเป็นเงินเพิ่มการครองชีพชั่วคราวให้แก่ลูกจ้างประจำ ตามระเบียบกระทรวงการคลัง</p>\r\n\r\n<p style=\"margin-left:36.0pt\">ว่าด้วยการเบิกจ่ายเงินเพิ่มการครองชีพของข้าราชการและลูกจ้างประจำส่วนราชการ (ฉบับที่ 5)</p>\r\n\r\n<p style=\"margin-left:36.0pt\">พ.ศ.2555 ถือปฏิบัติโดยอนุโลมตามหนังสือ ด่วนที่สุด ที่ มท.0809.3/ว 1259</p>\r\n\r\n<p style=\"margin-left:36.0pt\">ลงวันที่ 14 พฤษภาคม 2555</p>\r\n\r\n<p>ตั้งจ่ายจากเงินรายได้ (ปรากฏในแผนงานบริหารงานทั่วไป&nbsp; งานบริหารงานทั่วไป)</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p><strong>1.2.6 ประเภทค่าตอบแทนพนักงานจ้าง (220700)&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;จำนวน&nbsp; 1,843,760.-บาท</strong></p>\r\n\r\n<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; เพื่อจ่ายเป็นค่าตอบแทนให้แก่พนักงานจ้าง จำนวน 15 อัตรา ตามอัตราที่กำหนด โดยคำนวณ</p>\r\n\r\n<p>ตั้งจ่ายไว้ไม่เกิน 12 เดือน</p>\r\n\r\n<p>ตั้งจ่ายจากเงินรายได้ (ปรากฏในแผนงานบริหารงานทั่วไป&nbsp; งานบริหารงานทั่วไป)</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p><strong>1.2.7 ประเภทเงินเพิ่มต่างๆของพนักงานจ้าง&nbsp; (220800)&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; จำนวน&nbsp;&nbsp; 352,000.-บาท</strong></p>\r\n\r\n<p style=\"margin-left:36.0pt\">เพื่อจ่ายเป็นเงินเพิ่มค่าครองชีพชั่วคราวให้แก่พนักงานจ้าง จำนวน 15 อัตราตามระเบียกระทรวง</p>\r\n\r\n<p style=\"margin-left:36.0pt\">การคลังว่าด้วยการเบิกจ่ายเงินเพิ่มการครองชีพชั่วคราวของข้าราชการและลูกจ้างประจำส่วน</p>\r\n\r\n<p style=\"margin-left:36.0pt\">ราชการ (ฉบับที่ 5) พ.ศ.2555 ถือปฏิบัติโดยอนุโลมตามหนังสือด่วนที่สุด ที่ มท. 0809.3/ว 1259</p>\r\n\r\n<p style=\"margin-left:36.0pt\">ลงวันที่ 14 พฤษภาคม 2555</p>\r\n\r\n<p>&nbsp;ตั้งจ่ายจากเงินรายได้ (ปรากฏในแผนงานบริหารงานทั่วไป&nbsp; งานบริหารงานทั่วไป)</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p><strong>2. งบดำเนินการ (530000)&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; รวม 4,175,600.-บาท</strong></p>\r\n\r\n<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <strong>2.1 หมวดค่าตอบแทน (531000)&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; รวม&nbsp;&nbsp;&nbsp;&nbsp; 585,600.-บาท</strong></p>\r\n\r\n<p><strong>2.1.1 ประเภทค่าตอบแทนผู้ปฏิบัติราชการอันเป็นประโยชน์แก่องค์กรปกครอง </strong></p>\r\n\r\n<p><strong>ส่วนท้องถิ่นอื่น (310100)&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; จำนวน </strong><strong>180,000.-บาท</strong></p>\r\n\r\n<ol>\r\n	<li><strong>ค่าตอบแทนผู้ปฏิบัติราชการอันเป็นประโยชน์แก่องค์กรฯ&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; จำนวน&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </strong><strong>150,000.-บาท</strong></li>\r\n</ol>\r\n\r\n<p style=\"margin-left:36.0pt\">เพื่อจ่ายเป็นเงินตอบแทนอื่นเป็นกรณีพิเศษ (เงินรางวัลประจำปี,เงินโบนัส) สำหรับพนักงานส่วนท้องถิ่นของเทศบาล</p>\r\n\r\n<p>ตั้งจ่ายจากเงินรายได้(ปรากฏในแผนงานบริหารงานทั่วไป&nbsp; งานบริหารงานทั่วไป)</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p><strong>2.&nbsp; ค่าตอบแทน อปพร.&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp; จำนวน 30,000.-บาท</strong></p>\r\n\r\n<p style=\"margin-left:36.0pt\">เพื่อจ่ายเป็นค่าตอบแทนสำหรับ อปพร.ในเขตตำบลกุดนกเปล้า และงานอื่นๆที่ได้รับคำสั่งมอบหมายให้แก่ อปพร.ตำบลกุดนกเปล้า</p>\r\n\r\n<p>ตั้งจ่ายจากเงินอุดหนุนทั่วไป (ปรากฏในแผนงานบริหารงานทั่วไป&nbsp; งานบริหารงานทั่วไป)</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p><strong>2.1.2 ประเภทค่าเบี้ยประชุม (310200)&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp; จำนวน&nbsp; 50,000.-บาท</strong></p>\r\n\r\n<p style=\"margin-left:36.0pt\">เพื่อจ่ายเป็นค่าเบี้ยประชุม คณะกรรมการที่สภาเทศบาล ผู้บริหารแต่งตั้งขึ้น หรือคณะกรรมการ</p>\r\n\r\n<p style=\"margin-left:36.0pt\">ที่ได้รับการแต่งตั้งตามกฏหมาย</p>\r\n\r\n<p>ตั้งจ่ายจากเงินอุดหนุนทั่วไป (ปรากฏในแผนงานบริหารงานทั่วไป งานบริหารงานทั่วไป)</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p><strong>2.1.3 ประเภทค่าตอบแทนการปฏิบัติงานนอกเวลาราชการ (310300)&nbsp;&nbsp; &nbsp;&nbsp; จำนวน&nbsp;&nbsp; 50,000.-บาท</strong></p>\r\n\r\n<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; เพื่อจ่ายเป็นเงินค่าตอบแทนการปฏิบัติงานนอกเวลาราชการ ให้แก่ พนักงานส่วนตำบล,พนักงาน</p>\r\n\r\n<p>จ้างตามภารกิจและพนักงานจ้างทั่วไปที่มาปฏิบัติงานนอกเวลาราชการ ซึ่งเป็นงานเร่งด่วนนอก</p>\r\n\r\n<p>เวลาราชการปกติหรืองานที่ไม่อาจทำในเวลาราชการ ฯลฯ</p>\r\n\r\n<p>ตั้งจ่ายจากเงินรายได้ (ปรากฏในแผนงานบริหารงานทั่วไป งานบริหารงานทั่วไป)</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p><strong>2.1.4 ประเภทค่าเช่าบ้าน&nbsp; (310400)&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;จำนวน&nbsp;&nbsp; 225,600.-บาท</strong></p>\r\n\r\n<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; เพื่อจ่ายเป็นค่าเช่าบ้านให้แก่พนักงานเทศบาลที่มีสิทธิเบิกค่าเช่าบ้าน จำนวน 8 อัตรา</p>\r\n\r\n<p>ได้ตามระเบียบฯ</p>\r\n\r\n<p>ตั้งจ่ายจากเงินรายได้ (ปรากฏในแผนงานบริหารงานทั่วไป งานบริหารงานทั่วไป)</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p><strong>2.1.5 ประเภทเงินช่วยเหลือการศึกษาบุตร&nbsp; (310500)&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp; จำนวน &nbsp;80,000.-บาท</strong></p>\r\n\r\n<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; เพื่อจ่ายเป็นเงินช่วยเหลือการศึกษาบุตรให้แก่ผู้บริหาร,พนักงานเทศบาลและลูกจ้าง ซึ่งมีสิทธิเบิก</p>\r\n\r\n<p>ค่าช่วยเหลือการศึกษาบุตรได้ตามระเบียบฯ</p>\r\n\r\n<p>&nbsp;ตั้งจ่ายจากเงินรายได้ (ปรากฏในแผนงานบริหารงานทั่วไป&nbsp; งานบริหารงานทั่วไป)</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p><strong>2.2 หมวดค่าใช้สอย&nbsp; (532000)&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; รวม &nbsp;2,155,000.-บาท</strong></p>\r\n\r\n<p><strong>2.2.1 ประเภทรายจ่ายเพื่อให้ได้มาซึ่งบริการ&nbsp; (320100)&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; จำนวน 400,000.-บาท</strong></p>\r\n\r\n<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; เพื่อจ่ายเป็น&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; -ค่าเย็บหนังสือหรือเข้าปกหนังสือ</p>\r\n\r\n<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; -ค่าซักฟอก</p>\r\n\r\n<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; -ค่าธรรมเนียม และค่าลงทะเบียนต่างๆ</p>\r\n\r\n<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; -ค่าโฆษณาและเผยแพร่</p>\r\n\r\n<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; -ค่าล้างฟิล์ม อัดขยายรูป และค่าถ่ายพิมพ์เขียวแบบแปลน</p>\r\n\r\n<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; ,ค่าถ่ายเอกสาร</p>\r\n\r\n<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; -ค่าจ้างเหมาบริการให้ผู้รับจ้างทำการอย่างใดอย่างหนึ่ง</p>\r\n\r\n<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; ซึ่งมิใช่เป็นการประกอบดัดแปลง ต่อเติมครุภัณฑ์หรือ</p>\r\n\r\n<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; สิ่งก่อสร้างฯลฯ</p>\r\n\r\n<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; -ค่าจ้างเหมาจัดทำเว็บไวซ์ตำบลกุดนกเปล้า ฯลฯ</p>\r\n\r\n<p>&nbsp;ตั้งจ่ายจากเงินรายได้ จำนวน 200,000.-บาท และตั้งจ่ายจากเงินอุดหนุน จำนวน 200,000.-บาท</p>\r\n\r\n<p>&nbsp;(ปรากฏในแผนงานบริหารงานทั่วไป&nbsp; งานบริหารงานทั่วไป)</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p><strong>2.2.2 ประเภทรายจ่ายเกี่ยวกับการรับรองและพิธีการ&nbsp; (320200)&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; จำนวน&nbsp; 140,000.-บาท</strong></p>\r\n\r\n<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <strong>1.ค่ารับรอง&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; จำนวน&nbsp; &nbsp; 50,000.-บาท</strong></p>\r\n\r\n<p style=\"margin-left:36.0pt\"><strong>-</strong>เพื่อจ่ายเป็นค่ารับรองในการต้อนรับบุคคลหรือคณะบุคคล เช่น ค่าอาหาร,ค่าเครื่องดื่ม,ค่าของขวัญ,ค่าพิมพ์เอกสารค่าใช้จ่ายที่เกี่ยวเนื่องในการเลี้ยงรับรองรวมทั้งค่าบริการด้วย และค่าใช้จ่ายอื่น ซึ่งจำเป็นต้องจ่ายที่เกี่ยวกับการรับรองในการต้อนรับบุคคลหรือคณะบุคคล&nbsp; ที่ไปนิเทศงาน ตรวจงานหรือเยี่ยมงาน หรือทัศนศึกษาดูงานและเจ้าหน้าที่ ที่เกี่ยวข้อง ซึ่งร่วมต้อนรับบุคคลหรือคณะบุคคล</p>\r\n\r\n<p style=\"margin-left:36.0pt\">-เพื่อจ่ายเป็นค่าเลี้ยงรับรองในการประชุมต่างๆ เช่นในการประชุมสภาท้องถิ่นคณะกรรมการหรืออนุกรรมการและผู้เข้าร่วมประชุมในกิจการต่างๆ ของเทศบาล รวมทั้งเป็นค่าอาหาร ค่าเครื่องดื่ม ค่าดอกไม้ ค่าธูปเทียน และอื่นๆที่เกี่ยวข้อง ฯลฯ</p>\r\n\r\n<p>ตั้งจ่ายจากเงินรายได้ (ปรากฏในแผนงานบริหารงานทั่วไป&nbsp; งานบริหารงานทั่วไป)</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p><strong>2. ค่าใช้จ่ายทางพิธีทางศาสนา และงานพิธีการต่างๆ&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; จำนวน&nbsp; 50,000.-บาท</strong></p>\r\n\r\n<p style=\"margin-left:36.0pt\">-เพื่อจ่ายเป็นค่าใช้จ่ายในงานรัฐพิธีและงานพิธีการต่างๆ หรือกิจกรรมที่เกิดขึ้นเป็นกรณีพิเศษ เช่น งานรับเสด็จ งานเฉลิมฉลองงานรัฐพิธี งานต้อนรับแขกเมือง งานพิธีการทางศาสนา เช่นการจัดซื้อเครื่องราชสักการะ เครื่องทองน้อย กระถางธูปเชิงเทียนแจกัน ดอกไม้ พานพุ่ม เครื่องไทยธรรม เครื่องกัณฑ์เทศน์ ผ้าแพรธงชาติ ป้ายตราสัญลักษณ์ต่างๆ พระบรมฉายาลักษณ์ พวงมาลา</p>\r\n\r\n<p>วัสดุอุปกรณ์ที่เกี่ยวเนื่องในการจัดงานต่างๆ ฯลฯ</p>\r\n\r\n<p>ตั้งจ่ายจากเงินอุดหนุนทั่วไป&nbsp; (ปรากฏในแผนงานบริหารงานทั่วไป&nbsp; งานบริหารงานทั่วไป)</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <strong>3.ค่าโฆษณาและเผยแพร่ &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; จำนวน&nbsp; 40,000.-บาท</strong></p>\r\n\r\n<p style=\"margin-left:36.0pt\">-เพื่อจ่ายเป็นค่าจ้างเหมาโฆษณาและเผยแพร่ กิจกรรมของเทศบาล ทางวิทยุ หนังสือพิมพ์ และสื่ออื่นๆ ค่าจ้างเหมาจัดทำป้ายประชาสัมพันธ์ โปสเตอร์ แผ่นพับ แผ่น CD จัดทำป้ายนิเทศเพื่อเผยแพร่ประชาสัมพันธ์ ข้อมูลข่าวสารทางราชการ จัดทำตู้รับเรื่องราวร้องทุกข์ ร้องเรียนประจำหมู่บ้าน ฯลฯ</p>\r\n\r\n<p>ตั้งจ่ายจากเงินอุดหนุนทั่วไป (ปรากฏในแผนงานบริหารงานทั่วไป&nbsp; งานบริหารงานทั่วไป)</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p><strong>2.2.3 ประเภทรายจ่ายเกี่ยวเนื่องกับการปฏิบัติราชการที่ไม่เข้า&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; จำนวน&nbsp; 1,315,000.-บาท</strong></p>\r\n\r\n<p><strong>ลักษณะรายจ่ายหมวดอื่น (</strong><strong>320300)&nbsp; เพื่อจ่ายเป็น</strong></p>\r\n\r\n<ol>\r\n	<li><strong>ค่าใช้จ่ายในการดำเนินการเลือกตั้ง&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; จำนวน&nbsp;&nbsp; &nbsp;&nbsp;</strong><strong>500,000.-บาท</strong></li>\r\n</ol>\r\n\r\n<p style=\"margin-left:36.0pt\">เพื่อจ่ายเป็นค่าใช้จ่ายในการดำเนินการเลือกตั้งสมาชิกสภาท้องถิ่นหรือผู้บริหารท้องถิ่น เช่น ค่าตอบแทนคณะกรรมการประจำหน่วยเลือกตั้ง ค่าจ้างเหมาบริการ ค่าใช้จ่ายในการอบรบคณะกรรมการประจำหน่วยเลือกตั้ง ค่าวัสดุอุปกรณ์ แบบพิมพ์ที่ใช้ในการเลือกตั้ง ฯลฯ</p>\r\n\r\n<p>ตั้งจ่ายจากเงินอุดหนุนทั่วไป &nbsp;(ปรากฏในแผนงานบริหารงานทั่วไป&nbsp; งานบริหารงานทั่วไป)</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<ol>\r\n	<li><strong>ค่าใช้จ่ายในการฝึกอบรมและสัมมนา ค่าใช้จ่ายในการเดินทางไปราชการในราชอาณาจักรและนอกราชอาณาจักร&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; จำนวน&nbsp;&nbsp; </strong><strong>200,000.-บาท</strong></li>\r\n</ol>\r\n\r\n<p style=\"margin-left:36.0pt\">เพื่อจ่ายเป็นค่าลงทะเบียน ค่าเบี้ยเลี้ยงเดินทาง ค่าพาหนะ และค่าเช่าที่พักระหว่างเดินทางในประเทศและต่างประเทศ ฯลฯ ให้แก่คณะผู้บริหาร สมาชิกสภาเทศบาล พนักงานเทศบาล ลูกจ้างและพนักงานจ้าง ที่มีความจำเป็นต้องเดินทางไปติดต่อราชการหรือมีการโอนย้ายหรือเข้ารับการอบรมสัมมนา หรือสอบคัดเลือก และมีสิทธิตามระเบียบที่ทางราชการกำหนด</p>\r\n\r\n<p>&nbsp;ตั้งจ่ายจากเงินอุดหนุนทั่วไป (ปรากฏในแผนงานบริหารงานทั่วไป&nbsp; งานบริหารงานทั่วไป)</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<ol>\r\n	<li><strong>ค่าพวงมาลา ช่อดอกไม้ กระเช้าดอกไม้และพวงมาลา&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; จำนวน</strong><strong>&nbsp;&nbsp; 10,000.-บาท</strong></li>\r\n</ol>\r\n\r\n<p style=\"margin-left:36.0pt\">เพื่อจ่ายเป็นค่าพวงมาลา ช่อดอกไม้ กระเช้าดอกไม้และพวงมาลา เพื่อใช้ในงานพิธีต่างๆ หรืองานกิจกรรมต่างๆ ของเทศบาลฯลฯ</p>\r\n\r\n<p>&nbsp;ตั้งจ่ายจากเงินรายได้ (ปรากฏในแผนงานบริหารงานทั่วไป&nbsp; งานบริหารงานทั่วไป)</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<ol>\r\n	<li><strong>ค่าสินไหมทดแทน</strong><strong>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; จำนวน&nbsp;&nbsp; 50,000.-บาท</strong></li>\r\n</ol>\r\n\r\n<p style=\"margin-left:36.0pt\">เพื่อจ่ายเป็นค่าสินไหมทดแทน กรณีเมื่อรถของเทศบาลก่อให้เกิดความเสียหาย ตาม พรบ.คุ้มครองผู้ประสบภัยจากรถ พ.ศ. 2535 หรือเกิดอุบัติเหตุทางเทศบาล ฯลฯ</p>\r\n\r\n<p>ตั้งจ่ายจากเงินอุดหนุนทั่วไป (ปรากฏในแผนงานบริหารงานทั่วไป&nbsp; งานบริหารงานทั่วไป)</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<ol>\r\n	<li><strong>ค่าช่วยเหลือพนักงาน</strong><strong>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; จำนวน&nbsp;&nbsp;&nbsp;&nbsp; 30,000.-บาท</strong></li>\r\n</ol>\r\n\r\n<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; เพื่อจ่ายเป็นเงินช่วยเหลือพนักงานเทศบาลหรือลูกจ้างที่ต้องหาคดีอาญา</p>\r\n\r\n<p>ตั้งจ่ายจากเงินอุดหนุนทั่วไป (ปรากฏในแผนงานบริหารงานทั่วไป&nbsp; งานบริหารงานทั่วไป)</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<ol>\r\n	<li><strong>โครงการอบรมสัมมนาและทัศนศึกษาดูงาน&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; จำนวน&nbsp;&nbsp;&nbsp; </strong><strong>200,000.- บาท&nbsp; </strong></li>\r\n</ol>\r\n\r\n<p style=\"margin-left:36.0pt\">เพื่อจ่ายเป็นค่าใช้จ่ายในการอบรมสัมมนาและทัศนศึกษาดูงานทั้งในและต่างประเทศ&nbsp; ด้านการพัฒนาและเพิ่มประสิทธิภาพในการปฏิบัติงานให้แก่คณะผู้บริหาร สมาชิกสภาเทศบาล ข้าราชการ พนักงานเทศบาล&nbsp;</p>\r\n\r\n<p>ตั้งจ่ายจากเงินอุดหนุนทั่วไป&nbsp; (ปรากฏในแผนงานบริหารงานทั่วไป&nbsp; งานบริหารงานทั่วไป)</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<ol>\r\n	<li><strong>โครงการเทศบาลเคลื่อนที่&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; จำนวน&nbsp; </strong><strong>&nbsp;50,000.- บาท&nbsp; </strong></li>\r\n</ol>\r\n\r\n<p style=\"margin-left:36.0pt\">เพื่อจ่ายเป็นค่าใช้จ่ายในการออกหน่วยเทศบาลเคลื่อนที่ ค่าอาหาร&nbsp; ค่าเครื่องดื่ม&nbsp; สำหรับเจ้าหน้าที่&nbsp; ค่าเต็นท์&nbsp; ค่าเช่าเครื่องขยายเสียง ค่าตอบแทน ผู้ร่วมโครงการจากหน่วยงานอื่นและค่าใช้จ่ายที่จำเป็น&nbsp;</p>\r\n\r\n<p>ตั้งจ่ายจากเงินอุดหนุนทั่วไป&nbsp; (ปรากฏในแผนงานบริหารงานทั่วไป งานบริหารงานทั่วไป)</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<ol>\r\n	<li><strong>โครงการฝึกอบรมบุคลากรของเทศบาลตำบล&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; จำนวน</strong>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <strong>50,000.-บาท&nbsp; </strong></li>\r\n</ol>\r\n\r\n<p><strong>กุดนกเปล้าด้านคุณธรรมจริยธรรม</strong>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</p>\r\n\r\n<p>เพื่อจ่ายค่าดำเนินโครงการฝึกอบรมบุคลากรของเทศบาลตำบลกุดนกเปล้าด้านคุณธรรมจริยธรรม&nbsp;&nbsp;</p>\r\n\r\n<p>ตั้งจ่ายจากเงินอุดหนุนทั่วไป ( ปรากฏในแผนงานบริหารงานทั่วไป งานบริหารงานทั่วไป )</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<ol>\r\n	<li><strong>&nbsp;โครงการจัดงานวันเฉลิมพระชนมพรรษาฯ&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;จำนวน&nbsp;&nbsp;&nbsp;&nbsp; </strong><strong>200,000.-บาท</strong></li>\r\n</ol>\r\n\r\n<p style=\"margin-left:36.0pt\">เพื่อจ่ายเป็นค่าดำเนินการโครงการจัดงานวันเฉลิมพระชนมพรรษาพระบาทสมเด็จพระเจ้าอยู่หัว,พระนางเจ้าสิริกิติ์ พระบรมราชินีนาถและสมเด็จพระเทพรัตนราชสุดาฯ สยามบรมราชกุมารี &nbsp;&nbsp;&nbsp;&nbsp;</p>\r\n\r\n<p>&nbsp;ตั้งจ่ายจากเงินรายได้ จำนวน 100,000.-บาท และตั้งจ่ายจากเงินอุดหนุน จำนวน 100,000.-บาท</p>\r\n\r\n<p>&nbsp;(ปรากฏในแผนงานบริหารงานทั่วไป&nbsp; งานบริหารงานทั่วไป)</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p><strong>(</strong><strong>10) โครงการเพิ่มประสิทธิภาพศูนย์รวมข้อมูลข่าวสารการ&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; จำนวน&nbsp;&nbsp; 25,000.-บาท</strong></p>\r\n\r\n<p><strong>ซื้อหรือการจ้างขององค์กรปกครองส่วนท้องถิ่น&nbsp; ประจำปี </strong><strong>2559 อำเภอเมืองสระบุรี&nbsp; จังหวัดสระบุรี&nbsp; </strong></p>\r\n\r\n<p style=\"margin-left:36.0pt\">เพื่อจ่ายเป็นค่าโครงการเพิ่มประสิทธิภาพศูนย์รวมข้อมูลข่าวสารการซื้อหรือการจ้างขององค์กรปกครองส่วนท้องถิ่น&nbsp;&nbsp;&nbsp; ประจำปี 2559 &nbsp;อำเภอเมืองสระบุรี&nbsp; จังหวัดสระบุรี&nbsp;</p>\r\n\r\n<p>ตั้งจ่ายจากเงินอุดหนุนทั่วไป (ปรากฏในแผนงานบริหารงานทั่วไป งานบริหารงานทั่วไป)&nbsp;&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p><strong>2.2.4 ประเภทค่าบำรุงและรักษาซ่อมแซม&nbsp;&nbsp;&nbsp; (320400)&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; จำนวน&nbsp; 300,000.- บาท </strong></p>\r\n\r\n<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; เพื่อจ่ายเป็น</p>\r\n\r\n<p style=\"margin-left:36.0pt\">- ค่าบำรุงรักษาซ่อมแซมครุภัณฑ์ เช่น รถยนต์สำนักงาน ,รถดับเพลิง,รถจักยานยนต์ ,เครื่องตัดหญ้า,เลื่อยโซ่ยนต์, เครื่องพิมพ์ดีด ,เครื่องอัดสำเนา , เครื่องปรับอากาศ , ตู้, โต๊ะ , เครื่องถ่ายเอกสาร , เครื่องคอมพิวเตอร์พร้อมอุปกรณ์ส่วนคอมต่าง ๆ &nbsp;&nbsp;และครุภัณฑ์ต่างๆ&nbsp;&nbsp; ฯ ล ฯ</p>\r\n\r\n<p>- ค่าบำรุงรักษาหรือซ่อมแซมทรัพย์สินอื่นๆเช่น อาคารสำนักงาน</p>\r\n\r\n<p>ตั้งจ่ายจากเงินรายได้ จำนวน 150,000.-บาท และตั้งจ่ายจากเงินอุดหนุน จำนวน 150,000.-บาท</p>\r\n\r\n<p>&nbsp;(ปรากฏในแผนงานบริหารงานทั่วไป&nbsp; งานบริหารงานทั่วไป)</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p><strong>2.3 หมวดค่าวัสดุ&nbsp; (533000)&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; รวม&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 945</strong><strong>,</strong><strong>000.-</strong><strong>บาท</strong></p>\r\n\r\n<p><strong>2.3.1 ประเภทค่าวัสดุสำนักงาน&nbsp; (330100)&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; จำนวน&nbsp; 115,000.-บาท&nbsp; </strong></p>\r\n\r\n<p style=\"margin-left:36.0pt\">เพื่อจ่ายเป็นค่าจัดซื้อสิ่งของเครื่องใช้ของสำนักงาน เครื่องเขียน แบบพิมพ์ต่าง ๆ และวัสดุสำนักงานอื่น ๆ เช่น โต๊ะต่างๆ เก้าอี้ต่างๆ ตู้ต่างๆ กระดาษ ดินสอ ตรายาง ทะเบียนหนังสือรับ &ndash; ส่ง &nbsp;</p>\r\n\r\n<p style=\"margin-left:36.0pt\">หมึกโรเนียว ค่าน้ำดื่ม แผ่นป้ายจราจร ฯลฯ</p>\r\n\r\n<p>&nbsp;ตั้งจ่ายจากเงินรายได้ จำนวน 65,000.-บาท และตั้งจ่ายจากเงินอุดหนุน จำนวน 50,000.-บาท</p>\r\n\r\n<p>&nbsp;(ปรากฏในแผนงานบริหารงานทั่วไป&nbsp; งานบริหารงานทั่วไป)</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p><strong>2.3.2 ประเภทค่าวัสดุงานบ้านงานครัว&nbsp; (330300)&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; จำนวน&nbsp; 100,000.-บาท&nbsp; </strong></p>\r\n\r\n<p style=\"margin-left:36.0pt\">เพื่อจ่ายเป็นค่าวัสดุงานบ้านงานครัว&nbsp; เช่น ไม้กวาด, แปรง&nbsp; ,สบู่ ,ผงซักฟอก,น้ำยาล้างห้องน้ำ , น้ำยาถูพื้น , น้ำยาเช็ดกระจก ,ถ้วยชาม , แก้วน้ำจานรอง,กระติกน้ำร้อน,กระติกน้ำแข็ง ฯลฯ&nbsp;</p>\r\n\r\n<p>ตั้งจ่ายจากเงินรายได้ จำนวน 50,000.-บาท และตั้งจ่ายจากเงินอุดหนุน จำนวน 50,000.-บาท</p>\r\n\r\n<p>&nbsp;(ปรากฏในแผนงานบริหารงานทั่วไป&nbsp; งานบริหารงานทั่วไป)</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p><strong>2.3.3 ประเภทวัสดุก่อสร้าง (330600)&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; จำนวน&nbsp; 50,000&nbsp; .-บาท </strong></p>\r\n\r\n<p style=\"margin-left:36.0pt\">เพื่อจ่ายเป็นค่าวัสดุก่อสร้าง&nbsp; เช่น&nbsp; อิฐ&nbsp;&nbsp;&nbsp; ทราย&nbsp; ปูนซีเมนต์&nbsp;&nbsp; ท่อน้ำประปา&nbsp; จอบ&nbsp; เสียม&nbsp; ค้อน&nbsp; คีม และ อุปกรณ์ไฟฟ้า&nbsp;&nbsp; ฯลฯ</p>\r\n\r\n<p>&nbsp;ตั้งจ่ายจากเงินอุดหนุนทั่วไป ( ปรากฏในแผนงานบริหารงานทั่วไป&nbsp; งานบริหารงานทั่วไป)</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p><strong>2.3.4 ประเภทวัสดุยานพาหนะและขนส่ง&nbsp;&nbsp; (330700)&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; จำนวน&nbsp;&nbsp; 100,000.-&nbsp; บาท </strong></p>\r\n\r\n<p style=\"margin-left:36.0pt\">เพื่อจ่ายเป็นค่าวัสดุยานพาหนะและขนส่ง&nbsp; เช่น&nbsp; ยางนอกรถยนต์แบตเตอรี่&nbsp; สายไมล์&nbsp; ตลับลูกปืน&nbsp; ห้องเครื่อง&nbsp;&nbsp; หม้อน้ำ&nbsp; น้ำมันเบรก และรายจ่ายอื่นๆ ฯลฯ</p>\r\n\r\n<p>ตั้งจ่ายจากเงินรายได้ จำนวน 50,000.-บาท และตั้งจ่ายจากเงินอุดหนุน จำนวน 50,000.-บาท</p>\r\n\r\n<p>&nbsp;(ปรากฏในแผนงานบริหารงานทั่วไป&nbsp; งานบริหารงานทั่วไป)</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p><strong>2.3.5 ประเภทวัสดุเชื้อเพลิงและหล่อลื่น&nbsp;&nbsp; (330800)&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;จำนวน 200,000.-บาท </strong></p>\r\n\r\n<p style=\"margin-left:36.0pt\">เพื่อจ่ายเป็นค่าน้ำมันเชื้อเพลิง เช่น น้ำมันดีเซลน้ำมันเบนซิน น้ำมันเครื่อง &nbsp;&nbsp;สำหรับรถยนต์ &nbsp;รถจักรยานยนต์ เครื่องตัดหญ้าจารบี แก๊สหุงต้ม น้ำมันก๊าดฯลฯ&nbsp;&nbsp;&nbsp;</p>\r\n\r\n<p>ตั้งจ่ายจากเงินรายได้ จำนวน 100,000.-บาท และตั้งจ่ายจากเงินอุดหนุน จำนวน 100,000.-บาท</p>\r\n\r\n<p>&nbsp;(ปรากฏในแผนงานบริหารงานทั่วไป&nbsp; งานบริหารงานทั่วไป)</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p><strong>2.3.6 ประเภทวัสดุวิทยาศาสตร์และการแพทย์ (330900)&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; จำนวน&nbsp; 50,000&nbsp; .-บาท </strong></p>\r\n\r\n<p style=\"margin-left:36.0pt\">เพื่อจ่ายเป็นค่าวัสดุวิทยาศาสตร์และการแพทย์&nbsp; เช่น&nbsp; ถังดับเพลิง&nbsp; น้ำยาเคมี ดับเพลิง&nbsp;&nbsp; น้ำยาตรวจหาสารเสพติดในปัสสาวะ เปลหามคนไข้ และอื่นๆ&nbsp; ฯลฯ</p>\r\n\r\n<p>&nbsp;ตั้งจ่ายจากเงินอุดหนุนทั่วไป (ปรากฏในแผนงานบริหารงานทั่วไป งานบริหารงานทั่วไป)</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p><strong>2.3.7 ประเภทวัสดุการเกษตร (331000)&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; จำนวน&nbsp; 50,000&nbsp; .-&nbsp; บาท </strong></p>\r\n\r\n<p style=\"margin-left:36.0pt\">เพื่อจ่ายเป็นค่าวัสดุการเกษตร&nbsp; เช่น&nbsp;&nbsp; ยาฆ่าหญ้า , ปุ๋ยเคมี&nbsp; ,จอบ , เสียม , พันธ์ไม้ ,&nbsp; ไม้ดอกไม้เศรษฐกิจ พันธ์พืช&nbsp; / สัตว์อาหารสัตว์และอื่นๆ ผ้าใบ พลาสติก&nbsp; ที่จำเป็นฯลฯ&nbsp;</p>\r\n\r\n<p>ตั้งจ่ายจากเงินอุดหนุนทั่วไป (ปรากฏในแผนงานบริหารงานทั่วไป งานบริหารงานทั่วไป)</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p><strong>2.3.8 ป', NULL, NULL),
(163, 1, 108, 'แผนการดำเนินงาน ประจำปีงบประมาณ พ.ศ.2560', 1, '<p style=\"text-align:center\"><img alt=\"\" src=\"http://www.kudnokplao.go.th/kudnokplao/assets/images/Document-page-001%20.jpg\" style=\"height:508px; width:718px\" /></p>\r\n\r\n<p style=\"text-align:center\"><img alt=\"\" src=\"http://www.kudnokplao.go.th/kudnokplao/assets/images/Document-page-002%20.jpg\" style=\"height:508px; width:718px\" /></p>\r\n\r\n<p style=\"text-align:center\"><img alt=\"\" src=\"http://www.kudnokplao.go.th/kudnokplao/assets/images/Document-page-003%20.jpg\" style=\"height:508px; width:718px\" /></p>\r\n\r\n<p style=\"text-align:center\"><img alt=\"\" src=\"http://www.kudnokplao.go.th/kudnokplao/assets/images/Document-page-004%20.jpg\" style=\"height:508px; width:718px\" /></p>\r\n\r\n<p style=\"text-align:center\"><img alt=\"\" src=\"http://www.kudnokplao.go.th/kudnokplao/assets/images/Document-page-005%20.jpg\" style=\"height:508px; width:718px\" /></p>\r\n\r\n<p style=\"text-align:center\"><img alt=\"\" src=\"http://www.kudnokplao.go.th/kudnokplao/assets/images/Document-page-006%20.jpg\" style=\"height:508px; width:718px\" /></p>\r\n\r\n<p style=\"text-align:center\"><img alt=\"\" src=\"http://www.kudnokplao.go.th/kudnokplao/assets/images/Document-page-007%20.jpg\" style=\"height:508px; width:718px\" /></p>\r\n\r\n<p style=\"text-align:center\"><img alt=\"\" src=\"http://www.kudnokplao.go.th/kudnokplao/assets/images/Document-page-008%20.jpg\" style=\"height:508px; width:718px\" /></p>\r\n\r\n<p style=\"text-align:center\"><img alt=\"\" src=\"http://www.kudnokplao.go.th/kudnokplao/assets/images/Document-page-009%20.jpg\" style=\"height:508px; width:718px\" /></p>\r\n\r\n<p style=\"text-align:center\"><img alt=\"\" src=\"http://www.kudnokplao.go.th/kudnokplao/assets/images/Document-page-010%20.jpg\" style=\"height:508px; width:718px\" /></p>\r\n\r\n<p style=\"text-align:center\"><img alt=\"\" src=\"http://www.kudnokplao.go.th/kudnokplao/assets/images/Document-page-011%20.jpg\" style=\"height:508px; width:718px\" /></p>\r\n\r\n<p style=\"text-align:center\"><img alt=\"\" src=\"http://www.kudnokplao.go.th/kudnokplao/assets/images/Document-page-012%20.jpg\" style=\"height:508px; width:718px\" /></p>\r\n\r\n<p style=\"text-align:center\"><img alt=\"\" src=\"http://www.kudnokplao.go.th/kudnokplao/assets/images/Document-page-013%20.jpg\" style=\"height:508px; width:718px\" /></p>\r\n\r\n<p style=\"text-align:center\"><img alt=\"\" src=\"http://www.kudnokplao.go.th/kudnokplao/assets/images/Document-page-014%20.jpg\" style=\"height:508px; width:718px\" /></p>\r\n\r\n<p style=\"text-align:center\"><img alt=\"\" src=\"http://www.kudnokplao.go.th/kudnokplao/assets/images/Document-page-015.jpg\" style=\"height:508px; width:718px\" /></p>\r\n\r\n<p style=\"text-align:center\"><img alt=\"\" src=\"http://www.kudnokplao.go.th/kudnokplao/assets/images/Document-page-016.jpg\" style=\"height:508px; width:718px\" /></p>\r\n\r\n<p style=\"text-align:center\"><img alt=\"\" src=\"http://www.kudnokplao.go.th/kudnokplao/assets/images/Document-page-017.jpg\" style=\"height:508px; width:718px\" /></p>\r\n\r\n<p style=\"text-align:center\"><img alt=\"\" src=\"http://www.kudnokplao.go.th/kudnokplao/assets/images/Document-page-018.jpg\" style=\"height:508px; width:718px\" /></p>\r\n\r\n', NULL, NULL);
INSERT INTO `mhd_language_detail` (`id`, `language_id`, `ref_id`, `name`, `type`, `detail`, `detail_2`, `detail_3`) VALUES
(164, 1, 109, 'แผนงานงบกลาง  (00410)', 1, '<p style=\"text-align: center;\"><strong>แผนงานงบกลาง</strong><strong>&nbsp; (00410)</strong></p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p><strong><u>งานงบกลาง</u></strong><strong>&nbsp;&nbsp;&nbsp;&nbsp; (00411)&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; รวมทั้งสิ้น&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 3,906,226.-บาท</strong></p>\r\n\r\n<p><strong>1.รายจ่ายงบกลาง (510000)&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; รวมทั้งสิ้น&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 3,906,266.-บาท</strong></p>\r\n\r\n<p><strong>1.1 ประเภทค่าชำระหนี้เงินต้นและดอกเบี้ย&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; รวม&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;2,358,400.-บาท</strong></p>\r\n\r\n<p><strong>แยกเป็น </strong></p>\r\n\r\n<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <strong>1. ประเภทค่าชำระหนี้เงินต้น (110100)&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; จำนวน&nbsp; &nbsp;&nbsp; 1,358,400.-บาท</strong></p>\r\n\r\n<p>เพื่อจ่ายชำระหนี้เงินต้นให้กับสำนักงานกองทุนพัฒนาเมืองในภูมิภาคธนาคารออมสิน&nbsp; เงินกู้เพื่อใช้ในการก่อสร้างอาคารสำนักงานเทศบาลตำบลกุดนกเปล้า ตั้งจ่ายตามสัญญาเลขที่&nbsp; 20&nbsp; / 2552&nbsp; ลงวันที่&nbsp; 19&nbsp; เดือนตุลาคม&nbsp; พ.ศ.2553&nbsp; จำนวนเงินกู้&nbsp; 16,980,000&nbsp; บาท</p>\r\n\r\n<p>ตั้งจ่ายจากเงินรายได้ จำนวน 679,200.-บาท และตั้งจ่ายจากเงินอุดหนุนทั่วไป จำนวน 679,200.-บาท (ปรากฏในแผนงานงบกลาง&nbsp; งานงบกลาง)</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <strong>2.ประเภทค่าชำระดอกเบี้ย (</strong><strong>110200)&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; จำนวน&nbsp; &nbsp;&nbsp;&nbsp;&nbsp; 1,000,000.-บาท</strong></p>\r\n\r\n<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; เพื่อจ่ายชำระหนี้ดอกเบี้ยให้กับสำนักงานกองทุนพัฒนาเมืองในภูมิภาคธนาคารออมสิน&nbsp; เงินกู้เพื่อใช้ในการก่อสร้างอาคารสำนักงานเทศบาลตำบลกุดนกเปล้า&nbsp; ตั้งจ่ายตามสัญญาเลขที่&nbsp; 20&nbsp; / 2552 ลงวันที่&nbsp; 19&nbsp; เดือนตุลาคม&nbsp; พ.ศ.&nbsp; 2553&nbsp; จำนวนเงินกู้&nbsp; 16,980,000&nbsp; บาท ตามสัญญาโดยการชำระดอกเบี้ยงวดแรกจะชำระภายในทุกวันที่ครบกำหนด&nbsp; 6&nbsp; เดือน&nbsp; นับตั้งแต่วันเบิกเงินกู้งวดแรก&nbsp; และงวดต่อๆไปจะชำระภายในวันที่ครบกำหนด&nbsp; 6&nbsp; เดือน นับตั้งแต่วันเบิกเงินกู้งวดแรก&nbsp; และงวดต่อๆไป&nbsp; เช่นนี้ตลอดไปจนกว่าจะชำระหนี้เสร็จสิ้น&nbsp;</p>\r\n\r\n<p>ตั้งจ่ายจากเงินรายได้ จำนวน 500,000.-บาท และตั้งจ่ายจากเงินอุดหนุนทั่วไป จำนวน 500,000.-บาท (ปรากฏในแผนงานงบกลาง&nbsp; งานงบกลาง)</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p><strong>1.2 เงินสมทบกองทุนประกันสังคม (110300) จำนวน&nbsp; &nbsp;255,286.- บาท&nbsp; </strong></p>\r\n\r\n<p>เพื่อจ่ายเป็นค่าสมทบเงินประกันสังคมและจ่ายค่าเบี้ยยังชีพประกันสังคมแทนพนักงานจ้างตามประกาศคณะกรรมการกลางพนักงานเทศบาล เรื่องมาตรฐานทั่วไปเกี่ยวกับพนักงานจ้าง หมวด 5 ข้อ 33&nbsp; ให้พนักงานได้รับสิทธิประโยชน์และมีหน้าที่ต้องปฏิบัติตามกฎหมายว่าด้วยการประกันสังคมเว้นแต่ค่าเบี้ยประกันสังคมให้เทศบาลเป็นผู้ชำระแทนพนักงาน</p>\r\n\r\n<p>&nbsp;ตั้งจ่ายจากเงินรายได้&nbsp; (ปรากฏในแผนงานงบกลาง งานงบกลาง)</p>\r\n\r\n<p style=\"margin-left:72.0pt\"><strong>วิธีคำนวณ</strong></p>\r\n\r\n<p style=\"margin-left:72.0pt\">ค่าตอบแทนพนักงานจ้างประจำปี&nbsp; 2559&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; = 4,505,720&nbsp;&nbsp;&nbsp;&nbsp; บาท</p>\r\n\r\n<p style=\"margin-left:72.0pt\">จ่ายค่าสมทบประกันสังคมและจ่ายแทนพนักงานจ้างในอัตรา&nbsp; 5 %</p>\r\n\r\n<p style=\"margin-left:72.0pt\">ของค่าตอบแทน พนักงานจ้างทั้งหมด&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; =&nbsp;&nbsp; 255,286&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; บาท</p>\r\n\r\n<p style=\"margin-left:72.0pt\">( ขอตั้งงบประมาณ.&nbsp;&nbsp; 255,286&nbsp; บาท )</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p><strong>1.3 เงินสำรองจ่าย&nbsp; (111000 )&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; จำนวน&nbsp;&nbsp; 240,000.-&nbsp; บาท</strong></p>\r\n\r\n<p>เพื่อจ่ายเป็นค่าใช้จ่ายในกรณีไม่สามารถคาดการณ์ได้ล่วงหน้าและจำเป็นตามความเหมาะสม&nbsp; โดยอนุมัติของคณะผู้บริหาร ตามระเบียบกระทรวงมหาดไทยว่าด้วยวิธีงบประมาณขององค์กรปกครองส่วนท้องถิ่น&nbsp; พ.ศ. 2541&nbsp; ข้อ &nbsp;19 ตั้งจ่ายจากเงินรายได้&nbsp; (ปรากฏในแผนงานงบกลาง งานงบกลาง)</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p><strong>1.4 ประเภทรายจ่ายตามข้อผูกพัน (111100)&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; รวม&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;562,540.-บาท</strong></p>\r\n\r\n<p><strong>แยกเป็น</strong></p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p><strong>1.เงินสมทบกองทุนหลักประกันสุขภาพในระดับท้องถิ่น&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; จำนวน &nbsp;&nbsp;500,000.-บาท</strong></p>\r\n\r\n<p><strong>หรือพื้นที่เทศบาลตำบลกุดนกเปล้า </strong>&nbsp;</p>\r\n\r\n<p>&nbsp;เพื่อจ่ายเป็นเงินสมทบกองทุนหลักประกันสุขภาพในระดับท้องถิ่นหรือพื้นที่เทศบาลตำบล&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; กุดนกเปล้าตามหลักเกณฑ์การสมทบเงินเข้ากองทุน&nbsp; คือ เทศบาลต้องสมทบไม่น้อยกว่า&nbsp; ร้อยละ 50&nbsp; ของเงินสมทบจากสำนักงานหลักประกันสุขภาพแห่งชาติ&nbsp; ตั้งจ่ายจากเงินอุดหนุนทั่วไป (ปรากฏในแผนงานงบกลาง งานงบกลาง)</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p><strong>2.เงินสมทบสมาคมสันนิบาตเทศบาลแห่งประเทศไทย (ส.ท.ท ) &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; จำนวน&nbsp; &nbsp;32,540.-&nbsp; บาท</strong></p>\r\n\r\n<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;เพื่อจ่ายเป็นค่าบำรุงสมาคมสันนิบาตเทศบาลเทศบาลแห่งประเทศไทย (ส.ท.ท.)&nbsp;&nbsp; ตามข้อบังคับสันนิบาตแห่งประเทศไทย&nbsp; โดยคำนวณตั้งจ่ายในอัตราร้อยละ 1/6 ของรายรับจริงในปีงบประมาณที่ผ่านมาทั้งนี้ไม่รวมเงินกู้&nbsp; เงินจ่ายขาดเงินสะสม&nbsp; เงินอุดหนุนทั่วไป&nbsp; และเงินอุดหนุนจากรัฐบาล&nbsp; ตามหนังสือสมาคมสันนิบาตเทศบาลแห่งประเทศไทย&nbsp; ที่ 100/2545&nbsp; ลงวันที่ 22&nbsp; กุมภาพันธ์&nbsp; 2545&nbsp;&nbsp; ตั้งจ่ายจากเงินอุดหนุนทั่วไป&nbsp; (ปรากฎในแผนงานงบกลาง งานงบกลาง)</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p><strong>3. ค่าใช้จ่ายเบี้ยยังชีพผู้ป่วยเอดส์&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; จำนวน&nbsp; &nbsp;30,000.-&nbsp; บาท </strong></p>\r\n\r\n<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; เพื่อจ่ายเป็นเงินเบี้ยยังชีพผู้ป่วยเอดส์&nbsp; ตำบลกุดนกเปล้า&nbsp; อำเภอเมืองสระบุรี&nbsp; จังหวัดสระบุรี&nbsp;&nbsp; จำนวน&nbsp; 5&nbsp; คนๆละ 500&nbsp; บาท/เดือน&nbsp; ตั้งจ่ายจากเงินอุดหนุนทั่วไป&nbsp; (ปรากฏในแผนงานงบกลาง งานงบกลาง)</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p><strong>1.5 ประเภทเงินช่วยพิเศษ (111200)&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;รวม&nbsp;&nbsp; 30,000.-บาท</strong></p>\r\n\r\n<p><strong>แยกเป็น</strong></p>\r\n\r\n<p style=\"margin-left:36.0pt\"><strong>1.เงินเพิ่มพิเศษให้แก่พนักงานเทศบาลและลูกจ้างเทศบาล&nbsp; &nbsp;&nbsp; จำนวน 10,000.-&nbsp; บาท</strong></p>\r\n\r\n<p style=\"margin-left:36.0pt\">&nbsp;เพื่อจ่ายเป็นเงินเพิ่มพิเศษให้แก่พนักงานเทศบาลและลูกจ้าง ที่ถึงแก่ความตายในระหว่างรับราชการ<strong>&nbsp; ตั้งจ่ายจากเงินอุดหนุนทั่วไป&nbsp; (ปรากฏในแผนงานงบกลาง&nbsp; งานงบกลาง)</strong></p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p><strong>2.เงินทำขวัญพนักงานเทศบาลและลูกจ้างเทศบาล&nbsp; &nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; จำนวน&nbsp; 20,000.-บาท </strong></p>\r\n\r\n<p>เพื่อจ่ายเป็นเงินทำขวัญให้แก่พนักงานเทศบาลและลูกจ้าง&nbsp; ซึ่งได้รับอันตรายหรือเจ็บป่วยเพราะเหตุปฏิบัติราชการ&nbsp; ตั้งจ่ายจากเงินอุดหนุนทั่วไป&nbsp; (ปรากฏในแผนงานงบกลาง&nbsp; งานงบกลาง)</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p><strong>1.6 เงินสมทบกองทุนบำเหน็จบำนาญข้าราชการ&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; จำนวน 460,000.-บาท</strong></p>\r\n\r\n<p><strong>ส่วนท้องถิ่น&nbsp; ( กบท ) (</strong><strong>120100) </strong>&nbsp;&nbsp;&nbsp;</p>\r\n\r\n<p>ตั้งจ่ายเป็นเงินสมทบกองทุนบำเหน็จบำนาญข้าราชการส่วนท้องถิ่น&nbsp; (กบท ในอัตราร้อยละ 2 %&nbsp;</p>\r\n\r\n<p>ของรายได้ที่ไม่รวมเงินอุดหนุนทุกประเภท&nbsp; ตั้งจ่ายจากเงินอุดหนุนทั่วไป&nbsp; (ปรากฏในแผนงานงบกลาง&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;งานงบกลาง)</p>\r\n\r\n<p style=\"margin-left:72.0pt\"><strong>วิธีคำนวณ</strong></p>\r\n\r\n<p style=\"margin-left:36.0pt\">รายรับปี&nbsp;&nbsp; พ.ศ.&nbsp;&nbsp; 2559 ตั้งรับไว้รวม&nbsp; =&nbsp; 38,000,000&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; บาท</p>\r\n\r\n<p style=\"margin-left:36.0pt\">หักเงินอุดหนุนทั่วไป&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; =&nbsp; 15,000,000&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; บาท</p>\r\n\r\n<p style=\"margin-left:36.0pt\">คงเหลือรายรับไม่รวมเงินอุดหนุน &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; =&nbsp; 23,000,000&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; บาท</p>\r\n\r\n<p style=\"margin-left:36.0pt\">คิดเป็นเงินสมทบ&nbsp; ก.บ.ท&nbsp; ดังนี้&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; x2%&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; =&nbsp;&nbsp; 460,000&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; บาท</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&hellip;&hellip;&hellip;&hellip;&hellip;&hellip;&hellip;&hellip;&hellip;&hellip;&hellip;&hellip;&hellip;&hellip;&hellip;&hellip;&hellip;&hellip;&hellip;&hellip;&hellip;&hellip;&hellip;&hellip;&hellip;.</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n', NULL, NULL),
(165, 1, 110, 'ส่วนที่ 1 คำแถลงประกอบงบประมาณรายจ่าย ประจำปีงบประมาณ พ.ศ. 2559', 1, '<p><img alt=\"\" src=\"http://www.kudnokplao.go.th/kudnokplao/assets/images/Document-page-1.jpg\" style=\"height:973px; width:688px\" /></p>\r\n<p><img alt=\"\" src=\"http://www.kudnokplao.go.th/kudnokplao/assets/images/Document-page-2.jpg\" style=\"height:973px; width:688px\" /></p>\r\n<p><img alt=\"\" src=\"http://www.kudnokplao.go.th/kudnokplao/assets/images/Document-page-3.jpg\" style=\"height:973px; width:688px\" /></p>\r\n<p><img alt=\"\" src=\"http://www.kudnokplao.go.th/kudnokplao/assets/images/Document-page-4.jpg\" style=\"height:973px; width:688px\" /></p>\r\n<p><img alt=\"\" src=\"http://www.kudnokplao.go.th/kudnokplao/assets/images/Document-page-5.jpg\" style=\"height:973px; width:688px\" /></p>\r\n\r\n', NULL, NULL),
(166, 1, 111, 'แผนพัฒนาสามปี (พ.ศ. 2560 – 2562)', 1, '<h2 style=\"text-align: center;\">ส่วนที่ 1 &nbsp;<br />\r\nบทนำ</h2>\r\n\r\n<p>พระราชบัญญัติกำหนดแผนและขั้นตอนการกระจายอำนาจให้แก่องค์กรปกครองส่วนท้องถิ่น พ.ศ. 2542 ได้กำหนดหน้าที่ขององค์กรปกครองส่วนท้องถิ่นในการให้บริการสาธารณะที่จำเป็นแก่ท้องถิ่น ตลอดจนรายได้ของท้องถิ่นที่เพิ่มขึ้น ทำให้องค์กรปกครองส่วนท้องถิ่นต้องใช้ทรัพยากร และรายได้ของตนเองให้เกิดประโยชน์สูงสุดเพื่อตอบสนองความต้องการของประชาชนอย่างทั่วถึง ประกอบกับระเบียบกระทรวงมหาดไทย ว่าด้วยการจัดทำแผนพัฒนาขององค์กรปกครองส่วนท้องถิ่น พ.ศ. 2548 ได้กำหนดประเภทของแผนพัฒนาไว้ 3 ประเภท คือ &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; แผนยุทธศาสตร์การพัฒนา แผนพัฒนาสามปี และแผนดำเนินงาน&nbsp;<br />\r\nแผนพัฒนาสามปี เป็นแผนพัฒนาเศรษฐกิจและสังคมที่องค์กรปกครองส่วนท้องถิ่นกำหนดยุทธศาสตร์ขึ้นใช้เป็นแนวทางในการพัฒนา มีวัตถุประสงค์ เป้าหมาย ประกอบกับกิจกรรม / โครงการ ที่จะดำเนินการในระยะเวลา 3 ปี (พ.ศ. 2560 &ndash; 2562) &nbsp;รวมทั้งมีหน่วยงานผู้รับผิดชอบ แผนพัฒนาสามปีจึงเป็นแผนพัฒนาเทศบาลที่สอดคล้องกับแผนยุทธศาสตร์การพัฒนาขององค์กรปกครองส่วนท้องถิ่น เทศบาลตำบลกุดนกเปล้าจึงได้จัดทำแผนพัฒนาสามปีขึ้น เพื่อใช้เป็นแผนพัฒนาตำบล นำกิจกรรมไปสู่การปฏิบัติในพื้นที่ให้สอดคล้องกับศักยภาพของพื้นที่ ปัญหาและความต้องการของประชาชน อันจะนำไปสู่การจัดทำงบประมาณรายจ่ายประจำปีต่อไป<br />\r\n1.1&nbsp;&nbsp; &nbsp;<u>ลักษณะของแผนสามปี&nbsp;</u><br />\r\n&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;แผนสามปีเป็นการแปลงยุทธศาสตร์การพัฒนาไปสู่การปฏิบัติ โดยมีหลักคิดที่ว่า ภายใต้ยุทธศาสตร์การพัฒนาหนึ่งๆ &nbsp;จะมีแนวทางการพัฒนาได้มากกว่าหนึ่งแนวทาง &nbsp;และภายใต้แนวทางหนึ่งการพัฒนาหนึ่ง จะมีโครงการ/กิจกรรมได้มากกว่าหนึ่งโครงการ/กิจกรรมที่จะต้องนำมาดำเนินการเพื่อให้บรรลุตามวัตถุประสงค์และเป้าหมายที่ต้องการในแต่ละยุทธศาสตร์การพัฒนา &nbsp; &nbsp; ซึ่งจะมีผลต่อวัตถุประสงค์เป้าหมาย &nbsp;จุดมุ่งหมายการพัฒนาอย่างยั่งยืน และวิสัยทัศน์ในที่สุด&nbsp;<br />\r\n&nbsp; &nbsp; นอกจากนั้น &nbsp;แผนพัฒนาสามปี &nbsp;เป็นแผนที่มีความสัมพันธ์ใกล้ชิดกับงบประมาณรายจ่ายประจำปี กล่าวคือ องค์กรปกครองส่วนท้องถิ่น &nbsp;ใช้การวางแผนพัฒนาเป็นเครื่องมือในการจัดทำงบประมาณรายจ่ายประจำปี โดยนำโครงการ/กิจกรรมจากแผนพัฒนาสามปี ในปีที่จะจัดทำงบประมาณรายจ่ายประจำปี ไปจัดทำงบประมาณ &nbsp;เพื่อให้กระบวนการจัดทำงบประมาณเป็นไปด้วยความเรียบร้อย และผ่านกระบวนการการมีส่วนร่วมของประชาชน</p>\r\n\r\n<p><u>วัตถุประสงค์ของการจัดทำแผนพัฒนาสามปี</u><br />\r\n-&nbsp;&nbsp; &nbsp;เพื่อแสดงความสัมพันธ์เชื่อมโยงและสอดคล้องกันระหว่างแผนยุทธศาสตร์การพัฒนา และการจัดทำแผนพัฒนาอย่างมีประสิทธิภาพ<br />\r\n-&nbsp;&nbsp; &nbsp;เพื่อแสดงแนวทางการพัฒนาในช่วงสามปีที่มีความสอดคล้องและสามารถสนองตอบต่อยุทธศาสตร์การพัฒนาอย่างมีประสิทธิภาพ<br />\r\n-&nbsp;&nbsp; &nbsp;เป็นการเตรียมโครงการการพัฒนาต่าง ๆ ให้อยู่ในลักษณะที่พร้อมจะบรรจุในเอกสารงบประมาณประจำปี &nbsp;และนำไปปฏิบัติได้ทันทีเมื่อได้รับงบประมาณ<br />\r\n1.2&nbsp;&nbsp; &nbsp;<u>ขั้นตอนในการจัดทำแผนพัฒนาสามปี</u> &nbsp;แบ่งออกเป็น &nbsp;7 &nbsp;ขั้นตอน ดังนี้<br />\r\n ขั้นตอนที่ &nbsp;1 &nbsp;ขั้นเตรียมการจัดทำแผน &nbsp;<br />\r\n ขั้นตอนที่ &nbsp;2 &nbsp;การคัดเลือกยุทธศาสตร์และแนวทางการพัฒนา&nbsp;<br />\r\n ขั้นตอนที่ &nbsp;3 &nbsp;การเก็บรวบรวมข้อมูลและการวิเคราะห์ข้อมูล<br />\r\n ขั้นตอนที่ &nbsp;4 &nbsp;การกำหนดวัตถุประสงค์ของแนวทางการพัฒนา<br />\r\n ขั้นตอนที่ &nbsp;5 &nbsp;การจัดทำรายละเอียดโครงการ/กิจกรรมการพัฒนา<br />\r\n ขั้นตอนที่ &nbsp;6 &nbsp;การจัดทำร่างแผนพัฒนาสามปี<br />\r\n ขั้นตอนที่ &nbsp;7 &nbsp;การอนุมัติและประกาศใช้แผนพัฒนาสามปี<br />\r\n1.3&nbsp;&nbsp; <u>&nbsp;ประโยชน์ของการจัดทำแผนพัฒนาสามปี</u><br />\r\nการจัดทำแผนพัฒนาสามปี &nbsp; เป็นเครื่องมือที่จะช่วยให้องค์กรปกครองส่วนท้องถิ่น &nbsp; ได้พิจารณาอย่างรอบคอบให้เห็นถึงความเชื่อมโยงระหว่างแนวทางการดำเนินการต่าง ๆ ที่อาจมีความเชื่อมโยงและส่งผลทั้งในเชิงสนับสนุน และเป็นอุปสรรคต่อกัน เพื่อให้องค์กรปกครองส่วนท้องถิ่นนำมาตัดสินใจกำหนดแนวทางการดำเนินงาน และใช้ทรัพยากรการบริหารของท้องถิ่นอย่างมีประสิทธิภาพเพื่อให้เกิดประโยชน์สาธารณะสูงสุด &nbsp;</p>\r\n\r\n<p style=\"text-align: center;\"><br />\r\n-------------------------------------------------------</p>\r\n', NULL, NULL),
(167, 1, 112, 'รายงานกิจการสภาปี 2559', 1, '<p><a href=\"http://www.kudnokplao.go.th/upload/content/%E0%B8%9B%E0%B8%B52559.pdf\" target=\"_blank\">: รายงานกิจการสภาปี 2559</a></p>\r\n\r\n<p><a href=\"http://www.kudnokplao.go.th/upload/content/%E0%B9%81%E0%B8%9C%E0%B8%99%E0%B8%9E%E0%B8%B1%E0%B8%92%E0%B8%99%E0%B8%B2%E0%B8%AA%E0%B8%B2%E0%B8%A1%E0%B8%9B%E0%B8%B5-2560-2562.pdf\">แผนพัฒนาสามปี-2560-2562</a></p>\r\n', NULL, NULL),
(168, 1, 113, 'รายงานกิจการสภาปี2560', 1, '<p><a href=\"http://www.kudnokplao.go.th/upload/content/%E0%B8%A3%E0%B8%B2%E0%B8%A2%E0%B8%87%E0%B8%B2%E0%B8%99%E0%B8%81%E0%B8%B4%E0%B8%88%E0%B8%81%E0%B8%B2%E0%B8%A3%E0%B8%AA%E0%B8%A0%E0%B8%B2%E0%B8%9B%E0%B8%B52560.pdf\">รายงานกิจการสภาปี2560</a></p>\r\n', NULL, NULL),
(169, 1, 114, 'แผนพัฒนาสามปี  2559', 1, '<p><strong><a href=\"http://www.kudnokplao.go.th/upload/content/%E0%B8%9B%E0%B8%B52559.pdf\">แผนพัฒนาสามปี พ.ศ. 2560 &ndash; 2562</a></strong></p>\r\n\r\n<p><strong><a href=\"http://www.kudnokplao.go.th/upload/content/%E0%B9%81%E0%B8%9C%E0%B8%99%E0%B8%9E%E0%B8%B1%E0%B8%92%E0%B8%99%E0%B8%B2%E0%B8%AA%E0%B8%B2%E0%B8%A1%E0%B8%9B%E0%B8%B5-2560-2562.pdf\">แผนพัฒนาสามปี </a><a href=\"http://www.kudnokplao.go.th/upload/content/%E0%B8%9B%E0%B8%B52559.pdf\">&nbsp;พ.ศ.&nbsp;</a><a href=\"http://www.kudnokplao.go.th/upload/content/%E0%B9%81%E0%B8%9C%E0%B8%99%E0%B8%9E%E0%B8%B1%E0%B8%92%E0%B8%99%E0%B8%B2%E0%B8%AA%E0%B8%B2%E0%B8%A1%E0%B8%9B%E0%B8%B5-2560-2562.pdf\">2560-2562-2</a></strong></p>\r\n', NULL, NULL),
(170, 1, 115, 'เทศบัญญัติ', 1, '<p><strong><a href=\"http://www.kudnokplao.go.th/upload/content/%E0%B8%A3%E0%B8%B2%E0%B8%A2%E0%B8%87%E0%B8%B2%E0%B8%99%E0%B8%81%E0%B8%B4%E0%B8%88%E0%B8%81%E0%B8%B2%E0%B8%A3%E0%B8%AA%E0%B8%A0%E0%B8%B2%E0%B8%9B%E0%B8%B52560.pdf\">เทศบัญญัติ&nbsp;</a></strong></p>\r\n', NULL, NULL),
(171, 1, 116, 'ประกาศเทศบาลตำบลกุดนกเปล้า เรื่อง แผนการจัดหาพัสดุ (ผด.2) ประจำปีงบประมาณ 2559', 1, NULL, NULL, NULL),
(172, 1, 117, 'ประกาศเทศบาลตำบลกุดนกเปล้า เรื่อง แผนการจัดหาพัสดุ (ผด.2) ประจำปีงบประมาณ 2559', 1, '<p><img alt=\"\" src=\"http://website-thai.com/project/kudnokplao/upload/userfile/images/________________2559.jpeg\" style=\"height:1200px; width:906px\" /><img alt=\"\" src=\"http://website-thai.com/project/kudnokplao/upload/userfile/images/1.jpeg\" style=\"height:1200px; width:881px\" /></p>\r\n\r\n<p><img alt=\"\" src=\"http://website-thai.com/project/kudnokplao/upload/userfile/images/2.jpeg\" style=\"height:1200px; width:873px\" /><img alt=\"\" src=\"http://website-thai.com/project/kudnokplao/upload/userfile/images/3.jpeg\" style=\"height:1200px; width:871px\" /><img alt=\"\" src=\"http://website-thai.com/project/kudnokplao/upload/userfile/images/4.jpeg\" style=\"height:1200px; width:873px\" /><img alt=\"\" src=\"http://website-thai.com/project/kudnokplao/upload/userfile/images/5.jpeg\" style=\"height:1200px; width:873px\" /><img alt=\"\" src=\"http://website-thai.com/project/kudnokplao/upload/userfile/images/6.jpeg\" style=\"height:1200px; width:873px\" /></p>\r\n', NULL, NULL),
(173, 1, 118, 'ประกาศเทศบลตำบลกุดนกเปล้า เรื่อง รายงานทางการเงินงบแสดงฐานะการเงินและงบอื่้นๆ ประจำปีงบประมาณ 2559', 1, '<p><img alt=\"\" src=\"http://website-thai.com/project/kudnokplao/upload/userfile/images/รายงานทางการเงิน2559.jpeg\" style=\"height:1200px; width:873px\" /></p>\r\n', NULL, NULL),
(174, 1, 119, 'รายงานกิจการสภาปี 2558', 1, '<p><a href=\"http://www.kudnokplao.go.th/upload/content/New%20Microsoft%20Word%20Document.pdf\">รายงานกิจการสภาปี 2558</a></p>\r\n', NULL, NULL),
(175, 1, 56, 'แก้ไขหน้าหลัก', 0, NULL, NULL, NULL),
(176, 1, 120, '123', 1, NULL, NULL, NULL),
(177, 1, 57, 'แบนเนอร์', 0, NULL, NULL, NULL),
(178, 1, 121, 'แบนเนอร์', 1, '', NULL, NULL),
(179, 1, 58, 'โครงการ', 0, '', NULL, NULL),
(180, 1, 122, 'EQAI', 1, '<p>ou have to make your websites with love these days!</p>\r\n', NULL, NULL),
(181, 1, 123, 'EQAM', 1, '<p>his theme as is, or you can make changes!</p>\r\n', NULL, NULL),
(182, 1, 124, 'EQAC', 1, '<p>EQACEQACEQACEQACEQACEQAC</p>\r\n', NULL, NULL),
(183, 1, 125, 'EQAH', 1, '<p>EQAHEQAHEQAHEQAHEQAHEQAHEQAH</p>\r\n', NULL, NULL),
(184, 1, 126, 'EQAP', 1, '<p>EQAPEQAPEQAPEQAPEQAPEQAPEQAPEQAPEQAP</p>\r\n', NULL, NULL),
(185, 1, 127, 'EQAT', 1, '<p>EQATEQATEQATEQATEQATEQATEQATEQATEQAT</p>\r\n', NULL, NULL),
(186, 1, 59, 'ข่าวประชาสัมพันธ์', 0, '', NULL, NULL),
(187, 1, 128, 'ประชาสัมพันธ์1', 1, '', NULL, NULL),
(188, 1, 129, 'ประชาสัมพันธ์2', 1, '', NULL, NULL),
(189, 1, 60, 'EQAI', 0, '', NULL, NULL),
(190, 1, 61, 'EQAM', 0, '', NULL, NULL),
(191, 1, 62, 'EQAC', 0, '<p>EQACEQACEQACEQAC</p>\r\n', NULL, NULL),
(192, 1, 63, 'EQAH', 0, '<p>EQAHEQAHEQAH</p>\r\n', NULL, NULL),
(193, 1, 64, 'EQAP', 0, '<p>EQAPEQAPEQAP</p>\r\n', NULL, NULL),
(194, 1, 65, 'EQAT', 0, '<p>EQATEQATEQAT</p>\r\n', NULL, NULL),
(195, 1, 66, 'ประชาสัมพันธ์', 0, '', NULL, NULL),
(196, 1, 67, 'ประชาสัมพันธ์2', 0, '', NULL, NULL),
(197, 1, 68, 'ประชาสัมพันธ์3', 0, '', NULL, NULL),
(198, 1, 69, 'ประชาสัมพันธ์4', 0, '', NULL, NULL),
(199, 1, 70, 'ประชาสัมพันธ์', 0, '', NULL, NULL),
(200, 1, 130, 'EQAB', 1, '<p>EQAIEQAIEQAIEQAI</p>\r\n', NULL, NULL),
(201, 1, 131, 'UC-EQAM', 1, '<p>EQAMEQAMEQAMEQAM</p>\r\n', NULL, NULL),
(202, 1, 132, 'EQAC', 1, '<p>EQACEQACEQAC</p>\r\n', NULL, NULL),
(203, 1, 133, 'EQAH', 1, '<p>EQACEQACEQAC</p>\r\n', NULL, NULL),
(204, 1, 134, 'EQAP', 1, '<p>EQACEQACEQACEQAC</p>\r\n', NULL, NULL),
(205, 1, 135, 'หนังสือประชาสัมพันธ์การสมัครสมาชิก', 1, NULL, NULL, NULL),
(206, 1, 136, 'เปิดโครงการใหม่สำหรับ EQAB', 1, '<p>ภาควิชาจุลชีววิทยาและเทคโนโลยีประยุกต์ คณะเทคนิคการแพทย์ มหาวิทยาลัยมหิดล เปิดโครงการใหม่ EQAB</p>\r\n\r\n<p>ท่านสามารถสมัครสมาชิกได้โดยผ่านทางเวบไซต์ หรือดาวน์โหลดเอกสารรับสมัครตามไฟล์แนบ</p>\r\n', NULL, NULL),
(207, 1, 137, 'ประชาสัมพันธ์3', 1, '', NULL, NULL),
(208, 1, 138, 'ประชาสัมพันธ์4', 1, '', NULL, NULL),
(209, 1, 139, 'ประชาสัมพันธ์5', 1, '', NULL, NULL),
(210, 1, 71, 'ดาวน์โหลดเอกสารและคู่มือ', 0, '', NULL, NULL),
(211, 1, 140, 'คู่มือ B-EQAM', 1, '<p>คู่มืออธิบายการประเมินผล</p>\r\n', NULL, NULL),
(212, 1, 141, 'คู่มือเพิ่มเติม B-EQAM', 1, '<p>เพิ่มเติมเนื้อหา</p>\r\n', NULL, NULL),
(213, 1, 142, 'เอกสาร', 1, '', NULL, NULL),
(214, 1, 143, 'เอกสาร4', 1, '', NULL, NULL),
(215, 1, 144, 'เอกสาร5', 1, '', NULL, NULL),
(216, 1, 72, 'การประเมินความพึงพอใจ', 0, '', NULL, NULL),
(217, 1, 145, 'แบบประเมินความพึงพอใจ B-EQAM', 1, '<p>โปรดประเมิน</p>\r\n', NULL, NULL),
(218, 1, 146, 'แบบประเมิน2', 1, '', NULL, NULL),
(219, 1, 147, 'แบบประเมิน3', 1, '', NULL, NULL),
(220, 1, 148, 'แบบประเมิน4', 1, '', NULL, NULL),
(221, 1, 149, 'แบบประเมิน5', 1, '', NULL, NULL),
(222, 1, 150, 'ประเมินความพึงพอใจ EQAS', 1, '<p>โปรดประเมิน แล้วส่งกลับทางอีเมล์</p>\r\n', NULL, NULL),
(223, 1, 151, 'EQAT', 1, '', NULL, NULL),
(224, 1, 152, 'EQAI: Syphilis', 1, NULL, NULL, NULL),
(225, 1, 153, 'EQAI: HBV', 1, '', NULL, NULL),
(226, 1, 154, 'แบบสมัครสมาชิก 2561', 1, '', NULL, NULL),
(227, 1, 73, 'เกี่ยวกับโครงการ_bak', 0, NULL, NULL, NULL),
(228, 1, 74, '1. สาขาเคมีคลินิก', 0, '', NULL, NULL),
(229, 1, 75, '2. สาขาจุลทรรศนศาสตร์คลินิก', 0, '', NULL, NULL),
(230, 1, 76, '3. สาขาปรสิตวิทยา', 0, '', NULL, NULL),
(231, 1, 77, '4. สาขาภูมิคุ้มกันวิทยาคลินิก', 0, '', NULL, NULL),
(232, 1, 78, '5. สาขาแบคทีเรียวิทยา ', 0, '', NULL, NULL),
(233, 1, 155, 'เคมีคลินิก (The External Quality Assessment Scheme in Clinical Chemistry: EQAC)', 1, '', NULL, NULL),
(234, 1, 156, 'ฮอร์โมน (The External Quality Assessment Scheme in Hormone: EQAH)', 1, '', NULL, NULL),
(235, 1, 157, 'สารบ่งชี้มะเร็ง (The External Quality Assessment Scheme in Tumor Markers: EQAT)', 1, '', NULL, NULL),
(236, 1, 158, 'การทดสอบความสมบูรณ์ของเม็ดเลือด (The External Quality Assessment Scheme in Clinical Microscopy: CBC, B-EQAM) ', 1, '', NULL, NULL),
(237, 1, 159, 'การตรวจสเมียร์เลือด (The External Quality Assessment Scheme in Clinical Microscopy: Blood Film Examination, H-EQAM) ', 1, '', NULL, NULL),
(238, 1, 160, 'ภาพถ่ายตะกอนปัสสาวะและภาพถ่ายสเมียร์เลือด (The External Quality Assessment Scheme in Clinical Microscopy: Urine - Cytohematology Photo, UC-EQAM) ', 1, '', NULL, NULL),
(239, 1, 161, 'การตรวจปรสิต (The External Quality Assessment Scheme in Parasitology: EQAP)', 1, '', NULL, NULL),
(240, 1, 162, 'การตรวจซิฟิลิส (The External Quality Assessment Scheme in Clinical Immunology, EQAI - Syphilis)', 1, '', NULL, NULL),
(241, 1, 163, 'การตรวจไวรัสตับอักเสบชนิดบี (The External Quality Assessment Scheme in Clinical Immunology: EQAI – Hepatitis B)', 1, '', NULL, NULL),
(242, 1, 164, 'การย้อมสีแกรม (EQAB: Gram)', 1, '', NULL, NULL),
(243, 1, 165, 'การย้อม Acid Fast Bacilli (EQAB: AFB)', 1, '', NULL, NULL),
(244, 1, 166, 'การวินิจฉัยแยกชนิดและการทดสอบความไวต่อยาปฏิชีวนะ (EQAB: IDEN & AST)', 1, '', NULL, NULL),
(245, 1, 79, 'Scheme ที่ให้บริการ', 0, NULL, NULL, NULL),
(246, 1, 167, 'EQAC', 1, '<p>ทดสอบแก้ไข</p>\r\n', NULL, NULL),
(247, 1, 168, 'EQAH', 1, '', NULL, NULL),
(248, 1, 169, 'EQAT', 1, '', NULL, NULL),
(249, 1, 170, 'EQAP', 1, '<p>ท่านสามารถดาวน์โหลดคู่มือได้ที่ www.mahidol.ac.th/EQAP</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>แก้ไขเมื่อวันที่ 111111</p>\r\n', NULL, NULL),
(250, 1, 171, 'B-EQAM', 1, '', NULL, NULL),
(251, 1, 172, 'H-EQAM', 1, '', NULL, NULL),
(252, 1, 173, 'UC-EQAM', 1, '', NULL, NULL),
(253, 1, 174, 'EQAI', 1, '', NULL, NULL),
(254, 1, 175, 'EQAB', 1, '', NULL, NULL),
(255, 1, 80, 'ติดต่อโครงการ', 0, '', NULL, NULL),
(256, 1, 176, 'ติดต่อเรา', 1, '<p>&nbsp;สถานที่ : คณะเทคนิคการแพทย์ มหาวิทยาลัยมหิดล เลขที่ 2 ถนนวังหลัง แขวงศิริราช เขตบางกอกน้อย กรุงเทพฯ 10700</p>\r\n\r\n<p>&nbsp;โทร : +66 (2) 441 4371-5ต่อ2202 ,fax : +66 (2) 441 4380</p>\r\n\r\n<p>&nbsp;อีเมลล์ : mtwww@mahidol.ac.th</p>\r\n', NULL, NULL),
(257, 1, 81, 'ใบสมัครสมาชิก', 0, '', NULL, NULL),
(258, 1, 177, 'ใบสมัคร 1', 1, '', NULL, NULL),
(259, 1, 178, 'ใบสมัคร 2', 1, '', NULL, NULL),
(260, 1, 82, 'อื่นๆ', 0, NULL, NULL, NULL),
(261, 1, 179, 'เกี่ยวกับโครงการ', 1, '<p>โครงการประเมินคุณภาพห้องปฏิบัติการโดยองค์กรภายนอก (The External Quality Assessment Schemes in Clinical Laboratory) คณะเทคนิคการแพทย์ มหาวิทยาลัยมหิดล&nbsp; ได้เริ่มดำเนินการตั้งแต่ ปี พ.ศ. 2528 จากการริเริ่มของศาสตราจารย์วีกูล วีรานุวัตติ์ คณบดี&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; ท่านแรก นับเป็นปฐมบทของการควบคุมคุณภาพการวิเคราะห์ทางห้องปฏิบัติการทางการแพทย์&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; ในประเทศไทยและภูมิภาคอาเซียน และมีการดำเนินการพัฒนาโครงการต่างๆ เพื่อให้ครอบคลุมงานทางห้องปฏิบัติการทุกด้าน ปัจจุบันคณะเทคนิคการแพทย์ มหาวิทยาลัยมหิดล ได้ให้บริการโครงการประเมินคุณภาพห้องปฏิบัติการโดยองค์กรภายนอก จำนวนทั้งสิ้น 10 โครงการ จำแนกเป็น 5 สาขา ดังนี้&nbsp;</p>\r\n\r\n<p>1. สาขาเคมีคลินิก</p>\r\n\r\n<div style=\"margin-left:.38in;\">-เคมีคลินิก (The External Quality Assessment Scheme in Clinical Chemistry: EQAC)</div>\r\n\r\n<div style=\"margin-left:.38in;\">-ฮอร์โมน (The External Quality Assessment Scheme in Hormone: EQAH)</div>\r\n\r\n<div style=\"margin-left:.38in;\">-สารบ่งชี้มะเร็ง (The External Quality Assessment Scheme in Tumor Markers: EQAT)</div>\r\n\r\n<p>2. สาขาจุลทรรศนศาสตร์คลินิก</p>\r\n\r\n<div style=\"margin-left:.38in;\">-การทดสอบความสมบูรณ์ของเม็ดเลือด (The External Quality Assessment Scheme in Clinical Microscopy: CBC, B-EQAM)</div>\r\n\r\n<div style=\"margin-left:.38in;\">-การตรวจสเมียร์เลือด (The External Quality Assessment Scheme in Clinical Microscopy: Blood Film Examination, H-EQAM)</div>\r\n\r\n<div style=\"margin-left:.38in;\">-ภาพถ่ายตะกอนปัสสาวะและภาพถ่ายสเมียร์เลือด (The External Quality Assessment Scheme in Clinical Microscopy: Urine - Cytohematology Photo, UC-EQAM)</div>\r\n\r\n<p>3. สาขาปรสิตวิทยา (The External Quality Assessment Scheme in Parasitology: EQAP)</p>\r\n\r\n<p style=\"margin-left:.29in\">4. สาขาภูมิคุ้มกันวิทยาคลินิก</p>\r\n\r\n<div style=\"margin-left:.38in;\">-การตรวจซิฟิลิส (The External Quality Assessment Scheme in Clinical Immunology, EQAI - Syphilis)</div>\r\n\r\n<div style=\"margin-left:.38in;\">-การตรวจไวรัสตับอักเสบชนิดบี (The External Quality Assessment Scheme in Clinical Immunology: EQAI &ndash; Hepatitis B)</div>\r\n\r\n<p style=\"margin-left:.69in\">5. สาขาจุลชีววิทยาคลินิก (The External Quality Assessment Scheme in Bacteriology, EQAB)</p>\r\n\r\n<div style=\"margin-left:.38in;\">-การย้อมสีแกรม (EQAB: Gram)</div>\r\n\r\n<div style=\"margin-left:.38in;\">-การย้อม Acid Fast Bacilli (EQAB: AFB)</div>\r\n\r\n<div style=\"margin-left:.38in;\">-การวินิจฉัยแยกชนิดและการทดสอบความไวต่อยาปฏิชีวนะ (EQAB: IDEN &amp; AST)</div>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>จากการดำเนินการที่ผ่านมาพบว่าจำนวนสมาชิกของโครงการมีแนวโน้มเพิ่มขึ้นทุกๆ ปี และทางโครงการได้มีการปรับปรุงการดำเนินงานให้สอดคล้องตามมาตรฐาน ISO/IEC 17043 ซึ่งจะทำให้เกิดประโยชน์สูงสุดแก่ห้องปฏิบัติการสมาชิก จึงหวังว่าห้องปฏิบัติการทางการแพทย์จะให้ความไว้วางใจเข้าร่วมเป็นสมาชิกของโครงการอย่างต่อเนื่องต่อไป</p>\r\n', NULL, NULL),
(262, 1, 180, 'B-EQAM', 1, '', NULL, NULL),
(263, 1, 181, 'H-EQAM', 1, '', NULL, NULL),
(264, 1, 182, '2. ทดสอบ', 1, '', NULL, NULL),
(265, 1, 83, '111', 0, '', NULL, NULL),
(266, 1, 183, 'banner', 1, '', NULL, NULL),
(267, 1, 184, 'รูปหน้าหลัก', 1, NULL, NULL, NULL),
(268, 1, 185, 'รูปแบคกราว', 1, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `mhd_member`
--

CREATE TABLE `mhd_member` (
  `id` int(11) NOT NULL,
  `member_no` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `password` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `firstname` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `lastname` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `telephone` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `forget_code` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `del` int(1) DEFAULT 0,
  `date_login` datetime DEFAULT NULL,
  `date_added` datetime DEFAULT NULL,
  `date_modify` datetime DEFAULT NULL,
  `confirm` int(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `mhd_member`
--

INSERT INTO `mhd_member` (`id`, `member_no`, `email`, `password`, `firstname`, `lastname`, `telephone`, `forget_code`, `del`, `date_login`, `date_added`, `date_modify`, `confirm`) VALUES
(1, '0001', 'munk.gorn@gmail.com', '81dc9bdb52d04dc20036dbd8313ed055', 'munk', 'gorn', '+66863498778', NULL, 0, '2021-02-05 13:02:23', '2021-01-12 13:43:45', '2021-01-12 13:43:45', 1);

-- --------------------------------------------------------

--
-- Table structure for table `mhd_payment`
--

CREATE TABLE `mhd_payment` (
  `id` int(11) NOT NULL,
  `register_id` int(11) DEFAULT NULL,
  `member_id` int(11) DEFAULT NULL,
  `admin_id` int(11) DEFAULT NULL COMMENT 'admin check/change',
  `image` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `status` int(11) DEFAULT 0,
  `bank_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `total` double(11,2) DEFAULT NULL,
  `slip_date` date DEFAULT NULL,
  `slip_time` time DEFAULT NULL,
  `date_added` datetime DEFAULT NULL,
  `date_modify` datetime DEFAULT NULL,
  `del` int(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `mhd_payment`
--

INSERT INTO `mhd_payment` (`id`, `register_id`, `member_id`, `admin_id`, `image`, `status`, `bank_name`, `total`, `slip_date`, `slip_time`, `date_added`, `date_modify`, `del`) VALUES
(1, 1, 1, 1, '6c11a009dcdd1afbf1ec3db69a02b990.png', 1, 'ธนาคารกรุงเทพ', 6500.00, '2021-01-12', '13:51:24', '2021-01-12 13:51:34', '2021-01-18 14:36:36', 0),
(2, 1, 1, 1, '0879cc916bc7a106b6ee61323fb85317.png', 1, 'ธนาคารกรุงเทพ', 18900.00, '2021-01-18', '12:36:50', '2021-01-18 12:36:56', '2021-01-18 14:39:07', 0);

-- --------------------------------------------------------

--
-- Table structure for table `mhd_program`
--

CREATE TABLE `mhd_program` (
  `id` int(11) NOT NULL,
  `sort` int(11) DEFAULT 0,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `slug` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `code` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `structure` longtext COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'structure default value',
  `price` decimal(10,2) DEFAULT NULL,
  `date_added` datetime DEFAULT NULL,
  `date_modify` datetime DEFAULT NULL,
  `del` int(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `mhd_program`
--

INSERT INTO `mhd_program` (`id`, `sort`, `name`, `slug`, `code`, `structure`, `price`, `date_added`, `date_modify`, `del`) VALUES
(1, 1, 'EQAC', 'eqac', 'EC', '[{\"name\":\"home\",\"option\":[{\"value\":\"112\",\"name\":\"Dirui CS-600B\",\"selected\":0},{\"value\":\"119\",\"name\":\"ILab 600/650/Taurus\",\"selected\":0},{\"value\":\"147\",\"name\":\"Sysmex JCA-BM6010/C\",\"selected\":0},{\"value\":\"165\",\"name\":\"Roche Cobas c501/502/503\",\"selected\":0},{\"value\":\"54\",\"name\":\"NM-BAPTA\",\"selected\":0},{\"value\":\"32\",\"name\":\"Jaffe Kinetic\",\"selected\":0},{\"value\":\"33\",\"name\":\"Jendrassik - Grof \",\"selected\":0},{\"value\":\"44\",\"name\":\"PNP.AMP buff; AACC\",\"selected\":0},{\"value\":\"45\",\"name\":\"PNP.DEA buff;  DGKC\",\"selected\":0},{\"value\":\"46\",\"name\":\"Reflotron\",\"selected\":0},{\"value\":\"47\",\"name\":\"SSCC\",\"selected\":0},{\"value\":\"48\",\"name\":\"Vitros\",\"selected\":0},{\"value\":\"49\",\"name\":\"Vitros; ISE\",\"selected\":0},{\"value\":\"34\",\"name\":\"Kinetic 37C/ Kinetic - without pyridoxal \",\"selected\":0},{\"value\":\"35\",\"name\":\"Kinetic - pyridoxal\",\"selected\":0},{\"value\":\"36\",\"name\":\"Malloy - Evelyn \",\"selected\":0},{\"value\":\"37\",\"name\":\"Margon/ Xylidyl blue\",\"selected\":0},{\"value\":\"38\",\"name\":\"Methylthymol blue\",\"selected\":0},{\"value\":\"39\",\"name\":\"Molybdenum EP\",\"selected\":0},{\"value\":\"40\",\"name\":\"Molybdenum UV\",\"selected\":0},{\"value\":\"41\",\"name\":\"Others\",\"selected\":0},{\"value\":\"42\",\"name\":\"Phospho. Precip./ Polyanion\",\"selected\":0},{\"value\":\"43\",\"name\":\"PNP AMP buff; IFCC\",\"selected\":0},{\"value\":\"1\",\"name\":\"Arsenazo/ Chlorophosphonazo\",\"selected\":0},{\"value\":\"2\",\"name\":\"Bromocresol green\",\"selected\":0},{\"value\":\"3\",\"name\":\"Bromocresol purple\",\"selected\":0},{\"value\":\"4\",\"name\":\"Beckman\",\"selected\":0},{\"value\":\"5\",\"name\":\"Biuret - Blank\",\"selected\":0},{\"value\":\"6\",\"name\":\"Biuret - Unblank\",\"selected\":0},{\"value\":\"7\",\"name\":\"CK-NAC/IFCC\",\"selected\":0},{\"value\":\"8\",\"name\":\"CNPG3\",\"selected\":0},{\"value\":\"9\",\"name\":\"Colorimetric\",\"selected\":0},{\"value\":\"10\",\"name\":\"CPC/ Arsenazo\",\"selected\":0},{\"value\":\"11\",\"name\":\"Dade Behring\",\"selected\":0},{\"value\":\"12\",\"name\":\"DCA/DPD\",\"selected\":0},{\"value\":\"13\",\"name\":\"DGKC\",\"selected\":0},{\"value\":\"14\",\"name\":\"Diazonium\",\"selected\":0},{\"value\":\"15\",\"name\":\"Direct Determination\",\"selected\":0},{\"value\":\"16\",\"name\":\"Direct ISE\",\"selected\":0},{\"value\":\"17\",\"name\":\"Enz Color Total TG\",\"selected\":0},{\"value\":\"18\",\"name\":\"Enzyme\",\"selected\":0},{\"value\":\"19\",\"name\":\"Enzyme Colorimetric\",\"selected\":0},{\"value\":\"20\",\"name\":\"Enzyme EP Blank\",\"selected\":0},{\"value\":\"21\",\"name\":\"Enzyme EP Unblank\",\"selected\":0},{\"value\":\"22\",\"name\":\"Enzyme Kinetic\",\"selected\":0},{\"value\":\"23\",\"name\":\"G7PNP\",\"selected\":0},{\"value\":\"24\",\"name\":\"Glucose Dehydrogenase\",\"selected\":0},{\"value\":\"25\",\"name\":\"Glycerol Blank\",\"selected\":0},{\"value\":\"26\",\"name\":\"Glucose Oxidase\",\"selected\":0},{\"value\":\"27\",\"name\":\"Hexokinase\",\"selected\":0},{\"value\":\"28\",\"name\":\"IFCC\",\"selected\":0},{\"value\":\"29\",\"name\":\"Indirect ISE\",\"selected\":0},{\"value\":\"30\",\"name\":\"ISE\",\"selected\":0},{\"value\":\"31\",\"name\":\"Jaffe EP\",\"selected\":0},{\"value\":\"50\",\"name\":\"Direct with PVS/PEGMS\",\"selected\":0},{\"value\":\"51\",\"name\":\"Imm.Inhibition\",\"selected\":0},{\"value\":\"52\",\"name\":\"Water & Gerarde Method\",\"selected\":0},{\"value\":\"53\",\"name\":\"Vanadate\",\"selected\":0},{\"value\":\"101\",\"name\":\"Abbott Architect c Systems\",\"selected\":0},{\"value\":\"102\",\"name\":\"Audicom AC9000 Series electrolyte analyzer\",\"selected\":0},{\"value\":\"104\",\"name\":\"Beckman Coulter DxC600/ DxC800\",\"selected\":0},{\"value\":\"103\",\"name\":\"Beckman Coulter AU400/480/680/5800\",\"selected\":0},{\"value\":\"105\",\"name\":\"Beckman Coulter DxC700 AU\",\"selected\":0},{\"value\":\"106\",\"name\":\"Biosystems A15\",\"selected\":0},{\"value\":\"107\",\"name\":\"Biosystems BA400\",\"selected\":0},{\"value\":\"108\",\"name\":\"Caretium XI-921\",\"selected\":0},{\"value\":\"109\",\"name\":\"Roche Cobas Mira S\",\"selected\":0},{\"value\":\"110\",\"name\":\"Diasys BioMajesty JCA-BM6010/C\",\"selected\":0},{\"value\":\"111\",\"name\":\"Dirui CS Series\",\"selected\":0},{\"value\":\"113\",\"name\":\"Electa4 analyzer\",\"selected\":0},{\"value\":\"114\",\"name\":\"Erba XL Series\",\"selected\":0},{\"value\":\"115\",\"name\":\"Fuji Dri-Chem NX500i\",\"selected\":0},{\"value\":\"116\",\"name\":\"GASTAT-1820\",\"selected\":0},{\"value\":\"117\",\"name\":\"Hitachi 911\",\"selected\":0},{\"value\":\"118\",\"name\":\"Horiba Pentra 400\",\"selected\":0},{\"value\":\"120\",\"name\":\"ILab 600/650/Taurus\",\"selected\":0},{\"value\":\"121\",\"name\":\"In4lyte\",\"selected\":0},{\"value\":\"122\",\"name\":\"Konelab 20/30/60 / Thermo Indiko\",\"selected\":0},{\"value\":\"123\",\"name\":\"Mindray BC 2000/3000 series\",\"selected\":0},{\"value\":\"124\",\"name\":\"Mindray BS Series\",\"selected\":0},{\"value\":\"125\",\"name\":\"Nova 4 electrolyte analyzer\",\"selected\":0},{\"value\":\"126\",\"name\":\"Ortho Vitros 250/350\",\"selected\":0},{\"value\":\"127\",\"name\":\"Ortho Vitros 4600/5600\",\"selected\":0},{\"value\":\"128\",\"name\":\"PKL PPC 125\",\"selected\":0},{\"value\":\"129\",\"name\":\"Q4-Lyte\",\"selected\":0},{\"value\":\"130\",\"name\":\"Randox RX series\",\"selected\":0},{\"value\":\"131\",\"name\":\"Reflotron\",\"selected\":0},{\"value\":\"132\",\"name\":\"Roche Cobas c111\",\"selected\":0},{\"value\":\"133\",\"name\":\"Roche Cobas c311\",\"selected\":0},{\"value\":\"134\",\"name\":\"Roche Cobas c501/502/503\",\"selected\":0},{\"value\":\"135\",\"name\":\"Roche Cobas Integra 400 Plus\",\"selected\":0},{\"value\":\"136\",\"name\":\"Rx Modena\",\"selected\":0},{\"value\":\"137\",\"name\":\"Rx-lyte v.4\",\"selected\":0},{\"value\":\"138\",\"name\":\"SFRI ISE electrolyte series\",\"selected\":0},{\"value\":\"139\",\"name\":\"Siemens Advia 1800\",\"selected\":0},{\"value\":\"140\",\"name\":\"Siemens Rapidlab 348Ex\",\"selected\":0},{\"value\":\"141\",\"name\":\"Siemens/Dade Dimension EXL\",\"selected\":0},{\"value\":\"142\",\"name\":\"Siemens/Dade Dimension RxL /Max/Xpand\",\"selected\":0},{\"value\":\"143\",\"name\":\"Sinnowa BS-3000\",\"selected\":0},{\"value\":\"144\",\"name\":\"Sinnowa DS301\",\"selected\":0},{\"value\":\"145\",\"name\":\"Sysmex BX-3010\",\"selected\":0},{\"value\":\"146\",\"name\":\"Sysmex BX-4000\",\"selected\":0},{\"value\":\"148\",\"name\":\"Tecom TC220\",\"selected\":0},{\"value\":\"149\",\"name\":\"Thermo Fisher Konelab Delta\",\"selected\":0},{\"value\":\"150\",\"name\":\"Tokyo Boeki/Biolis/ Prestige 24i/TMS 1024\",\"selected\":0},{\"value\":\"151\",\"name\":\"URIT-8031\",\"selected\":0},{\"value\":\"152\",\"name\":\"Vitalab Scientific Flexor E\",\"selected\":0},{\"value\":\"153\",\"name\":\"XD 687 Electrolyte Analyzer\",\"selected\":0},{\"value\":\"154\",\"name\":\"XD 697 Electrolyte Analyzer\",\"selected\":0},{\"value\":\"155\",\"name\":\"Q4-LyteEx \",\"selected\":0},{\"value\":\"157\",\"name\":\"Biotecnica BT Series\",\"selected\":0},{\"value\":\"158\",\"name\":\"URIT 8280\",\"selected\":0},{\"value\":\"159\",\"name\":\"GE300 electrolyte analyzer\",\"selected\":0},{\"value\":\"160\",\"name\":\"Biosystems BA200\",\"selected\":0},{\"value\":\"161\",\"name\":\"Roche Cobas c701/702\",\"selected\":0},{\"value\":\"162\",\"name\":\"HumaStar 200\",\"selected\":0},{\"value\":\"156\",\"name\":\"Furuno CA-800\",\"selected\":0},{\"value\":\"163\",\"name\":\"Diasys Respons 920\",\"selected\":0},{\"value\":\"164\",\"name\":\"Rayto Chemray 120\",\"selected\":0},{\"value\":\"166\",\"name\":\"URIT-910 Plus\",\"selected\":0},{\"value\":\"167\",\"name\":\"Siemens Atellica Solution\",\"selected\":0},{\"value\":\"545\",\"name\":\"Medica\",\"selected\":0},{\"value\":\"546\",\"name\":\"Bt GEN\",\"selected\":0},{\"value\":\"501\",\"name\":\"Abbott laboratories\",\"selected\":0},{\"value\":\"502\",\"name\":\"Beckman Coulter\",\"selected\":0},{\"value\":\"503\",\"name\":\"BioSystems\",\"selected\":0},{\"value\":\"504\",\"name\":\"Biozen\",\"selected\":0},{\"value\":\"505\",\"name\":\"Caretium \",\"selected\":0},{\"value\":\"506\",\"name\":\"Centronic\",\"selected\":0},{\"value\":\"507\",\"name\":\"Diamond\",\"selected\":0},{\"value\":\"508\",\"name\":\"DiaSys\",\"selected\":0},{\"value\":\"509\",\"name\":\"Diazyme\",\"selected\":0},{\"value\":\"510\",\"name\":\"Dirui\",\"selected\":0},{\"value\":\"511\",\"name\":\"Electa\",\"selected\":0},{\"value\":\"512\",\"name\":\"Elitech\",\"selected\":0},{\"value\":\"513\",\"name\":\"Erba Lachema\",\"selected\":0},{\"value\":\"514\",\"name\":\"Fuji\",\"selected\":0},{\"value\":\"515\",\"name\":\"Furuno\",\"selected\":0},{\"value\":\"516\",\"name\":\"Horiba\",\"selected\":0},{\"value\":\"517\",\"name\":\"Iberlab\",\"selected\":0},{\"value\":\"518\",\"name\":\"I-med\",\"selected\":0},{\"value\":\"519\",\"name\":\"Infocus firming\",\"selected\":0},{\"value\":\"520\",\"name\":\"Instumentation laboratory\",\"selected\":0},{\"value\":\"521\",\"name\":\"Jiangsu Audicom \",\"selected\":0},{\"value\":\"522\",\"name\":\"Meditop\",\"selected\":0},{\"value\":\"523\",\"name\":\"Mindray\",\"selected\":0},{\"value\":\"524\",\"name\":\"Olympus\",\"selected\":0},{\"value\":\"525\",\"name\":\"Ortho-Clinical Diagnostics\",\"selected\":0},{\"value\":\"526\",\"name\":\"PCL\",\"selected\":0},{\"value\":\"527\",\"name\":\"Randox\",\"selected\":0},{\"value\":\"528\",\"name\":\"Roche Diagnotics\",\"selected\":0},{\"value\":\"529\",\"name\":\"SFRI\",\"selected\":0},{\"value\":\"530\",\"name\":\"Shanghai Xunda\",\"selected\":0},{\"value\":\"531\",\"name\":\"Siemens\",\"selected\":0},{\"value\":\"532\",\"name\":\"Slidedrychem\",\"selected\":0},{\"value\":\"533\",\"name\":\"Spinreact\",\"selected\":0},{\"value\":\"534\",\"name\":\"Stanbio\",\"selected\":0},{\"value\":\"535\",\"name\":\"Sysmex\",\"selected\":0},{\"value\":\"536\",\"name\":\"Techno Medica\",\"selected\":0},{\"value\":\"537\",\"name\":\"Tecom\",\"selected\":0},{\"value\":\"538\",\"name\":\"Thermoscientific\",\"selected\":0},{\"value\":\"539\",\"name\":\"Toyobo\",\"selected\":0},{\"value\":\"540\",\"name\":\"URIT\",\"selected\":0},{\"value\":\"541\",\"name\":\"Wako\",\"selected\":0},{\"value\":\"542\",\"name\":\"YD diagnostic\",\"selected\":0},{\"value\":\"543\",\"name\":\"Biotecnica Instruments\",\"selected\":0},{\"value\":\"544\",\"name\":\"Genrui Biotech\",\"selected\":0},{\"value\":\"547\",\"name\":\"Q4-Lyte\",\"selected\":0},{\"value\":\"548\",\"name\":\"Q4-LyteEx\",\"selected\":0},{\"value\":\"549\",\"name\":\"Rayto\",\"selected\":0},{\"value\":\"550\",\"name\":\"QuantILab\",\"selected\":0}]},{\"name\":\"tab\",\"option\":[{\"value\":\"2\",\"name\":\"ALP (U/L)\",\"selected\":0},{\"value\":\"3\",\"name\":\"ALT (U/L)\",\"selected\":0},{\"value\":\"4\",\"name\":\"Amylase, Total  (U/L)\",\"selected\":0},{\"value\":\"5\",\"name\":\"AST  (U/L)\",\"selected\":0},{\"value\":\"6\",\"name\":\"BUN (mg/dL)\",\"selected\":0},{\"value\":\"7\",\"name\":\"Bilirubin, Total  (mg/dL)\",\"selected\":0},{\"value\":\"8\",\"name\":\"Calcium (mg/dL)\",\"selected\":0},{\"value\":\"9\",\"name\":\"Chloride (mmol/L)\",\"selected\":0},{\"value\":\"11\",\"name\":\"CK, Total (U/L)\",\"selected\":0},{\"value\":\"13\",\"name\":\"GGT (U/L)\",\"selected\":0},{\"value\":\"14\",\"name\":\"Glucose (mg/dL)\",\"selected\":0},{\"value\":\"10\",\"name\":\"Cholesterol (mg/dL)\",\"selected\":0},{\"value\":\"15\",\"name\":\"HDL-cholesterol (mg/dL)\",\"selected\":0},{\"value\":\"17\",\"name\":\"LDL-cholesterol (mg/dL)\",\"selected\":0},{\"value\":\"16\",\"name\":\"LDH (U/L)\",\"selected\":0},{\"value\":\"18\",\"name\":\"Magnesium (mg/dL)\",\"selected\":0},{\"value\":\"19\",\"name\":\"Phosphorus, Inorganic (mg/dL)\",\"selected\":0},{\"value\":\"20\",\"name\":\"Potassium (mmol/L)\",\"selected\":0},{\"value\":\"21\",\"name\":\"Total Protein (g/dL)\",\"selected\":0},{\"value\":\"22\",\"name\":\"Sodium (mmol/L)\",\"selected\":0},{\"value\":\"23\",\"name\":\"Triglyceride (mg/dL)\",\"selected\":0},{\"value\":\"24\",\"name\":\"Uric acid (mg/dL)\",\"selected\":0},{\"value\":\"1\",\"name\":\"Albumin (g/dL)\",\"selected\":0},{\"value\":\"12\",\"name\":\"Creatinine (mg/dL)\",\"selected\":0}]}]', '3000.00', '2020-09-21 14:00:45', '2020-09-22 13:28:42', 0),
(2, 2, 'EQAH', 'eqah', 'EH', NULL, '4500.00', '2020-09-21 14:00:55', NULL, 0),
(3, 3, 'EQAT', 'eqat', 'ET', NULL, '4500.00', '2020-09-21 14:01:13', NULL, 0),
(4, 4, 'EQAP', 'eqap', 'EP', NULL, '2000.00', '2020-09-21 14:01:16', NULL, 0),
(5, 5, 'B-EQAM', 'b-eqam', 'MB', NULL, '2000.00', '2020-09-21 14:01:21', NULL, 0),
(6, 6, 'H-EQAM', 'h-eqam', 'MH', NULL, '1500.00', '2020-09-21 14:01:26', NULL, 0),
(7, 7, 'UC-EQAM', 'uc-eqam', 'UC', NULL, '1000.00', '2020-09-21 14:01:31', NULL, 0),
(8, 8, 'EQAI:Syphilis', 'eqaisyphilis', 'IS', '', '2200.00', '2020-09-21 14:01:37', NULL, 0),
(9, 9, 'EQAI:HBV', 'eqaihbv', 'IB', '', '2200.00', '2020-09-21 14:01:44', NULL, 0),
(10, 10, 'EQAB:GRAM', 'eqabgram', 'BG', '', '1000.00', '2020-09-21 14:01:48', '2020-09-21 14:03:41', 0),
(11, NULL, 'EQAB:GRAM', 'eqabgram', NULL, NULL, NULL, '2020-09-21 14:03:14', NULL, 1),
(12, 11, 'EQAB:AFB', 'eqabafb', 'BA', NULL, '1000.00', '2020-09-21 14:04:32', NULL, 0),
(13, 12, 'EQAB IDEN&AST', 'eqab-idenast', 'BI', NULL, '1000.00', '2020-09-21 14:04:39', NULL, 0);

-- --------------------------------------------------------

--
-- Table structure for table `mhd_program_infection`
--

CREATE TABLE `mhd_program_infection` (
  `id` int(11) NOT NULL,
  `program_id` int(11) DEFAULT NULL,
  `code` int(11) DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `other` int(11) DEFAULT NULL,
  `section` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `event` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fix_decimal` int(11) NOT NULL DEFAULT 0,
  `del` int(11) DEFAULT 0
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `mhd_program_infection`
--

INSERT INTO `mhd_program_infection` (`id`, `program_id`, `code`, `name`, `other`, `section`, `event`, `fix_decimal`, `del`) VALUES
(61, 5, 1, 'WBC (x10<sup>9</sup>/L) ', NULL, NULL, NULL, 0, 0),
(62, 5, 2, 'RBC (x10<sup>12</sup>/L)', NULL, NULL, NULL, 0, 0),
(63, 5, 3, 'Hb (g/dL)', NULL, NULL, NULL, 0, 0),
(64, 5, 4, 'Hct (%)', NULL, NULL, NULL, 0, 0),
(65, 5, 5, 'MCV (fL)', NULL, NULL, NULL, 0, 0),
(66, 5, 6, 'MCH (pg)', NULL, NULL, NULL, 0, 0),
(67, 5, 7, 'MCHC (g/dL)', NULL, NULL, NULL, 0, 0),
(68, 5, 8, 'RDW (%)', NULL, NULL, NULL, 0, 0),
(69, 5, 9, 'PLT (x10<sup>9</sup>/L)', NULL, NULL, NULL, 0, 0),
(70, 3, 1, 'AFP* IU/mL', NULL, NULL, NULL, 3, 0),
(71, 3, 2, 'CEA ng/mL', NULL, NULL, NULL, 3, 0),
(72, 3, 3, 'PSA ng/mL', NULL, NULL, NULL, 3, 0),
(73, 3, 4, 'CA 125 u/mL', NULL, NULL, NULL, 3, 0),
(74, 3, 5, 'CA 15-3 u/mL', NULL, NULL, NULL, 3, 0),
(75, 3, 6, 'CA 19-9 u/mL', NULL, NULL, NULL, 3, 0),
(76, 3, 7, 'B-hCG mIU/mL', NULL, NULL, NULL, 3, 0),
(77, 7, 1, 'Lymphoblast', NULL, '1', NULL, 0, 0),
(78, 7, 2, 'Prolymphocyte', NULL, '1', NULL, 0, 0),
(79, 7, 3, 'Monoblast', NULL, '1', NULL, 0, 0),
(80, 7, 4, 'Promonocyte', NULL, '1', NULL, 0, 0),
(81, 7, 5, 'Myeloblast', NULL, '1', NULL, 0, 0),
(82, 7, 6, 'Promyelocyte', NULL, '1', NULL, 0, 0),
(83, 7, 7, 'Neutrophilic myelocyte', NULL, '1', NULL, 0, 0),
(84, 7, 8, 'Eosinophilic myelocyte', NULL, '1', NULL, 0, 0),
(85, 7, 9, 'Basophilic myelocyte', NULL, '1', NULL, 0, 0),
(86, 7, 10, 'Neutrophilic metamyelocyte', NULL, '1', NULL, 0, 0),
(87, 7, 11, 'Eosinophilic metamyelocyte', NULL, '1', NULL, 0, 0),
(88, 7, 12, 'Basophilic metamyelocyte', NULL, '1', NULL, 0, 0),
(89, 7, 13, 'Band form neutrophil', NULL, '1', NULL, 0, 0),
(90, 7, 14, 'Neutrophil', NULL, '1', NULL, 0, 0),
(91, 7, 15, 'Eosinophil', NULL, '1', NULL, 0, 0),
(92, 7, 16, 'Basophil', NULL, '1', NULL, 0, 0),
(93, 7, 17, 'Monocyte', NULL, '1', NULL, 0, 0),
(94, 7, 18, 'Small lymphocyte', NULL, '1', NULL, 0, 0),
(95, 7, 19, 'Large lymphocyte', NULL, '1', NULL, 0, 0),
(96, 7, 20, 'Atypical lymphocyte', NULL, '1', NULL, 0, 0),
(97, 7, 21, 'Plasma cell', NULL, '1', NULL, 0, 0),
(98, 7, 22, 'Auer rod', NULL, '1', NULL, 0, 0),
(99, 7, 23, 'Faggot cell', NULL, '1', NULL, 0, 0),
(100, 7, 24, 'Döhle body', NULL, '1', NULL, 0, 0),
(101, 7, 25, 'Neutrophil with toxic granule', NULL, '1', NULL, 0, 0),
(102, 7, 26, 'Neutrophil with vacuolization', NULL, '1', NULL, 0, 0),
(103, 7, 27, 'Hypersegmented neutrophil', NULL, '1', NULL, 0, 0),
(104, 7, 28, 'Hyposegmented  neutrophil', NULL, '1', NULL, 0, 0),
(105, 7, 29, 'Smudge cell / Basket cell', NULL, '1', NULL, 0, 0),
(106, 7, 30, 'Pyknotic cell', NULL, '1', NULL, 0, 0),
(107, 7, 31, 'Platelet satellitism', NULL, '1', NULL, 0, 0),
(108, 7, 32, 'Platelet clumping', NULL, '1', NULL, 0, 0),
(109, 7, 33, 'Pale stained platelet', NULL, '1', NULL, 0, 0),
(110, 7, 34, 'Giant platelet', NULL, '1', NULL, 0, 0),
(111, 7, 35, 'Micromegakaryocyte', NULL, '1', NULL, 0, 0),
(112, 7, 37, 'Pronormoblast', NULL, '2', NULL, 0, 0),
(113, 7, 38, 'Basophilic normoblast', NULL, '2', NULL, 0, 0),
(114, 7, 39, 'Polychromatic normoblast', NULL, '2', NULL, 0, 0),
(115, 7, 40, 'Orthochromatic normoblast', NULL, '2', NULL, 0, 0),
(116, 7, 41, 'Polychromasia', NULL, '2', NULL, 0, 0),
(117, 7, 42, 'Reticulocyte', NULL, '2', NULL, 0, 0),
(118, 7, 43, 'Normal red blood cell', NULL, '2', NULL, 0, 0),
(119, 7, 44, 'Microcyte', NULL, '2', NULL, 0, 0),
(120, 7, 45, 'Round macrocyte', NULL, '2', NULL, 0, 0),
(121, 7, 46, 'Oval macrocyte', NULL, '2', NULL, 0, 0),
(122, 7, 47, 'Ovalocyte/Elliptocyte', NULL, '2', NULL, 0, 0),
(123, 7, 48, 'Target cell', NULL, '2', NULL, 0, 0),
(124, 7, 49, 'Schistocyte/Fragmented cells', NULL, '2', NULL, 0, 0),
(125, 7, 50, 'Crenated red blood cell', NULL, '2', NULL, 0, 0),
(126, 7, 51, 'Teardrop cell', NULL, '2', NULL, 0, 0),
(127, 7, 52, 'Sickle cell', NULL, '2', NULL, 0, 0),
(128, 7, 53, 'Spherocyte', NULL, '2', NULL, 0, 0),
(129, 7, 54, 'Irregular contracted RBC (IRC)', NULL, '2', NULL, 0, 0),
(130, 7, 55, 'Bite cell', NULL, '2', NULL, 0, 0),
(131, 7, 56, 'Blister cell', NULL, '2', NULL, 0, 0),
(132, 7, 57, 'Burr cell', NULL, '2', NULL, 0, 0),
(133, 7, 58, 'Acanthocyte', NULL, '2', NULL, 0, 0),
(134, 7, 59, 'Stomatocyte', NULL, '2', NULL, 0, 0),
(135, 7, 60, 'Stomato-ovalocyte', NULL, '2', NULL, 0, 0),
(136, 7, 61, 'Hypochromia', NULL, '2', NULL, 0, 0),
(137, 7, 62, 'Basophilic stippling', NULL, '2', NULL, 0, 0),
(138, 7, 63, 'Howell - Jolly bodies', NULL, '2', NULL, 0, 0),
(139, 7, 64, 'Cabot’s ring', NULL, '2', NULL, 0, 0),
(140, 7, 65, 'Pappenheimer bodies', NULL, '2', NULL, 0, 0),
(141, 7, 66, 'Hb H inclusion bodies', NULL, '2', NULL, 0, 0),
(142, 7, 67, 'Heinz’s body', NULL, '2', NULL, 0, 0),
(143, 7, 68, 'Red cell agglutination', NULL, '2', NULL, 0, 0),
(144, 7, 69, 'Rouleaux formation', NULL, '2', NULL, 0, 0),
(526, 7, 3, 'Ghost red blood cell', NULL, '3', NULL, 0, 0),
(146, 7, 36, 'Megakaryocyte fragment', 1, '2', NULL, 0, 0),
(147, 7, 1, 'Red blood cell', NULL, '3', NULL, 0, 0),
(148, 7, 2, 'Dysmorphic Rbc ', NULL, '3', NULL, 0, 0),
(149, 7, 4, 'White blood cell', NULL, '3', NULL, 0, 0),
(150, 7, 5, 'Wbc with clumping ', NULL, '3', NULL, 0, 0),
(151, 7, 6, 'Macrophage', NULL, '3', NULL, 0, 0),
(152, 7, 7, 'Squamous epithelial cell', NULL, '3', NULL, 0, 0),
(153, 7, 8, 'Transitional epithelial cell', NULL, '3', NULL, 0, 0),
(154, 7, 9, 'Renal epithelial cell', NULL, '3', NULL, 0, 0),
(155, 7, 10, 'Oval fat body', NULL, '3', NULL, 0, 0),
(156, 7, 11, 'Spermatozoa', NULL, '3', NULL, 0, 0),
(157, 7, 12, 'Bacteria', NULL, '3', NULL, 0, 0),
(158, 7, 13, 'Budding yeast', NULL, '3', NULL, 0, 0),
(159, 7, 14, 'Pseudohyphae', NULL, '3', NULL, 0, 0),
(160, 7, 15, 'T. vaginalis', NULL, '3', NULL, 0, 0),
(161, 7, 16, 'Atypical cell with high N : C', NULL, '3', NULL, 0, 0),
(162, 7, 17, 'Hyaline cast', NULL, '3', NULL, 0, 0),
(163, 7, 18, 'Granular cast', NULL, '3', NULL, 0, 0),
(164, 7, 19, 'Rbc cast', NULL, '3', NULL, 0, 0),
(165, 7, 20, 'Heme cast', NULL, '3', NULL, 0, 0),
(166, 7, 21, 'Wbc cast', NULL, '3', NULL, 0, 0),
(167, 7, 22, 'Renal epithelial cell cast', NULL, '3', NULL, 0, 0),
(168, 7, 23, 'Mixed cellular cast', NULL, '3', NULL, 0, 0),
(169, 7, 24, 'Bacterial  cast', NULL, '4', NULL, 0, 0),
(170, 7, 25, 'Waxy cast ', NULL, '4', NULL, 0, 0),
(171, 7, 26, 'Fatty cast', NULL, '4', NULL, 0, 0),
(172, 7, 27, 'Broad cast', NULL, '4', NULL, 0, 0),
(173, 7, 28, 'Uric acid crystal', NULL, '4', NULL, 0, 0),
(174, 7, 29, 'Calcium oxalate crystal', NULL, '4', NULL, 0, 0),
(175, 7, 30, 'Calcium carbonate crystal', NULL, '4', NULL, 0, 0),
(176, 7, 31, 'Calcium phosphate crystal', NULL, '4', NULL, 0, 0),
(177, 7, 32, 'Ammonium urate crystal', NULL, '4', NULL, 0, 0),
(178, 7, 33, 'Ammonium biurate crystal', NULL, '4', NULL, 0, 0),
(179, 7, 34, 'Triple phosphate crystal', NULL, '4', NULL, 0, 0),
(180, 7, 35, 'Cystine crystal', NULL, '4', NULL, 0, 0),
(181, 7, 36, 'Tyrosine crystal', NULL, '4', NULL, 0, 0),
(182, 7, 37, 'Leucine crystal', NULL, '4', NULL, 0, 0),
(183, 7, 38, 'Sulfonamide crystal', NULL, '4', NULL, 0, 0),
(184, 7, 39, 'Cholesterol crystal', NULL, '4', NULL, 0, 0),
(185, 7, 40, 'Bilirubin crystal', NULL, '4', NULL, 0, 0),
(186, 7, 41, 'Amorphous ', NULL, '4', NULL, 0, 0),
(187, 7, 42, 'Mucous thread', NULL, '4', NULL, 0, 0),
(188, 7, 43, 'Fat droplet', NULL, '4', NULL, 0, 0),
(189, 7, 44, 'Starch granule', NULL, '4', NULL, 0, 0),
(190, 7, 45, 'Other (โปรดระบุ)', 1, '4', NULL, 0, 0),
(235, 6, 1, 'Blast cell (cannot be identified)', NULL, '1', NULL, 0, 0),
(236, 6, 2, 'Lymphoblast/prolymphocyte', NULL, '1', NULL, 0, 0),
(237, 6, 3, 'Monoblast/promonocyte', NULL, '1', NULL, 0, 0),
(238, 6, 4, 'Myeloblast', NULL, '1', NULL, 0, 0),
(239, 6, 5, 'Promyelocyte', NULL, '1', NULL, 0, 0),
(240, 6, 6, 'Myelocyte', NULL, '1', NULL, 0, 0),
(241, 6, 7, 'Metamyelocyte', NULL, '1', NULL, 0, 0),
(242, 6, 8, 'Band form neutrophil', NULL, '1', NULL, 0, 0),
(243, 6, 9, 'Neutrophil', NULL, '1', NULL, 0, 0),
(244, 6, 10, 'Eosinophil', NULL, '1', NULL, 0, 0),
(245, 6, 11, 'Basophil', NULL, '1', NULL, 0, 0),
(246, 6, 12, 'Monocyte', NULL, '1', NULL, 0, 0),
(247, 6, 13, 'Lymphocyte', NULL, '1', NULL, 0, 0),
(248, 6, 14, 'Atypical lymphocyte', NULL, '1', NULL, 0, 0),
(249, 6, 15, 'Plasma cell', NULL, '1', NULL, 0, 0),
(250, 6, 16, 'NRBC (....../ WBC 100 เซลล์)', NULL, '1', NULL, 0, 0),
(251, 6, 17, 'Auer rod', NULL, '2', NULL, 0, 0),
(252, 6, 18, 'Döhle bodies', NULL, '2', NULL, 0, 0),
(253, 6, 19, 'Toxic granules in neutrophil', NULL, '2', NULL, 0, 0),
(254, 6, 20, 'Vacuolization in  neutrophil', NULL, '2', NULL, 0, 0),
(255, 6, 21, 'Hypersegmented  neutrophil', NULL, '2', NULL, 0, 0),
(256, 6, 22, 'Pelger - Huët anomaly', NULL, '2', NULL, 0, 0),
(257, 6, 23, 'Anisocytosis', NULL, '3', NULL, 0, 0),
(258, 6, 24, 'Poikilocytosis', NULL, '3', NULL, 0, 0),
(259, 6, 25, 'Microcyte*', NULL, '3', NULL, 0, 0),
(260, 6, 26, 'Round macrocyte', NULL, '3', NULL, 0, 0),
(261, 6, 27, 'Oval macrocyte', NULL, '3', NULL, 0, 0),
(262, 6, 28, 'Target cell', NULL, '3', NULL, 0, 0),
(263, 6, 29, 'Ovalocyte / elliptocyte', NULL, '3', NULL, 0, 0),
(264, 6, 30, 'Schistocyte / fragmented cells', NULL, '3', NULL, 0, 0),
(265, 6, 31, 'Tear drop cell', NULL, '3', NULL, 0, 0),
(266, 6, 32, 'Spherocyte', NULL, '3', NULL, 0, 0),
(267, 6, 33, 'Defected spherocyte / IRC', NULL, '3', NULL, 0, 0),
(268, 6, 34, 'Bite cell', NULL, '3', NULL, 0, 0),
(269, 6, 35, 'Blister cell / rbc with contracted  Hb', NULL, '3', NULL, 0, 0),
(270, 6, 36, 'Burr cell', NULL, '3', NULL, 0, 0),
(271, 6, 37, 'Acanthocyte', NULL, '3', NULL, 0, 0),
(272, 6, 38, 'Stomatocyte', NULL, '3', NULL, 0, 0),
(273, 6, 39, 'Hypochromia*', NULL, '3', NULL, 0, 0),
(274, 6, 40, 'Polychromasia', NULL, '3', NULL, 0, 0),
(275, 6, 41, 'Normal red blood cell', NULL, '4', NULL, 0, 0),
(276, 6, 42, 'Basophilic stippling', NULL, '4', NULL, 0, 0),
(277, 6, 43, 'Howell-Jolly bodies', NULL, '4', NULL, 0, 0),
(278, 6, 44, 'Pappenheimer bodies', NULL, '4', NULL, 0, 0),
(279, 6, 45, 'Cabot’s ring', NULL, '4', NULL, 0, 0),
(280, 6, 46, 'Agglutination', NULL, '4', NULL, 0, 0),
(281, 6, 47, 'Rouleaux formation', NULL, '4', NULL, 0, 0),
(282, 6, 48, 'Nucleated red blood cell (โปรดระบุระยะของเซลล์ที่พบ)', 1, '4', NULL, 0, 0),
(283, 6, 49, 'Platelet  ', NULL, '5', NULL, 0, 0),
(531, 2, NULL, NULL, NULL, NULL, NULL, 0, 0),
(284, 6, 50, 'Pale  stained platelet', NULL, '6', NULL, 0, 0),
(285, 6, 51, 'Giant platelet', NULL, '6', NULL, 0, 0),
(286, 6, 52, 'Micromegakaryocyte / megakaryocyte fragment', NULL, '6', NULL, 0, 0),
(287, 6, 53, 'Other abnormalities (โปรดระบุ)', 1, '6', NULL, 0, 0),
(288, 12, 65, 'No AFB Observed', NULL, '1', NULL, 0, 0),
(289, 12, 66, '1-9 AFB per 100 fields', NULL, '1', NULL, 0, 0),
(290, 12, 67, 'AFB 1+ (10-99 AFB/100 fields)', NULL, '1', NULL, 0, 0),
(291, 12, 68, 'AFB 2+ (1-10 AFB per field in 50 fields)', 1, '1', NULL, 0, 0),
(292, 12, 69, 'AFB 3+ (more than 10 AFB per field in 20 fields)', NULL, '1', NULL, 0, 0),
(293, 12, 70, 'Conventional tests', NULL, '2', NULL, 0, 0),
(294, 12, 71, 'VITEK', NULL, '2', NULL, 0, 0),
(295, 12, 72, 'VITEK 2', NULL, '2', NULL, 0, 0),
(296, 12, 73, 'MicroScan', NULL, '2', NULL, 0, 0),
(297, 12, 74, 'MALDI-TOF (bioMerieux)', NULL, '2', NULL, 0, 0),
(298, 12, 75, 'MALDI-TOF (Bruker)', NULL, '2', NULL, 0, 0),
(457, 12, 1, 'Kinyoun stain', NULL, '4', NULL, 0, 0),
(299, 12, 76, 'Molecular techniques', NULL, '2', NULL, 0, 0),
(300, 12, 77, 'API (bioMerieux)', NULL, '2', NULL, 0, 0),
(301, 12, 78, 'Rapid Test NF PLUS', NULL, '2', NULL, 0, 0),
(302, 12, 79, 'Phoenix M50', NULL, '2', NULL, 0, 0),
(303, 12, 80, 'Other…', 1, '2', NULL, 0, 0),
(304, 12, 81, 'Question Type', NULL, '3', NULL, 0, 0),
(305, 12, 82, 'Disc diffusion', NULL, '3', NULL, 0, 0),
(306, 12, 83, 'VITEK', NULL, '3', NULL, 0, 0),
(307, 12, 84, 'VITEK 2', NULL, '3', NULL, 0, 0),
(308, 12, 85, 'Phoenix M50', NULL, '3', NULL, 0, 0),
(309, 12, 86, 'MicroScan', NULL, '3', NULL, 0, 0),
(310, 12, 87, 'Sensititre', NULL, '3', NULL, 0, 0),
(311, 12, 88, 'Other…', 1, '3', NULL, 0, 0),
(344, 12, 2, 'Ziehl-Neelsen stain', NULL, '4', NULL, 0, 0),
(342, 12, 3, 'Auramine Rhodamine Fluorochrome stain', NULL, '4', NULL, 0, 0),
(340, 12, 4, 'Other ระบุ', 1, '4', NULL, 0, 0),
(317, 10, 1, 'Gram positive cocci in clusters, single, pairs and short chains', NULL, NULL, NULL, 0, 0),
(318, 10, 2, 'Gram positive cocci in chains', NULL, NULL, NULL, 0, 0),
(319, 10, 3, 'Gram positive cocci in tetrads', NULL, NULL, NULL, 0, 0),
(320, 10, 4, 'Gram positive large bacilli with spore', NULL, NULL, NULL, 0, 0),
(321, 10, 5, 'Gram positive bacilli, regular rod', NULL, NULL, NULL, 0, 0),
(322, 10, 6, 'Gram positive large bacilli', NULL, NULL, NULL, 0, 0),
(323, 10, 7, 'Gram positive irregular bacilli', NULL, NULL, NULL, 0, 0),
(324, 10, 8, 'Gram positive diplococci in lancet shape', NULL, NULL, NULL, 0, 0),
(325, 10, 9, 'Gram positive bacilli with terminal spore', NULL, NULL, NULL, 0, 0),
(326, 10, 10, 'Gram positive bacilli in Chinese letter or palisade', NULL, NULL, NULL, 0, 0),
(327, 10, 11, 'Gram negative coccobacilli', NULL, NULL, NULL, 0, 0),
(328, 10, 12, 'Gram negative cocci and coccobacilli', NULL, NULL, NULL, 0, 0),
(329, 10, 13, 'Gram negative diplococci in kidney shape', NULL, NULL, NULL, 0, 0),
(330, 10, 14, 'Gram negative bacilli', NULL, NULL, NULL, 0, 0),
(331, 10, 15, 'Gram negative pleomorphic bacilli', NULL, NULL, NULL, 0, 0),
(332, 10, 16, 'Gram negative bacilli with bipolar staining', NULL, NULL, NULL, 0, 0),
(333, 13, 1, 'Disc diffusion', NULL, '1', NULL, 0, 0),
(334, 13, 2, 'VITEX', NULL, '1', NULL, 0, 0),
(343, 13, 3, 'VITEX 2', NULL, '1', NULL, 0, 0),
(341, 13, 4, 'Phoenix m50', NULL, '1', NULL, 0, 0),
(339, 13, 5, 'MicroScan', NULL, '1', NULL, 0, 0),
(337, 13, 6, 'Sensititre', NULL, '1', NULL, 0, 0),
(335, 13, 7, 'Other', 1, '1', NULL, 0, 0),
(476, 9, 1, 'HBs Ag', NULL, NULL, 'true', 0, 0),
(477, 9, 2, 'Anti HBs', NULL, NULL, 'true', 0, 0),
(513, 8, NULL, NULL, NULL, NULL, NULL, 0, 0),
(439, 2, 1, 'Total T3 (ng/dL)', NULL, NULL, NULL, 3, 0),
(436, 2, 2, 'Total T4 (ug/dL)', NULL, NULL, NULL, 3, 0),
(434, 2, 3, 'FT3 (pg/mL)', NULL, NULL, NULL, 3, 0),
(432, 2, 4, 'FT4 (ng/dL)', NULL, NULL, NULL, 3, 0),
(430, 2, 5, 'TSH (uIU/mL)', NULL, NULL, NULL, 3, 0),
(459, 13, 1, 'Conventional tests', NULL, '3', NULL, 0, 0),
(460, 13, 2, 'VITEK', NULL, '3', NULL, 0, 0),
(461, 13, 3, 'VITEK 2', NULL, '3', NULL, 0, 0),
(462, 13, 4, 'MicroScan', NULL, '3', NULL, 0, 0),
(463, 13, 5, 'MALDI-TOF (bioMerieux)', NULL, '3', NULL, 0, 0),
(464, 13, 6, 'MALDI-TOF (Bruker)', NULL, '3', NULL, 0, 0),
(466, 13, 7, 'Molecular techniques', NULL, '3', NULL, 0, 0),
(467, 13, 8, 'API (bioMerieux)', NULL, '3', NULL, 0, 0),
(468, 13, 9, 'Rapid Test NF PLUS', NULL, '3', NULL, 0, 0),
(469, 13, 10, 'Phoenix M50', NULL, '3', NULL, 0, 0),
(470, 13, 11, 'Other…', 1, '3', NULL, 0, 0),
(471, 13, 1, 'Susceptible', NULL, '4', NULL, 0, 0),
(472, 13, 2, 'Susceptible dose dependent', NULL, '4', NULL, 0, 0),
(473, 13, 3, 'Intermedate', NULL, '4', NULL, 0, 0),
(474, 13, 4, 'Resistant', NULL, '4', NULL, 0, 0),
(475, 9, 3, 'Anti HBc', NULL, NULL, NULL, 0, 0),
(478, 9, 4, 'HBe Ag', NULL, NULL, NULL, 0, 0),
(479, 9, 5, 'Anti HBe', NULL, NULL, NULL, 0, 0),
(480, 1, 1, 'Albumin (g/dL)', NULL, '1', '[\"48\",\"2\",\"3\"]', 2, 0),
(481, 1, 2, 'ALP (U/L)', NULL, NULL, '[\"44\",\"45\",\"46\",\"48\",\"43\",\"4\"]', 0, 0),
(482, 1, 3, 'ALT (U/L)', NULL, NULL, '[\"46\",\"48\",\"34\",\"35\",\"4\",\"11\"]', 0, 0),
(483, 1, 4, 'Amylase, Total  (U/L)', NULL, NULL, '[\"48\",\"41\",\"8\",\"23\"]', 0, 0),
(484, 1, 5, 'AST  (U/L)', NULL, NULL, '[\"46\",\"48\",\"34\",\"35\",\"4\",\"11\"]', 0, 0),
(485, 1, 6, 'BUN (mg/dL)', NULL, NULL, '[\"46\",\"48\",\"18\",\"22\"]', 1, 0),
(486, 1, 7, 'Bilirubin, Total  (mg/dL)', NULL, NULL, '[\"33\",\"46\",\"48\",\"36\",\"12\",\"14\",\"52\",\"53\"]', 2, 0),
(487, 1, 8, 'Calcium (mg/dL)', NULL, NULL, '[\"54\",\"48\",\"10\",\"30\"]', 1, 0),
(488, 1, 9, 'Chloride (mmol/L)', NULL, NULL, '[\"49\",\"16\",\"29\"]', 0, 0),
(489, 1, 11, 'CK, Total (U/L)', NULL, NULL, '[\"46\",\"48\",\"7\",\"9\"]', 0, 0),
(490, 1, 12, 'Creatinine (mg/dL)', NULL, '1', '[\"32\",\"46\",\"48\",\"18\",\"31\"]', 2, 0),
(491, 1, 13, 'GGT (U/L)', NULL, NULL, '[\"46\",\"48\",\"11\",\"19\",\"22\"]', 0, 0),
(492, 1, 14, 'Glucose (mg/dL)', NULL, NULL, '[\"46\",\"48\",\"24\",\"26\",\"27\"]', 0, 0),
(493, 1, 10, 'Cholesterol (mg/dL)', NULL, NULL, '[\"46\",\"48\",\"4\",\"11\",\"19\"]', 0, 0),
(494, 1, 15, 'HDL-cholesterol (mg/dL)', NULL, NULL, '[\"46\",\"48\",\"41\",\"42\",\"15\",\"50\",\"51\"]', 1, 0),
(495, 1, 17, 'LDL-cholesterol (mg/dL)', NULL, NULL, '[\"41\",\"15\",\"50\"]', 1, 0),
(496, 1, 16, 'LDH (U/L)', NULL, NULL, '[\"47\",\"48\",\"4\",\"13\",\"28\"]', 0, 0),
(497, 1, 18, 'Magnesium (mg/dL)', NULL, NULL, '[\"48\",\"37\",\"38\",\"41\",\"1\"]', 1, 0),
(498, 1, 19, 'Phosphorus, Inorganic (mg/dL)', NULL, NULL, '[\"48\",\"39\",\"40\"]', 1, 0),
(499, 1, 20, 'Potassium (mmol/L)', NULL, NULL, '[\"49\",\"16\",\"29\"]', 2, 0),
(500, 1, 21, 'Total Protein (g/dL)', NULL, NULL, '[\"48\",\"5\",\"6\"]', 2, 0),
(501, 1, 22, 'Sodium (mmol/L)', NULL, NULL, '[\"49\",\"16\",\"29\"]', 1, 0),
(502, 1, 23, 'Triglyceride (mg/dL)', NULL, NULL, '[\"46\",\"48\",\"11\",\"17\",\"25\"]', 0, 0),
(503, 1, 24, 'Uric acid (mg/dL)', NULL, NULL, '[\"46\",\"48\",\"11\",\"20\",\"21\"]', 2, 0),
(504, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0),
(505, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0),
(515, 4, NULL, NULL, NULL, NULL, NULL, 0, 0),
(522, 12, NULL, NULL, NULL, NULL, NULL, 0, 0),
(525, 7, 70, 'Other (โปรดระบุ)', NULL, '2', NULL, 0, 0),
(528, 10, 17, 'Gram negative curved bacilli', NULL, NULL, NULL, 0, 0),
(529, 10, 18, 'Gram negative bacilli, seagull wing', NULL, NULL, NULL, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `mhd_program_infection_backup`
--

CREATE TABLE `mhd_program_infection_backup` (
  `id` int(11) NOT NULL,
  `program_id` int(11) DEFAULT NULL,
  `code` int(255) DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `other` int(11) DEFAULT NULL,
  `section` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `event` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fix_decimal` int(255) NOT NULL DEFAULT 0,
  `del` int(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `mhd_program_infection_backup`
--

INSERT INTO `mhd_program_infection_backup` (`id`, `program_id`, `code`, `name`, `other`, `section`, `event`, `fix_decimal`, `del`) VALUES
(61, 5, 1, 'WBC (x10<sup>9</sup>/L) ', NULL, NULL, NULL, 0, 0),
(62, 5, 2, 'RBC (x10<sup>12</sup>/L)', NULL, NULL, NULL, 0, 0),
(63, 5, 3, 'Hb (g/dL)', NULL, NULL, NULL, 0, 0),
(64, 5, 4, 'Hct (%)', NULL, NULL, NULL, 0, 0),
(65, 5, 5, 'MCV (fL)', NULL, NULL, NULL, 0, 0),
(66, 5, 6, 'MCH (pg)', NULL, NULL, NULL, 0, 0),
(67, 5, 7, 'MCHC (g/dL)', NULL, NULL, NULL, 0, 0),
(68, 5, 8, 'RDW (%)', NULL, NULL, NULL, 0, 0),
(69, 5, 9, 'PLT (x10<sup>9</sup>/L)', NULL, NULL, NULL, 0, 0),
(70, 3, 1, 'AFP* IU/mL', NULL, NULL, NULL, 3, 0),
(71, 3, 2, 'CEA ng/mL', NULL, NULL, NULL, 3, 0),
(72, 3, 3, 'PSA ng/mL', NULL, NULL, NULL, 3, 0),
(73, 3, 4, 'CA 125 u/mL', NULL, NULL, NULL, 3, 0),
(74, 3, 5, 'CA 15-3 u/mL', NULL, NULL, NULL, 3, 0),
(75, 3, 6, 'CA 19-9 u/mL', NULL, NULL, NULL, 3, 0),
(76, 3, 7, 'B-hCG mIU/mL', NULL, NULL, NULL, 3, 0),
(77, 17, 1, 'Lymphoblast', NULL, '1', NULL, 0, 0),
(78, 17, 2, 'Prolymphocyte', NULL, '1', NULL, 0, 0),
(79, 17, 3, 'Monoblast', NULL, '1', NULL, 0, 0),
(80, 17, 4, 'Promonocyte', NULL, '1', NULL, 0, 0),
(81, 17, 5, 'Myeloblast', NULL, '1', NULL, 0, 0),
(82, 17, 6, 'Promyelocyte', NULL, '1', NULL, 0, 0),
(83, 17, 7, 'Neutrophilic myelocyte', NULL, '1', NULL, 0, 0),
(84, 17, 8, 'Eosinophilic myelocyte', NULL, '1', NULL, 0, 0),
(85, 17, 9, 'Basophilic myelocyte', NULL, '1', NULL, 0, 0),
(86, 17, 10, 'Neutrophilic metamyelocyte', NULL, '1', NULL, 0, 0),
(87, 17, 11, 'Eosinophilic metamyelocyte', NULL, '1', NULL, 0, 0),
(88, 17, 12, 'Basophilic metamyelocyte', NULL, '1', NULL, 0, 0),
(89, 17, 13, 'Band form neutrophil', NULL, '1', NULL, 0, 0),
(90, 17, 14, 'Neutrophil', NULL, '1', NULL, 0, 0),
(91, 17, 15, 'Eosinophil', NULL, '1', NULL, 0, 0),
(92, 17, 16, 'Basophil', NULL, '1', NULL, 0, 0),
(93, 17, 17, 'Monocyte', NULL, '1', NULL, 0, 0),
(94, 17, 18, 'Small lymphocyte', NULL, '1', NULL, 0, 0),
(95, 17, 19, 'Large lymphocyte', NULL, '1', NULL, 0, 0),
(96, 17, 20, 'Atypical lymphocyte', NULL, '1', NULL, 0, 0),
(97, 17, 21, 'Plasma cell', NULL, '1', NULL, 0, 0),
(98, 17, 22, 'Auer rod', NULL, '1', NULL, 0, 0),
(99, 17, 23, 'Faggot cell', NULL, '1', NULL, 0, 0),
(100, 17, 24, 'Döhle body', NULL, '1', NULL, 0, 0),
(101, 17, 25, 'Neutrophil with toxic granule', NULL, '1', NULL, 0, 0),
(102, 17, 26, 'Neutrophil with vacuolization', NULL, '1', NULL, 0, 0),
(103, 17, 27, 'Hypersegmented neutrophil', NULL, '1', NULL, 0, 0),
(104, 17, 28, 'Hyposegmented  neutrophil', NULL, '1', NULL, 0, 0),
(105, 17, 29, 'Smudge cell / Basket cell', NULL, '1', NULL, 0, 0),
(106, 17, 30, 'Pyknotic cell', NULL, '1', NULL, 0, 0),
(107, 17, 31, 'Platelet satellitism', NULL, '1', NULL, 0, 0),
(108, 17, 32, 'Platelet clumping', NULL, '1', NULL, 0, 0),
(109, 17, 33, 'Pale stained platelet', NULL, '1', NULL, 0, 0),
(110, 17, 34, 'Giant platelet', NULL, '1', NULL, 0, 0),
(111, 17, 35, 'Micromegakaryocyte', NULL, '1', NULL, 0, 0),
(112, 17, 37, 'Pronormoblast', NULL, '2', NULL, 0, 0),
(113, 17, 38, 'Basophilic normoblast', NULL, '2', NULL, 0, 0),
(114, 17, 39, 'Polychromatic normoblast', NULL, '2', NULL, 0, 0),
(115, 17, 40, 'Orthochromatic normoblast', NULL, '2', NULL, 0, 0),
(116, 17, 41, 'Polychromasia', NULL, '2', NULL, 0, 0),
(117, 17, 42, 'Reticulocyte', NULL, '2', NULL, 0, 0),
(118, 17, 43, 'Normal red blood cell', NULL, '2', NULL, 0, 0),
(119, 17, 44, 'Microcyte', NULL, '2', NULL, 0, 0),
(120, 17, 45, 'Round macrocyte', NULL, '2', NULL, 0, 0),
(121, 17, 46, 'Oval macrocyte', NULL, '2', NULL, 0, 0),
(122, 17, 47, 'Ovalocyte/Elliptocyte', NULL, '2', NULL, 0, 0),
(123, 17, 48, 'Target cell', NULL, '2', NULL, 0, 0),
(124, 17, 49, 'Schistocyte/Fragmented cells', NULL, '2', NULL, 0, 0),
(125, 17, 50, 'Crenated red blood cell', NULL, '2', NULL, 0, 0),
(126, 17, 51, 'Teardrop cell', NULL, '2', NULL, 0, 0),
(127, 17, 52, 'Sickle cell', NULL, '2', NULL, 0, 0),
(128, 17, 53, 'Spherocyte', NULL, '2', NULL, 0, 0),
(129, 17, 54, 'Irregular contracted RBC (IRC)', NULL, '2', NULL, 0, 0),
(130, 17, 55, 'Bite cell', NULL, '2', NULL, 0, 0),
(131, 17, 56, 'Blister cell', NULL, '2', NULL, 0, 0),
(132, 17, 57, 'Burr cell', NULL, '2', NULL, 0, 0),
(133, 17, 58, 'Acanthocyte', NULL, '2', NULL, 0, 0),
(134, 17, 59, 'Stomatocyte', NULL, '2', NULL, 0, 0),
(135, 17, 60, 'Stomato-ovalocyte', NULL, '2', NULL, 0, 0),
(136, 17, 61, 'Hypochromia', NULL, '2', NULL, 0, 0),
(137, 17, 62, 'Basophilic stippling', NULL, '2', NULL, 0, 0),
(138, 17, 63, 'Howell - Jolly bodies', NULL, '2', NULL, 0, 0),
(139, 17, 64, 'Cabot’s ring', NULL, '2', NULL, 0, 0),
(140, 17, 65, 'Pappenheimer bodies', NULL, '2', NULL, 0, 0),
(141, 17, 66, 'Hb H inclusion bodies', NULL, '2', NULL, 0, 0),
(142, 17, 67, 'Heinz’s body', NULL, '2', NULL, 0, 0),
(143, 17, 68, 'Red cell agglutination', NULL, '2', NULL, 0, 0),
(144, 17, 69, 'Rouleaux formation', NULL, '2', NULL, 0, 0),
(146, 17, 36, 'Megakaryocyte fragment', 1, '2', NULL, 0, 0),
(147, 17, 1, 'Red blood cell', NULL, '3', NULL, 0, 0),
(148, 17, 2, 'Dysmorphic Rbc ', NULL, '3', NULL, 0, 0),
(149, 17, 4, 'White blood cell', NULL, '3', NULL, 0, 0),
(150, 17, 5, 'Wbc with clumping ', NULL, '3', NULL, 0, 0),
(151, 17, 6, 'Macrophage', NULL, '3', NULL, 0, 0),
(152, 17, 7, 'Squamous epithelial cell', NULL, '3', NULL, 0, 0),
(153, 17, 8, 'Transitional epithelial cell', NULL, '3', NULL, 0, 0),
(154, 17, 9, 'Renal epithelial cell', NULL, '3', NULL, 0, 0),
(155, 17, 10, 'Oval fat body', NULL, '3', NULL, 0, 0),
(156, 17, 11, 'Spermatozoa', NULL, '3', NULL, 0, 0),
(157, 17, 12, 'Bacteria', NULL, '3', NULL, 0, 0),
(158, 17, 13, 'Budding yeast', NULL, '3', NULL, 0, 0),
(159, 17, 14, 'Pseudohyphae', NULL, '3', NULL, 0, 0),
(160, 17, 15, 'T. vaginalis', NULL, '3', NULL, 0, 0),
(161, 17, 16, 'Atypical cell with high N : C', NULL, '3', NULL, 0, 0),
(162, 17, 17, 'Hyaline cast', NULL, '3', NULL, 0, 0),
(163, 17, 18, 'Granular cast', NULL, '3', NULL, 0, 0),
(164, 17, 19, 'Rbc cast', NULL, '3', NULL, 0, 0),
(165, 17, 20, 'Heme cast', NULL, '3', NULL, 0, 0),
(166, 17, 21, 'Wbc cast', NULL, '3', NULL, 0, 0),
(167, 17, 22, 'Renal epithelial cell cast', NULL, '3', NULL, 0, 0),
(168, 17, 23, 'Mixed cellular cast', NULL, '3', NULL, 0, 0),
(169, 17, 24, 'Bacterial  cast', NULL, '4', NULL, 0, 0),
(170, 17, 25, 'Waxy cast ', NULL, '4', NULL, 0, 0),
(171, 17, 26, 'Fatty cast', NULL, '4', NULL, 0, 0),
(172, 17, 27, 'Broad cast', NULL, '4', NULL, 0, 0),
(173, 17, 28, 'Uric acid crystal', NULL, '4', NULL, 0, 0),
(174, 17, 29, 'Calcium oxalate crystal', NULL, '4', NULL, 0, 0),
(175, 17, 30, 'Calcium carbonate crystal', NULL, '4', NULL, 0, 0),
(176, 17, 31, 'Calcium phosphate crystal', NULL, '4', NULL, 0, 0),
(177, 17, 32, 'Ammonium urate crystal', NULL, '4', NULL, 0, 0),
(178, 17, 33, 'Ammonium biurate crystal', NULL, '4', NULL, 0, 0),
(179, 17, 34, 'Triple phosphate crystal', NULL, '4', NULL, 0, 0),
(180, 17, 35, 'Cystine crystal', NULL, '4', NULL, 0, 0),
(181, 17, 36, 'Tyrosine crystal', NULL, '4', NULL, 0, 0),
(182, 17, 37, 'Leucine crystal', NULL, '4', NULL, 0, 0),
(183, 17, 38, 'Sulfonamide crystal', NULL, '4', NULL, 0, 0),
(184, 17, 39, 'Cholesterol crystal', NULL, '4', NULL, 0, 0),
(185, 17, 40, 'Bilirubin crystal', NULL, '4', NULL, 0, 0),
(186, 17, 41, 'Amorphous ', NULL, '4', NULL, 0, 0),
(187, 17, 42, 'Mucous thread', NULL, '4', NULL, 0, 0),
(188, 17, 43, 'Fat droplet', NULL, '4', NULL, 0, 0),
(189, 17, 44, 'Starch granule', NULL, '4', NULL, 0, 0),
(190, 17, 45, 'Other (โปรดระบุ)', 1, '4', NULL, 0, 0),
(235, 16, 1, 'Blast cell (cannot be identified)', NULL, '1', NULL, 0, 0),
(236, 16, 2, 'Lymphoblast/prolymphocyte', NULL, '1', NULL, 0, 0),
(237, 16, 3, 'Monoblast/promonocyte', NULL, '1', NULL, 0, 0),
(238, 16, 4, 'Myeloblast', NULL, '1', NULL, 0, 0),
(239, 16, 5, 'Promyelocyte', NULL, '1', NULL, 0, 0),
(240, 16, 6, 'Myelocyte', NULL, '1', NULL, 0, 0),
(241, 16, 7, 'Metamyelocyte', NULL, '1', NULL, 0, 0),
(242, 16, 8, 'Band form neutrophil', NULL, '1', NULL, 0, 0),
(243, 16, 9, 'Neutrophil', NULL, '1', NULL, 0, 0),
(244, 16, 10, 'Eosinophil', NULL, '1', NULL, 0, 0),
(245, 16, 11, 'Basophil', NULL, '1', NULL, 0, 0),
(246, 16, 12, 'Monocyte', NULL, '1', NULL, 0, 0),
(247, 16, 13, 'Lymphocyte', NULL, '1', NULL, 0, 0),
(248, 16, 14, 'Atypical lymphocyte', NULL, '1', NULL, 0, 0),
(249, 16, 15, 'Plasma cell', NULL, '1', NULL, 0, 0),
(250, 16, 16, 'NRBC (....../ WBC 100 เซลล์)', NULL, '1', NULL, 0, 0),
(251, 16, 17, 'Auer rod', NULL, '2', NULL, 0, 0),
(252, 16, 18, 'Döhle bodies', NULL, '2', NULL, 0, 0),
(253, 16, 19, 'Toxic granules in neutrophil', NULL, '2', NULL, 0, 0),
(254, 16, 20, 'Vacuolization in  neutrophil', NULL, '2', NULL, 0, 0),
(255, 16, 21, 'Hypersegmented  neutrophil', NULL, '2', NULL, 0, 0),
(256, 16, 22, 'Pelger - Huët anomaly', NULL, '2', NULL, 0, 0),
(257, 16, 23, 'Anisocytosis', NULL, '3', NULL, 0, 0),
(258, 16, 24, 'Poikilocytosis', NULL, '3', NULL, 0, 0),
(259, 16, 25, 'Microcyte*', NULL, '3', NULL, 0, 0),
(260, 16, 26, 'Round macrocyte', NULL, '3', NULL, 0, 0),
(261, 16, 27, 'Oval macrocyte', NULL, '3', NULL, 0, 0),
(262, 16, 28, 'Target cell', NULL, '3', NULL, 0, 0),
(263, 16, 29, 'Ovalocyte / elliptocyte', NULL, '3', NULL, 0, 0),
(264, 16, 30, 'Schistocyte / fragmented cells', NULL, '3', NULL, 0, 0),
(265, 16, 31, 'Tear drop cell', NULL, '3', NULL, 0, 0),
(266, 16, 32, 'Spherocyte', NULL, '3', NULL, 0, 0),
(267, 16, 33, 'Defected spherocyte / IRC', NULL, '3', NULL, 0, 0),
(268, 16, 34, 'Bite cell', NULL, '3', NULL, 0, 0),
(269, 16, 35, 'Blister cell / rbc with contracted  Hb', NULL, '3', NULL, 0, 0),
(270, 16, 36, 'Burr cell', NULL, '3', NULL, 0, 0),
(271, 16, 37, 'Acanthocyte', NULL, '3', NULL, 0, 0),
(272, 16, 38, 'Stomatocyte', NULL, '3', NULL, 0, 0),
(273, 16, 39, 'Hypochromia*', NULL, '3', NULL, 0, 0),
(274, 16, 40, 'Polychromasia', NULL, '3', NULL, 0, 0),
(275, 16, 41, 'Normal red blood cell', NULL, '4', NULL, 0, 0),
(276, 16, 42, 'Basophilic stippling', NULL, '4', NULL, 0, 0),
(277, 16, 43, 'Howell-Jolly bodies', NULL, '4', NULL, 0, 0),
(278, 16, 44, 'Pappenheimer bodies', NULL, '4', NULL, 0, 0),
(279, 16, 45, 'Cabot’s ring', NULL, '4', NULL, 0, 0),
(280, 16, 46, 'Agglutination', NULL, '4', NULL, 0, 0),
(281, 16, 47, 'Rouleaux formation', NULL, '4', NULL, 0, 0),
(282, 16, 48, 'Nucleated red blood cell (โปรดระบุระยะของเซลล์ที่พบ)', 1, '4', NULL, 0, 0),
(283, 16, 49, 'Platelet  ', NULL, '5', NULL, 0, 0),
(284, 16, 50, 'Pale  stained platelet', NULL, '6', NULL, 0, 0),
(285, 16, 51, 'Giant platelet', NULL, '6', NULL, 0, 0),
(286, 16, 52, 'Micromegakaryocyte / megakaryocyte fragment', NULL, '6', NULL, 0, 0),
(287, 16, 53, 'Other abnormalities (โปรดระบุ)', 1, '6', NULL, 0, 0),
(288, 12, 65, 'No AFB Observed', NULL, '1', NULL, 0, 0),
(289, 12, 66, '1-9 AFB per 100 fields', NULL, '1', NULL, 0, 0),
(290, 12, 67, 'AFB 1+ (10-99 AFB/100 fields)', NULL, '1', NULL, 0, 0),
(291, 12, 68, 'AFB 2+ (1-10 AFB per field in 50 fields)', 1, '1', NULL, 0, 0),
(292, 12, 69, 'AFB 3+ (more than 10 AFB per field in 20 fields)', NULL, '1', NULL, 0, 0),
(293, 12, 70, 'Conventional tests', NULL, '2', NULL, 0, 0),
(294, 12, 71, 'VITEK', NULL, '2', NULL, 0, 0),
(295, 12, 72, 'VITEK 2', NULL, '2', NULL, 0, 0),
(296, 12, 73, 'MicroScan', NULL, '2', NULL, 0, 0),
(297, 12, 74, 'MALDI-TOF (bioMerieux)', NULL, '2', NULL, 0, 0),
(298, 12, 75, 'MALDI-TOF (Bruker)', NULL, '2', NULL, 0, 0),
(299, 12, 76, 'Molecular techniques', NULL, '2', NULL, 0, 0),
(300, 12, 77, 'API (bioMerieux)', NULL, '2', NULL, 0, 0),
(301, 12, 78, 'Rapid Test NF PLUS', NULL, '2', NULL, 0, 0),
(302, 12, 79, 'Phoenix M50', NULL, '2', NULL, 0, 0),
(303, 12, 80, 'Other…', 1, '2', NULL, 0, 0),
(304, 12, 81, 'Question Type', NULL, '3', NULL, 0, 0),
(305, 12, 82, 'Disc diffusion', NULL, '3', NULL, 0, 0),
(306, 12, 83, 'VITEK', NULL, '3', NULL, 0, 0),
(307, 12, 84, 'VITEK 2', NULL, '3', NULL, 0, 0),
(308, 12, 85, 'Phoenix M50', NULL, '3', NULL, 0, 0),
(309, 12, 86, 'MicroScan', NULL, '3', NULL, 0, 0),
(310, 12, 87, 'Sensititre', NULL, '3', NULL, 0, 0),
(311, 12, 88, 'Other…', 1, '3', NULL, 0, 0),
(317, 10, 1, 'Gram positive cocci in clusters, single, pairs and short chains', NULL, NULL, NULL, 0, 0),
(318, 10, 2, 'Gram positive cocci in chains', NULL, NULL, NULL, 0, 0),
(319, 10, 3, 'Gram positive cocci in tetrads', NULL, NULL, NULL, 0, 0),
(320, 10, 4, 'Gram positive large bacilli with spore', NULL, NULL, NULL, 0, 0),
(321, 10, 5, 'Gram positive bacilli, regular rod', NULL, NULL, NULL, 0, 0),
(322, 10, 6, 'Gram positive large bacilli', NULL, NULL, NULL, 0, 0),
(323, 10, 7, 'Gram positive irregular bacilli', NULL, NULL, NULL, 0, 0),
(324, 10, 8, 'Gram positive diplococci in lancet shape', NULL, NULL, NULL, 0, 0),
(325, 10, 9, 'Gram positive bacilli with terminal spore', NULL, NULL, NULL, 0, 0),
(326, 10, 10, 'Gram positive bacilli in Chinese letter or palisade', NULL, NULL, NULL, 0, 0),
(327, 10, 11, 'Gram negative coccobacilli', NULL, NULL, NULL, 0, 0),
(328, 10, 12, 'Gram negative cocci and coccobacilli', NULL, NULL, NULL, 0, 0),
(329, 10, 13, 'Gram negative diplococci in kidney shape', NULL, NULL, NULL, 0, 0),
(330, 10, 14, 'Gram negative bacilli', NULL, NULL, NULL, 0, 0),
(331, 10, 15, 'Gram negative pleomorphic bacilli', NULL, NULL, NULL, 0, 0),
(332, 10, 16, 'Gram negative bacilli with bipolar staining', NULL, NULL, NULL, 0, 0),
(333, 13, 1, 'Disc diffusion', NULL, '1', NULL, 0, 0),
(334, 13, 2, 'VITEX', NULL, '1', NULL, 0, 0),
(335, 13, 7, 'Other', 1, '1', NULL, 0, 0),
(337, 13, 6, 'Sensititre', NULL, '1', NULL, 0, 0),
(339, 13, 5, 'MicroScan', NULL, '1', NULL, 0, 0),
(340, 12, 4, 'Other ระบุ', 1, '4', NULL, 0, 0),
(341, 13, 4, 'Phoenix m50', NULL, '1', NULL, 0, 0),
(342, 12, 3, 'Auramine Rhodamine Fluorochrome stain', NULL, '4', NULL, 0, 0),
(343, 13, 3, 'VITEX 2', NULL, '1', NULL, 0, 0),
(344, 12, 2, 'Ziehl-Neelsen stain', NULL, '4', NULL, 0, 0),
(430, 2, 5, 'TSH (uIU/mL)', NULL, NULL, NULL, 3, 0),
(432, 2, 4, 'FT4 (ng/dL)', NULL, NULL, NULL, 3, 0),
(434, 2, 3, 'FT3 (pg/mL)', NULL, NULL, NULL, 3, 0),
(436, 2, 2, 'Total T4 (ug/dL)', NULL, NULL, NULL, 3, 0),
(439, 2, 1, 'Total T3 (ng/dL)', NULL, NULL, NULL, 3, 0),
(457, 12, 1, 'Kinyoun stain', NULL, '4', NULL, 0, 0),
(459, 13, 1, 'Conventional tests', NULL, '3', NULL, 0, 0),
(460, 13, 2, 'VITEK', NULL, '3', NULL, 0, 0),
(461, 13, 3, 'VITEK 2', NULL, '3', NULL, 0, 0),
(462, 13, 4, 'MicroScan', NULL, '3', NULL, 0, 0),
(463, 13, 5, 'MALDI-TOF (bioMerieux)', NULL, '3', NULL, 0, 0),
(464, 13, 6, 'MALDI-TOF (Bruker)', NULL, '3', NULL, 0, 0),
(466, 13, 7, 'Molecular techniques', NULL, '3', NULL, 0, 0),
(467, 13, 8, 'API (bioMerieux)', NULL, '3', NULL, 0, 0),
(468, 13, 9, 'Rapid Test NF PLUS', NULL, '3', NULL, 0, 0),
(469, 13, 10, 'Phoenix M50', NULL, '3', NULL, 0, 0),
(470, 13, 11, 'Other…', 1, '3', NULL, 0, 0),
(471, 13, 1, 'Susceptible', NULL, '4', NULL, 0, 0),
(472, 13, 2, 'Susceptible dose dependent', NULL, '4', NULL, 0, 0),
(473, 13, 3, 'Intermedate', NULL, '4', NULL, 0, 0),
(474, 13, 4, 'Resistant', NULL, '4', NULL, 0, 0),
(475, 9, 3, 'Anti HBc', NULL, NULL, NULL, 0, 0),
(476, 9, 1, 'HBs Ag', NULL, NULL, 'true', 0, 0),
(477, 9, 2, 'Anti HBs', NULL, NULL, 'true', 0, 0),
(478, 9, 4, 'HBe Ag', NULL, NULL, NULL, 0, 0),
(479, 9, 5, 'Anti HBe', NULL, NULL, NULL, 0, 0),
(480, 1, 1, 'Albumin (g/dL)', NULL, '1', '[\"48\",\"2\",\"3\"]', 2, 0),
(481, 1, 2, 'ALP (U/L)', NULL, NULL, '[\"44\",\"45\",\"46\",\"48\",\"43\",\"4\"]', 0, 0),
(482, 1, 3, 'ALT (U/L)', NULL, NULL, '[\"46\",\"48\",\"34\",\"35\",\"4\",\"11\"]', 0, 0),
(483, 1, 4, 'Amylase, Total  (U/L)', NULL, NULL, '[\"48\",\"41\",\"8\",\"23\"]', 0, 0),
(484, 1, 5, 'AST  (U/L)', NULL, NULL, '[\"46\",\"48\",\"34\",\"35\",\"4\",\"11\"]', 0, 0),
(485, 1, 6, 'BUN (mg/dL)', NULL, NULL, '[\"46\",\"48\",\"18\",\"22\"]', 1, 0),
(486, 1, 7, 'Bilirubin, Total  (mg/dL)', NULL, NULL, '[\"33\",\"46\",\"48\",\"36\",\"12\",\"14\",\"52\",\"53\"]', 2, 0),
(487, 1, 8, 'Calcium (mg/dL)', NULL, NULL, '[\"54\",\"48\",\"10\",\"30\"]', 1, 0),
(488, 1, 9, 'Chloride (mmol/L)', NULL, NULL, '[\"49\",\"16\",\"29\"]', 0, 0),
(489, 1, 11, 'CK, Total (U/L)', NULL, NULL, '[\"46\",\"48\",\"7\",\"9\"]', 0, 0),
(490, 1, 12, 'Creatinine (mg/dL)', NULL, '1', '[\"32\",\"46\",\"48\",\"18\",\"31\"]', 2, 0),
(491, 1, 13, 'GGT (U/L)', NULL, NULL, '[\"46\",\"48\",\"11\",\"19\",\"22\"]', 0, 0),
(492, 1, 14, 'Glucose (mg/dL)', NULL, NULL, '[\"46\",\"48\",\"24\",\"26\",\"27\"]', 0, 0),
(493, 1, 10, 'Cholesterol (mg/dL)', NULL, NULL, '[\"46\",\"48\",\"4\",\"11\",\"19\"]', 0, 0),
(494, 1, 15, 'HDL-cholesterol (mg/dL)', NULL, NULL, '[\"46\",\"48\",\"41\",\"42\",\"15\",\"50\",\"51\"]', 1, 0),
(495, 1, 17, 'LDL-cholesterol (mg/dL)', NULL, NULL, '[\"41\",\"15\",\"50\"]', 1, 0),
(496, 1, 16, 'LDH (U/L)', NULL, NULL, '[\"47\",\"48\",\"4\",\"13\",\"28\"]', 0, 0),
(497, 1, 18, 'Magnesium (mg/dL)', NULL, NULL, '[\"48\",\"37\",\"38\",\"41\",\"1\"]', 1, 0),
(498, 1, 19, 'Phosphorus, Inorganic (mg/dL)', NULL, NULL, '[\"48\",\"39\",\"40\"]', 1, 0),
(499, 1, 20, 'Potassium (mmol/L)', NULL, NULL, '[\"49\",\"16\",\"29\"]', 2, 0),
(500, 1, 21, 'Total Protein (g/dL)', NULL, NULL, '[\"48\",\"5\",\"6\"]', 2, 0),
(501, 1, 22, 'Sodium (mmol/L)', NULL, NULL, '[\"49\",\"16\",\"29\"]', 1, 0),
(502, 1, 23, 'Triglyceride (mg/dL)', NULL, NULL, '[\"46\",\"48\",\"11\",\"17\",\"25\"]', 0, 0),
(503, 1, 24, 'Uric acid (mg/dL)', NULL, NULL, '[\"46\",\"48\",\"11\",\"20\",\"21\"]', 2, 0),
(504, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0),
(505, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0),
(513, 8, NULL, NULL, NULL, NULL, NULL, 0, 0),
(515, 4, NULL, NULL, NULL, NULL, NULL, 0, 0),
(522, 10, NULL, NULL, NULL, NULL, NULL, 0, 1),
(525, 17, 70, 'Other (โปรดระบุ)', NULL, '2', NULL, 0, 0),
(526, 17, 3, 'Ghost red blood cell', NULL, '3', NULL, 0, 0),
(528, 10, 17, 'Gram negative curved bacilli', NULL, NULL, NULL, 0, 0),
(529, 10, 18, 'Gram negative bacilli, seagull wing', NULL, NULL, NULL, 0, 0),
(531, 2, NULL, NULL, NULL, NULL, NULL, 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `mhd_program_principle`
--

CREATE TABLE `mhd_program_principle` (
  `id` int(11) NOT NULL,
  `program_id` int(11) DEFAULT NULL,
  `code` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `other` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `del` int(11) DEFAULT 0
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `mhd_program_principle`
--

INSERT INTO `mhd_program_principle` (`id`, `program_id`, `code`, `name`, `other`, `del`) VALUES
(1, 2, '1', 'CLIA', NULL, 0),
(2, 2, '2', 'ECLIA', NULL, 0),
(3, 2, '3', 'ELFA', NULL, 0),
(4, 2, '4', 'CMIA', NULL, 0),
(5, 2, '5', 'FEIA', NULL, 0),
(6, 2, '99', 'Other', '1', 0),
(12, 3, '1', 'CLIA', NULL, 0),
(13, 3, '2', 'ECLIA', NULL, 0),
(14, 3, '3', 'ELFA', NULL, 0),
(15, 3, '4', 'CMIA', NULL, 0),
(16, 3, '5', 'FEIA', NULL, 0),
(17, 3, '6', 'ICMA', '1', 0),
(19, 3, '7', 'IRMA', NULL, 0),
(20, 3, '99', 'Others', NULL, 0);

-- --------------------------------------------------------

--
-- Table structure for table `mhd_program_tools`
--

CREATE TABLE `mhd_program_tools` (
  `id` int(11) NOT NULL,
  `program_id` int(11) DEFAULT NULL,
  `code` varchar(11) COLLATE utf8_unicode_ci DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `other` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `section` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `method` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `del` int(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `mhd_program_tools`
--

INSERT INTO `mhd_program_tools` (`id`, `program_id`, `code`, `name`, `other`, `section`, `method`, `del`) VALUES
(1, 5, '18', 'Sysmex K series, XP series', NULL, '18', NULL, 0),
(2, 5, '15', 'XS series', NULL, '15', NULL, 0),
(3, 5, '17', 'XE series', NULL, '17', NULL, 0),
(4, 5, '14', 'XN series', NULL, '14', NULL, 0),
(5, 5, '1', 'BC 3000 series', NULL, '31', NULL, 0),
(6, 5, '2', 'BC 5000 series', NULL, '32', NULL, 0),
(9, 5, '3', 'BC 6000 series', NULL, '33', NULL, 0),
(10, 5, '7', 'LH', NULL, '27', NULL, 0),
(11, 5, '6', 'DxH ', NULL, '26', NULL, 0),
(16, 5, '22', 'Advia 120/2120', NULL, '67', NULL, 0),
(17, 5, '11', 'Quintus', NULL, '62', NULL, 0),
(20, 5, '4', 'BF 6800', NULL, '4', NULL, 0),
(22, 5, '19', 'Swelab', NULL, '64', NULL, 0),
(24, 5, '20', 'Hycel', NULL, '65', NULL, 0),
(26, 8, '26', 'VDRL', NULL, 'NTP', NULL, 0),
(27, 8, '27', 'RPR', NULL, 'NTP', NULL, 0),
(28, 8, '28', 'Unheated VDLR', NULL, 'NTP', NULL, 0),
(29, 8, '29', 'Other', '1', 'NTP', NULL, 0),
(30, 8, '30', 'TPHA', NULL, 'TP', NULL, 0),
(31, 8, '31', 'FTA-ABS', NULL, 'TP', NULL, 0),
(32, 8, '32', 'TPPA', NULL, 'TP', NULL, 0),
(33, 8, '33', 'Immunochromatography', NULL, 'TP', NULL, 0),
(34, 8, '34', 'CMIA', NULL, 'TP', NULL, 0),
(35, 8, '35', 'ECLIA', NULL, 'TP', NULL, 0),
(36, 8, '40', 'Other', '1', 'TP', NULL, 0),
(37, 8, '37', 'Reactive', NULL, 'Qualitative', NULL, 0),
(38, 8, '38', 'Weakly Reactive', NULL, 'Qualitative', NULL, 0),
(39, 8, '39', 'Non-reactive', NULL, 'Qualitative', NULL, 0),
(40, 3, '01', 'Maglumi Series /800', NULL, NULL, 'CLIA', 0),
(41, 3, '02', 'Abbott, Architect Series /Armity', NULL, NULL, 'CMIA', 0),
(42, 3, '03', 'Siemens, Advia Centaur CP  [  ] XP', NULL, NULL, 'ICMA', 0),
(43, 3, '04', 'Beckman, Access ; Unicel DXi', NULL, NULL, 'ICMA', 0),
(44, 3, '05', 'BioMerieux, VIDAS ; Minividas', NULL, NULL, 'ELFA', 0),
(45, 3, '06', 'Tosoh AIA Series', NULL, NULL, 'FEIA', 0),
(46, 3, '07', 'Johnson, Vitros ECi 3600, 5600', NULL, NULL, 'ICMA', 0),
(47, 3, '08', 'Roche; Cobas Series, Modular, Elecsys series', NULL, NULL, 'ECLIA', 0),
(48, 3, '09', 'Hybiome AE-180', NULL, NULL, 'CLIA', 0),
(49, 3, '10', 'Mindray CL 2000 i / 1000 i', NULL, NULL, 'ICMA', 0),
(50, 3, '11', 'Liaison Series ;', NULL, NULL, 'CLIA', 0),
(51, 3, '12', 'Immulite, LKB1277, DPC, Others', NULL, NULL, 'IEMA, ICMA, IRMA, CLLA, ECLIA', 0),
(52, 2, '01', 'Maglumi Series 800', NULL, NULL, 'CLIA', 0),
(53, 2, '02', 'Abbott Architect Series; Armity', NULL, NULL, 'CLIA', 0),
(54, 2, '03', 'Advia centaur CP; XP', NULL, NULL, 'ECLIA', 0),
(55, 2, '04', 'Beckman, access series DXi', NULL, NULL, 'CLIA', 0),
(56, 2, '05', 'Bio merieux; Vidas; Mini Vidas', NULL, NULL, 'ELFA', 0),
(57, 2, '06', 'Tosoh AIA series', NULL, NULL, 'CLIA', 0),
(58, 2, '07', 'Johnson vitros Eci. 3600, 5600', NULL, NULL, 'CMIA', 0),
(59, 2, '08', 'Roche; Cobas series; Elecsys series; Modular', NULL, NULL, 'FEIA', 0),
(60, 2, '09', 'Hybiome AE-180', NULL, NULL, 'CLIA', 0),
(61, 2, '10', 'Mindray CL 1000i; 2000i; 6000', NULL, NULL, 'CLIA', 0),
(62, 2, '11', 'Liaison; Liaison XL', NULL, NULL, 'CLIA', 0),
(63, 2, '12', 'Sysmex HISCL-800', '', NULL, '', 0),
(65, 12, '65', 'No AFB Observed', NULL, '1', '', 0),
(66, 12, '66', '1-9 AFB per 100 fields', NULL, '1', '', 0),
(67, 12, '67', 'AFB 1+ (10-99 AFB/100 fields)', NULL, '1', '', 0),
(68, 12, '68', 'AFB 2+ (1-10 AFB per field in 50 fields', '1', '1', '', 0),
(69, 12, '69', 'AFB 3+ (more than 10 AFB per field in 20 fields)', NULL, '1', '', 0),
(70, 12, '70', 'Conventional tests', NULL, '2', '', 0),
(71, 12, '71', 'VITEK', NULL, '2', '', 0),
(72, 12, '72', 'VITEK 2', NULL, '2', '', 0),
(73, 12, '73', 'MicroScan', NULL, '2', '', 0),
(74, 12, '74', 'MALDI-TOF (bioMerieux)', NULL, '2', '', 0),
(75, 12, '75', 'MALDI-TOF (Bruker)', NULL, '2', '', 0),
(76, 12, '76', 'Molecular techniques', NULL, '2', '', 0),
(77, 12, '77', 'API (bioMerieux)', NULL, '2', '', 0),
(78, 12, '78', 'Rapid Test NF PLUS', NULL, '2', '', 0),
(79, 12, '79', 'Phoenix M50', NULL, '2', '', 0),
(80, 12, '80', 'Other…', '1', '2', '', 0),
(81, 12, '81', 'Question Type', NULL, '3', '', 0),
(82, 12, '82', 'Disc diffusion', NULL, '3', '', 0),
(83, 12, '83', 'VITEK', NULL, '3', '', 0),
(84, 12, '84', 'VITEK 2', NULL, '3', '', 0),
(85, 12, '85', 'Phoenix M50', NULL, '3', '', 0),
(86, 12, '86', 'MicroScan', NULL, '3', '', 0),
(87, 12, '87', 'Sensititre', NULL, '3', '', 0),
(88, 12, '88', 'Other…', '1', '3', '', 0),
(159, 4, '1', 'Amoeba trophozoite ', NULL, NULL, NULL, 0),
(160, 4, '2', 'Ascaris lumbricoides egg ', NULL, NULL, NULL, 0),
(161, 4, '3', 'Balantidium coli cyst ', NULL, NULL, NULL, 0),
(162, 4, '4', 'Balantidium coli trophozoite ', NULL, NULL, NULL, 0),
(163, 4, '5', 'Blastocystis hominis ', NULL, NULL, NULL, 0),
(164, 4, '6', 'Capillaria philippinensis adult ', NULL, NULL, NULL, 0),
(165, 4, '7', 'Capillaria philippinensis egg ', NULL, NULL, NULL, 0),
(166, 4, '8', 'Capillaria philippinensis larva ', NULL, NULL, NULL, 0),
(167, 4, '9', 'Chilomastix mesnili cyst ', NULL, NULL, NULL, 0),
(168, 4, '10', 'Chilomastix mesnili trophozoite ', NULL, NULL, NULL, 0),
(169, 4, '11', 'Cyclospora oocyst ', NULL, NULL, NULL, 0),
(170, 4, '12', 'Diphyllobrothium latum egg ', NULL, NULL, NULL, 0),
(171, 4, '13', 'Dipylidium caninum egg ', NULL, NULL, NULL, 0),
(172, 4, '14', 'Endolimax nana cyst ', NULL, NULL, NULL, 0),
(173, 4, '15', 'Entamoeba coli cyst ', NULL, NULL, NULL, 0),
(174, 4, '16', 'Entamoeba histolytica cyst ', NULL, NULL, NULL, 0),
(175, 4, '17', 'Enterobious vermicularis egg ', NULL, NULL, NULL, 0),
(176, 4, '18', 'Fasciolopsis/Fasciola/Echinostoma egg ', NULL, NULL, NULL, 0),
(177, 4, '19', 'Giardia lamblia cyst ', NULL, NULL, NULL, 0),
(178, 4, '20', 'Giardia lamblia trophozoite ', NULL, NULL, NULL, 0),
(179, 4, '21', 'Hookworm egg ', NULL, NULL, NULL, 0),
(180, 4, '22', 'Hookworm filariform larva ', NULL, NULL, NULL, 0),
(181, 4, '23', 'Hookworm rhabditiform larva ', NULL, NULL, NULL, 0),
(182, 4, '24', 'Hymenolepis diminuta egg ', NULL, NULL, NULL, 0),
(183, 4, '25', 'Hymenolepis nana egg ', NULL, NULL, NULL, 0),
(184, 4, '26', 'Iodamoeba butschlii cyst ', NULL, NULL, NULL, 0),
(185, 4, '27', 'Isospora belli oocyst ', NULL, NULL, NULL, 0),
(186, 4, '28', 'Opisthorchis/MIF egg ', NULL, NULL, NULL, 0),
(187, 4, '29', 'Paragonimus heterotremus egg ', NULL, NULL, NULL, 0),
(188, 4, '30', 'Paragonimus westermani egg ', NULL, NULL, NULL, 0),
(189, 4, '31', 'Plasmodium falciparum asexual form ', NULL, NULL, NULL, 0),
(190, 4, '32', 'Plasmodium falciparum gametocyte ', NULL, NULL, NULL, 0),
(191, 4, '33', 'Plasmodium malariae asexual form ', NULL, NULL, NULL, 0),
(192, 4, '34', 'Plasmodium malariae gametocyte ', NULL, NULL, NULL, 0),
(193, 4, '35', 'Plasmodium ovale asexual form ', NULL, NULL, NULL, 0),
(194, 4, '36', 'Plasmodium ovale gametocyte ', NULL, NULL, NULL, 0),
(195, 4, '37', 'Plasmodium vivax asexual form ', NULL, NULL, NULL, 0),
(196, 4, '38', 'Plasmodium vivax gametocyte ', NULL, NULL, NULL, 0),
(197, 4, '39', 'Sarcocystis hominis sporocyst/oocyst ', NULL, NULL, NULL, 0),
(198, 4, '40', 'Schistosoma haematobium egg ', NULL, NULL, NULL, 0),
(199, 4, '41', 'Schistosoma japonicum egg ', NULL, NULL, NULL, 0),
(200, 4, '42', 'Schistosoma mansoni egg ', NULL, NULL, NULL, 0),
(201, 4, '43', 'Schistosoma mekongi egg ', NULL, NULL, NULL, 0),
(202, 4, '44', 'Strongyloides stercoralis female ', NULL, NULL, NULL, 0),
(203, 4, '45', 'Strongyloides stercoralis filariform larva ', NULL, NULL, NULL, 0),
(204, 4, '46', 'Strongyloides stercoralis male ', NULL, NULL, NULL, 0),
(205, 4, '47', 'Strongyloides stercoralis rhabditiform larva ', NULL, NULL, NULL, 0),
(206, 4, '48', 'Taenia solium/Taenia saginata egg ', NULL, NULL, NULL, 0),
(207, 4, '49', 'Trichomonas hominis trophozoite ', NULL, NULL, NULL, 0),
(208, 4, '50', 'Trichuris trichiura egg ', NULL, NULL, NULL, 0),
(209, 4, '51', 'Not Found ', NULL, NULL, NULL, 0),
(211, 9, '4', 'E-CLIA', NULL, 'auto', NULL, 0),
(212, 9, '3', 'CMIA', NULL, 'auto', NULL, 0),
(213, 9, '2', 'CLIA', NULL, 'auto', NULL, 0),
(214, 9, '1', 'EIA / ELISA', NULL, 'auto', NULL, 0),
(215, 9, '3', 'Other', 'other', '1', NULL, 0),
(216, 9, '2', 'Immunochromatography', NULL, '1', NULL, 0),
(217, 9, '1', 'Automation', 'auto', '1', NULL, 0),
(218, 9, '5', 'FEIA', NULL, 'auto', NULL, 0),
(219, 9, '1', 'Positive', NULL, '2', NULL, 0),
(220, 9, '2', 'Weakly Positive', NULL, '2', NULL, 0),
(221, 9, '3', 'Negative', NULL, '2', NULL, 0),
(225, 1, '32', 'Jaffe Kinetic', NULL, '1', NULL, 0),
(226, 1, '33', 'Jendrassik - Grof ', NULL, '1', NULL, 0),
(227, 1, '44', 'PNP.AMP buff; AACC', NULL, '1', NULL, 0),
(228, 1, '45', 'PNP.DEA buff;  DGKC', NULL, '1', NULL, 0),
(229, 1, '46', 'Reflotron', NULL, '1', NULL, 0),
(230, 1, '47', 'SSCC', NULL, '1', NULL, 0),
(231, 1, '48', 'Vitros', NULL, '1', NULL, 0),
(232, 1, '49', 'Vitros; ISE', NULL, '1', NULL, 0),
(253, 13, '28', 'Gentamycin', NULL, '2', NULL, 0),
(254, 13, '20', 'Clindamycin', NULL, '2', NULL, 0),
(255, 13, '19', 'Clarithomycin', NULL, '2', NULL, 0),
(256, 13, '18', 'Ciprofloxacin', NULL, '2', NULL, 0),
(257, 13, '17', 'Chloramphenicol', NULL, '2', NULL, 0),
(258, 13, '16', 'Cefuroxime', NULL, '2', NULL, 0),
(259, 13, '15', 'Ceftriaxone', NULL, '2', NULL, 0),
(260, 13, '14', 'Ceftolozane-lazobactam', NULL, '2', NULL, 0),
(261, 13, '13', 'Ceftazidime', NULL, '2', NULL, 0),
(262, 13, '12', 'Ceftaroline', NULL, '2', NULL, 0),
(263, 13, '11', 'Cefoxtin', NULL, '2', NULL, 0),
(264, 13, '10', 'Cefotetan', NULL, '2', NULL, 0),
(265, 13, '9', 'Cefotaxime', NULL, '2', NULL, 0),
(266, 13, '8', 'Cefepime', NULL, '2', NULL, 0),
(267, 13, '7', 'Cefazolin', NULL, '2', NULL, 0),
(268, 13, '6', 'Aztreonam', NULL, '2', NULL, 0),
(269, 13, '5', 'Azithromycin', NULL, '2', NULL, 0),
(270, 13, '4', 'Ampicillin-sulbactam', NULL, '2', NULL, 0),
(271, 13, '3', 'Ampicillin', NULL, '2', NULL, 0),
(272, 13, '2', 'Amoxicillin-calvulonate', NULL, '2', NULL, 0),
(273, 13, '1', 'Amikacin', NULL, '2', NULL, 0),
(274, 13, '27', 'Fosfomycin', NULL, '2', NULL, 0),
(275, 13, '23', 'Doripenem', NULL, '2', NULL, 0),
(276, 13, '41', 'Penicillin', NULL, '2', NULL, 0),
(277, 13, '22', 'Daptomycin', NULL, '2', NULL, 0),
(278, 13, '21', 'Colistin', NULL, '2', NULL, 0),
(279, 13, '40', 'Oxacillin', NULL, '2', NULL, 0),
(280, 13, '39', 'Oritavancin', NULL, '2', NULL, 0),
(281, 13, '38', 'Nitrofurantoin', NULL, '2', NULL, 0),
(282, 13, '37', 'Netilmicin', NULL, '2', NULL, 0),
(283, 13, '36', 'Moxifloxacin', NULL, '2', NULL, 0),
(284, 13, '35', 'Minocycline', NULL, '2', NULL, 0),
(285, 13, '34', 'Meropenem', NULL, '2', NULL, 0),
(286, 13, '33', 'Linezolid', NULL, '2', NULL, 0),
(287, 13, '32', 'Levofloxacin', NULL, '2', NULL, 0),
(288, 13, '31', 'Imipenem', NULL, '2', NULL, 0),
(289, 13, '30', 'Hight-level Streptomycin ', NULL, '2', NULL, 0),
(290, 13, '29', 'Hight-level Gentamycin', NULL, '2', NULL, 0),
(291, 13, '26', 'Erythomycin', NULL, '2', NULL, 0),
(292, 13, '25', 'Ertapenem', NULL, '2', NULL, 0),
(293, 13, '24', 'Doxycycline', NULL, '2', NULL, 0),
(294, 13, '42', 'Rifampin', NULL, '2', NULL, 0),
(295, 13, '43', 'Piperracillin-tazobactam', NULL, '2', NULL, 0),
(296, 13, '44', 'Sulfisoxazole', NULL, '2', NULL, 0),
(297, 13, '45', 'Tedizolid', NULL, '2', NULL, 0),
(298, 13, '46', 'Telavancin', NULL, '2', NULL, 0),
(299, 13, '47', 'Tetracycline', NULL, '2', NULL, 0),
(300, 13, '48', 'Tobramycin', NULL, '2', NULL, 0),
(301, 13, '49', 'Trimethoprim', NULL, '2', NULL, 0),
(302, 13, '50', 'Trimethoprim-sulfamethoxzole', NULL, '2', NULL, 0),
(303, 13, '51', 'Vancomycin', NULL, '2', NULL, 0),
(305, 1, '34', 'Kinetic 37C/ Kinetic - without pyridoxal ', NULL, '1', NULL, 0),
(306, 1, '35', 'Kinetic - pyridoxal', NULL, '1', NULL, 0),
(309, 5, '9', 'Others', NULL, '9', NULL, 0),
(310, 2, '13', 'Others', '1', NULL, NULL, 0),
(311, 8, '36', 'CLIA', NULL, 'TP', NULL, 0),
(312, 1, '36', 'Malloy - Evelyn ', NULL, '1', NULL, 0),
(313, 1, '37', 'Margon/ Xylidyl blue', NULL, '1', NULL, 0),
(314, 1, '38', 'Methylthymol blue', NULL, '1', NULL, 0),
(315, 1, '39', 'Molybdenum EP', NULL, '1', NULL, 0),
(319, 1, '40', 'Molybdenum UV', NULL, '1', NULL, 0),
(320, 1, '41', 'Others', NULL, '1', NULL, 0),
(321, 1, '42', 'Phospho. Precip./ Polyanion', NULL, '1', NULL, 0),
(322, 1, '43', 'PNP AMP buff; IFCC', NULL, '1', NULL, 0),
(323, 1, '1', 'Arsenazo/ Chlorophosphonazo', NULL, '1', NULL, 0),
(326, 5, '5', 'Cell-Dyn ', NULL, '5', NULL, 0),
(332, 5, '21', 'ABX Micros/Minos/ABC VET', NULL, '66', NULL, 0),
(336, 5, '10', 'Pentra', NULL, '61', NULL, 0),
(337, 1, '2', 'Bromocresol green', NULL, '1', NULL, 0),
(338, 4, '52', 'Not Tested', NULL, NULL, NULL, 0),
(339, 1, '3', 'Bromocresol purple', NULL, '1', NULL, 0),
(340, 1, '4', 'Beckman', NULL, '1', NULL, 0),
(341, 1, '5', 'Biuret - Blank', NULL, '1', NULL, 0),
(342, 1, '6', 'Biuret - Unblank', NULL, '1', NULL, 0),
(343, 1, '7', 'CK-NAC/IFCC', NULL, '1', NULL, 0),
(344, 1, '8', 'CNPG3', NULL, '1', NULL, 0),
(345, 1, '9', 'Colorimetric', NULL, '1', NULL, 0),
(346, 1, '10', 'CPC/ Arsenazo', NULL, '1', NULL, 0),
(347, 1, '11', 'Dade Behring', NULL, '1', NULL, 0),
(348, 1, '12', 'DCA/DPD', NULL, '1', NULL, 0),
(349, 1, '13', 'DGKC', NULL, '1', NULL, 0),
(350, 1, '14', 'Diazonium', NULL, '1', NULL, 0),
(351, 1, '15', 'Direct Determination', NULL, '1', NULL, 0),
(352, 1, '16', 'Direct ISE', NULL, '1', NULL, 0),
(353, 1, '17', 'Enz Color Total TG', NULL, '1', NULL, 0),
(354, 1, '18', 'Enzyme', NULL, '1', NULL, 0),
(355, 1, '19', 'Enzyme Colorimetric', NULL, '1', NULL, 0),
(356, 1, '20', 'Enzyme EP Blank', NULL, '1', NULL, 0),
(357, 1, '21', 'Enzyme EP Unblank', NULL, '1', NULL, 0),
(358, 1, '22', 'Enzyme Kinetic', NULL, '1', NULL, 0),
(359, 1, '23', 'G7PNP', NULL, '1', NULL, 0),
(360, 1, '24', 'Glucose Dehydrogenase', NULL, '1', NULL, 0),
(361, 1, '25', 'Glycerol Blank', NULL, '1', NULL, 0),
(362, 1, '26', 'Glucose Oxidase', NULL, '1', NULL, 0),
(363, 1, '27', 'Hexokinase', NULL, '1', NULL, 0),
(364, 1, '28', 'IFCC', NULL, '1', NULL, 0),
(365, 1, '29', 'Indirect ISE', NULL, '1', NULL, 0),
(366, 1, '30', 'ISE', NULL, '1', NULL, 0),
(367, 1, '31', 'Jaffe EP', NULL, '1', NULL, 0),
(369, 1, '101', 'Abbott Architect c Systems', NULL, '2', NULL, 0),
(370, 1, '102', 'Audicom AC9000 Series electrolyte analyzer', NULL, '2', NULL, 0),
(373, 1, '103', 'Beckman Coulter AU400/480/680/5800', NULL, '2', NULL, 0),
(374, 1, '104', 'Beckman Coulter DxC600/ DxC800', NULL, '2', NULL, 0),
(375, 1, '105', 'Beckman Coulter DxC700 AU', NULL, '2', NULL, 0),
(376, 1, '106', 'Biosystems A15', NULL, '2', NULL, 0),
(377, 1, '107', 'Biosystems BA400', NULL, '2', NULL, 0),
(378, 1, '108', 'Caretium XI-921', NULL, '2', NULL, 0),
(379, 1, '109', 'Roche Cobas Mira S', NULL, '2', NULL, 0),
(380, 1, '110', 'Diasys BioMajesty JCA-BM6010/C', NULL, '2', NULL, 0),
(381, 1, '111', 'Dirui CS Series', NULL, '2', NULL, 0),
(382, 1, '112', 'Dirui CS-600B', NULL, NULL, NULL, 0),
(383, 1, '113', 'Electa4 analyzer', NULL, '2', NULL, 0),
(384, 1, '114', 'Erba XL Series', NULL, '2', NULL, 0),
(385, 1, '115', 'Fuji Dri-Chem NX500i', NULL, '2', NULL, 0),
(386, 1, '116', 'GASTAT-1820', NULL, '2', NULL, 0),
(387, 1, '117', 'Hitachi 911', NULL, '2', NULL, 0),
(388, 1, '118', 'Horiba Pentra 400', NULL, '2', NULL, 0),
(389, 1, '119', 'ILab 600/650/Taurus', NULL, NULL, NULL, 0),
(390, 1, '120', 'ILab 600/650/Taurus', NULL, '2', NULL, 0),
(391, 1, '121', 'In4lyte', NULL, '2', NULL, 0),
(392, 1, '122', 'Konelab 20/30/60 / Thermo Indiko', NULL, '2', NULL, 0),
(393, 1, '123', 'Mindray BC 2000/3000 series', NULL, '2', NULL, 0),
(394, 1, '124', 'Mindray BS Series', NULL, '2', NULL, 0),
(395, 1, '125', 'Nova 4 electrolyte analyzer', NULL, '2', NULL, 0),
(396, 1, '126', 'Ortho Vitros 250/350', NULL, '2', NULL, 0),
(397, 1, '127', 'Ortho Vitros 4600/5600', NULL, '2', NULL, 0),
(398, 1, '128', 'PKL PPC 125', NULL, '2', NULL, 0),
(399, 1, '129', 'Q4-Lyte', NULL, '2', NULL, 0),
(400, 1, '130', 'Randox RX series', NULL, '2', NULL, 0),
(401, 1, '131', 'Reflotron', NULL, '2', NULL, 0),
(402, 1, '132', 'Roche Cobas c111', NULL, '2', NULL, 0),
(403, 1, '133', 'Roche Cobas c311', NULL, '2', NULL, 0),
(404, 1, '134', 'Roche Cobas c501/502/503', NULL, '2', NULL, 0),
(405, 1, '135', 'Roche Cobas Integra 400 Plus', NULL, '2', NULL, 0),
(406, 1, '136', 'Rx Modena', NULL, '2', NULL, 0),
(407, 1, '137', 'Rx-lyte v.4', NULL, '2', NULL, 0),
(408, 1, '138', 'SFRI ISE electrolyte series', NULL, '2', NULL, 0),
(409, 1, '139', 'Siemens Advia 1800', NULL, '2', NULL, 0),
(410, 1, '140', 'Siemens Rapidlab 348Ex', NULL, '2', NULL, 0),
(411, 1, '141', 'Siemens/Dade Dimension EXL', NULL, '2', NULL, 0),
(412, 1, '142', 'Siemens/Dade Dimension RxL /Max/Xpand', NULL, '2', NULL, 0),
(413, 1, '143', 'Sinnowa BS-3000', NULL, '2', NULL, 0),
(414, 1, '144', 'Sinnowa DS301', NULL, '2', NULL, 0),
(415, 1, '145', 'Sysmex BX-3010', NULL, '2', NULL, 0),
(416, 1, '146', 'Sysmex BX-4000', NULL, '2', NULL, 0),
(417, 1, '147', 'Sysmex JCA-BM6010/C', NULL, NULL, NULL, 0),
(418, 1, '148', 'Tecom TC220', NULL, '2', NULL, 0),
(419, 1, '149', 'Thermo Fisher Konelab Delta', NULL, '2', NULL, 0),
(420, 1, '150', 'Tokyo Boeki/Biolis/ Prestige 24i/TMS 1024', NULL, '2', NULL, 0),
(421, 1, '151', 'URIT-8031', NULL, '2', NULL, 0),
(422, 1, '152', 'Vitalab Scientific Flexor E', NULL, '2', NULL, 0),
(423, 1, '153', 'XD 687 Electrolyte Analyzer', NULL, '2', NULL, 0),
(424, 1, '154', 'XD 697 Electrolyte Analyzer', NULL, '2', NULL, 0),
(425, 1, '501', 'Abbott laboratories', NULL, '3', NULL, 0),
(426, 1, '502', 'Beckman Coulter', NULL, '3', NULL, 0),
(427, 1, '503', 'BioSystems', NULL, '3', NULL, 0),
(428, 1, '504', 'Biozen', NULL, '3', NULL, 0),
(429, 1, '505', 'Caretium ', NULL, '3', NULL, 0),
(430, 1, '506', 'Centronic', NULL, '3', NULL, 0),
(431, 1, '507', 'Diamond', NULL, '3', NULL, 0),
(432, 1, '508', 'DiaSys', NULL, '3', NULL, 0),
(433, 1, '509', 'Diazyme', NULL, '3', NULL, 0),
(434, 1, '510', 'Dirui', NULL, '3', NULL, 0),
(435, 1, '511', 'Electa', NULL, '3', NULL, 0),
(436, 1, '512', 'Elitech', NULL, '3', NULL, 0),
(437, 1, '513', 'Erba Lachema', NULL, '3', NULL, 0),
(438, 1, '514', 'Fuji', NULL, '3', NULL, 0),
(439, 1, '515', 'Furuno', NULL, '3', NULL, 0),
(440, 1, '516', 'Horiba', NULL, '3', NULL, 0),
(441, 1, '517', 'Iberlab', NULL, '3', NULL, 0),
(442, 1, '518', 'I-med', NULL, '3', NULL, 0),
(443, 1, '519', 'Infocus firming', NULL, '3', NULL, 0),
(444, 1, '520', 'Instumentation laboratory', NULL, '3', NULL, 0),
(445, 1, '521', 'Jiangsu Audicom ', NULL, '3', NULL, 0),
(446, 1, '522', 'Meditop', NULL, '3', NULL, 0),
(447, 1, '523', 'Mindray', NULL, '3', NULL, 0),
(448, 1, '524', 'Olympus', NULL, '3', NULL, 0),
(449, 1, '525', 'Ortho-Clinical Diagnostics', NULL, '3', NULL, 0),
(450, 1, '526', 'PCL', NULL, '3', NULL, 0),
(451, 1, '527', 'Randox', NULL, '3', NULL, 0),
(452, 1, '528', 'Roche Diagnotics', NULL, '3', NULL, 0),
(453, 1, '529', 'SFRI', NULL, '3', NULL, 0),
(454, 1, '530', 'Shanghai Xunda', NULL, '3', NULL, 0),
(455, 1, '531', 'Siemens', NULL, '3', NULL, 0),
(456, 1, '532', 'Slidedrychem', NULL, '3', NULL, 0),
(457, 1, '533', 'Spinreact', NULL, '3', NULL, 0),
(458, 1, '534', 'Stanbio', NULL, '3', NULL, 0),
(459, 1, '535', 'Sysmex', NULL, '3', NULL, 0),
(460, 1, '536', 'Techno Medica', NULL, '3', NULL, 0),
(461, 1, '537', 'Tecom', NULL, '3', NULL, 0),
(462, 1, '538', 'Thermoscientific', NULL, '3', NULL, 0),
(463, 1, '539', 'Toyobo', NULL, '3', NULL, 0),
(464, 1, '540', 'URIT', NULL, '3', NULL, 0),
(465, 1, '541', 'Wako', NULL, '3', NULL, 0),
(466, 1, '542', 'YD diagnostic', NULL, '3', NULL, 0),
(469, 12, NULL, NULL, NULL, NULL, NULL, 0),
(474, 1, '155', 'Q4-LyteEx ', NULL, '2', NULL, 0),
(476, 1, '157', 'Biotecnica BT Series', NULL, '2', NULL, 0),
(479, 1, '543', 'Biotecnica Instruments', NULL, '3', NULL, 0),
(480, 1, '158', 'URIT 8280', NULL, '2', NULL, 0),
(481, 1, '159', 'GE300 electrolyte analyzer', NULL, '2', NULL, 0),
(482, 1, '544', 'Genrui Biotech', NULL, '3', NULL, 0),
(483, 1, '160', 'Biosystems BA200', NULL, '2', NULL, 0),
(485, 1, '161', 'Roche Cobas c701/702', NULL, '2', NULL, 0),
(486, 1, '162', 'HumaStar 200', NULL, '2', NULL, 0),
(487, 1, '545', 'Medica', NULL, '3', NULL, 0),
(488, 1, '546', 'Bt GEN', NULL, '3', NULL, 0),
(489, 1, '547', 'Q4-Lyte', NULL, '3', NULL, 0),
(490, 1, '548', 'Q4-LyteEx', NULL, '3', NULL, 0),
(491, 1, '50', 'Direct with PVS/PEGMS', NULL, '1', NULL, 0),
(492, 1, '51', 'Imm.Inhibition', NULL, '1', NULL, 0),
(493, 1, '52', 'Water & Gerarde Method', NULL, '1', NULL, 0),
(494, 1, '53', 'Vanadate', NULL, '1', NULL, 0),
(495, 1, '156', 'Furuno CA-800', NULL, '2', NULL, 0),
(496, 1, '163', 'Diasys Respons 920', NULL, '2', NULL, 0),
(497, 1, '164', 'Rayto Chemray 120', NULL, '2', NULL, 0),
(498, 1, '549', 'Rayto', NULL, '3', NULL, 0),
(499, 1, '550', 'QuantILab', NULL, '3', NULL, 0),
(500, 1, '165', 'Roche Cobas c501/502/503', NULL, NULL, NULL, 0),
(501, 1, '166', 'URIT-910 Plus', NULL, '2', NULL, 0),
(502, 1, '167', 'Siemens Atellica Solution', NULL, '2', NULL, 0),
(503, 5, '16', 'XT series', NULL, '16', NULL, 0),
(504, 5, '12', 'URIT', NULL, '63', NULL, 0),
(505, 5, '8', 'MEK', NULL, '60', NULL, 0),
(506, 5, '13', 'XN-L series', NULL, '13', NULL, 0),
(507, 5, '23', 'Ac.T 5 series', NULL, '23', NULL, 0),
(508, 1, '54', 'NM-BAPTA', NULL, '1', NULL, 0);

-- --------------------------------------------------------

--
-- Table structure for table `mhd_program_trial`
--

CREATE TABLE `mhd_program_trial` (
  `id` int(11) NOT NULL,
  `year_id` int(11) DEFAULT NULL,
  `program_id` int(11) DEFAULT NULL,
  `slug` varchar(255) DEFAULT NULL,
  `name` text DEFAULT NULL,
  `start_report_date` date DEFAULT NULL,
  `end_report_date` date DEFAULT NULL,
  `dispatched` date DEFAULT NULL,
  `dispatched_count` int(11) DEFAULT 0,
  `file` text DEFAULT NULL,
  `date_send` date DEFAULT NULL,
  `row_limit` int(11) DEFAULT NULL,
  `specimen_name` text DEFAULT NULL,
  `trial_year` varchar(255) DEFAULT NULL,
  `note` varchar(255) DEFAULT NULL,
  `del` int(11) NOT NULL DEFAULT 0,
  `date_added` datetime DEFAULT NULL,
  `date_modify` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `mhd_program_trial`
--

INSERT INTO `mhd_program_trial` (`id`, `year_id`, `program_id`, `slug`, `name`, `start_report_date`, `end_report_date`, `dispatched`, `dispatched_count`, `file`, `date_send`, `row_limit`, `specimen_name`, `trial_year`, `note`, `del`, `date_added`, `date_modify`) VALUES
(3, NULL, 4, 'h-eqam-6002', 'H-EQAM 6002', '2030-11-00', '2016-12-08', '2016-12-08', 50, NULL, '2030-11-00', 1, 'H6002', '2017', NULL, 1, '2016-12-08 17:57:09', NULL),
(4, NULL, 4, 'u-eqam-6002', 'U-EQAM 6002', '2030-11-00', '2010-10-10', '2010-10-10', 0, NULL, '2030-11-00', 1, 'U6002', '2017', NULL, 1, '2016-12-23 02:02:35', NULL),
(19, NULL, 4, 'c-eqam-6002', 'C-EQAM 6002', '2030-11-00', '2017-05-31', '2017-05-31', 0, NULL, '2030-11-00', 1, 'C-EQAM 6002', '2017', NULL, 1, '2017-05-31 08:56:19', NULL),
(20, NULL, 4, 'b-eqam-6002', 'B-EQAM 6002', '2030-11-00', '2017-11-22', '2017-11-22', 100, NULL, '2030-11-00', 1, 'B6002', '2017', NULL, 1, '2017-08-22 11:24:40', NULL),
(41, 1, 12, 'eqab-8020-afb-12020', 'EQAB 8020 : AFB 1/2020', '2021-02-28', '2021-02-28', '2021-02-28', 0, '', '2021-02-28', 0, NULL, '2020', '', 0, '2021-02-01 14:12:04', '2021-02-01 14:12:04'),
(44, 1, 10, 'eqab-8010-gram-12020', 'EQAB 8010 : GRAM 1/2020', '2021-02-28', '2021-02-28', '2021-02-28', 0, '', '2021-02-28', 0, NULL, '2020', '', 0, '2021-02-01 13:58:04', '2021-02-01 13:58:04'),
(48, 1, 13, 'eqab-8150-iden-12020', 'EQAB 8150 : IDEN 1/2020', '2021-02-28', '2021-02-28', '2021-02-28', 0, '', '2021-02-28', 0, NULL, '2020', '', 0, '2021-02-01 14:24:06', '2021-02-01 14:24:06'),
(126, 1, 1, '280', '280', '2020-01-01', '2021-02-28', '2021-02-28', 0, '', '2021-02-28', 2, NULL, '2020', '', 0, '2021-02-02 17:45:40', '2021-02-02 17:45:40'),
(127, 1, 8, 'se-01-20-1', 'SE-01-20-1', '2020-09-30', '2020-07-15', '2020-07-15', 0, NULL, '2020-09-30', 1, NULL, '2020', NULL, 0, '2020-01-07 15:21:34', NULL),
(128, 1, 9, 'se-02-20-1', 'SE-02-20-1', '2020-06-09', '2020-01-28', '2020-01-28', NULL, NULL, '2020-06-09', 1, NULL, '2020', NULL, 0, '2020-01-07 15:24:51', NULL),
(129, 1, 3, 'trial-175-176-january-2020', 'Trial 175-176 [January 2020]', '2020-10-31', '2020-07-23', '2020-07-23', 0, NULL, '2020-10-31', 0, NULL, '2020', NULL, 0, '2020-01-10 14:58:00', NULL),
(130, 1, 2, 'trial109', 'Trial109', '2020-01-01', '2021-03-30', '2020-02-13', 0, '', '2020-11-26', 0, NULL, '2020', '', 0, '2021-02-02 17:40:00', '2021-02-02 17:40:00'),
(134, 1, 1, '281', '281', '2021-01-31', '2020-02-03', '2020-02-03', 0, '', '2021-01-31', 2, NULL, '2020', NULL, 0, '2021-01-12 14:12:40', '2021-01-12 14:12:40'),
(135, 1, 4, '1-2563', '1-2563', '2020-03-01', '2020-02-05', '2020-02-05', 146, NULL, '2020-03-01', 1, NULL, '2020', NULL, 0, '2020-02-06 15:33:28', NULL),
(136, 1, 7, 'uc6301', 'UC6301', '2021-02-28', '2021-02-28', '2021-02-28', 14, '', '2021-02-28', 1, NULL, '2020', '', 0, '2021-02-01 12:52:12', '2021-02-01 12:52:12'),
(137, 1, 5, 'b6301', 'B6301', '2021-01-31', '2021-01-31', '2021-01-31', 14, '', '2021-01-31', 1, NULL, '2020', '', 0, '2021-01-20 14:58:07', '2021-01-20 14:58:07'),
(138, 1, 6, '6301', '6301', '2021-01-31', '2021-01-31', '2021-01-31', 21, '', '2021-01-31', 1, NULL, '2020', '', 0, '2021-01-21 15:54:34', '2021-01-21 15:54:34'),
(140, 1, 3, 'trial-177-178-march-2020', 'Trial 177-178 ( March 2020 )', '2020-04-17', '2020-03-12', '2020-03-12', 0, NULL, '2020-04-17', 0, NULL, '2020', NULL, 0, '2020-02-28 14:07:29', NULL),
(143, 1, 1, '282', '282', '2020-04-03', '2020-03-04', '2020-03-04', 0, NULL, '2020-04-03', 2, NULL, '2020', NULL, 0, '2020-03-10 09:00:40', NULL),
(148, 1, 2, 'trial110', 'Trial110', '2020-05-28', '2020-04-07', '2020-04-07', 0, NULL, '2020-05-28', 0, NULL, '2020', NULL, 0, '2020-04-03 07:33:18', NULL),
(149, 1, 1, '283', '283', '2020-05-06', '2020-04-01', '2020-04-01', 1, NULL, '2020-05-06', 2, NULL, '2020', NULL, 0, '2020-04-04 12:24:37', NULL),
(151, 1, 3, 'trial-179-180-may-2020', 'Trial 179-180 ( May 2020 )', '2020-06-12', '2020-05-12', '2020-05-12', 0, NULL, '2020-06-12', 0, NULL, '2020', NULL, 0, '2020-04-10 10:40:15', NULL),
(152, 1, 4, '2-2563', '2-2563', '2020-06-01', '2020-05-05', '2020-05-05', 0, NULL, '2020-06-01', 1, NULL, '2020', NULL, 0, '2020-04-17 11:13:22', NULL),
(153, 1, 8, 'se-01-20-2', 'SE-01-20-2', '2020-05-25', '2020-04-28', '2020-04-28', 0, NULL, '2020-05-25', 1, NULL, '2020', NULL, 0, '2020-04-21 20:50:19', NULL),
(154, 1, 9, 'se-02-20-2', 'SE-02-20-2', '2020-05-25', '2020-04-28', '2020-04-28', 0, NULL, '2020-05-25', 1, NULL, '2020', NULL, 0, '2020-04-21 20:58:00', NULL),
(155, 1, 1, '284', '284', '2020-06-03', '2020-05-05', '2020-05-05', 0, NULL, '2020-06-03', 2, NULL, '2020', NULL, 0, '2020-05-07 09:41:28', NULL),
(156, 1, 7, 'uc6302', 'UC6302', '2020-06-01', '2020-05-18', '2020-05-18', 0, NULL, '2020-06-01', 1, NULL, '2020', '', 0, '2020-05-18 09:04:51', NULL),
(157, 1, 6, '6302', '6302', '2020-07-20', '2020-06-25', '2020-06-25', 0, NULL, '2020-07-20', 1, NULL, '2020', NULL, 0, '2020-05-18 09:06:04', NULL),
(158, 1, 5, 'b6302', 'B6302', '2020-06-23', '2020-06-09', '2020-06-09', 0, NULL, '2020-06-23', 1, NULL, '2020', NULL, 0, '2020-05-18 09:06:45', NULL),
(159, 1, 2, 'test', 'test', '2021-01-31', '2020-01-24', '2020-01-24', 5, '', '2021-01-31', 10, NULL, '2021', 'test', 0, '2021-01-18 14:40:16', '2021-01-18 14:40:16'),
(160, 1, 1, '285', '285', '2020-07-04', '2020-06-05', '2020-06-05', 0, NULL, '2020-07-04', 2, NULL, '2020', NULL, 0, '2020-06-08 11:21:02', NULL),
(161, 1, 2, 'trial111', 'Trial111', '2020-07-09', '2020-06-09', '2020-06-09', 0, NULL, '2020-07-09', 0, NULL, '2020', NULL, 0, '2020-06-12 10:54:34', NULL),
(162, 1, 2, 'trial112', 'Trial112', '2020-09-10', '2020-08-10', '2020-08-10', 0, NULL, '2020-09-10', 0, NULL, '2020', '', 0, '2020-06-12 10:58:56', NULL),
(164, 1, 12, 'eqab-8020-afb-22020', 'EQAB 8020 : AFB 2/2020', '2020-07-20', '2020-06-16', '2020-06-16', 0, NULL, '2020-07-20', NULL, NULL, '2020', NULL, 0, '2020-06-15 20:15:56', NULL),
(165, 1, 10, 'eqab-8010-gram-22020', 'EQAB 8010 : GRAM 2/2020', '2020-07-20', '2020-06-16', '2020-06-16', 0, NULL, '2020-07-20', NULL, NULL, '2020', NULL, 0, '2020-06-15 20:21:39', NULL),
(166, 1, 13, 'eqab-8150-iden-22020', 'EQAB 8150 : IDEN 2/2020', '2020-07-20', '2020-06-16', '2020-06-16', 0, NULL, '2020-07-20', NULL, NULL, '2020', NULL, 0, '2020-06-15 20:23:36', NULL),
(169, 1, 1, '286', '286', '2020-08-04', '2020-07-09', '2020-07-09', 0, NULL, '2020-08-04', 2, NULL, '2020', NULL, 0, '2020-07-09 16:35:03', NULL),
(170, 1, 4, '3-2563', '3-2563', '2020-09-01', '2020-08-05', '2020-08-05', 0, NULL, '2020-09-01', 1, NULL, '2020', NULL, 0, '2020-07-10 14:03:45', NULL),
(171, 1, 3, 'trial-181-182-july-2020', 'Trial 181-182 ( July 2020 )', '2020-08-13', '2020-07-10', '2020-07-10', 0, NULL, '2020-08-13', 0, NULL, '2020', NULL, 0, '2020-07-15 14:25:41', NULL),
(172, 1, 1, 'test-program-only', 'test-program-only', '2020-12-27', '1970-01-01', '1970-01-01', 0, NULL, '2020-12-27', 0, NULL, '2020', NULL, 1, '2020-07-21 15:09:11', NULL),
(173, 1, 8, 'se-01-20-3', 'SE-01-20-3', '2020-08-14', '2020-07-30', '2020-07-30', 0, NULL, '2020-08-14', 1, NULL, '2020', NULL, 0, '2020-07-21 18:09:35', NULL),
(174, 1, 9, 'se-02-20-3', 'SE-02-20-3', '2020-08-14', '2020-07-30', '2020-07-30', 0, NULL, '2020-08-14', 1, NULL, '2020', '', 0, '2020-08-01 07:44:39', NULL),
(175, 1, 1, '287', '287', '2020-09-03', '2020-08-07', '2020-08-07', 0, NULL, '2020-09-03', 2, NULL, '2020', NULL, 0, '2020-08-11 09:32:45', NULL),
(176, 1, 8, 'se-01-20-4', 'SE-01-20-4', '2020-11-12', '2020-10-29', '2020-10-29', 0, NULL, '2020-11-12', 1, NULL, '2020', NULL, 0, '2020-09-03 09:18:47', NULL),
(177, 1, 9, 'se-02-20-4', 'SE-02-20-4', '2020-11-12', '2020-10-29', '2020-10-29', 0, NULL, '2020-11-12', 1, NULL, '2020', NULL, 0, '2020-09-03 09:46:46', NULL),
(178, 1, 1, '288', '288', '2020-10-02', '2020-09-02', '2020-09-02', 0, NULL, '2020-10-02', 2, NULL, '2020', NULL, 0, '2020-09-03 16:19:35', NULL),
(179, 1, 7, 'uc6303', 'UC6303', '2020-10-22', '2020-09-14', '2020-09-14', 0, NULL, '2020-10-22', 1, NULL, '2020', NULL, 0, '2020-09-14 10:09:02', NULL),
(180, 1, 5, 'b6303', 'B6303', '2020-10-14', '2020-09-29', '2020-09-29', 0, NULL, '2020-10-14', 1, NULL, '2020', NULL, 0, '2020-09-14 10:10:01', NULL),
(181, 1, 3, 'trial-183-184-september-2020', 'Trial 183-184 ( September 2020 )', '2020-10-12', '2020-09-10', '2020-09-10', 0, NULL, '2020-10-12', 0, NULL, '2020', NULL, 0, '2020-09-14 14:52:53', NULL),
(183, 1, 8, '', '', '1970-01-01', '1970-01-01', '1970-01-01', 0, NULL, '1970-01-01', 0, NULL, '2020', '', 1, '2020-09-23 10:26:47', NULL),
(185, 1, 2, 'trial113', 'Trial113', '2020-11-09', '2020-10-08', '2020-10-08', 0, NULL, '2020-11-09', 2, NULL, '2020', NULL, 0, '2020-10-01 09:39:19', NULL),
(186, 1, 3, 'trial-185-186-november-2020', 'Trial 185-186 ( November 2020 )', '2020-12-14', '2020-11-10', '2020-11-10', 0, NULL, '2020-12-14', 0, NULL, '2020', NULL, 0, '2020-10-05 08:55:08', NULL),
(187, 1, 1, '289', '289', '2020-10-31', '2020-09-28', '2020-09-28', 1, NULL, '2020-10-31', 2, NULL, '2020', NULL, 0, '2020-10-05 11:44:15', NULL),
(188, 1, 10, 'eqab-8010-gram-32020', 'EQAB 8010 : GRAM 3/2020', '2020-11-17', '2020-10-15', '2020-10-15', 0, NULL, '2020-11-17', NULL, NULL, '2020', NULL, 0, '2020-10-16 14:05:51', NULL),
(189, 1, 12, 'eqab-8020-afb-32020', 'EQAB 8020 : AFB 3/2020', '2020-11-17', '2020-10-15', '2020-10-15', 0, NULL, '2020-11-17', NULL, NULL, '2020', NULL, 0, '2020-10-16 14:07:41', NULL),
(191, 1, 13, 'eqab-8015-iden-32020', 'EQAB 8015 : IDEN 3/2020', '2020-11-17', '2020-10-15', '2020-10-15', 0, NULL, '2020-11-17', NULL, NULL, '2020', NULL, 0, '2020-10-16 14:10:00', NULL),
(192, 1, 1, '290', '290', '2020-11-30', '2020-11-02', '2020-11-02', 0, NULL, '2020-11-30', 2, NULL, '2020', '', 0, '2020-11-02 17:38:27', NULL),
(193, 1, 4, '4-2563', '4-2563', '2021-01-31', '2021-01-31', '2021-01-31', 0, '', '2021-01-31', 1, NULL, '2020', '', 0, '2021-01-20 14:46:04', '2021-01-20 14:46:04'),
(194, 1, 6, '6303', '6303', '2021-01-31', '2021-01-31', '2021-01-31', 0, '', '2021-01-31', 1, NULL, '2020', '', 0, '2021-01-21 15:53:29', '2021-01-21 15:53:29'),
(195, 1, 5, 'b6304', 'B6304', '2020-12-17', '2020-12-01', '2020-12-01', 7, NULL, '2020-12-17', 1, NULL, '2020', NULL, 0, '2020-11-27 13:46:31', NULL),
(196, 1, 1, '291', '291', '2020-12-31', '2020-12-04', '2020-12-04', 0, NULL, '2020-12-31', 2, NULL, '2020', '', 0, '2020-12-01 14:29:02', NULL),
(197, 1, 2, 'trial114', 'Trial114', '2021-01-07', '2020-12-07', '2020-12-07', 0, NULL, '2021-01-07', 0, NULL, '2020', NULL, 0, '2020-12-09 14:31:39', NULL),
(198, 1, 1, 'test', 'test', '2021-01-11', '2021-01-11', '2021-01-11', 0, NULL, '2021-01-11', NULL, NULL, NULL, NULL, 1, NULL, NULL),
(199, 1, 1, 'test2', 'test2', '2021-01-11', '2021-01-11', '2021-01-11', 0, '', '2021-01-11', NULL, NULL, NULL, NULL, 1, NULL, NULL),
(200, 1, 1, 'test', 'test', '2021-01-11', '2021-01-11', '2021-01-11', 0, '', '2021-01-11', NULL, NULL, NULL, NULL, 1, NULL, NULL),
(201, 1, 1, 'munk-gorn', 'munk gorn', '2021-01-11', '2021-01-11', '2021-01-11', 0, '', '2021-01-11', NULL, NULL, NULL, NULL, 1, '2021-01-11 15:22:15', '2021-01-11 15:22:15'),
(202, 1, 1, 'test', 'test', '2021-01-11', '2021-01-11', '2021-01-11', 0, '', '2021-01-11', NULL, NULL, NULL, NULL, 1, '2021-01-11 15:30:17', '2021-01-11 15:30:17'),
(203, 1, 3, 'testeqat', 'testeqat', '2021-01-31', '2021-01-31', '2021-01-31', 1, '', '2021-01-31', NULL, NULL, NULL, NULL, 0, '2021-01-18 15:19:58', '2021-01-18 15:19:58'),
(204, 1, 8, 'test', 'test', '2021-01-31', '2021-01-31', '2021-01-31', 1, '', '2021-01-31', 1, NULL, NULL, '', 0, '2021-01-18 15:29:38', '2021-01-18 15:29:38'),
(205, 1, 9, 'test', 'test', '2021-01-31', '2021-01-31', '2021-01-31', 1, '', '2021-01-31', 1, NULL, NULL, '', 0, '2021-01-18 17:20:06', '2021-01-18 17:20:06'),
(206, 2, 1, 'munk-gorn', 'munk gorn', '2021-01-20', '2021-01-20', '2021-01-20', 0, '', '2021-01-20', 0, NULL, NULL, '', 1, '2021-01-20 14:21:55', '2021-01-20 14:21:55');

-- --------------------------------------------------------

--
-- Table structure for table `mhd_program_trial_specimen`
--

CREATE TABLE `mhd_program_trial_specimen` (
  `id` int(11) NOT NULL,
  `program_id` int(11) DEFAULT NULL,
  `trial_id` int(11) DEFAULT NULL,
  `name` text DEFAULT NULL,
  `file` varchar(255) DEFAULT NULL,
  `file_name` varchar(255) DEFAULT NULL,
  `date_added` datetime DEFAULT NULL,
  `date_modify` datetime DEFAULT NULL,
  `del` int(11) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `mhd_program_trial_specimen`
--

INSERT INTO `mhd_program_trial_specimen` (`id`, `program_id`, `trial_id`, `name`, `file`, `file_name`, `date_added`, `date_modify`, `del`) VALUES
(1, 8, 1, 'test 01', NULL, NULL, '2016-12-23 01:52:47', NULL, 0),
(2, 8, 1, 'test 02.5', NULL, NULL, '2016-12-23 01:54:01', NULL, 0),
(5, 8, 1, 'test 03', NULL, NULL, '2016-12-23 02:06:44', NULL, 0),
(6, 8, 1, 'test 04', NULL, NULL, '2016-12-23 02:12:34', NULL, 0),
(7, 8, 2, 'no 01', NULL, NULL, '2016-12-23 02:14:45', NULL, 0),
(8, 8, 2, 'no 02', NULL, NULL, '2016-12-23 02:18:21', NULL, 0),
(10, 4, 7, 'no 01', NULL, NULL, '2016-12-23 02:53:47', NULL, 0),
(11, 4, 6, 'no 01', NULL, NULL, '2016-12-23 02:54:15', NULL, 0),
(12, 4, 1, 'B6002', NULL, NULL, '2017-05-22 15:28:05', NULL, 0),
(13, 8, 6, 'SE-01-17-1-1', NULL, NULL, '2017-05-22 15:28:48', NULL, 0),
(20, 8, 6, 'SE-01-17-1-2', NULL, NULL, '2017-05-29 11:42:59', NULL, 0),
(21, 8, 6, 'SE-01-17-1-3', NULL, NULL, '2017-05-29 11:43:05', NULL, 0),
(22, 8, 6, 'SE-01-17-1-4', NULL, NULL, '2017-05-29 11:43:09', NULL, 0),
(24, 8, 12, 'SE-01-17-2-1', NULL, NULL, '2017-05-31 09:05:17', NULL, 0),
(25, 8, 12, 'SE-01-17-2-2', NULL, NULL, '2017-05-31 09:06:26', NULL, 0),
(26, 8, 12, 'SE-01-17-2-3', NULL, NULL, '2017-05-31 09:06:32', NULL, 0),
(27, 8, 12, 'SE-01-17-2-4', NULL, NULL, '2017-05-31 09:06:41', NULL, 0),
(28, 8, 13, 'SE-01-17-3-1', NULL, NULL, '2017-05-31 09:07:08', NULL, 0),
(29, 8, 13, 'SE-01-17-3-2', NULL, NULL, '2017-05-31 09:07:19', NULL, 0),
(30, 8, 13, 'SE-01-17-3-3', NULL, NULL, '2017-05-31 09:07:32', NULL, 0),
(31, 8, 15, 'SE-01-17-4-1', NULL, NULL, '2017-11-23 14:06:53', NULL, 0),
(33, 8, 15, 'SE-01-17-4-2', NULL, NULL, '2017-11-23 14:07:08', NULL, 0),
(34, 8, 15, 'SE-01-17-4-3', NULL, NULL, '2017-11-23 14:07:16', NULL, 0),
(35, 8, 15, 'SE-01-17-4-4', NULL, NULL, '2017-11-23 14:07:35', NULL, 0),
(39, 4, 20, 'B6002', NULL, NULL, '2017-11-23 14:08:48', NULL, 0),
(41, 5, 22, '1', NULL, NULL, '2017-12-21 18:29:16', NULL, 0),
(44, 1, 25, 'Sample 1', NULL, NULL, '2018-05-09 13:14:45', NULL, 0),
(45, 1, 25, 'Sample 2', NULL, NULL, '2018-07-25 15:59:01', NULL, 0),
(46, 1, 36, 'sample 1', NULL, NULL, '2018-07-25 16:10:19', NULL, 0),
(47, 2, 38, 'sample 1', NULL, NULL, '2018-07-25 17:30:46', NULL, 0),
(48, 2, 38, 'sample 2', NULL, NULL, '2018-07-25 17:30:47', NULL, 0),
(49, 2, 40, 'S1', NULL, NULL, '2018-07-25 17:34:33', NULL, 0),
(50, 2, 40, 'S2', NULL, NULL, '2018-07-25 17:35:03', NULL, 0),
(51, 3, 37, 'trial 157', NULL, NULL, '2018-07-26 11:35:09', NULL, 0),
(52, 3, 37, 'trial 158', NULL, NULL, '2018-07-26 11:35:13', NULL, 0),
(53, 12, 41, 'EQAB 8020 : AFB 20-1-1', '', NULL, '2018-08-07 13:23:49', NULL, 0),
(54, 7, 42, 'C1', NULL, NULL, '2018-08-08 16:07:19', NULL, 0),
(55, 7, 42, 'C2', NULL, NULL, '2018-08-08 16:07:23', NULL, 0),
(56, 6, 43, 'H1', NULL, NULL, '2018-08-09 10:44:21', NULL, 0),
(57, 6, 43, 'H2', NULL, NULL, '2018-08-09 10:44:26', NULL, 0),
(58, 10, 44, 'EQAB 8010 : Gram 20-1-1', NULL, NULL, '2018-08-09 16:19:38', NULL, 0),
(59, 10, 44, 'EQAB 8010 : Gram 20-1-2', NULL, NULL, '2018-08-09 16:19:58', NULL, 0),
(60, 13, 45, 'EQAB 8015 : IDEN 18-1-1', NULL, NULL, '2018-08-09 16:23:36', NULL, 0),
(61, 13, 45, 'EQAB 8015 : IDEN 18-1-2', NULL, NULL, '2018-08-09 16:23:38', NULL, 0),
(62, 4, 23, 'sample_1', NULL, NULL, '2018-08-09 16:29:24', NULL, 0),
(63, 4, 23, 'sample_2', NULL, NULL, '2018-08-09 16:29:27', NULL, 0),
(64, 12, 41, 'EQAB 8020 : AFB 20-1-2', '', NULL, '2018-08-10 12:33:06', NULL, 0),
(66, 8, 46, 'test speci', NULL, NULL, '2018-08-14 14:39:19', NULL, 0),
(67, 9, 47, 'S2-1-1', NULL, NULL, '2018-08-17 16:33:51', NULL, 0),
(68, 9, 47, 'S2-1-2', NULL, NULL, '2018-08-17 16:33:58', NULL, 0),
(69, 9, 47, 'S2-1-3', NULL, NULL, '2018-08-17 16:34:05', NULL, 0),
(70, 9, 47, 'S2-1-4', NULL, NULL, '2018-08-17 16:34:14', NULL, 0),
(75, 7, 42, 'U1', NULL, NULL, '2018-09-26 14:26:13', NULL, 0),
(76, 7, 42, 'U2', NULL, NULL, '2018-09-26 14:26:18', NULL, 0),
(77, 13, 48, 'EQAB : 8150 IDEN 20-1-1', NULL, NULL, '2018-10-02 11:42:09', NULL, 0),
(78, 13, 48, 'EQAB : 8150 IDEN 20-1-2', NULL, NULL, '2018-10-02 11:42:14', NULL, 0),
(79, 1, 50, 'sample1', NULL, NULL, '2018-10-16 14:19:13', NULL, 0),
(80, 1, 51, 'EQAC 266', NULL, NULL, '2018-10-31 10:14:13', NULL, 0),
(81, 1, 52, '268', NULL, NULL, '2018-10-31 10:57:05', NULL, 0),
(82, 13, 54, 'sample 1', NULL, NULL, '2018-11-14 10:31:29', NULL, 0),
(83, 13, 54, 'ssss2', NULL, NULL, '2018-11-14 10:31:36', NULL, 0),
(84, 1, 55, '269', NULL, NULL, '2018-11-28 09:46:22', NULL, 0),
(85, 1, 56, '222', NULL, NULL, '2018-11-28 09:53:30', NULL, 0),
(87, 1, 59, 'test system', NULL, NULL, '2018-12-19 14:38:19', NULL, 0),
(88, 2, 62, 'S1', NULL, NULL, '2019-07-05 13:21:02', NULL, 0),
(89, 2, 62, 'S2', NULL, NULL, '2019-07-05 13:24:57', NULL, 0),
(90, 4, 64, 'ST-6208-1', NULL, NULL, '2019-07-05 13:44:06', NULL, 0),
(91, 4, 64, 'BL-6208-2', NULL, NULL, '2019-07-05 13:44:22', NULL, 0),
(92, 2, 67, 'S1', NULL, NULL, '2019-07-05 13:52:16', NULL, 0),
(93, 2, 67, 'S2', NULL, NULL, '2019-07-05 13:52:24', NULL, 0),
(94, 1, 65, '269', NULL, NULL, '2019-07-05 14:30:56', NULL, 0),
(95, 1, 53, '280', NULL, NULL, '2019-08-15 12:30:43', NULL, 0),
(96, 1, 77, '281', NULL, NULL, '2019-08-15 12:31:27', NULL, 0),
(97, 1, 78, '282', NULL, NULL, '2019-08-15 12:36:39', NULL, 0),
(98, 1, 79, '282', NULL, NULL, '2019-08-15 12:46:31', NULL, 0),
(99, 1, 80, '284', NULL, NULL, '2019-08-15 12:48:08', NULL, 0),
(100, 1, 81, '285', NULL, NULL, '2019-08-15 12:51:48', NULL, 0),
(101, 1, 82, '286', NULL, NULL, '2019-08-15 12:54:51', NULL, 0),
(102, 5, 83, 'B6301', NULL, NULL, '2019-10-30 13:52:22', NULL, 0),
(103, 6, 84, '6301.1', NULL, NULL, '2019-10-30 14:14:24', NULL, 0),
(104, 6, 84, '6301.2', NULL, NULL, '2019-10-30 14:20:53', NULL, 0),
(105, 7, 85, 'C1', NULL, NULL, '2019-10-30 14:36:58', NULL, 0),
(106, 7, 85, 'C2', NULL, NULL, '2019-10-30 14:37:03', NULL, 0),
(107, 7, 85, 'U1', NULL, NULL, '2019-10-30 14:37:10', NULL, 0),
(108, 7, 85, 'U2', NULL, NULL, '2019-10-30 14:37:16', NULL, 0),
(109, 8, 76, 'SE01-20-1-1', NULL, NULL, '2019-11-12 16:26:12', NULL, 0),
(110, 8, 76, 'SE01-20-1-2', NULL, NULL, '2019-11-12 16:27:04', NULL, 0),
(111, 8, 76, 'SE01-20-1-3', NULL, NULL, '2019-11-12 16:27:17', NULL, 0),
(112, 8, 76, 'SE01-20-1-4', NULL, NULL, '2019-11-12 16:27:26', NULL, 0),
(113, 9, 86, 'SE02-20-1-1', NULL, NULL, '2019-11-12 16:31:43', NULL, 0),
(114, 9, 86, 'SE02-20-1-2', NULL, NULL, '2019-11-12 16:31:57', NULL, 0),
(115, 9, 86, 'SE02-20-1-3', NULL, NULL, '2019-11-12 16:32:06', NULL, 0),
(116, 9, 86, 'SE02-20-1-4', NULL, NULL, '2019-11-12 16:32:15', NULL, 0),
(117, 4, 87, 'ST-6211-1', NULL, NULL, '2019-11-14 08:48:29', NULL, 0),
(118, 4, 87, 'BL-6211-2', NULL, NULL, '2019-11-14 08:48:42', NULL, 0),
(119, 2, 89, '430', NULL, NULL, '2019-11-27 14:06:14', NULL, 0),
(120, 2, 91, 'Result 428', NULL, NULL, '2019-11-27 14:09:36', NULL, 0),
(121, 2, 91, 'Result 429', NULL, NULL, '2019-11-27 14:27:56', NULL, 0),
(124, 6, 93, '1test', NULL, NULL, '2019-11-29 16:24:35', NULL, 0),
(125, 2, 94, 'sample1', NULL, NULL, '2019-12-02 09:43:59', NULL, 0),
(126, 2, 95, 'sample1', NULL, NULL, '2019-12-02 09:46:55', NULL, 0),
(127, 2, 95, 'sample2', NULL, NULL, '2019-12-02 09:47:06', NULL, 0),
(128, 3, 96, 'Trial173', NULL, NULL, '2019-12-02 10:35:43', NULL, 0),
(129, 3, 96, 'Trial174', NULL, NULL, '2019-12-02 10:36:01', NULL, 0),
(130, 2, 97, 'sample1', NULL, NULL, '2019-12-02 10:55:09', NULL, 0),
(131, 2, 97, 'Sampl2', NULL, NULL, '2019-12-02 10:55:19', NULL, 0),
(132, 9, 99, 'SE020302', NULL, NULL, '2019-12-04 08:02:41', NULL, 0),
(133, 9, 99, 'SE020102', NULL, NULL, '2019-12-04 08:02:47', NULL, 0),
(134, 9, 99, '3', NULL, NULL, '2019-12-04 08:02:53', NULL, 0),
(135, 9, 99, '4', NULL, NULL, '2019-12-04 08:02:58', NULL, 0),
(136, 8, 88, '123', NULL, NULL, '2019-12-04 08:09:42', NULL, 0),
(137, 8, 88, '456', NULL, NULL, '2019-12-04 08:09:47', NULL, 0),
(138, 8, 105, 'SE 01-20-2-1', NULL, NULL, '2019-12-24 10:24:59', NULL, 0),
(139, 8, 105, 'SE 01-20-2-2', NULL, NULL, '2019-12-24 10:25:10', NULL, 0),
(140, 8, 105, 'SE 01-20-2-3', NULL, NULL, '2019-12-24 10:25:17', NULL, 0),
(141, 8, 105, 'SE 01-20-2-4', NULL, NULL, '2019-12-24 10:25:23', NULL, 0),
(142, 9, 104, 'SE 02-20-2-1', NULL, NULL, '2019-12-24 10:31:57', NULL, 0),
(143, 9, 104, 'SE 02-20-2-2', NULL, NULL, '2019-12-24 10:32:04', NULL, 0),
(144, 9, 104, 'SE 02-20-2-3', NULL, NULL, '2019-12-24 10:32:11', NULL, 0),
(145, 9, 104, 'SE 02-20-2-4', NULL, NULL, '2019-12-24 10:32:21', NULL, 0),
(146, 8, 106, 'SE 01-21-1-1', NULL, NULL, '2019-12-24 16:00:54', NULL, 0),
(147, 8, 106, 'SE 01-21-1-2', NULL, NULL, '2019-12-24 16:01:06', NULL, 0),
(148, 8, 106, 'SE 01-21-1-3', NULL, NULL, '2019-12-24 16:01:27', NULL, 0),
(149, 8, 106, 'SE 01-21-1-4', NULL, NULL, '2019-12-24 16:01:47', NULL, 0),
(150, 1, 107, '287', NULL, NULL, '2019-12-25 11:19:03', NULL, 0),
(151, 1, 108, '288', NULL, NULL, '2019-12-25 11:19:41', NULL, 0),
(152, 1, 109, '289', NULL, NULL, '2019-12-25 11:20:25', NULL, 0),
(153, 1, 110, '290', NULL, NULL, '2019-12-25 11:21:25', NULL, 0),
(154, 1, 111, '291', NULL, NULL, '2019-12-25 11:22:00', NULL, 0),
(155, 3, 115, 'T173', NULL, NULL, '2019-12-25 13:19:00', NULL, 0),
(156, 3, 115, 'T174', NULL, NULL, '2019-12-25 13:19:09', NULL, 0),
(157, 2, 112, '108_Sample1', NULL, NULL, '2019-12-25 13:22:26', NULL, 0),
(158, 2, 112, '108_Sample2', NULL, NULL, '2019-12-25 13:22:46', NULL, 0),
(159, 1, 118, '292', NULL, NULL, '2019-12-25 14:16:38', NULL, 0),
(160, 2, 119, 'sample1', NULL, NULL, '2019-12-25 14:45:30', NULL, 0),
(161, 2, 119, 'sample2', NULL, NULL, '2019-12-25 14:45:41', NULL, 0),
(162, 2, 120, 'Sample1', NULL, NULL, '2019-12-26 14:45:48', NULL, 0),
(163, 2, 120, 'Sample2', NULL, NULL, '2019-12-26 14:47:07', NULL, 0),
(164, 3, 123, 'Trial173', NULL, NULL, '2019-12-26 14:50:13', NULL, 0),
(165, 3, 123, 'Trial174', NULL, NULL, '2019-12-26 14:50:29', NULL, 0),
(166, 6, 124, '6303.1', NULL, NULL, '2020-01-06 15:38:53', NULL, 0),
(167, 6, 124, '6303.2', NULL, NULL, '2020-01-06 15:39:00', NULL, 0),
(168, 1, 125, '280', NULL, NULL, '2020-01-07 10:09:01', NULL, 0),
(169, 1, 126, '280', NULL, NULL, '2020-01-07 10:10:47', NULL, 0),
(170, 9, 128, 'SE-02-20-1-1', NULL, NULL, '2020-01-07 15:25:10', NULL, 0),
(171, 9, 128, 'SE-02-20-1-2', NULL, NULL, '2020-01-07 15:25:20', NULL, 0),
(172, 9, 128, 'SE-02-20-1-3', NULL, NULL, '2020-01-07 15:25:27', NULL, 0),
(173, 9, 128, 'SE-02-20-1-4', NULL, NULL, '2020-01-07 15:25:33', NULL, 0),
(174, 8, 127, 'SE01-20-1-1', NULL, NULL, '2020-01-09 12:54:47', NULL, 0),
(175, 8, 127, 'SE01-20-1-2', NULL, NULL, '2020-01-09 12:55:07', NULL, 0),
(176, 8, 127, 'SE01-20-1-3', NULL, NULL, '2020-01-09 12:55:20', NULL, 0),
(177, 8, 127, 'SE01-20-1-4', NULL, NULL, '2020-01-09 12:55:32', NULL, 0),
(178, 6, 93, 'test', NULL, NULL, '2020-01-09 16:04:51', NULL, 0),
(179, 3, 129, 'Trial175', NULL, NULL, '2020-01-10 14:58:25', NULL, 0),
(180, 3, 129, 'Trial176', NULL, NULL, '2020-01-10 14:58:40', NULL, 0),
(181, 2, 130, 'Sample1', NULL, NULL, '2020-01-10 15:08:53', NULL, 0),
(182, 2, 130, 'Sample2', NULL, NULL, '2020-01-10 15:09:07', NULL, 0),
(188, 7, 132, 'C1', NULL, NULL, '2020-01-23 10:15:49', NULL, 0),
(189, 7, 132, 'C2', NULL, NULL, '2020-01-23 10:15:52', NULL, 0),
(190, 7, 132, 'U1', NULL, NULL, '2020-01-23 10:15:59', NULL, 0),
(191, 7, 132, 'U2', NULL, NULL, '2020-01-23 10:16:10', NULL, 0),
(192, 7, 133, 'C1', NULL, NULL, '2020-01-23 10:44:23', NULL, 0),
(193, 7, 133, 'C2', NULL, NULL, '2020-01-23 10:44:27', NULL, 0),
(194, 7, 133, 'U1', NULL, NULL, '2020-01-23 10:44:30', NULL, 0),
(195, 7, 133, 'U2', NULL, NULL, '2020-01-23 10:44:34', NULL, 0),
(196, 6, 101, '6302.1', NULL, NULL, '2020-01-28 11:04:36', NULL, 0),
(197, 6, 101, '6302.2', NULL, NULL, '2020-01-28 11:04:43', NULL, 0),
(199, 1, 134, '281', NULL, NULL, '2020-02-03 14:31:10', NULL, 0),
(200, 4, 135, 'ST-6302-1', NULL, NULL, '2020-02-07 15:00:40', NULL, 0),
(201, 4, 135, 'ST-6302-2', NULL, NULL, '2020-02-07 15:00:51', NULL, 0),
(208, 7, 136, 'C1', NULL, NULL, '2020-02-17 15:19:24', NULL, 0),
(209, 7, 136, 'C2', NULL, NULL, '2020-02-17 15:19:28', NULL, 0),
(210, 7, 136, 'U1', NULL, NULL, '2020-02-17 15:19:32', NULL, 0),
(211, 7, 136, 'U2', NULL, NULL, '2020-02-17 15:19:36', NULL, 0),
(212, 5, 137, 'B6301', NULL, NULL, '2020-02-17 15:20:15', NULL, 0),
(213, 6, 138, '6301.1', NULL, NULL, '2020-02-17 15:20:34', NULL, 0),
(214, 6, 138, '6301.2', NULL, NULL, '2020-02-17 15:20:39', NULL, 0),
(215, 8, 139, '1', NULL, NULL, '2020-02-17 16:03:45', NULL, 0),
(216, 3, 140, 'Trial 177', NULL, NULL, '2020-02-28 14:10:05', NULL, 0),
(217, 3, 140, 'Trial 178', NULL, NULL, '2020-02-28 14:10:25', NULL, 0),
(218, 1, 143, '282', NULL, NULL, '2020-03-10 09:00:47', NULL, 0),
(219, 9, 146, '1', NULL, NULL, '2020-03-23 09:06:58', NULL, 0),
(220, 9, 146, '2', NULL, NULL, '2020-03-23 09:07:03', NULL, 0),
(221, 9, 146, '3', NULL, NULL, '2020-03-23 09:07:07', NULL, 0),
(222, 9, 146, '4', NULL, NULL, '2020-03-23 09:07:12', NULL, 0),
(223, 8, 147, '1', NULL, NULL, '2020-03-23 09:41:47', NULL, 0),
(224, 8, 147, '2', NULL, NULL, '2020-03-23 09:41:50', NULL, 0),
(225, 8, 147, '3', NULL, NULL, '2020-03-23 09:41:53', NULL, 0),
(226, 8, 147, '4', NULL, NULL, '2020-03-23 09:41:57', NULL, 0),
(227, 2, 148, 'Sample 1', NULL, NULL, '2020-04-03 07:37:51', NULL, 0),
(228, 1, 149, '282', NULL, NULL, '2020-04-04 12:24:51', NULL, 0),
(229, 1, 150, '284', NULL, NULL, '2020-04-04 19:22:27', NULL, 0),
(230, 2, 148, 'Sample 2', NULL, NULL, '2020-04-09 16:28:15', NULL, 0),
(231, 3, 151, 'Trial 179', NULL, NULL, '2020-04-10 10:41:38', NULL, 0),
(232, 3, 151, 'Trial 180', NULL, NULL, '2020-04-10 10:41:50', NULL, 0),
(233, 4, 152, 'ST-6305-1', NULL, NULL, '2020-04-17 11:13:54', NULL, 0),
(234, 4, 152, 'BL-6305-2', NULL, NULL, '2020-04-17 11:14:11', NULL, 0),
(235, 8, 153, 'SE01-20-2-1', NULL, NULL, '2020-04-21 20:51:04', NULL, 0),
(236, 8, 153, 'SE01-20-2-2', NULL, NULL, '2020-04-21 20:52:10', NULL, 0),
(237, 8, 153, 'SE01-20-2-3', NULL, NULL, '2020-04-21 20:52:20', NULL, 0),
(238, 8, 153, 'SE01-20-2-4', NULL, NULL, '2020-04-21 20:52:30', NULL, 0),
(239, 9, 154, 'SE-02-20-2-1', NULL, NULL, '2020-04-21 20:58:22', NULL, 0),
(240, 9, 154, 'SE-02-20-2-2', NULL, NULL, '2020-04-21 20:58:56', NULL, 0),
(241, 9, 154, 'SE-02-20-2-3', NULL, NULL, '2020-04-21 20:59:03', NULL, 0),
(242, 9, 154, 'SE-02-20-2-4', NULL, NULL, '2020-04-21 20:59:11', NULL, 0),
(243, 1, 155, '284', NULL, NULL, '2020-05-07 09:41:39', NULL, 0),
(244, 7, 156, 'C1', NULL, NULL, '2020-05-18 09:05:00', NULL, 0),
(245, 7, 156, 'C2', NULL, NULL, '2020-05-18 09:05:05', NULL, 0),
(246, 7, 156, 'U1', NULL, NULL, '2020-05-18 09:05:10', NULL, 0),
(247, 7, 156, 'U2', NULL, NULL, '2020-05-18 09:05:16', NULL, 0),
(248, 6, 157, '6302.1', NULL, NULL, '2020-05-18 09:06:17', NULL, 0),
(249, 6, 157, '6302.2', NULL, NULL, '2020-05-18 09:06:23', NULL, 0),
(250, 5, 158, 'B6302', NULL, NULL, '2020-05-18 09:06:59', NULL, 0),
(251, 1, 160, '285', NULL, NULL, '2020-06-08 11:21:09', NULL, 0),
(252, 2, 161, 'Sample 1', NULL, NULL, '2020-06-12 10:55:22', NULL, 0),
(253, 2, 161, 'Sample 2', NULL, NULL, '2020-06-12 10:55:36', NULL, 0),
(254, 2, 162, 'Sample 1', NULL, NULL, '2020-06-12 10:59:20', NULL, 0),
(255, 2, 162, 'Sample 2', NULL, NULL, '2020-06-12 10:59:30', NULL, 0),
(256, 12, 164, 'EQAB 8020 : AFB 20-2-1', NULL, NULL, '2020-06-15 20:19:45', NULL, 0),
(257, 12, 164, 'EQAB 8020 : AFB 20-2-2', NULL, NULL, '2020-06-15 20:19:58', NULL, 0),
(258, 10, 165, 'EQAB 8010 : Gram 20-2-1', NULL, NULL, '2020-06-15 20:22:23', NULL, 0),
(259, 10, 165, 'EQAB 8010 : Gram 20-2-2', NULL, NULL, '2020-06-15 20:22:33', NULL, 0),
(260, 13, 166, 'EQAB : 8150 IDEN 20-2-1', NULL, NULL, '2020-06-15 20:24:08', NULL, 0),
(261, 13, 166, 'EQAB : 8150 IDEN 20-2-2', NULL, NULL, '2020-06-15 20:24:20', NULL, 0),
(262, 8, 167, 'SE-01-21-1-1', NULL, NULL, '2020-06-19 15:03:23', NULL, 0),
(263, 1, 168, '286', NULL, NULL, '2020-07-01 16:20:39', NULL, 0),
(264, 1, 169, '286', NULL, NULL, '2020-07-09 16:35:21', NULL, 0),
(265, 4, 170, 'ST-6308-1', NULL, NULL, '2020-07-10 15:03:13', NULL, 0),
(266, 4, 170, 'ST-6308-2', NULL, NULL, '2020-07-10 15:03:20', NULL, 0),
(267, 3, 171, 'Trial 181', NULL, NULL, '2020-07-15 14:26:25', NULL, 0),
(268, 3, 171, 'Trial 182', NULL, NULL, '2020-07-15 14:26:42', NULL, 0),
(269, 1, 172, '111', NULL, NULL, '2020-07-21 15:09:16', NULL, 0),
(270, 8, 173, 'SE-01-20-3-1', NULL, NULL, '2020-07-21 18:10:01', NULL, 0),
(271, 8, 173, 'SE-01-20-3-2', NULL, NULL, '2020-07-21 18:10:13', NULL, 0),
(272, 8, 173, 'SE-01-20-3-3', NULL, NULL, '2020-07-21 18:10:26', NULL, 0),
(273, 8, 173, 'SE-01-20-3-4', NULL, NULL, '2020-07-21 18:10:34', NULL, 0),
(274, 9, 174, 'SE-02-20-3-1', NULL, NULL, '2020-08-01 07:45:57', NULL, 0),
(275, 9, 174, 'SE-02-20-3-2', NULL, NULL, '2020-08-01 07:46:08', NULL, 0),
(276, 9, 174, 'SE-02-20-3-3', NULL, NULL, '2020-08-01 07:46:15', NULL, 0),
(277, 9, 174, 'SE-02-20-3-4', NULL, NULL, '2020-08-01 07:46:23', NULL, 0),
(278, 1, 175, '287', NULL, NULL, '2020-08-11 09:32:55', NULL, 0),
(279, 8, 176, 'SE-01-20-4-1', NULL, NULL, '2020-09-03 09:19:06', NULL, 0),
(280, 9, 177, 'SE-02-20-4-1', NULL, NULL, '2020-09-03 09:47:03', NULL, 0),
(281, 8, 176, 'SE-01-20-4-2', NULL, NULL, '2020-09-03 14:42:13', NULL, 0),
(282, 8, 176, 'SE-01-20-4-3', NULL, NULL, '2020-09-03 14:42:44', NULL, 0),
(283, 8, 176, 'SE-01-20-4-4', NULL, NULL, '2020-09-03 14:43:07', NULL, 0),
(284, 1, 178, '288', NULL, NULL, '2020-09-03 16:21:56', NULL, 0),
(285, 7, 179, 'C1', NULL, NULL, '2020-09-14 10:09:12', NULL, 0),
(286, 7, 179, 'C2', NULL, NULL, '2020-09-14 10:09:17', NULL, 0),
(287, 7, 179, 'U1', NULL, NULL, '2020-09-14 10:09:22', NULL, 0),
(288, 7, 179, 'U2', NULL, NULL, '2020-09-14 10:09:27', NULL, 0),
(289, 5, 180, 'B6303', NULL, NULL, '2020-09-14 10:10:10', NULL, 0),
(290, 3, 181, 'Trial 183', NULL, NULL, '2020-09-14 14:54:40', NULL, 0),
(291, 3, 181, 'Trial 184', NULL, NULL, '2020-09-14 14:54:53', NULL, 0),
(292, 9, 177, 'SE-02-20-4-2', NULL, NULL, '2020-09-15 11:38:05', NULL, 0),
(293, 9, 177, 'SE-02-20-4-3', NULL, NULL, '2020-09-15 11:38:11', NULL, 0),
(294, 9, 177, 'SE-02-20-4-4', NULL, NULL, '2020-09-15 11:38:18', NULL, 0),
(295, 8, 182, '121', NULL, NULL, '2020-09-23 10:27:36', NULL, 0),
(296, 8, 182, '12', NULL, NULL, '2020-09-23 10:27:57', NULL, 0),
(297, 2, 185, 'Sample 1', NULL, NULL, '2020-10-01 09:39:49', NULL, 0),
(298, 2, 185, 'Sample 2', NULL, NULL, '2020-10-01 09:40:52', NULL, 0),
(299, 3, 186, 'Trial 185', NULL, NULL, '2020-10-05 08:56:07', NULL, 0),
(300, 3, 186, 'Trial 186', NULL, NULL, '2020-10-05 08:56:20', NULL, 0),
(301, 1, 187, '289', NULL, NULL, '2020-10-05 11:44:54', NULL, 0),
(302, 12, 189, 'EQAB 8020 : AFB 20-3-1', NULL, NULL, '2020-10-16 14:12:16', NULL, 0),
(303, 12, 189, 'EQAB 8020 : AFB 20-3-2', NULL, NULL, '2020-10-16 14:12:25', NULL, 0),
(304, 10, 188, 'EQAB 8010 : GRAM 20-3-1', NULL, NULL, '2020-10-16 14:12:46', NULL, 0),
(305, 10, 188, 'EQAB 8010 : GRAM 20-3-2', NULL, NULL, '2020-10-16 14:12:53', NULL, 0),
(306, 13, 191, 'EQAB 8015 : IDEN 20-3-1', NULL, NULL, '2020-10-16 14:13:12', NULL, 0),
(307, 13, 191, 'EQAB 8015 : IDEN 20-3-2', NULL, NULL, '2020-10-16 14:13:19', NULL, 0),
(308, 1, 192, '290', NULL, NULL, '2020-11-02 17:38:35', NULL, 0),
(309, 4, 193, 'ST-6311-1', NULL, NULL, '2020-11-07 06:41:00', NULL, 0),
(310, 4, 193, 'BL-6311-2', NULL, NULL, '2020-11-07 06:41:49', NULL, 0),
(311, 6, 194, '6303.1', NULL, NULL, '2020-11-27 13:45:39', NULL, 0),
(312, 6, 194, '6303.2', NULL, NULL, '2020-11-27 13:45:44', NULL, 0),
(313, 5, 195, 'B6304', NULL, NULL, '2020-11-27 13:46:41', NULL, 0),
(314, 1, 196, '291', NULL, NULL, '2020-12-01 14:29:09', NULL, 0),
(315, 2, 197, 'Sample 1', NULL, NULL, '2020-12-09 14:34:05', NULL, 0),
(316, 2, 197, 'Sample 2', NULL, NULL, '2020-12-09 14:34:20', NULL, 0),
(318, 7, 198, 'C1', NULL, NULL, '2020-12-28 09:43:49', NULL, 0),
(319, 7, 198, 'C2', NULL, NULL, '2020-12-28 09:43:53', NULL, 0),
(320, 7, 198, 'U1', NULL, NULL, '2020-12-28 09:43:57', NULL, 0),
(321, 7, 198, 'U2', NULL, NULL, '2020-12-28 09:44:00', NULL, 0),
(322, 6, 199, '6304.1', NULL, NULL, '2020-12-28 09:45:58', NULL, 0),
(323, 6, 199, '6304.2', NULL, NULL, '2020-12-28 09:46:05', NULL, 0),
(324, 1, 200, '292', NULL, NULL, '2021-01-03 21:05:42', NULL, 0),
(325, 3, 201, 'Sample 1', NULL, NULL, '2021-01-06 13:28:16', NULL, 0),
(326, 3, 201, 'Sample 2', NULL, NULL, '2021-01-06 13:28:33', NULL, 0),
(327, NULL, NULL, 'test', NULL, NULL, '2021-01-11 16:12:31', NULL, 0),
(328, NULL, NULL, 'test2', NULL, NULL, '2021-01-11 16:12:41', NULL, 0),
(329, 3, 181, 'test3', NULL, NULL, '2021-01-11 16:13:37', NULL, 1),
(330, 1, 126, 'ะะะะ', NULL, NULL, '2021-01-11 16:34:58', NULL, 1),
(331, 8, 204, 'test1', NULL, NULL, '2021-01-18 15:32:57', NULL, 0),
(332, 8, 204, 'test2', NULL, NULL, '2021-01-18 15:33:01', NULL, 0),
(333, 9, 205, 'test1', NULL, NULL, '2021-01-18 17:34:58', NULL, 0),
(334, 9, 205, 'test2', NULL, NULL, '2021-01-18 17:35:02', NULL, 0);

-- --------------------------------------------------------

--
-- Table structure for table `mhd_register`
--

CREATE TABLE `mhd_register` (
  `id` int(11) NOT NULL,
  `parent_id` int(11) DEFAULT 0,
  `member_id` int(11) DEFAULT NULL,
  `company_id` int(11) DEFAULT NULL,
  `year_id` int(11) DEFAULT NULL,
  `total` double(10,2) DEFAULT NULL,
  `date_added` datetime DEFAULT NULL,
  `date_modify` datetime DEFAULT NULL,
  `del` int(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `mhd_register`
--

INSERT INTO `mhd_register` (`id`, `parent_id`, `member_id`, `company_id`, `year_id`, `total`, `date_added`, `date_modify`, `del`) VALUES
(1, 0, 1, 1, 1, 19400.00, '2021-01-12 13:43:45', NULL, 0);

-- --------------------------------------------------------

--
-- Table structure for table `mhd_register_program`
--

CREATE TABLE `mhd_register_program` (
  `id` int(11) NOT NULL,
  `register_id` int(11) DEFAULT NULL,
  `parent_id` int(11) DEFAULT NULL,
  `company_id` int(11) DEFAULT NULL,
  `member_id` int(11) DEFAULT NULL,
  `year_id` int(11) DEFAULT NULL,
  `program_id` int(11) DEFAULT NULL,
  `trial_id` int(11) DEFAULT NULL,
  `price` decimal(10,2) DEFAULT NULL,
  `payment_id` int(11) DEFAULT NULL,
  `send_slip` int(11) DEFAULT 0,
  `date_added` datetime DEFAULT NULL,
  `date_modify` datetime DEFAULT NULL,
  `del` int(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `mhd_register_program`
--

INSERT INTO `mhd_register_program` (`id`, `register_id`, `parent_id`, `company_id`, `member_id`, `year_id`, `program_id`, `trial_id`, `price`, `payment_id`, `send_slip`, `date_added`, `date_modify`, `del`) VALUES
(1, 1, 0, 1, 1, 1, 1, NULL, '3000.00', 2, 1, '2021-01-12 13:44:05', NULL, 0),
(2, 1, 0, 1, 1, 1, 5, NULL, '2000.00', 2, 1, '2021-01-12 13:44:05', NULL, 0),
(3, 1, 0, 1, 1, 1, 6, NULL, '1500.00', 2, 1, '2021-01-12 13:44:05', NULL, 0),
(4, 1, 0, 1, 1, 1, 2, NULL, '4500.00', 2, 1, '2021-01-18 12:36:46', NULL, 0),
(5, 1, 0, 1, 1, 1, 3, NULL, '4500.00', 2, 1, '2021-01-18 12:36:46', NULL, 0),
(6, 1, 0, 1, 1, 1, 4, NULL, '2000.00', 2, 1, '2021-01-18 12:36:46', NULL, 0),
(7, 1, 0, 1, 1, 1, 7, NULL, '1000.00', 2, 1, '2021-01-18 12:36:46', NULL, 0),
(8, 1, 0, 1, 1, 1, 8, NULL, '2200.00', 2, 1, '2021-01-18 12:36:46', NULL, 0),
(9, 1, 0, 1, 1, 1, 9, NULL, '2200.00', 2, 1, '2021-01-18 12:36:46', NULL, 0),
(10, 1, 0, 1, 1, 1, 10, NULL, '1000.00', 2, 1, '2021-01-18 12:36:46', NULL, 0),
(11, 1, 0, 1, 1, 1, 12, NULL, '1000.00', 2, 1, '2021-01-18 12:36:46', NULL, 0),
(12, 1, 0, 1, 1, 1, 13, NULL, '1000.00', 2, 1, '2021-01-18 12:36:46', NULL, 0);

-- --------------------------------------------------------

--
-- Table structure for table `mhd_report`
--

CREATE TABLE `mhd_report` (
  `id` int(11) NOT NULL,
  `admin_id` int(11) DEFAULT NULL,
  `report_status` int(11) DEFAULT 0,
  `member_id` int(11) DEFAULT NULL,
  `company_id` int(11) DEFAULT NULL,
  `year_id` int(11) DEFAULT NULL,
  `register_id` int(11) DEFAULT NULL,
  `register_program_id` int(11) DEFAULT NULL,
  `program_id` int(11) DEFAULT NULL,
  `trial_id` int(11) DEFAULT NULL,
  `save` longtext COLLATE utf8_unicode_ci DEFAULT NULL,
  `received_status` int(11) DEFAULT NULL,
  `received_status_other` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_report` date DEFAULT NULL,
  `date_added` datetime DEFAULT NULL,
  `date_modify` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `mhd_report`
--

INSERT INTO `mhd_report` (`id`, `admin_id`, `report_status`, `member_id`, `company_id`, `year_id`, `register_id`, `register_program_id`, `program_id`, `trial_id`, `save`, `received_status`, `received_status_other`, `date_report`, `date_added`, `date_modify`) VALUES
(1, 0, 0, 1, 1, 1, 1, 1, 1, 126, '{\"infection\":{\"480\":\"2\",\"481\":\"48\",\"482\":\"46\",\"483\":\"\",\"484\":\"\",\"485\":\"\",\"486\":\"\",\"487\":\"\",\"488\":\"\",\"493\":\"\",\"489\":\"\",\"490\":\"\",\"491\":\"\",\"492\":\"\",\"494\":\"\",\"496\":\"\",\"495\":\"\",\"497\":\"\",\"498\":\"\",\"499\":\"\",\"500\":\"\",\"501\":\"\",\"502\":\"\",\"503\":\"\"},\"tool_sec2\":{\"480\":\"102\",\"481\":\"101\",\"482\":\"104\",\"483\":\"\",\"484\":\"\",\"485\":\"\",\"486\":\"\",\"487\":\"\",\"488\":\"\",\"493\":\"\",\"489\":\"\",\"490\":\"\",\"491\":\"\",\"492\":\"\",\"494\":\"\",\"496\":\"\",\"495\":\"\",\"497\":\"\",\"498\":\"\",\"499\":\"\",\"500\":\"\",\"501\":\"\",\"502\":\"\",\"503\":\"\"},\"tool_sec3\":{\"480\":\"506\",\"481\":\"503\",\"482\":\"502\",\"483\":\"\",\"484\":\"\",\"485\":\"\",\"486\":\"\",\"487\":\"\",\"488\":\"\",\"493\":\"\",\"489\":\"\",\"490\":\"\",\"491\":\"\",\"492\":\"\",\"494\":\"\",\"496\":\"\",\"495\":\"\",\"497\":\"\",\"498\":\"\",\"499\":\"\",\"500\":\"\",\"501\":\"\",\"502\":\"\",\"503\":\"\"},\"result\":{\"480\":\"3.00\",\"481\":\"1.00\",\"482\":\"2.00\",\"483\":\"\",\"484\":\"\",\"485\":\"\",\"486\":\"\",\"487\":\"\",\"488\":\"\",\"493\":\"\",\"489\":\"\",\"490\":\"\",\"491\":\"\",\"492\":\"\",\"494\":\"\",\"496\":\"\",\"495\":\"\",\"497\":\"\",\"498\":\"\",\"499\":\"\",\"500\":\"\",\"501\":\"\",\"502\":\"\",\"503\":\"\"},\"name\":\"fsoftpro\",\"telephone\":\"+66863498778\",\"position\":\"\",\"comment\":\"\",\"report_date\":\"2021-02-02\"}', 1, '', '2021-02-02', '2021-02-02 16:54:23', '2021-02-02 16:58:08'),
(2, 0, 0, 1, 1, 1, 1, 4, 2, 130, '{\"tools\":{\"531\":\"13\",\"439\":\"02\",\"436\":\"03\",\"434\":\"\",\"432\":\"10\",\"430\":\"\"},\"tools_other\":{\"531\":\"13\",\"439\":\"\",\"436\":\"\",\"434\":\"\",\"432\":\"\",\"430\":\"\"},\"method\":{\"531\":\"99\",\"439\":\"1\",\"436\":\"3\",\"434\":\"\",\"432\":\"99\",\"430\":\"\"},\"principle_other\":{\"531\":\"333\",\"439\":\"\",\"436\":\"\",\"434\":\"\",\"432\":\"3\",\"430\":\"\"},\"name\":\"fsoftpro\",\"telephone\":\"+66863498778\",\"position\":\"\",\"comment\":\"asdf\",\"report_date\":\"2021-02-02\"}', 1, '', '2021-02-02', '2021-02-02 17:55:49', '2021-02-02 18:07:55');

-- --------------------------------------------------------

--
-- Table structure for table `mhd_sessions`
--

CREATE TABLE `mhd_sessions` (
  `id` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `ip_address` varchar(45) COLLATE utf8_unicode_ci NOT NULL,
  `timestamp` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `data` blob NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `mhd_sessions`
--

INSERT INTO `mhd_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES
('61d5c885b9eae396fa06281930a1cb67ebd6f05c', '::1', 1612256705, 0x5f5f63695f6c6173745f726567656e65726174657c693a313631323235363730353b61646d696e5f746f6b656e7c733a3336343a223638623438396464336439633538343838646462376163646331323130623734643939366430323565333234346638383664353166373966626537633534303036653433626131313939613334346262313932393362383833376365363831643162346265613462666636656435633237346338353964616334353135346664422f7a765767464b2b456f774533526d696c7674683063386241417a2f64796941345652343843536c5273424f55754b44364349696c4d796e79707557613348585644374c5945475856346e6b5534626a4d3262454a72716c464f4d776744744967613258494b70536d2b5a594a6c63506978646e384b6e6855686d46494f61642b33703562476c544b7a4f3037796c57677249366b49696764795a417066517748514c4d62346b5979384b4d47554a7372576b4e4954464a3362384a437064764a786e4c6f64735435534747553053576d6a48417137514c664674426361516f71646a416979795572513d223b61646d696e5f696e666f7c613a313a7b733a383a22757365726e616d65223b733a353a2261646d696e223b7d61646d696e5f72656769737465727c733a36343a223c7370616e20636c6173733d2262616467652062616467652d73756363657373207269676874223ee0b980e0b89be0b8b4e0b89420323032303c2f7370616e3e223b6d656d6265725f696e666f7c613a323a7b733a393a226d656d6265725f6e6f223b733a383a223230323030303031223b733a353a22656d61696c223b733a31393a226d756e6b2e676f726e40676d61696c2e636f6d223b7d796561727c733a343a2232303230223b746f6b656e7c733a3537363a2239393762393134363233383030653265636263396437633231366563616561313762313833373636396236623135663034306232333962623662376661306632343839323531396165636361346333386434363535613833613163646538376236373264653165353433386439666265306239356137336266346431626330635168673939793963396e58437758504d4a6f70537a737052705570364e707967704e7466447a732f74717631337954774f395a7344324a62326147584d6f30305a507a665035757a5877304a365855764b462b32797a78416e3630704f4e4a612b7a617a4a4e3445387a5753732f48694b4f3064714567724468304e486164336e4c687841764e3347687a4366686b576f495365656b5754536e2f53732b77562b356333397a7974385856544731376a6f554c676148763955362b2b77742f6d69582f487562596c446b70666a354a4a3058473748654e33723068672b6b504454503662594b58307859757a72345343496d324c516568354b4a5a4479542f6149617634594474493739384e4a4d2b2f54656479415657377531376457384c725a79466673417969366f77416c4f667639546562585154552b685761546e46462b2f4d41376b62474f45474f50736f57316c694d3043476b377432555850636b4449314a6476744d6d73655533674c72443943504950726d61623868323168516a7664536c614a584f736930703946556f4439574c58382b515a6b55537649484f79364b425943557643723550337a787949565870667357475757366f393972223b),
('2deef36b1485b9ae0416bc9dc94632c394d1378b', '::1', 1612257043, 0x5f5f63695f6c6173745f726567656e65726174657c693a313631323235373034333b61646d696e5f746f6b656e7c733a3336343a223638623438396464336439633538343838646462376163646331323130623734643939366430323565333234346638383664353166373966626537633534303036653433626131313939613334346262313932393362383833376365363831643162346265613462666636656435633237346338353964616334353135346664422f7a765767464b2b456f774533526d696c7674683063386241417a2f64796941345652343843536c5273424f55754b44364349696c4d796e79707557613348585644374c5945475856346e6b5534626a4d3262454a72716c464f4d776744744967613258494b70536d2b5a594a6c63506978646e384b6e6855686d46494f61642b33703562476c544b7a4f3037796c57677249366b49696764795a417066517748514c4d62346b5979384b4d47554a7372576b4e4954464a3362384a437064764a786e4c6f64735435534747553053576d6a48417137514c664674426361516f71646a416979795572513d223b61646d696e5f696e666f7c613a313a7b733a383a22757365726e616d65223b733a353a2261646d696e223b7d61646d696e5f72656769737465727c733a36343a223c7370616e20636c6173733d2262616467652062616467652d73756363657373207269676874223ee0b980e0b89be0b8b4e0b89420323032303c2f7370616e3e223b6d656d6265725f696e666f7c613a323a7b733a393a226d656d6265725f6e6f223b733a383a223230323030303031223b733a353a22656d61696c223b733a31393a226d756e6b2e676f726e40676d61696c2e636f6d223b7d796561727c733a343a2232303230223b746f6b656e7c733a3537363a2239393762393134363233383030653265636263396437633231366563616561313762313833373636396236623135663034306232333962623662376661306632343839323531396165636361346333386434363535613833613163646538376236373264653165353433386439666265306239356137336266346431626330635168673939793963396e58437758504d4a6f70537a737052705570364e707967704e7466447a732f74717631337954774f395a7344324a62326147584d6f30305a507a665035757a5877304a365855764b462b32797a78416e3630704f4e4a612b7a617a4a4e3445387a5753732f48694b4f3064714567724468304e486164336e4c687841764e3347687a4366686b576f495365656b5754536e2f53732b77562b356333397a7974385856544731376a6f554c676148763955362b2b77742f6d69582f487562596c446b70666a354a4a3058473748654e33723068672b6b504454503662594b58307859757a72345343496d324c516568354b4a5a4479542f6149617634594474493739384e4a4d2b2f54656479415657377531376457384c725a79466673417969366f77416c4f667639546562585154552b685761546e46462b2f4d41376b62474f45474f50736f57316c694d3043476b377432555850636b4449314a6476744d6d73655533674c72443943504950726d61623868323168516a7664536c614a584f736930703946556f4439574c58382b515a6b55537649484f79364b425943557643723550337a787949565870667357475757366f393972223b),
('943761369bead40d6b04c1318b6745e5a585e570', '::1', 1612257406, 0x5f5f63695f6c6173745f726567656e65726174657c693a313631323235373430363b61646d696e5f746f6b656e7c733a3336343a223638623438396464336439633538343838646462376163646331323130623734643939366430323565333234346638383664353166373966626537633534303036653433626131313939613334346262313932393362383833376365363831643162346265613462666636656435633237346338353964616334353135346664422f7a765767464b2b456f774533526d696c7674683063386241417a2f64796941345652343843536c5273424f55754b44364349696c4d796e79707557613348585644374c5945475856346e6b5534626a4d3262454a72716c464f4d776744744967613258494b70536d2b5a594a6c63506978646e384b6e6855686d46494f61642b33703562476c544b7a4f3037796c57677249366b49696764795a417066517748514c4d62346b5979384b4d47554a7372576b4e4954464a3362384a437064764a786e4c6f64735435534747553053576d6a48417137514c664674426361516f71646a416979795572513d223b61646d696e5f696e666f7c613a313a7b733a383a22757365726e616d65223b733a353a2261646d696e223b7d61646d696e5f72656769737465727c733a36343a223c7370616e20636c6173733d2262616467652062616467652d73756363657373207269676874223ee0b980e0b89be0b8b4e0b89420323032303c2f7370616e3e223b6d656d6265725f696e666f7c613a323a7b733a393a226d656d6265725f6e6f223b733a383a223230323030303031223b733a353a22656d61696c223b733a31393a226d756e6b2e676f726e40676d61696c2e636f6d223b7d796561727c733a343a2232303230223b746f6b656e7c733a3537363a2239393762393134363233383030653265636263396437633231366563616561313762313833373636396236623135663034306232333962623662376661306632343839323531396165636361346333386434363535613833613163646538376236373264653165353433386439666265306239356137336266346431626330635168673939793963396e58437758504d4a6f70537a737052705570364e707967704e7466447a732f74717631337954774f395a7344324a62326147584d6f30305a507a665035757a5877304a365855764b462b32797a78416e3630704f4e4a612b7a617a4a4e3445387a5753732f48694b4f3064714567724468304e486164336e4c687841764e3347687a4366686b576f495365656b5754536e2f53732b77562b356333397a7974385856544731376a6f554c676148763955362b2b77742f6d69582f487562596c446b70666a354a4a3058473748654e33723068672b6b504454503662594b58307859757a72345343496d324c516568354b4a5a4479542f6149617634594474493739384e4a4d2b2f54656479415657377531376457384c725a79466673417969366f77416c4f667639546562585154552b685761546e46462b2f4d41376b62474f45474f50736f57316c694d3043476b377432555850636b4449314a6476744d6d73655533674c72443943504950726d61623868323168516a7664536c614a584f736930703946556f4439574c58382b515a6b55537649484f79364b425943557643723550337a787949565870667357475757366f393972223b737563636573737c733a34303a2253656e64207265706f7274203c623e45514143202d203238303c2f623e207375636365737366756c223b),
('11e5f4eaa3ea8d948e1046cd7885734a044a78d7', '::1', 1612258019, 0x5f5f63695f6c6173745f726567656e65726174657c693a313631323235383031393b61646d696e5f746f6b656e7c733a3336343a223638623438396464336439633538343838646462376163646331323130623734643939366430323565333234346638383664353166373966626537633534303036653433626131313939613334346262313932393362383833376365363831643162346265613462666636656435633237346338353964616334353135346664422f7a765767464b2b456f774533526d696c7674683063386241417a2f64796941345652343843536c5273424f55754b44364349696c4d796e79707557613348585644374c5945475856346e6b5534626a4d3262454a72716c464f4d776744744967613258494b70536d2b5a594a6c63506978646e384b6e6855686d46494f61642b33703562476c544b7a4f3037796c57677249366b49696764795a417066517748514c4d62346b5979384b4d47554a7372576b4e4954464a3362384a437064764a786e4c6f64735435534747553053576d6a48417137514c664674426361516f71646a416979795572513d223b61646d696e5f696e666f7c613a313a7b733a383a22757365726e616d65223b733a353a2261646d696e223b7d61646d696e5f72656769737465727c733a36343a223c7370616e20636c6173733d2262616467652062616467652d73756363657373207269676874223ee0b980e0b89be0b8b4e0b89420323032303c2f7370616e3e223b6d656d6265725f696e666f7c613a323a7b733a393a226d656d6265725f6e6f223b733a383a223230323030303031223b733a353a22656d61696c223b733a31393a226d756e6b2e676f726e40676d61696c2e636f6d223b7d796561727c733a343a2232303230223b746f6b656e7c733a3537363a2239393762393134363233383030653265636263396437633231366563616561313762313833373636396236623135663034306232333962623662376661306632343839323531396165636361346333386434363535613833613163646538376236373264653165353433386439666265306239356137336266346431626330635168673939793963396e58437758504d4a6f70537a737052705570364e707967704e7466447a732f74717631337954774f395a7344324a62326147584d6f30305a507a665035757a5877304a365855764b462b32797a78416e3630704f4e4a612b7a617a4a4e3445387a5753732f48694b4f3064714567724468304e486164336e4c687841764e3347687a4366686b576f495365656b5754536e2f53732b77562b356333397a7974385856544731376a6f554c676148763955362b2b77742f6d69582f487562596c446b70666a354a4a3058473748654e33723068672b6b504454503662594b58307859757a72345343496d324c516568354b4a5a4479542f6149617634594474493739384e4a4d2b2f54656479415657377531376457384c725a79466673417969366f77416c4f667639546562585154552b685761546e46462b2f4d41376b62474f45474f50736f57316c694d3043476b377432555850636b4449314a6476744d6d73655533674c72443943504950726d61623868323168516a7664536c614a584f736930703946556f4439574c58382b515a6b55537649484f79364b425943557643723550337a787949565870667357475757366f393972223b),
('de68d45c702e07d04157eb61f361feb7ff2e9f56', '::1', 1612258511, 0x5f5f63695f6c6173745f726567656e65726174657c693a313631323235383531313b61646d696e5f746f6b656e7c733a3336343a223638623438396464336439633538343838646462376163646331323130623734643939366430323565333234346638383664353166373966626537633534303036653433626131313939613334346262313932393362383833376365363831643162346265613462666636656435633237346338353964616334353135346664422f7a765767464b2b456f774533526d696c7674683063386241417a2f64796941345652343843536c5273424f55754b44364349696c4d796e79707557613348585644374c5945475856346e6b5534626a4d3262454a72716c464f4d776744744967613258494b70536d2b5a594a6c63506978646e384b6e6855686d46494f61642b33703562476c544b7a4f3037796c57677249366b49696764795a417066517748514c4d62346b5979384b4d47554a7372576b4e4954464a3362384a437064764a786e4c6f64735435534747553053576d6a48417137514c664674426361516f71646a416979795572513d223b61646d696e5f696e666f7c613a313a7b733a383a22757365726e616d65223b733a353a2261646d696e223b7d61646d696e5f72656769737465727c733a36343a223c7370616e20636c6173733d2262616467652062616467652d73756363657373207269676874223ee0b980e0b89be0b8b4e0b89420323032303c2f7370616e3e223b6d656d6265725f696e666f7c613a323a7b733a393a226d656d6265725f6e6f223b733a383a223230323030303031223b733a353a22656d61696c223b733a31393a226d756e6b2e676f726e40676d61696c2e636f6d223b7d796561727c733a343a2232303230223b746f6b656e7c733a3537363a2239393762393134363233383030653265636263396437633231366563616561313762313833373636396236623135663034306232333962623662376661306632343839323531396165636361346333386434363535613833613163646538376236373264653165353433386439666265306239356137336266346431626330635168673939793963396e58437758504d4a6f70537a737052705570364e707967704e7466447a732f74717631337954774f395a7344324a62326147584d6f30305a507a665035757a5877304a365855764b462b32797a78416e3630704f4e4a612b7a617a4a4e3445387a5753732f48694b4f3064714567724468304e486164336e4c687841764e3347687a4366686b576f495365656b5754536e2f53732b77562b356333397a7974385856544731376a6f554c676148763955362b2b77742f6d69582f487562596c446b70666a354a4a3058473748654e33723068672b6b504454503662594b58307859757a72345343496d324c516568354b4a5a4479542f6149617634594474493739384e4a4d2b2f54656479415657377531376457384c725a79466673417969366f77416c4f667639546562585154552b685761546e46462b2f4d41376b62474f45474f50736f57316c694d3043476b377432555850636b4449314a6476744d6d73655533674c72443943504950726d61623868323168516a7664536c614a584f736930703946556f4439574c58382b515a6b55537649484f79364b425943557643723550337a787949565870667357475757366f393972223b),
('05ca029677a5245d6b8c1e8de98cc0313a2b92e5', '::1', 1612258819, 0x5f5f63695f6c6173745f726567656e65726174657c693a313631323235383831393b61646d696e5f746f6b656e7c733a3336343a223638623438396464336439633538343838646462376163646331323130623734643939366430323565333234346638383664353166373966626537633534303036653433626131313939613334346262313932393362383833376365363831643162346265613462666636656435633237346338353964616334353135346664422f7a765767464b2b456f774533526d696c7674683063386241417a2f64796941345652343843536c5273424f55754b44364349696c4d796e79707557613348585644374c5945475856346e6b5534626a4d3262454a72716c464f4d776744744967613258494b70536d2b5a594a6c63506978646e384b6e6855686d46494f61642b33703562476c544b7a4f3037796c57677249366b49696764795a417066517748514c4d62346b5979384b4d47554a7372576b4e4954464a3362384a437064764a786e4c6f64735435534747553053576d6a48417137514c664674426361516f71646a416979795572513d223b61646d696e5f696e666f7c613a313a7b733a383a22757365726e616d65223b733a353a2261646d696e223b7d61646d696e5f72656769737465727c733a36343a223c7370616e20636c6173733d2262616467652062616467652d73756363657373207269676874223ee0b980e0b89be0b8b4e0b89420323032303c2f7370616e3e223b6d656d6265725f696e666f7c613a323a7b733a393a226d656d6265725f6e6f223b733a383a223230323030303031223b733a353a22656d61696c223b733a31393a226d756e6b2e676f726e40676d61696c2e636f6d223b7d796561727c733a343a2232303230223b746f6b656e7c733a3537363a2239393762393134363233383030653265636263396437633231366563616561313762313833373636396236623135663034306232333962623662376661306632343839323531396165636361346333386434363535613833613163646538376236373264653165353433386439666265306239356137336266346431626330635168673939793963396e58437758504d4a6f70537a737052705570364e707967704e7466447a732f74717631337954774f395a7344324a62326147584d6f30305a507a665035757a5877304a365855764b462b32797a78416e3630704f4e4a612b7a617a4a4e3445387a5753732f48694b4f3064714567724468304e486164336e4c687841764e3347687a4366686b576f495365656b5754536e2f53732b77562b356333397a7974385856544731376a6f554c676148763955362b2b77742f6d69582f487562596c446b70666a354a4a3058473748654e33723068672b6b504454503662594b58307859757a72345343496d324c516568354b4a5a4479542f6149617634594474493739384e4a4d2b2f54656479415657377531376457384c725a79466673417969366f77416c4f667639546562585154552b685761546e46462b2f4d41376b62474f45474f50736f57316c694d3043476b377432555850636b4449314a6476744d6d73655533674c72443943504950726d61623868323168516a7664536c614a584f736930703946556f4439574c58382b515a6b55537649484f79364b425943557643723550337a787949565870667357475757366f393972223b),
('b9998d2d7a6e270af88bc8859dadf00427d82469', '::1', 1612259279, 0x5f5f63695f6c6173745f726567656e65726174657c693a313631323235393237393b61646d696e5f746f6b656e7c733a3336343a223638623438396464336439633538343838646462376163646331323130623734643939366430323565333234346638383664353166373966626537633534303036653433626131313939613334346262313932393362383833376365363831643162346265613462666636656435633237346338353964616334353135346664422f7a765767464b2b456f774533526d696c7674683063386241417a2f64796941345652343843536c5273424f55754b44364349696c4d796e79707557613348585644374c5945475856346e6b5534626a4d3262454a72716c464f4d776744744967613258494b70536d2b5a594a6c63506978646e384b6e6855686d46494f61642b33703562476c544b7a4f3037796c57677249366b49696764795a417066517748514c4d62346b5979384b4d47554a7372576b4e4954464a3362384a437064764a786e4c6f64735435534747553053576d6a48417137514c664674426361516f71646a416979795572513d223b61646d696e5f696e666f7c613a313a7b733a383a22757365726e616d65223b733a353a2261646d696e223b7d61646d696e5f72656769737465727c733a36343a223c7370616e20636c6173733d2262616467652062616467652d73756363657373207269676874223ee0b980e0b89be0b8b4e0b89420323032303c2f7370616e3e223b6d656d6265725f696e666f7c613a323a7b733a393a226d656d6265725f6e6f223b733a383a223230323030303031223b733a353a22656d61696c223b733a31393a226d756e6b2e676f726e40676d61696c2e636f6d223b7d796561727c733a343a2232303230223b746f6b656e7c733a3537363a2239393762393134363233383030653265636263396437633231366563616561313762313833373636396236623135663034306232333962623662376661306632343839323531396165636361346333386434363535613833613163646538376236373264653165353433386439666265306239356137336266346431626330635168673939793963396e58437758504d4a6f70537a737052705570364e707967704e7466447a732f74717631337954774f395a7344324a62326147584d6f30305a507a665035757a5877304a365855764b462b32797a78416e3630704f4e4a612b7a617a4a4e3445387a5753732f48694b4f3064714567724468304e486164336e4c687841764e3347687a4366686b576f495365656b5754536e2f53732b77562b356333397a7974385856544731376a6f554c676148763955362b2b77742f6d69582f487562596c446b70666a354a4a3058473748654e33723068672b6b504454503662594b58307859757a72345343496d324c516568354b4a5a4479542f6149617634594474493739384e4a4d2b2f54656479415657377531376457384c725a79466673417969366f77416c4f667639546562585154552b685761546e46462b2f4d41376b62474f45474f50736f57316c694d3043476b377432555850636b4449314a6476744d6d73655533674c72443943504950726d61623868323168516a7664536c614a584f736930703946556f4439574c58382b515a6b55537649484f79364b425943557643723550337a787949565870667357475757366f393972223b),
('51b0133d80dec1be9c7eac4e40027a9e0828b9ed', '::1', 1612259641, 0x5f5f63695f6c6173745f726567656e65726174657c693a313631323235393634313b61646d696e5f746f6b656e7c733a3336343a223638623438396464336439633538343838646462376163646331323130623734643939366430323565333234346638383664353166373966626537633534303036653433626131313939613334346262313932393362383833376365363831643162346265613462666636656435633237346338353964616334353135346664422f7a765767464b2b456f774533526d696c7674683063386241417a2f64796941345652343843536c5273424f55754b44364349696c4d796e79707557613348585644374c5945475856346e6b5534626a4d3262454a72716c464f4d776744744967613258494b70536d2b5a594a6c63506978646e384b6e6855686d46494f61642b33703562476c544b7a4f3037796c57677249366b49696764795a417066517748514c4d62346b5979384b4d47554a7372576b4e4954464a3362384a437064764a786e4c6f64735435534747553053576d6a48417137514c664674426361516f71646a416979795572513d223b61646d696e5f696e666f7c613a313a7b733a383a22757365726e616d65223b733a353a2261646d696e223b7d61646d696e5f72656769737465727c733a36343a223c7370616e20636c6173733d2262616467652062616467652d73756363657373207269676874223ee0b980e0b89be0b8b4e0b89420323032303c2f7370616e3e223b6d656d6265725f696e666f7c613a323a7b733a393a226d656d6265725f6e6f223b733a383a223230323030303031223b733a353a22656d61696c223b733a31393a226d756e6b2e676f726e40676d61696c2e636f6d223b7d796561727c733a343a2232303230223b746f6b656e7c733a3537363a2239393762393134363233383030653265636263396437633231366563616561313762313833373636396236623135663034306232333962623662376661306632343839323531396165636361346333386434363535613833613163646538376236373264653165353433386439666265306239356137336266346431626330635168673939793963396e58437758504d4a6f70537a737052705570364e707967704e7466447a732f74717631337954774f395a7344324a62326147584d6f30305a507a665035757a5877304a365855764b462b32797a78416e3630704f4e4a612b7a617a4a4e3445387a5753732f48694b4f3064714567724468304e486164336e4c687841764e3347687a4366686b576f495365656b5754536e2f53732b77562b356333397a7974385856544731376a6f554c676148763955362b2b77742f6d69582f487562596c446b70666a354a4a3058473748654e33723068672b6b504454503662594b58307859757a72345343496d324c516568354b4a5a4479542f6149617634594474493739384e4a4d2b2f54656479415657377531376457384c725a79466673417969366f77416c4f667639546562585154552b685761546e46462b2f4d41376b62474f45474f50736f57316c694d3043476b377432555850636b4449314a6476744d6d73655533674c72443943504950726d61623868323168516a7664536c614a584f736930703946556f4439574c58382b515a6b55537649484f79364b425943557643723550337a787949565870667357475757366f393972223b),
('d124ef3730662322772046351f11ba74e49bb10b', '::1', 1612259972, 0x5f5f63695f6c6173745f726567656e65726174657c693a313631323235393937323b61646d696e5f746f6b656e7c733a3336343a223638623438396464336439633538343838646462376163646331323130623734643939366430323565333234346638383664353166373966626537633534303036653433626131313939613334346262313932393362383833376365363831643162346265613462666636656435633237346338353964616334353135346664422f7a765767464b2b456f774533526d696c7674683063386241417a2f64796941345652343843536c5273424f55754b44364349696c4d796e79707557613348585644374c5945475856346e6b5534626a4d3262454a72716c464f4d776744744967613258494b70536d2b5a594a6c63506978646e384b6e6855686d46494f61642b33703562476c544b7a4f3037796c57677249366b49696764795a417066517748514c4d62346b5979384b4d47554a7372576b4e4954464a3362384a437064764a786e4c6f64735435534747553053576d6a48417137514c664674426361516f71646a416979795572513d223b61646d696e5f696e666f7c613a313a7b733a383a22757365726e616d65223b733a353a2261646d696e223b7d61646d696e5f72656769737465727c733a36343a223c7370616e20636c6173733d2262616467652062616467652d73756363657373207269676874223ee0b980e0b89be0b8b4e0b89420323032303c2f7370616e3e223b6d656d6265725f696e666f7c613a323a7b733a393a226d656d6265725f6e6f223b733a383a223230323030303031223b733a353a22656d61696c223b733a31393a226d756e6b2e676f726e40676d61696c2e636f6d223b7d796561727c733a343a2232303230223b746f6b656e7c733a3537363a2239393762393134363233383030653265636263396437633231366563616561313762313833373636396236623135663034306232333962623662376661306632343839323531396165636361346333386434363535613833613163646538376236373264653165353433386439666265306239356137336266346431626330635168673939793963396e58437758504d4a6f70537a737052705570364e707967704e7466447a732f74717631337954774f395a7344324a62326147584d6f30305a507a665035757a5877304a365855764b462b32797a78416e3630704f4e4a612b7a617a4a4e3445387a5753732f48694b4f3064714567724468304e486164336e4c687841764e3347687a4366686b576f495365656b5754536e2f53732b77562b356333397a7974385856544731376a6f554c676148763955362b2b77742f6d69582f487562596c446b70666a354a4a3058473748654e33723068672b6b504454503662594b58307859757a72345343496d324c516568354b4a5a4479542f6149617634594474493739384e4a4d2b2f54656479415657377531376457384c725a79466673417969366f77416c4f667639546562585154552b685761546e46462b2f4d41376b62474f45474f50736f57316c694d3043476b377432555850636b4449314a6476744d6d73655533674c72443943504950726d61623868323168516a7664536c614a584f736930703946556f4439574c58382b515a6b55537649484f79364b425943557643723550337a787949565870667357475757366f393972223b),
('8f3193785e5d84c3a475ee694915a4feab46e7b5', '::1', 1612261970, 0x5f5f63695f6c6173745f726567656e65726174657c693a313631323236313937303b61646d696e5f746f6b656e7c733a3336343a223638623438396464336439633538343838646462376163646331323130623734643939366430323565333234346638383664353166373966626537633534303036653433626131313939613334346262313932393362383833376365363831643162346265613462666636656435633237346338353964616334353135346664422f7a765767464b2b456f774533526d696c7674683063386241417a2f64796941345652343843536c5273424f55754b44364349696c4d796e79707557613348585644374c5945475856346e6b5534626a4d3262454a72716c464f4d776744744967613258494b70536d2b5a594a6c63506978646e384b6e6855686d46494f61642b33703562476c544b7a4f3037796c57677249366b49696764795a417066517748514c4d62346b5979384b4d47554a7372576b4e4954464a3362384a437064764a786e4c6f64735435534747553053576d6a48417137514c664674426361516f71646a416979795572513d223b61646d696e5f696e666f7c613a313a7b733a383a22757365726e616d65223b733a353a2261646d696e223b7d61646d696e5f72656769737465727c733a36343a223c7370616e20636c6173733d2262616467652062616467652d73756363657373207269676874223ee0b980e0b89be0b8b4e0b89420323032303c2f7370616e3e223b6d656d6265725f696e666f7c613a323a7b733a393a226d656d6265725f6e6f223b733a383a223230323030303031223b733a353a22656d61696c223b733a31393a226d756e6b2e676f726e40676d61696c2e636f6d223b7d796561727c733a343a2232303230223b746f6b656e7c733a3537363a2239393762393134363233383030653265636263396437633231366563616561313762313833373636396236623135663034306232333962623662376661306632343839323531396165636361346333386434363535613833613163646538376236373264653165353433386439666265306239356137336266346431626330635168673939793963396e58437758504d4a6f70537a737052705570364e707967704e7466447a732f74717631337954774f395a7344324a62326147584d6f30305a507a665035757a5877304a365855764b462b32797a78416e3630704f4e4a612b7a617a4a4e3445387a5753732f48694b4f3064714567724468304e486164336e4c687841764e3347687a4366686b576f495365656b5754536e2f53732b77562b356333397a7974385856544731376a6f554c676148763955362b2b77742f6d69582f487562596c446b70666a354a4a3058473748654e33723068672b6b504454503662594b58307859757a72345343496d324c516568354b4a5a4479542f6149617634594474493739384e4a4d2b2f54656479415657377531376457384c725a79466673417969366f77416c4f667639546562585154552b685761546e46462b2f4d41376b62474f45474f50736f57316c694d3043476b377432555850636b4449314a6476744d6d73655533674c72443943504950726d61623868323168516a7664536c614a584f736930703946556f4439574c58382b515a6b55537649484f79364b425943557643723550337a787949565870667357475757366f393972223b),
('e988d748a7d49a526bcdcea07665062ec2d4599f', '::1', 1612262349, 0x5f5f63695f6c6173745f726567656e65726174657c693a313631323236323334393b61646d696e5f746f6b656e7c733a3336343a223638623438396464336439633538343838646462376163646331323130623734643939366430323565333234346638383664353166373966626537633534303036653433626131313939613334346262313932393362383833376365363831643162346265613462666636656435633237346338353964616334353135346664422f7a765767464b2b456f774533526d696c7674683063386241417a2f64796941345652343843536c5273424f55754b44364349696c4d796e79707557613348585644374c5945475856346e6b5534626a4d3262454a72716c464f4d776744744967613258494b70536d2b5a594a6c63506978646e384b6e6855686d46494f61642b33703562476c544b7a4f3037796c57677249366b49696764795a417066517748514c4d62346b5979384b4d47554a7372576b4e4954464a3362384a437064764a786e4c6f64735435534747553053576d6a48417137514c664674426361516f71646a416979795572513d223b61646d696e5f696e666f7c613a313a7b733a383a22757365726e616d65223b733a353a2261646d696e223b7d61646d696e5f72656769737465727c733a36343a223c7370616e20636c6173733d2262616467652062616467652d73756363657373207269676874223ee0b980e0b89be0b8b4e0b89420323032303c2f7370616e3e223b6d656d6265725f696e666f7c613a323a7b733a393a226d656d6265725f6e6f223b733a383a223230323030303031223b733a353a22656d61696c223b733a31393a226d756e6b2e676f726e40676d61696c2e636f6d223b7d796561727c733a343a2232303230223b746f6b656e7c733a3537363a223938356663616136366261373364383332643137383161613234623362653730653963323265333261353535343239373161613262646661336633346434656235326633643032643837613464626439353731363937313738306131323061376131376338386662346236323531393734323633316635393365316530626666353435466d316e4547724272315646674c4958624b742f4b6150504b515a4b68384873346d556d4e6835496e3958546e367231577965613937654e4e6f4731494149476a6368624a715255585043316f5135634267666838435a4674684f4c32307a617a69696d7571444757686b2f55642f46594c4655446e4f4e6b334d506c743852772f3566326d435a43555a6b6446737637636c4777546b4177746f4e6c4b6a772b6b3273474a6f5034396c324a65587348645a68716b4f495033664a32324f773036684b5373793752734266444d356f5954716242576b742f704258456d7776795630346d44632f494a415237776f514b442b4e5a5061524b634f6645445a5056452b56706778766c5778624446552b31686d6d317565536f31666a4676472b4f45575271626168576f56684d5a382f643978395952584a344b7a652b4a7633534264563567586a6e6e2f4f51757a716a625a7a476a516d327636507730386c4567693064594a4374336c66474548723273656a364c586e4c3571734739546a4e5667737a314a4742452f53756142334c7064354b58593771705474564c344f4431525a50426e2b4f3973473332634e353773742f716336594743486f223b),
('48655fc1dac92055ad68df5e22a9c5e4b089843a', '::1', 1612262711, 0x5f5f63695f6c6173745f726567656e65726174657c693a313631323236323731313b61646d696e5f746f6b656e7c733a3336343a223638623438396464336439633538343838646462376163646331323130623734643939366430323565333234346638383664353166373966626537633534303036653433626131313939613334346262313932393362383833376365363831643162346265613462666636656435633237346338353964616334353135346664422f7a765767464b2b456f774533526d696c7674683063386241417a2f64796941345652343843536c5273424f55754b44364349696c4d796e79707557613348585644374c5945475856346e6b5534626a4d3262454a72716c464f4d776744744967613258494b70536d2b5a594a6c63506978646e384b6e6855686d46494f61642b33703562476c544b7a4f3037796c57677249366b49696764795a417066517748514c4d62346b5979384b4d47554a7372576b4e4954464a3362384a437064764a786e4c6f64735435534747553053576d6a48417137514c664674426361516f71646a416979795572513d223b61646d696e5f696e666f7c613a313a7b733a383a22757365726e616d65223b733a353a2261646d696e223b7d61646d696e5f72656769737465727c733a36343a223c7370616e20636c6173733d2262616467652062616467652d73756363657373207269676874223ee0b980e0b89be0b8b4e0b89420323032303c2f7370616e3e223b6d656d6265725f696e666f7c613a323a7b733a393a226d656d6265725f6e6f223b733a383a223230323030303031223b733a353a22656d61696c223b733a31393a226d756e6b2e676f726e40676d61696c2e636f6d223b7d796561727c733a343a2232303230223b746f6b656e7c733a3537363a223938356663616136366261373364383332643137383161613234623362653730653963323265333261353535343239373161613262646661336633346434656235326633643032643837613464626439353731363937313738306131323061376131376338386662346236323531393734323633316635393365316530626666353435466d316e4547724272315646674c4958624b742f4b6150504b515a4b68384873346d556d4e6835496e3958546e367231577965613937654e4e6f4731494149476a6368624a715255585043316f5135634267666838435a4674684f4c32307a617a69696d7571444757686b2f55642f46594c4655446e4f4e6b334d506c743852772f3566326d435a43555a6b6446737637636c4777546b4177746f4e6c4b6a772b6b3273474a6f5034396c324a65587348645a68716b4f495033664a32324f773036684b5373793752734266444d356f5954716242576b742f704258456d7776795630346d44632f494a415237776f514b442b4e5a5061524b634f6645445a5056452b56706778766c5778624446552b31686d6d317565536f31666a4676472b4f45575271626168576f56684d5a382f643978395952584a344b7a652b4a7633534264563567586a6e6e2f4f51757a716a625a7a476a516d327636507730386c4567693064594a4374336c66474548723273656a364c586e4c3571734739546a4e5667737a314a4742452f53756142334c7064354b58593771705474564c344f4431525a50426e2b4f3973473332634e353773742f716336594743486f223b),
('ceae099ab157e1b29a4e1c7aa7d295903c8b0940', '::1', 1612263028, 0x5f5f63695f6c6173745f726567656e65726174657c693a313631323236333032383b61646d696e5f746f6b656e7c733a3336343a223638623438396464336439633538343838646462376163646331323130623734643939366430323565333234346638383664353166373966626537633534303036653433626131313939613334346262313932393362383833376365363831643162346265613462666636656435633237346338353964616334353135346664422f7a765767464b2b456f774533526d696c7674683063386241417a2f64796941345652343843536c5273424f55754b44364349696c4d796e79707557613348585644374c5945475856346e6b5534626a4d3262454a72716c464f4d776744744967613258494b70536d2b5a594a6c63506978646e384b6e6855686d46494f61642b33703562476c544b7a4f3037796c57677249366b49696764795a417066517748514c4d62346b5979384b4d47554a7372576b4e4954464a3362384a437064764a786e4c6f64735435534747553053576d6a48417137514c664674426361516f71646a416979795572513d223b61646d696e5f696e666f7c613a313a7b733a383a22757365726e616d65223b733a353a2261646d696e223b7d61646d696e5f72656769737465727c733a36343a223c7370616e20636c6173733d2262616467652062616467652d73756363657373207269676874223ee0b980e0b89be0b8b4e0b89420323032303c2f7370616e3e223b6d656d6265725f696e666f7c613a323a7b733a393a226d656d6265725f6e6f223b733a383a223230323030303031223b733a353a22656d61696c223b733a31393a226d756e6b2e676f726e40676d61696c2e636f6d223b7d796561727c733a343a2232303230223b746f6b656e7c733a3537363a223938356663616136366261373364383332643137383161613234623362653730653963323265333261353535343239373161613262646661336633346434656235326633643032643837613464626439353731363937313738306131323061376131376338386662346236323531393734323633316635393365316530626666353435466d316e4547724272315646674c4958624b742f4b6150504b515a4b68384873346d556d4e6835496e3958546e367231577965613937654e4e6f4731494149476a6368624a715255585043316f5135634267666838435a4674684f4c32307a617a69696d7571444757686b2f55642f46594c4655446e4f4e6b334d506c743852772f3566326d435a43555a6b6446737637636c4777546b4177746f4e6c4b6a772b6b3273474a6f5034396c324a65587348645a68716b4f495033664a32324f773036684b5373793752734266444d356f5954716242576b742f704258456d7776795630346d44632f494a415237776f514b442b4e5a5061524b634f6645445a5056452b56706778766c5778624446552b31686d6d317565536f31666a4676472b4f45575271626168576f56684d5a382f643978395952584a344b7a652b4a7633534264563567586a6e6e2f4f51757a716a625a7a476a516d327636507730386c4567693064594a4374336c66474548723273656a364c586e4c3571734739546a4e5667737a314a4742452f53756142334c7064354b58593771705474564c344f4431525a50426e2b4f3973473332634e353773742f716336594743486f223b),
('abfcc082e5a65b2f00af4b8be44d52a6e649a548', '::1', 1612263341, 0x5f5f63695f6c6173745f726567656e65726174657c693a313631323236333334313b61646d696e5f746f6b656e7c733a3336343a223638623438396464336439633538343838646462376163646331323130623734643939366430323565333234346638383664353166373966626537633534303036653433626131313939613334346262313932393362383833376365363831643162346265613462666636656435633237346338353964616334353135346664422f7a765767464b2b456f774533526d696c7674683063386241417a2f64796941345652343843536c5273424f55754b44364349696c4d796e79707557613348585644374c5945475856346e6b5534626a4d3262454a72716c464f4d776744744967613258494b70536d2b5a594a6c63506978646e384b6e6855686d46494f61642b33703562476c544b7a4f3037796c57677249366b49696764795a417066517748514c4d62346b5979384b4d47554a7372576b4e4954464a3362384a437064764a786e4c6f64735435534747553053576d6a48417137514c664674426361516f71646a416979795572513d223b61646d696e5f696e666f7c613a313a7b733a383a22757365726e616d65223b733a353a2261646d696e223b7d61646d696e5f72656769737465727c733a36343a223c7370616e20636c6173733d2262616467652062616467652d73756363657373207269676874223ee0b980e0b89be0b8b4e0b89420323032303c2f7370616e3e223b6d656d6265725f696e666f7c613a323a7b733a393a226d656d6265725f6e6f223b733a383a223230323030303031223b733a353a22656d61696c223b733a31393a226d756e6b2e676f726e40676d61696c2e636f6d223b7d796561727c733a343a2232303230223b746f6b656e7c733a3537363a223938356663616136366261373364383332643137383161613234623362653730653963323265333261353535343239373161613262646661336633346434656235326633643032643837613464626439353731363937313738306131323061376131376338386662346236323531393734323633316635393365316530626666353435466d316e4547724272315646674c4958624b742f4b6150504b515a4b68384873346d556d4e6835496e3958546e367231577965613937654e4e6f4731494149476a6368624a715255585043316f5135634267666838435a4674684f4c32307a617a69696d7571444757686b2f55642f46594c4655446e4f4e6b334d506c743852772f3566326d435a43555a6b6446737637636c4777546b4177746f4e6c4b6a772b6b3273474a6f5034396c324a65587348645a68716b4f495033664a32324f773036684b5373793752734266444d356f5954716242576b742f704258456d7776795630346d44632f494a415237776f514b442b4e5a5061524b634f6645445a5056452b56706778766c5778624446552b31686d6d317565536f31666a4676472b4f45575271626168576f56684d5a382f643978395952584a344b7a652b4a7633534264563567586a6e6e2f4f51757a716a625a7a476a516d327636507730386c4567693064594a4374336c66474548723273656a364c586e4c3571734739546a4e5667737a314a4742452f53756142334c7064354b58593771705474564c344f4431525a50426e2b4f3973473332634e353773742f716336594743486f223b),
('ed84a0790cb5de882f42d4c14842b1556317c7f8', '::1', 1612263644, 0x5f5f63695f6c6173745f726567656e65726174657c693a313631323236333634343b61646d696e5f746f6b656e7c733a3336343a223638623438396464336439633538343838646462376163646331323130623734643939366430323565333234346638383664353166373966626537633534303036653433626131313939613334346262313932393362383833376365363831643162346265613462666636656435633237346338353964616334353135346664422f7a765767464b2b456f774533526d696c7674683063386241417a2f64796941345652343843536c5273424f55754b44364349696c4d796e79707557613348585644374c5945475856346e6b5534626a4d3262454a72716c464f4d776744744967613258494b70536d2b5a594a6c63506978646e384b6e6855686d46494f61642b33703562476c544b7a4f3037796c57677249366b49696764795a417066517748514c4d62346b5979384b4d47554a7372576b4e4954464a3362384a437064764a786e4c6f64735435534747553053576d6a48417137514c664674426361516f71646a416979795572513d223b61646d696e5f696e666f7c613a313a7b733a383a22757365726e616d65223b733a353a2261646d696e223b7d61646d696e5f72656769737465727c733a36343a223c7370616e20636c6173733d2262616467652062616467652d73756363657373207269676874223ee0b980e0b89be0b8b4e0b89420323032303c2f7370616e3e223b6d656d6265725f696e666f7c613a323a7b733a393a226d656d6265725f6e6f223b733a383a223230323030303031223b733a353a22656d61696c223b733a31393a226d756e6b2e676f726e40676d61696c2e636f6d223b7d796561727c733a343a2232303230223b746f6b656e7c733a3537363a223938356663616136366261373364383332643137383161613234623362653730653963323265333261353535343239373161613262646661336633346434656235326633643032643837613464626439353731363937313738306131323061376131376338386662346236323531393734323633316635393365316530626666353435466d316e4547724272315646674c4958624b742f4b6150504b515a4b68384873346d556d4e6835496e3958546e367231577965613937654e4e6f4731494149476a6368624a715255585043316f5135634267666838435a4674684f4c32307a617a69696d7571444757686b2f55642f46594c4655446e4f4e6b334d506c743852772f3566326d435a43555a6b6446737637636c4777546b4177746f4e6c4b6a772b6b3273474a6f5034396c324a65587348645a68716b4f495033664a32324f773036684b5373793752734266444d356f5954716242576b742f704258456d7776795630346d44632f494a415237776f514b442b4e5a5061524b634f6645445a5056452b56706778766c5778624446552b31686d6d317565536f31666a4676472b4f45575271626168576f56684d5a382f643978395952584a344b7a652b4a7633534264563567586a6e6e2f4f51757a716a625a7a476a516d327636507730386c4567693064594a4374336c66474548723273656a364c586e4c3571734739546a4e5667737a314a4742452f53756142334c7064354b58593771705474564c344f4431525a50426e2b4f3973473332634e353773742f716336594743486f223b),
('909c2ae35094ed063e721402e82e608bd5649bbd', '::1', 1612263994, 0x5f5f63695f6c6173745f726567656e65726174657c693a313631323236333939343b61646d696e5f746f6b656e7c733a3336343a223638623438396464336439633538343838646462376163646331323130623734643939366430323565333234346638383664353166373966626537633534303036653433626131313939613334346262313932393362383833376365363831643162346265613462666636656435633237346338353964616334353135346664422f7a765767464b2b456f774533526d696c7674683063386241417a2f64796941345652343843536c5273424f55754b44364349696c4d796e79707557613348585644374c5945475856346e6b5534626a4d3262454a72716c464f4d776744744967613258494b70536d2b5a594a6c63506978646e384b6e6855686d46494f61642b33703562476c544b7a4f3037796c57677249366b49696764795a417066517748514c4d62346b5979384b4d47554a7372576b4e4954464a3362384a437064764a786e4c6f64735435534747553053576d6a48417137514c664674426361516f71646a416979795572513d223b61646d696e5f696e666f7c613a313a7b733a383a22757365726e616d65223b733a353a2261646d696e223b7d61646d696e5f72656769737465727c733a36343a223c7370616e20636c6173733d2262616467652062616467652d73756363657373207269676874223ee0b980e0b89be0b8b4e0b89420323032303c2f7370616e3e223b6d656d6265725f696e666f7c613a323a7b733a393a226d656d6265725f6e6f223b733a383a223230323030303031223b733a353a22656d61696c223b733a31393a226d756e6b2e676f726e40676d61696c2e636f6d223b7d796561727c733a343a2232303230223b746f6b656e7c733a3537363a223938356663616136366261373364383332643137383161613234623362653730653963323265333261353535343239373161613262646661336633346434656235326633643032643837613464626439353731363937313738306131323061376131376338386662346236323531393734323633316635393365316530626666353435466d316e4547724272315646674c4958624b742f4b6150504b515a4b68384873346d556d4e6835496e3958546e367231577965613937654e4e6f4731494149476a6368624a715255585043316f5135634267666838435a4674684f4c32307a617a69696d7571444757686b2f55642f46594c4655446e4f4e6b334d506c743852772f3566326d435a43555a6b6446737637636c4777546b4177746f4e6c4b6a772b6b3273474a6f5034396c324a65587348645a68716b4f495033664a32324f773036684b5373793752734266444d356f5954716242576b742f704258456d7776795630346d44632f494a415237776f514b442b4e5a5061524b634f6645445a5056452b56706778766c5778624446552b31686d6d317565536f31666a4676472b4f45575271626168576f56684d5a382f643978395952584a344b7a652b4a7633534264563567586a6e6e2f4f51757a716a625a7a476a516d327636507730386c4567693064594a4374336c66474548723273656a364c586e4c3571734739546a4e5667737a314a4742452f53756142334c7064354b58593771705474564c344f4431525a50426e2b4f3973473332634e353773742f716336594743486f223b),
('617af203ec34235e71c0a814b92da6a1a47f6c61', '::1', 1612264118, 0x5f5f63695f6c6173745f726567656e65726174657c693a313631323236333939343b61646d696e5f746f6b656e7c733a3336343a223638623438396464336439633538343838646462376163646331323130623734643939366430323565333234346638383664353166373966626537633534303036653433626131313939613334346262313932393362383833376365363831643162346265613462666636656435633237346338353964616334353135346664422f7a765767464b2b456f774533526d696c7674683063386241417a2f64796941345652343843536c5273424f55754b44364349696c4d796e79707557613348585644374c5945475856346e6b5534626a4d3262454a72716c464f4d776744744967613258494b70536d2b5a594a6c63506978646e384b6e6855686d46494f61642b33703562476c544b7a4f3037796c57677249366b49696764795a417066517748514c4d62346b5979384b4d47554a7372576b4e4954464a3362384a437064764a786e4c6f64735435534747553053576d6a48417137514c664674426361516f71646a416979795572513d223b61646d696e5f696e666f7c613a313a7b733a383a22757365726e616d65223b733a353a2261646d696e223b7d61646d696e5f72656769737465727c733a36343a223c7370616e20636c6173733d2262616467652062616467652d73756363657373207269676874223ee0b980e0b89be0b8b4e0b89420323032303c2f7370616e3e223b6d656d6265725f696e666f7c613a323a7b733a393a226d656d6265725f6e6f223b733a383a223230323030303031223b733a353a22656d61696c223b733a31393a226d756e6b2e676f726e40676d61696c2e636f6d223b7d796561727c733a343a2232303230223b746f6b656e7c733a3537363a223938356663616136366261373364383332643137383161613234623362653730653963323265333261353535343239373161613262646661336633346434656235326633643032643837613464626439353731363937313738306131323061376131376338386662346236323531393734323633316635393365316530626666353435466d316e4547724272315646674c4958624b742f4b6150504b515a4b68384873346d556d4e6835496e3958546e367231577965613937654e4e6f4731494149476a6368624a715255585043316f5135634267666838435a4674684f4c32307a617a69696d7571444757686b2f55642f46594c4655446e4f4e6b334d506c743852772f3566326d435a43555a6b6446737637636c4777546b4177746f4e6c4b6a772b6b3273474a6f5034396c324a65587348645a68716b4f495033664a32324f773036684b5373793752734266444d356f5954716242576b742f704258456d7776795630346d44632f494a415237776f514b442b4e5a5061524b634f6645445a5056452b56706778766c5778624446552b31686d6d317565536f31666a4676472b4f45575271626168576f56684d5a382f643978395952584a344b7a652b4a7633534264563567586a6e6e2f4f51757a716a625a7a476a516d327636507730386c4567693064594a4374336c66474548723273656a364c586e4c3571734739546a4e5667737a314a4742452f53756142334c7064354b58593771705474564c344f4431525a50426e2b4f3973473332634e353773742f716336594743486f223b),
('6f041a99d84c39532956e98f653a55c936f1beae', '::1', 1612422197, 0x5f5f63695f6c6173745f726567656e65726174657c693a313631323432323139373b746f6b656e7c733a3537363a223134636362636238313038336433626237343035663535366538383435363163373238333161333932353239623937646132623832346638346132656137323530656132613331636163343732366539363731633462323536306535376234383332656166653832633066316332613464323663346361316665313665323731546a636b49564c78527945414561667968656f30697a36423743702f6369573464343578335739713274576767536e534b6141554f636b2b41524434496f6245532f6f646f586c75342b7046666364466371526a314e554c747a6c625631435a76507861476b345435725973736c785938645a45764a7a6f4b4f4164536d695a616c32356b35697864706453724867426279347542766346736b7461356c4d42796b7158327438354650437347624c65477a664f75567334366e4a4b33374a343631515a6549512f374345684f7175636b642b6c61652b6864697878775545576b4b434d30745735424e736e6a37776a6d6443376155624268324843495555674a45307874394d63785151476f61554e30385264793243354775416b477a50794934496e397a2f334c394d437376675079732b6a45356b725173655271594a79466674346e354e7742756a644758396d4b41567247694139475a71685150347969355052414a77474773307435724944524f49505959664b4c6671487061343933773174684a494136494a3144494247767377585761716e6d4b4f64566447514756656d4b54327673355942486b374c316d4b7065654d4531464d31366f352b223b6d656d6265725f696e666f7c613a323a7b733a393a226d656d6265725f6e6f223b733a383a223230323030303031223b733a353a22656d61696c223b733a31393a226d756e6b2e676f726e40676d61696c2e636f6d223b7d796561727c733a343a2232303230223b),
('922b300e7887d68b1ab19be70931daebabb539c8', '::1', 1612423611, 0x5f5f63695f6c6173745f726567656e65726174657c693a313631323432333631313b6d656d6265725f696e666f7c613a323a7b733a393a226d656d6265725f6e6f223b733a383a223230323030303031223b733a353a22656d61696c223b733a31393a226d756e6b2e676f726e40676d61696c2e636f6d223b7d796561727c733a343a2232303230223b),
('de75064f963b6db6b3caf43ebb197337b5971876', '::1', 1612425361, 0x5f5f63695f6c6173745f726567656e65726174657c693a313631323432353336313b6d656d6265725f696e666f7c613a323a7b733a393a226d656d6265725f6e6f223b733a383a223230323030303031223b733a353a22656d61696c223b733a31393a226d756e6b2e676f726e40676d61696c2e636f6d223b7d796561727c733a343a2232303230223b),
('789a2ea227bc3bb4336a79fa6bf6f9930d9c682d', '::1', 1612427015, 0x5f5f63695f6c6173745f726567656e65726174657c693a313631323432373031353b6d656d6265725f696e666f7c613a323a7b733a393a226d656d6265725f6e6f223b733a383a223230323030303031223b733a353a22656d61696c223b733a31393a226d756e6b2e676f726e40676d61696c2e636f6d223b7d796561727c733a343a2232303230223b),
('45f8dff2a4e873bce53276ede50f0f618aa59ec8', '::1', 1612428474, 0x5f5f63695f6c6173745f726567656e65726174657c693a313631323432383437343b6d656d6265725f696e666f7c613a323a7b733a393a226d656d6265725f6e6f223b733a383a223230323030303031223b733a353a22656d61696c223b733a31393a226d756e6b2e676f726e40676d61696c2e636f6d223b7d796561727c733a343a2232303230223b),
('5f59a5f5794f643eac8b1c69b1c136ab566ec66f', '::1', 1612428743, 0x5f5f63695f6c6173745f726567656e65726174657c693a313631323432383437343b6d656d6265725f696e666f7c613a323a7b733a393a226d656d6265725f6e6f223b733a383a223230323030303031223b733a353a22656d61696c223b733a31393a226d756e6b2e676f726e40676d61696c2e636f6d223b7d796561727c733a343a2232303230223b),
('428857e4fed626e4a7ff2d2ba4eab890e442d60d', '::1', 1612508334, 0x5f5f63695f6c6173745f726567656e65726174657c693a313631323530383333343b746f6b656e7c733a3537363a2264346263303939623861333539663761303539336464366533333236396264376238646535373763326163363435303230613765333138646232393638663461653537363138343465303132656364643933396564346661633562333532653664323137623465633766396137383834313363386137653130653735366436342b664c506c3356335a773453595235796b777230574877374d70333263476c39565031457875732f6136374a76326e636377706b6f59612f6158645630304156444c6561704971646762595761394161543356676e773149653076386e47364d4b6a737a654562746f6670445043585a5846316b774344466c76734d5739446250325678704e76354a6b3051474d783077584d4d73785536334e626158325a7668742b4f77375a4673482f7a716d41344e4f76617072666b666734346a5746776467776e6541344b4e506b346159797376564c584743674636633975626e4e48797a31553435346b48477168736c493350484d6577786b4857694c38414e6a2b6463526f732f4c54426b6278784b30624649566e6d78774753514d6a614b4266732b367352486a2b4a73554c61565247694a395a354a5147456a6a64706e574a4c7569556462466d394976314579444c6469344638494f6e733939447a4a49365a4364646679455a4a387379514869456b4770692b50485170487763682b784238516f787556613633475235563078364c4e7930496872496b6a6d626e524d636d692b44546145792f48305a56736b4a35594d753168774c5a39734763447550223b6d656d6265725f696e666f7c613a323a7b733a393a226d656d6265725f6e6f223b733a383a223230323030303031223b733a353a22656d61696c223b733a31393a226d756e6b2e676f726e40676d61696c2e636f6d223b7d796561727c733a343a2232303230223b),
('34b4809536149a3e126071816e70964f82e2204e', '::1', 1612508675, 0x5f5f63695f6c6173745f726567656e65726174657c693a313631323530383637353b746f6b656e7c733a3537363a2264346263303939623861333539663761303539336464366533333236396264376238646535373763326163363435303230613765333138646232393638663461653537363138343465303132656364643933396564346661633562333532653664323137623465633766396137383834313363386137653130653735366436342b664c506c3356335a773453595235796b777230574877374d70333263476c39565031457875732f6136374a76326e636377706b6f59612f6158645630304156444c6561704971646762595761394161543356676e773149653076386e47364d4b6a737a654562746f6670445043585a5846316b774344466c76734d5739446250325678704e76354a6b3051474d783077584d4d73785536334e626158325a7668742b4f77375a4673482f7a716d41344e4f76617072666b666734346a5746776467776e6541344b4e506b346159797376564c584743674636633975626e4e48797a31553435346b48477168736c493350484d6577786b4857694c38414e6a2b6463526f732f4c54426b6278784b30624649566e6d78774753514d6a614b4266732b367352486a2b4a73554c61565247694a395a354a5147456a6a64706e574a4c7569556462466d394976314579444c6469344638494f6e733939447a4a49365a4364646679455a4a387379514869456b4770692b50485170487763682b784238516f787556613633475235563078364c4e7930496872496b6a6d626e524d636d692b44546145792f48305a56736b4a35594d753168774c5a39734763447550223b6d656d6265725f696e666f7c613a323a7b733a393a226d656d6265725f6e6f223b733a383a223230323030303031223b733a353a22656d61696c223b733a31393a226d756e6b2e676f726e40676d61696c2e636f6d223b7d796561727c733a343a2232303230223b);
INSERT INTO `mhd_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES
('d733659995c7eb22ca5b55c20fd5cf776ca40e85', '::1', 1612509032, 0x5f5f63695f6c6173745f726567656e65726174657c693a313631323530393033323b746f6b656e7c733a3537363a2264346263303939623861333539663761303539336464366533333236396264376238646535373763326163363435303230613765333138646232393638663461653537363138343465303132656364643933396564346661633562333532653664323137623465633766396137383834313363386137653130653735366436342b664c506c3356335a773453595235796b777230574877374d70333263476c39565031457875732f6136374a76326e636377706b6f59612f6158645630304156444c6561704971646762595761394161543356676e773149653076386e47364d4b6a737a654562746f6670445043585a5846316b774344466c76734d5739446250325678704e76354a6b3051474d783077584d4d73785536334e626158325a7668742b4f77375a4673482f7a716d41344e4f76617072666b666734346a5746776467776e6541344b4e506b346159797376564c584743674636633975626e4e48797a31553435346b48477168736c493350484d6577786b4857694c38414e6a2b6463526f732f4c54426b6278784b30624649566e6d78774753514d6a614b4266732b367352486a2b4a73554c61565247694a395a354a5147456a6a64706e574a4c7569556462466d394976314579444c6469344638494f6e733939447a4a49365a4364646679455a4a387379514869456b4770692b50485170487763682b784238516f787556613633475235563078364c4e7930496872496b6a6d626e524d636d692b44546145792f48305a56736b4a35594d753168774c5a39734763447550223b6d656d6265725f696e666f7c613a323a7b733a393a226d656d6265725f6e6f223b733a383a223230323030303031223b733a353a22656d61696c223b733a31393a226d756e6b2e676f726e40676d61696c2e636f6d223b7d796561727c733a343a2232303230223b),
('bbfe88ff8e0b59c82b393173350907e3173f9ac6', '::1', 1612509471, 0x5f5f63695f6c6173745f726567656e65726174657c693a313631323530393437313b746f6b656e7c733a3537363a2264346263303939623861333539663761303539336464366533333236396264376238646535373763326163363435303230613765333138646232393638663461653537363138343465303132656364643933396564346661633562333532653664323137623465633766396137383834313363386137653130653735366436342b664c506c3356335a773453595235796b777230574877374d70333263476c39565031457875732f6136374a76326e636377706b6f59612f6158645630304156444c6561704971646762595761394161543356676e773149653076386e47364d4b6a737a654562746f6670445043585a5846316b774344466c76734d5739446250325678704e76354a6b3051474d783077584d4d73785536334e626158325a7668742b4f77375a4673482f7a716d41344e4f76617072666b666734346a5746776467776e6541344b4e506b346159797376564c584743674636633975626e4e48797a31553435346b48477168736c493350484d6577786b4857694c38414e6a2b6463526f732f4c54426b6278784b30624649566e6d78774753514d6a614b4266732b367352486a2b4a73554c61565247694a395a354a5147456a6a64706e574a4c7569556462466d394976314579444c6469344638494f6e733939447a4a49365a4364646679455a4a387379514869456b4770692b50485170487763682b784238516f787556613633475235563078364c4e7930496872496b6a6d626e524d636d692b44546145792f48305a56736b4a35594d753168774c5a39734763447550223b6d656d6265725f696e666f7c613a323a7b733a393a226d656d6265725f6e6f223b733a383a223230323030303031223b733a353a22656d61696c223b733a31393a226d756e6b2e676f726e40676d61696c2e636f6d223b7d796561727c733a343a2232303230223b),
('9c14028c971af4aefbc49fe9d09457aaff574d5d', '::1', 1612509618, 0x5f5f63695f6c6173745f726567656e65726174657c693a313631323530393437313b746f6b656e7c733a3537363a2264346263303939623861333539663761303539336464366533333236396264376238646535373763326163363435303230613765333138646232393638663461653537363138343465303132656364643933396564346661633562333532653664323137623465633766396137383834313363386137653130653735366436342b664c506c3356335a773453595235796b777230574877374d70333263476c39565031457875732f6136374a76326e636377706b6f59612f6158645630304156444c6561704971646762595761394161543356676e773149653076386e47364d4b6a737a654562746f6670445043585a5846316b774344466c76734d5739446250325678704e76354a6b3051474d783077584d4d73785536334e626158325a7668742b4f77375a4673482f7a716d41344e4f76617072666b666734346a5746776467776e6541344b4e506b346159797376564c584743674636633975626e4e48797a31553435346b48477168736c493350484d6577786b4857694c38414e6a2b6463526f732f4c54426b6278784b30624649566e6d78774753514d6a614b4266732b367352486a2b4a73554c61565247694a395a354a5147456a6a64706e574a4c7569556462466d394976314579444c6469344638494f6e733939447a4a49365a4364646679455a4a387379514869456b4770692b50485170487763682b784238516f787556613633475235563078364c4e7930496872496b6a6d626e524d636d692b44546145792f48305a56736b4a35594d753168774c5a39734763447550223b6d656d6265725f696e666f7c613a323a7b733a393a226d656d6265725f6e6f223b733a383a223230323030303031223b733a353a22656d61696c223b733a31393a226d756e6b2e676f726e40676d61696c2e636f6d223b7d796561727c733a343a2232303230223b),
('4acea32b83ba11c43188d068a7bfe136893ebfa1', '::1', 1612766834, 0x5f5f63695f6c6173745f726567656e65726174657c693a313631323736363833343b61646d696e5f746f6b656e7c733a3336343a22323938373730333964366537333034363732623835376563623030363565373438383838323162333132313039616538623761643262393633636464396234373531623639363463663232373266343731306634653735336633333032633436373333386433336164393038616233376230613162653030663739663566633632534e2f3454566f736b3338554c41313166555743376f45694e7a512f34626463386f7a386a6e393172616c32627844504d694958744374504d646d54356a345a647368504d68754e78445469673044655a653057444b743336524c345a31662b596847754c433377497a5a4a373671717577316c7270355a387251307156324f5466413979324d3463706165636949494e365a6d2b6f327733556b504974354e75584f6d734c364556724e44656f554c51436541774d7276655451546b6a5953484867506f2f31616c52535541394e6f486c476a692f71694578782b2b742f4269354c6c4976785162343d223b61646d696e5f696e666f7c613a313a7b733a383a22757365726e616d65223b733a353a2261646d696e223b7d61646d696e5f72656769737465727c733a36343a223c7370616e20636c6173733d2262616467652062616467652d73756363657373207269676874223ee0b980e0b89be0b8b4e0b89420323032303c2f7370616e3e223b),
('3620bd0e1f446462bb242b741bb97211bcbef80d', '::1', 1612767590, 0x5f5f63695f6c6173745f726567656e65726174657c693a313631323736373539303b61646d696e5f746f6b656e7c733a3336343a22323938373730333964366537333034363732623835376563623030363565373438383838323162333132313039616538623761643262393633636464396234373531623639363463663232373266343731306634653735336633333032633436373333386433336164393038616233376230613162653030663739663566633632534e2f3454566f736b3338554c41313166555743376f45694e7a512f34626463386f7a386a6e393172616c32627844504d694958744374504d646d54356a345a647368504d68754e78445469673044655a653057444b743336524c345a31662b596847754c433377497a5a4a373671717577316c7270355a387251307156324f5466413979324d3463706165636949494e365a6d2b6f327733556b504974354e75584f6d734c364556724e44656f554c51436541774d7276655451546b6a5953484867506f2f31616c52535541394e6f486c476a692f71694578782b2b742f4269354c6c4976785162343d223b61646d696e5f696e666f7c613a313a7b733a383a22757365726e616d65223b733a353a2261646d696e223b7d61646d696e5f72656769737465727c733a36343a223c7370616e20636c6173733d2262616467652062616467652d73756363657373207269676874223ee0b980e0b89be0b8b4e0b89420323032303c2f7370616e3e223b),
('7ef2a481242dfcbacc358ee755f2d796d85d1887', '::1', 1612771134, 0x5f5f63695f6c6173745f726567656e65726174657c693a313631323737313133343b61646d696e5f746f6b656e7c733a3336343a22323938373730333964366537333034363732623835376563623030363565373438383838323162333132313039616538623761643262393633636464396234373531623639363463663232373266343731306634653735336633333032633436373333386433336164393038616233376230613162653030663739663566633632534e2f3454566f736b3338554c41313166555743376f45694e7a512f34626463386f7a386a6e393172616c32627844504d694958744374504d646d54356a345a647368504d68754e78445469673044655a653057444b743336524c345a31662b596847754c433377497a5a4a373671717577316c7270355a387251307156324f5466413979324d3463706165636949494e365a6d2b6f327733556b504974354e75584f6d734c364556724e44656f554c51436541774d7276655451546b6a5953484867506f2f31616c52535541394e6f486c476a692f71694578782b2b742f4269354c6c4976785162343d223b61646d696e5f696e666f7c613a313a7b733a383a22757365726e616d65223b733a353a2261646d696e223b7d61646d696e5f72656769737465727c733a36343a223c7370616e20636c6173733d2262616467652062616467652d73756363657373207269676874223ee0b980e0b89be0b8b4e0b89420323032303c2f7370616e3e223b),
('998f69e87fe506dcf6c38b1cdcc3ea2ab463ea3e', '::1', 1612771506, 0x5f5f63695f6c6173745f726567656e65726174657c693a313631323737313530363b61646d696e5f746f6b656e7c733a3336343a22323938373730333964366537333034363732623835376563623030363565373438383838323162333132313039616538623761643262393633636464396234373531623639363463663232373266343731306634653735336633333032633436373333386433336164393038616233376230613162653030663739663566633632534e2f3454566f736b3338554c41313166555743376f45694e7a512f34626463386f7a386a6e393172616c32627844504d694958744374504d646d54356a345a647368504d68754e78445469673044655a653057444b743336524c345a31662b596847754c433377497a5a4a373671717577316c7270355a387251307156324f5466413979324d3463706165636949494e365a6d2b6f327733556b504974354e75584f6d734c364556724e44656f554c51436541774d7276655451546b6a5953484867506f2f31616c52535541394e6f486c476a692f71694578782b2b742f4269354c6c4976785162343d223b61646d696e5f696e666f7c613a313a7b733a383a22757365726e616d65223b733a353a2261646d696e223b7d61646d696e5f72656769737465727c733a36343a223c7370616e20636c6173733d2262616467652062616467652d73756363657373207269676874223ee0b980e0b89be0b8b4e0b89420323032303c2f7370616e3e223b),
('8ac4dd8c91028a4a6bed9eb739ef55e144f4b670', '::1', 1612776366, 0x5f5f63695f6c6173745f726567656e65726174657c693a313631323737363336363b61646d696e5f746f6b656e7c733a3336343a22323938373730333964366537333034363732623835376563623030363565373438383838323162333132313039616538623761643262393633636464396234373531623639363463663232373266343731306634653735336633333032633436373333386433336164393038616233376230613162653030663739663566633632534e2f3454566f736b3338554c41313166555743376f45694e7a512f34626463386f7a386a6e393172616c32627844504d694958744374504d646d54356a345a647368504d68754e78445469673044655a653057444b743336524c345a31662b596847754c433377497a5a4a373671717577316c7270355a387251307156324f5466413979324d3463706165636949494e365a6d2b6f327733556b504974354e75584f6d734c364556724e44656f554c51436541774d7276655451546b6a5953484867506f2f31616c52535541394e6f486c476a692f71694578782b2b742f4269354c6c4976785162343d223b61646d696e5f696e666f7c613a313a7b733a383a22757365726e616d65223b733a353a2261646d696e223b7d61646d696e5f72656769737465727c733a36343a223c7370616e20636c6173733d2262616467652062616467652d73756363657373207269676874223ee0b980e0b89be0b8b4e0b89420323032303c2f7370616e3e223b),
('068774e17de543e55fcbb7b45f42e8e5fb0aaeb5', '::1', 1612776673, 0x5f5f63695f6c6173745f726567656e65726174657c693a313631323737363637333b61646d696e5f746f6b656e7c733a3336343a223737346361343364656336386537323832323037653330323961353363393637346338613136316666386532343263323662356134623533376266666436663636346433336132323063623833326533616663373833313038626330393461643431363962633739333038326634316438663138623037353162653732316235336d5644704561416533794773594f32696a43455772766d6778644179704b78612b33626272786a6f46515a73674f543167466150794543563773364d595a597072567573305a67326d6c3855746a31696b6562615953387a51654e38474f3778457337694a622b7674365a566d3330326277656347343267416b714e53464a64793848416a666d53626749597963446446795871566b6e3058494e67727767636c4e716754507a444b5363316379455a6c73443935592f37324f7474364d6f7168656639676f2f674372772b6f654f31314d76684d43394c51346863613543597a544237635a4c6538413d223b61646d696e5f696e666f7c613a313a7b733a383a22757365726e616d65223b733a353a2261646d696e223b7d61646d696e5f72656769737465727c733a36343a223c7370616e20636c6173733d2262616467652062616467652d73756363657373207269676874223ee0b980e0b89be0b8b4e0b89420323032303c2f7370616e3e223b),
('e4a332348c90d87a87542212746242650479656a', '::1', 1612781215, 0x5f5f63695f6c6173745f726567656e65726174657c693a313631323738313231353b61646d696e5f746f6b656e7c733a3336343a223737346361343364656336386537323832323037653330323961353363393637346338613136316666386532343263323662356134623533376266666436663636346433336132323063623833326533616663373833313038626330393461643431363962633739333038326634316438663138623037353162653732316235336d5644704561416533794773594f32696a43455772766d6778644179704b78612b33626272786a6f46515a73674f543167466150794543563773364d595a597072567573305a67326d6c3855746a31696b6562615953387a51654e38474f3778457337694a622b7674365a566d3330326277656347343267416b714e53464a64793848416a666d53626749597963446446795871566b6e3058494e67727767636c4e716754507a444b5363316379455a6c73443935592f37324f7474364d6f7168656639676f2f674372772b6f654f31314d76684d43394c51346863613543597a544237635a4c6538413d223b61646d696e5f696e666f7c613a313a7b733a383a22757365726e616d65223b733a353a2261646d696e223b7d61646d696e5f72656769737465727c733a36343a223c7370616e20636c6173733d2262616467652062616467652d73756363657373207269676874223ee0b980e0b89be0b8b4e0b89420323032303c2f7370616e3e223b),
('22ef4746aee4775fb99cd20a357440a6e759fd35', '::1', 1612781215, 0x5f5f63695f6c6173745f726567656e65726174657c693a313631323738313231353b61646d696e5f746f6b656e7c733a3336343a223737346361343364656336386537323832323037653330323961353363393637346338613136316666386532343263323662356134623533376266666436663636346433336132323063623833326533616663373833313038626330393461643431363962633739333038326634316438663138623037353162653732316235336d5644704561416533794773594f32696a43455772766d6778644179704b78612b33626272786a6f46515a73674f543167466150794543563773364d595a597072567573305a67326d6c3855746a31696b6562615953387a51654e38474f3778457337694a622b7674365a566d3330326277656347343267416b714e53464a64793848416a666d53626749597963446446795871566b6e3058494e67727767636c4e716754507a444b5363316379455a6c73443935592f37324f7474364d6f7168656639676f2f674372772b6f654f31314d76684d43394c51346863613543597a544237635a4c6538413d223b61646d696e5f696e666f7c613a313a7b733a383a22757365726e616d65223b733a353a2261646d696e223b7d61646d696e5f72656769737465727c733a36343a223c7370616e20636c6173733d2262616467652062616467652d73756363657373207269676874223ee0b980e0b89be0b8b4e0b89420323032303c2f7370616e3e223b);

-- --------------------------------------------------------

--
-- Table structure for table `mhd_setting`
--

CREATE TABLE `mhd_setting` (
  `id` int(11) NOT NULL,
  `key` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `value` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `mhd_setting`
--

INSERT INTO `mhd_setting` (`id`, `key`, `value`) VALUES
(1, 'config_register_year_id', '1'),
(2, 'config_register_open', '1');

-- --------------------------------------------------------

--
-- Table structure for table `mhd_year`
--

CREATE TABLE `mhd_year` (
  `id` int(11) NOT NULL,
  `admin_id` int(11) DEFAULT NULL,
  `year` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_added` datetime DEFAULT NULL,
  `date_modify` datetime DEFAULT NULL,
  `del` int(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `mhd_year`
--

INSERT INTO `mhd_year` (`id`, `admin_id`, `year`, `date_added`, `date_modify`, `del`) VALUES
(1, 1, '2020', NULL, NULL, 0),
(2, 1, '2021', NULL, NULL, 0),
(3, 1, '202222', NULL, '2020-09-15 11:56:42', 1),
(4, NULL, '2022', '2021-01-20 14:19:00', NULL, 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `md_tools`
--
ALTER TABLE `md_tools`
  ADD PRIMARY KEY (`id`) USING BTREE;

--
-- Indexes for table `mhd_admin`
--
ALTER TABLE `mhd_admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `mhd_company`
--
ALTER TABLE `mhd_company`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `mhd_content`
--
ALTER TABLE `mhd_content`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `mhd_content_cat`
--
ALTER TABLE `mhd_content_cat`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `mhd_content_pic`
--
ALTER TABLE `mhd_content_pic`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `mhd_language`
--
ALTER TABLE `mhd_language`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `mhd_language_detail`
--
ALTER TABLE `mhd_language_detail`
  ADD PRIMARY KEY (`id`),
  ADD KEY `language_id` (`language_id`) COMMENT '(null)';

--
-- Indexes for table `mhd_member`
--
ALTER TABLE `mhd_member`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `mhd_payment`
--
ALTER TABLE `mhd_payment`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `mhd_program`
--
ALTER TABLE `mhd_program`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `mhd_program_infection`
--
ALTER TABLE `mhd_program_infection`
  ADD PRIMARY KEY (`id`) USING BTREE;

--
-- Indexes for table `mhd_program_infection_backup`
--
ALTER TABLE `mhd_program_infection_backup`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `mhd_program_principle`
--
ALTER TABLE `mhd_program_principle`
  ADD PRIMARY KEY (`id`) USING BTREE;

--
-- Indexes for table `mhd_program_tools`
--
ALTER TABLE `mhd_program_tools`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `mhd_program_trial`
--
ALTER TABLE `mhd_program_trial`
  ADD PRIMARY KEY (`id`) USING BTREE;

--
-- Indexes for table `mhd_program_trial_specimen`
--
ALTER TABLE `mhd_program_trial_specimen`
  ADD PRIMARY KEY (`id`) USING BTREE;

--
-- Indexes for table `mhd_register`
--
ALTER TABLE `mhd_register`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `mhd_register_program`
--
ALTER TABLE `mhd_register_program`
  ADD PRIMARY KEY (`id`),
  ADD KEY `register_id` (`register_id`);

--
-- Indexes for table `mhd_report`
--
ALTER TABLE `mhd_report`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `mhd_sessions`
--
ALTER TABLE `mhd_sessions`
  ADD KEY `ci_sessions_timestamp` (`timestamp`);

--
-- Indexes for table `mhd_setting`
--
ALTER TABLE `mhd_setting`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `mhd_year`
--
ALTER TABLE `mhd_year`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `md_tools`
--
ALTER TABLE `md_tools`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=516;

--
-- AUTO_INCREMENT for table `mhd_admin`
--
ALTER TABLE `mhd_admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `mhd_company`
--
ALTER TABLE `mhd_company`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `mhd_content`
--
ALTER TABLE `mhd_content`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=186;

--
-- AUTO_INCREMENT for table `mhd_content_cat`
--
ALTER TABLE `mhd_content_cat`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=84;

--
-- AUTO_INCREMENT for table `mhd_content_pic`
--
ALTER TABLE `mhd_content_pic`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=166;

--
-- AUTO_INCREMENT for table `mhd_language`
--
ALTER TABLE `mhd_language`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `mhd_language_detail`
--
ALTER TABLE `mhd_language_detail`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=269;

--
-- AUTO_INCREMENT for table `mhd_member`
--
ALTER TABLE `mhd_member`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `mhd_payment`
--
ALTER TABLE `mhd_payment`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `mhd_program`
--
ALTER TABLE `mhd_program`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `mhd_program_infection`
--
ALTER TABLE `mhd_program_infection`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=532;

--
-- AUTO_INCREMENT for table `mhd_program_infection_backup`
--
ALTER TABLE `mhd_program_infection_backup`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=532;

--
-- AUTO_INCREMENT for table `mhd_program_principle`
--
ALTER TABLE `mhd_program_principle`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `mhd_program_tools`
--
ALTER TABLE `mhd_program_tools`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=509;

--
-- AUTO_INCREMENT for table `mhd_program_trial`
--
ALTER TABLE `mhd_program_trial`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=207;

--
-- AUTO_INCREMENT for table `mhd_program_trial_specimen`
--
ALTER TABLE `mhd_program_trial_specimen`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=335;

--
-- AUTO_INCREMENT for table `mhd_register`
--
ALTER TABLE `mhd_register`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `mhd_register_program`
--
ALTER TABLE `mhd_register_program`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `mhd_report`
--
ALTER TABLE `mhd_report`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `mhd_setting`
--
ALTER TABLE `mhd_setting`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `mhd_year`
--
ALTER TABLE `mhd_year`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `mhd_language_detail`
--
ALTER TABLE `mhd_language_detail`
  ADD CONSTRAINT `mhd_language_detail_ibfk_1` FOREIGN KEY (`language_id`) REFERENCES `mhd_language` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
